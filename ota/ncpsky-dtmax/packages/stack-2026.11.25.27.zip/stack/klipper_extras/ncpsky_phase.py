# Active coil-current cancellation for the three delta towers.
#
# The MCU streams a sine into TMC2160 XDIRECT and keeps following the
# step count, so G28 and normal moves still work. This module only
# measures the 4th electrical harmonic (full-step hum) and stores the
# amplitude that actually reduced it. With no saved profile the machine
# stays on ordinary step/dir StealthChop.
import json
import logging
import math
import os

TOWERS = ("stepper_a", "stepper_b", "stepper_c")
AMPS = (8, 16)
IMPROVE = 0.90
RUN_SCALE = 240


class NcpskyPhase:
    def __init__(self, config):
        self.printer = config.get_printer()
        self.gcode = self.printer.lookup_object("gcode")
        self.profile_path = config.get(
            "profile", "/home/pi/printer_data/config/ncpsky_phase.json")
        self.names = list(TOWERS)
        self.supported = False
        self.suspend_apply = False
        self.direct = {}
        self.align = {}
        self.setup_cmd = None
        self.tune_cmd = None
        self.query_cmd = {}
        self.steppers = {}
        self.meta = {}
        for name in self.names:
            tmc_cfg = config.getsection("tmc5160 " + name)
            step_cfg = config.getsection(name)
            micro = step_cfg.getint("microsteps", 64, minval=1)
            run_i = tmc_cfg.getfloat("run_current", above=0.)
            hold_i = tmc_cfg.getfloat("hold_current", run_i, above=0.)
            hold_scale = int(round(255.0 * hold_i / run_i))
            if hold_scale < 1:
                hold_scale = 1
            if hold_scale > 200:
                hold_scale = 200
            self.meta[name] = {
                "cs": tmc_cfg.get("cs_pin"),
                "sclk": tmc_cfg.get("spi_software_sclk_pin"),
                "mosi": tmc_cfg.get("spi_software_mosi_pin"),
                "steps": micro * 4,
                "hold_scale": hold_scale,
                "run_current": run_i,
                "hold_current": hold_i,
            }
            self.direct[name] = False
            self.align[name] = 0
        self.gcode.register_command(
            "NCPSKY_PHASE_APPLY", self.cmd_APPLY,
            desc="Apply saved coil-harmonic cancellation if the MCU supports it")
        self.gcode.register_command(
            "NCPSKY_PHASE_CALIBRATE", self.cmd_CALIBRATE,
            desc="Sweep the head and search a quieter coil waveform")
        self.printer.register_event_handler("klippy:connect", self._connect)

    def _connect(self):
        mcu = self.printer.lookup_object("mcu")
        setup = mcu.try_lookup_command(
            "ncpsky_xdirect_setup oid=%c cs_pin=%u sclk_pin=%u mosi_pin=%u"
            " steps_per_elec=%hu hold_scale=%c")
        tune = mcu.try_lookup_command(
            "ncpsky_xdirect_tune oid=%c enable=%c amp1=%c phase1=%c"
            " amp4=%c phase4=%c align=%c")
        if setup is None or tune is None:
            logging.info("ncpsky_phase: MCU has no xdirect, step/dir stays")
            return
        force_move = self.printer.lookup_object("force_move")
        try:
            query_fmt = "ncpsky_xdirect_query oid=%c"
            resp_fmt = "ncpsky_xdirect_state oid=%c enabled=%c align=%c"
            for name in self.names:
                stepper = force_move.lookup_stepper(name)
                self.steppers[name] = stepper
                self.query_cmd[name] = mcu.lookup_query_command(
                    query_fmt, resp_fmt, oid=stepper.get_oid())
        except Exception:
            logging.exception("ncpsky_phase: stepper lookup failed")
            return
        self.setup_cmd = setup
        self.tune_cmd = tune
        self.supported = True
        logging.info("ncpsky_phase: xdirect ready")

    def cmd_APPLY(self, gcmd):
        if not self.supported:
            return
        # G28 drops hold current back to the quiet value. While a calibration
        # owns the waveform, only put the hold current back to the run current
        # so the direct-mode home still has torque.
        if self.suspend_apply:
            try:
                for name in self.names:
                    if self.direct.get(name) or self._sync_mcu_state(name):
                        self._set_ihold_run(name)
            except self.printer.command_error as e:
                logging.info("ncpsky_phase hold refresh skipped: %s", e)
            return
        profile = self._load()
        if not self._any_amp(profile):
            return
        try:
            self._apply_profile(profile, enter=True)
        except self.printer.command_error as e:
            gcmd.respond_info("NCPSKY phase: 未启用 (%s)" % (e,))

    def cmd_CALIBRATE(self, gcmd):
        if not self.supported:
            raise gcmd.error("相位校准需要先在面板里确认刷写 MCU，当前芯片还是纯步进")
        toolhead = self.printer.lookup_object("toolhead")
        kin = toolhead.get_kinematics()
        if not hasattr(kin, "towers") or not hasattr(kin, "arm2"):
            raise gcmd.error("相位校准只用于这台三角洲")
        status = toolhead.get_status(self.printer.get_reactor().monotonic())
        saved_v = status["max_velocity"]
        saved_a = status["max_accel"]
        saved_mcr = status.get("minimum_cruise_ratio", 0.5)
        self.suspend_apply = True
        result = self._empty_profile()
        finished = False
        try:
            self.gcode.run_script_from_command("_NCPSKY_TOWER_CHOPPER")
            self.gcode.run_script_from_command(
                "AUTOTUNE_TMC STEPPER=extruder TUNING_GOAL=silent")
            self.gcode.run_script_from_command("G28")
            self._require_homed()
            self.gcode.run_script_from_command(
                "SET_VELOCITY_LIMIT VELOCITY=80 ACCEL=1500 MINIMUM_CRUISE_RATIO=0.3")
            self._enter_all(self._empty_profile())
            # The enable can shift the rotor by a fraction of a step.
            self.gcode.run_script_from_command("G28")
            self._require_homed()
            self._move_xy(0., 0., 80., 80.)
            result = self._search(gcmd)
            if self._any_amp(result):
                self._apply_profile(result, enter=False)
            else:
                self._leave_direct()
            self._save(result)
            finished = True
        except Exception:
            logging.exception("ncpsky_phase calibrate failed")
            try:
                self._leave_direct()
            except Exception:
                logging.exception("ncpsky_phase failed to leave direct mode")
            try:
                self.gcode.run_script_from_command("G28")
            except Exception:
                logging.exception("ncpsky_phase rehome after failure failed")
            raise
        finally:
            self.suspend_apply = False
            self.gcode.run_script_from_command(
                "SET_VELOCITY_LIMIT VELOCITY=%.4f ACCEL=%.4f MINIMUM_CRUISE_RATIO=%.4f"
                % (saved_v, saved_a, saved_mcr))
        if finished:
            self.gcode.run_script_from_command("G28")
        if self._any_amp(result):
            gcmd.respond_info("NCPSKY phase: 校准完成，归零后按这组波形运行")
        else:
            gcmd.respond_info("NCPSKY phase: 没有更安静的波形，已回到原来的步进")

    def _require_homed(self):
        toolhead = self.printer.lookup_object("toolhead")
        axes = toolhead.get_status(self.printer.get_reactor().monotonic())["homed_axes"]
        if "x" not in axes or "y" not in axes or "z" not in axes:
            raise self.printer.command_error("归零未完成，相位校准已停下")

    def _tmc(self, name):
        return self.printer.lookup_object("tmc5160 " + name)

    def _pin_name(self, pin_desc):
        # cs_pin=%u is still a pin enumeration: the host sends the name
        # and the protocol turns it into the MCU pin id.
        name = pin_desc.strip()
        if name[:1] in ("!", "^", "~"):
            name = name[1:].strip()
        if ":" in name:
            name = name.split(":", 1)[1].strip()
        mcu = self.printer.lookup_object("mcu")
        enums = mcu.get_enumerations().get("pin", {})
        if name not in enums:
            raise self.printer.command_error("找不到引脚 %s" % (name,))
        return name

    def _reported_position(self, stepper, cmd_pos=None):
        host = stepper.get_mcu_position(cmd_pos)
        if stepper.get_dir_inverted()[0]:
            return -host
        return host

    def _mscnt_for_raw(self, name, raw_mscnt):
        # Klipper flips MSCNT when the dir pin is not inverted so the phase
        # follows the host position. The MCU counter is that host position
        # with the invert undone, and for both invert states that matches
        # (1023 - mscnt).
        del name
        return (1023 - (int(raw_mscnt) & 0x3ff)) & 0x3ff

    def _read_mscnt(self, name):
        tmc = self._tmc(name)
        reg = tmc.fields.lookup_register("mscnt")
        val = tmc.mcu_tmc.get_register(reg)
        if hasattr(tmc.fields, "get_field"):
            try:
                return int(tmc.fields.get_field("mscnt", val))
            except Exception:
                pass
        return int(val) & 0x3ff

    def _set_field(self, name, field, value):
        tmc = self._tmc(name)
        reg = tmc.fields.lookup_register(field)
        val = tmc.fields.set_field(field, value)
        tmc.mcu_tmc.set_register(reg, val, None)

    def _set_ihold_run(self, name):
        tmc = self._tmc(name)
        irun = int(tmc.fields.get_field("irun") or 0)
        if irun <= 0:
            return
        self._set_field(name, "ihold", irun)

    def _setup_motor(self, name):
        meta = self.meta[name]
        oid = self.steppers[name].get_oid()
        self.setup_cmd.send([
            oid,
            self._pin_name(meta["cs"]),
            self._pin_name(meta["sclk"]),
            self._pin_name(meta["mosi"]),
            meta["steps"],
            meta["hold_scale"],
        ])

    def _send_tune(self, name, spec, enable):
        oid = self.steppers[name].get_oid()
        self.tune_cmd.send([
            oid,
            1 if enable else 0,
            int(spec.get("amp1", 0)) & 255,
            int(spec.get("phase1", 0)) & 255,
            int(spec.get("amp4", 0)) & 255,
            int(spec.get("phase4", 0)) & 255,
            int(self.align.get(name, 0)) & 255,
        ])

    def _sync_mcu_state(self, name):
        oid = self.steppers[name].get_oid()
        state = self.query_cmd[name].send([oid])
        if int(state.get("enabled", 0)):
            self.direct[name] = True
            self.align[name] = int(state.get("align", 0)) & 255
            return True
        return False

    def _enter_one(self, name, spec):
        self._setup_motor(name)
        if self._sync_mcu_state(name):
            self._set_ihold_run(name)
            self._set_field(name, "direct_mode", 1)
            self._send_tune(name, spec, True)
            return
        self.gcode.run_script_from_command(
            "SET_STEPPER_ENABLE STEPPER=%s ENABLE=1" % (name,))
        toolhead = self.printer.lookup_object("toolhead")
        toolhead.dwell(0.1)
        raw = self._read_mscnt(name)
        matched = self._mscnt_for_raw(name, raw)
        mscnt_angle = (matched * 256) // 1024
        pos = self._reported_position(self.steppers[name])
        period = self.meta[name]["steps"]
        mod = pos % period
        if mod < 0:
            mod += period
        pos_angle = (mod * 256) // period
        self.align[name] = (mscnt_angle - pos_angle) & 255
        self._set_ihold_run(name)
        # Arm the sine first, then switch the chip off the step sequencer
        # so the coil current is already the matching angle.
        self._send_tune(name, spec, True)
        self._set_field(name, "direct_mode", 1)
        self.direct[name] = True
        logging.info("ncpsky_phase %s align=%s mscnt=%s pos=%s",
                     name, self.align[name], raw, pos)

    def _enter_all(self, profile):
        for name in self.names:
            self._enter_one(name, profile.get(name) or {})

    def _apply_profile(self, profile, enter):
        for name in self.names:
            spec = profile.get(name) or {}
            if enter or not self.direct.get(name):
                self._enter_one(name, spec)
            else:
                self._set_ihold_run(name)
                self._set_field(name, "direct_mode", 1)
                self._send_tune(name, spec, True)

    def _leave_direct(self):
        blank = {}
        for name in self.names:
            if not self.direct.get(name):
                self._sync_mcu_state(name)
            if not self.direct.get(name):
                continue
            self._send_tune(name, blank, False)
            self._set_field(name, "direct_mode", 0)
            self.direct[name] = False
        lines = []
        for name in self.names:
            meta = self.meta[name]
            lines.append(
                "SET_TMC_CURRENT STEPPER=%s CURRENT=%.3f HOLDCURRENT=%.3f"
                % (name, meta["run_current"], meta["hold_current"]))
        self.gcode.run_script_from_command("\n".join(lines))

    def _move_xy(self, x, y, z, speed):
        toolhead = self.printer.lookup_object("toolhead")
        toolhead.manual_move([x, y, z], speed)
        toolhead.wait_moves()

    def _capture(self, x0, y0, x1, y1, speed, accel):
        dist = math.hypot(x1 - x0, y1 - y0)
        accel_d = speed * speed / (2.0 * accel)
        if dist <= (2.0 * accel_d + 2.0):
            raise self.printer.command_error("测量行程太短")
        t_accel = speed / accel
        t_cruise = (dist - 2.0 * accel_d) / speed
        self._move_xy(x0, y0, 80., speed)
        toolhead = self.printer.lookup_object("toolhead")
        toolhead.dwell(0.05)
        adxl = self.printer.lookup_object("adxl345")
        client = adxl.start_internal_client()
        t0 = toolhead.get_last_move_time()
        toolhead.manual_move([x1, y1, 80.], speed)
        toolhead.dwell(0.25)
        client.finish_measurements()
        cruise0 = t0 + t_accel
        cruise1 = cruise0 + t_cruise
        rows = []
        for sample in client.get_samples():
            ts = sample.time if hasattr(sample, "time") else sample[0]
            if ts < cruise0 or ts > cruise1:
                continue
            travelled = accel_d + speed * (ts - cruise0)
            frac = travelled / dist
            if frac < 0. or frac > 1.:
                continue
            ax = sample.accel_x if hasattr(sample, "accel_x") else sample[1]
            ay = sample.accel_y if hasattr(sample, "accel_y") else sample[2]
            rows.append((
                x0 + (x1 - x0) * frac,
                y0 + (y1 - y0) * frac,
                ax, ay))
        if len(rows) < 200:
            raise self.printer.command_error("加速度计样本不够（%d）" % (len(rows),))
        return rows

    def _theta(self, name, x, y, z):
        stepper = self.steppers[name]
        cmd = stepper.calc_position_from_coord([x, y, z])
        pos = self._reported_position(stepper, cmd)
        period = self.meta[name]["steps"]
        mod = pos % period
        if mod < 0:
            mod += period
        ang = mod * 256.0 / float(period)
        return ang + float(self.align.get(name, 0))

    def _fit_axis(self, thetas, values, harmonic):
        n = len(thetas)
        mean = 0.
        for v in values:
            mean += v
        mean /= float(n)
        ss = sc = cc = sy = cy = 0.
        scale = harmonic * 2.0 * math.pi / 256.0
        for theta, val in zip(thetas, values):
            yv = val - mean
            psi = theta * scale
            s = math.sin(psi)
            c = math.cos(psi)
            ss += s * s
            sc += s * c
            cc += c * c
            sy += s * yv
            cy += c * yv
        det = ss * cc - sc * sc
        if abs(det) < 1e-6:
            return 0., 0., 0.
        amp_s = (sy * cc - cy * sc) / det
        amp_c = (ss * cy - sc * sy) / det
        energy = amp_s * amp_s + amp_c * amp_c
        phase = math.atan2(amp_c, amp_s)
        return energy, phase, math.hypot(amp_s, amp_c)

    def _fit_motor(self, rows, name):
        thetas = [self._theta(name, x, y, 80.) for x, y, ax, ay in rows]
        best_e = -1.
        best_phase = 0.
        for axis in (2, 3):
            values = [row[axis] for row in rows]
            energy, phase, _amp = self._fit_axis(thetas, values, 4)
            if energy > best_e:
                best_e = energy
                best_phase = phase
        phase_u8 = int(round(best_phase * 256.0 / (2.0 * math.pi))) & 255
        return best_e, phase_u8

    def _search(self, gcmd):
        spans = ((-30., -30., 30., 30.), (30., 30., -30., -30.))
        flip = 0

        def measure():
            nonlocal flip
            span = spans[flip]
            flip ^= 1
            return self._capture(span[0], span[1], span[2], span[3], 70., 1500.)

        self._apply_profile(self._empty_profile(), enter=False)
        base_rows = measure()
        base_e = {}
        base_phase = {}
        for name in self.names:
            energy, phase = self._fit_motor(base_rows, name)
            base_e[name] = energy
            base_phase[name] = phase
            logging.info("ncpsky_phase baseline %s energy=%.4f phase=%s",
                         name, energy, phase)
        chosen = self._empty_profile()
        for name in self.names:
            best_e = base_e[name]
            best = {"amp1": 0, "phase1": 0, "amp4": 0, "phase4": 0}
            if best_e <= 0.:
                chosen[name] = best
                continue
            for amp in AMPS:
                for extra in (0, 128):
                    phase = (base_phase[name] + extra) & 255
                    trial = {
                        "amp1": 0, "phase1": 0, "amp4": amp, "phase4": phase,
                    }
                    spec = dict(chosen)
                    spec[name] = trial
                    self._apply_profile(spec, enter=False)
                    rows = measure()
                    energy, _phase = self._fit_motor(rows, name)
                    logging.info(
                        "ncpsky_phase try %s amp=%s phase=%s energy=%.4f",
                        name, amp, phase, energy)
                    if energy < best_e:
                        best_e = energy
                        best = trial
            if best_e > IMPROVE * base_e[name] or best["amp4"] == 0:
                best = {"amp1": 0, "phase1": 0, "amp4": 0, "phase4": 0}
                ratio = 1.
            else:
                ratio = best_e / base_e[name]
            chosen[name] = best
            gcmd.respond_info(
                "NCPSKY phase %s 4次谐波 幅度 %d 相位 %d 能量比 %.0f%%"
                % (name, best["amp4"], best["phase4"], ratio * 100.0))
            self._apply_profile(chosen, enter=False)
        return chosen

    def _empty_profile(self):
        blank = {"amp1": 0, "phase1": 0, "amp4": 0, "phase4": 0}
        return {name: dict(blank) for name in self.names}

    def _any_amp(self, profile):
        for name in self.names:
            spec = profile.get(name) or {}
            if int(spec.get("amp1", 0)) or int(spec.get("amp4", 0)):
                return True
        return False

    def _load(self):
        profile = self._empty_profile()
        try:
            with open(self.profile_path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
        except (OSError, ValueError):
            return profile
        steppers = data.get("steppers") or {}
        for name in self.names:
            spec = steppers.get(name) or {}
            profile[name] = {
                "amp1": int(spec.get("amp1", 0)) & 255,
                "phase1": int(spec.get("phase1", 0)) & 255,
                "amp4": int(spec.get("amp4", 0)) & 255,
                "phase4": int(spec.get("phase4", 0)) & 255,
            }
        return profile

    def _save(self, profile):
        payload = {
            "version": 1,
            "steppers": profile,
        }
        folder = os.path.dirname(self.profile_path)
        if folder:
            os.makedirs(folder, exist_ok=True)
        tmp = self.profile_path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
            handle.write("\n")
        os.replace(tmp, self.profile_path)
        logging.info("ncpsky_phase saved %s", self.profile_path)


def load_config(config):
    return NcpskyPhase(config)
