#!/usr/bin/env python3
"""Localhost helper: calibration CSVs + backlight + panel prefs."""
import glob
import json
import os
import re
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse

HOST = "127.0.0.1"
PORT = 7126
TMP = "/tmp"
BACKLIGHT = "/sys/class/backlight/backlight/brightness"
BACKLIGHT_MAX = "/sys/class/backlight/backlight/max_brightness"
SETTINGS = "/home/pi/ncpsky-panel/settings.json"
MOONRAKER = "http://127.0.0.1:7125"
TMC_AUTOTUNE_CFG = "/home/pi/printer_data/config/tmc_autotune.cfg"

# OTA + network helpers (same process)
try:
    import ncpsky_ota as ota
except Exception:
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    try:
        import ncpsky_ota as ota
    except Exception:
        ota = None

try:
    import ncpsky_net as net
except Exception:
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    try:
        import ncpsky_net as net
    except Exception:
        net = None

try:
    import ncpsky_noise_map as noise_map
except Exception:
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    try:
        import ncpsky_noise_map as noise_map
    except Exception:
        noise_map = None


def latest(pattern):
    files = glob.glob(os.path.join(TMP, pattern))
    if not files:
        return None
    files.sort(key=os.path.getmtime, reverse=True)
    return files[0]


def read_max():
    try:
        with open(BACKLIGHT_MAX, "r") as f:
            return max(1, int(f.read().strip()))
    except Exception:
        return 255


def read_brightness_pct():
    try:
        with open(BACKLIGHT, "r") as f:
            cur = int(f.read().strip())
        return int(round(100.0 * cur / float(read_max())))
    except Exception:
        return 100


def write_brightness_pct(pct):
    pct = max(5, min(100, int(pct)))
    mx = read_max()
    # Keep a small floor so the panel never goes fully dark
    val = max(12, int(round(mx * pct / 100.0)))
    with open(BACKLIGHT, "w") as f:
        f.write(str(val))
    return pct, val


def load_settings():
    data = {"brightness": 100, "language": "zh"}
    try:
        with open(SETTINGS, "r") as f:
            raw = json.load(f)
        if isinstance(raw, dict):
            data.update(raw)
    except Exception:
        pass
    return data


def save_settings(patch):
    data = load_settings()
    data.update(patch or {})
    os.makedirs(os.path.dirname(SETTINGS), exist_ok=True)
    tmp = SETTINGS + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f)
    os.replace(tmp, SETTINGS)
    return data


def _http_json(url, timeout=6):
    try:
        from urllib.request import urlopen, Request
        from urllib.parse import quote
        req = Request(url)
        with urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception as ex:
        return {"_error": str(ex)}


def _parse_autotune_goals():
    goals = {
        "stepper_a": "autoswitch",
        "stepper_b": "autoswitch",
        "stepper_c": "autoswitch",
        "extruder": "silent",
    }
    try:
        text = open(TMC_AUTOTUNE_CFG, "r").read()
    except Exception:
        return goals
    cur = None
    for line in text.splitlines():
        s = line.strip()
        m = re.match(r"^\[autotune_tmc\s+(\S+)\]", s)
        if m:
            cur = m.group(1)
            continue
        if cur and s.startswith("tuning_goal:"):
            goals[cur] = s.split(":", 1)[1].strip()
            cur = None
    return goals


def build_calib_view():
    """Aggregate currently applied calibration for the panel View tab."""
    from urllib.parse import quote

    objs = [
        "bed_mesh",
        "configfile",
        "printer_workmode",
        "tmc5160 stepper_a",
        "tmc5160 stepper_b",
        "tmc5160 stepper_c",
        "tmc5160 extruder",
    ]
    q = "&".join(quote(o) for o in objs)
    raw = _http_json(MOONRAKER + "/printer/objects/query?" + q)
    st = ((raw.get("result") or {}).get("status")) or {}
    settings = ((st.get("configfile") or {}).get("settings")) or {}

    ish = settings.get("input_shaper") or {}
    shaper = {
        "freq_x": float(ish.get("shaper_freq_x") or 0),
        "freq_y": float(ish.get("shaper_freq_y") or 0),
        "type_x": ish.get("shaper_type_x") or ish.get("shaper_type") or "",
        "type_y": ish.get("shaper_type_y") or ish.get("shaper_type") or "",
        "damping_x": float(ish.get("damping_ratio_x") or 0),
        "damping_y": float(ish.get("damping_ratio_y") or 0),
        "csv_x": bool(latest("calibration_data_x_*.csv") or latest("resonances_x_*.csv")),
        "csv_y": bool(latest("calibration_data_y_*.csv") or latest("resonances_y_*.csv")),
    }

    bm = st.get("bed_mesh") or {}
    profiles = bm.get("profiles") or {}
    prof_name = bm.get("profile_name") or ""
    points = bm.get("probed_matrix") or bm.get("mesh_matrix")
    params = {}
    if (not points or not points[0]) and "default" in profiles:
        points = profiles["default"].get("points") or []
        params = profiles["default"].get("mesh_params") or {}
        if not prof_name:
            prof_name = "default"
    elif prof_name and prof_name in profiles:
        params = profiles[prof_name].get("mesh_params") or {}
        if not points or not points[0]:
            points = profiles[prof_name].get("points") or []

    flat = []
    for row in points or []:
        for v in row:
            try:
                flat.append(float(v))
            except Exception:
                pass
    mesh = {
        "profile": prof_name or ("default" if "default" in profiles else ""),
        "points": points or [],
        "params": params,
        "z_min": min(flat) if flat else 0,
        "z_max": max(flat) if flat else 0,
        "z_avg": (sum(flat) / len(flat)) if flat else 0,
        "rows": len(points or []),
        "cols": len(points[0]) if points else 0,
    }

    sa = settings.get("stepper_a") or {}
    sb = settings.get("stepper_b") or {}
    sc = settings.get("stepper_c") or {}
    pr = settings.get("printer") or {}
    tilt = {
        "endstop_a": float(sa.get("position_endstop") or 0),
        "endstop_b": float(sb.get("position_endstop") or 0),
        "endstop_c": float(sc.get("position_endstop") or 0),
        "angle_a": float(sa.get("angle") or 0),
        "angle_b": float(sb.get("angle") or 0),
        "angle_c": float(sc.get("angle") or 0),
        "arm_length": float(sa.get("arm_length") or 0),
        "delta_radius": float(pr.get("delta_radius") or 0),
    }

    goals = _parse_autotune_goals()
    tmc = []
    for key, label, goal_key in (
        ("tmc5160 stepper_a", "A", "stepper_a"),
        ("tmc5160 stepper_b", "B", "stepper_b"),
        ("tmc5160 stepper_c", "C", "stepper_c"),
        ("tmc5160 extruder", "E", "extruder"),
    ):
        t = st.get(key) or {}
        tmc.append({
            "id": label,
            "run": float(t.get("run_current") or 0),
            "hold": float(t.get("hold_current") or 0),
            "goal": goals.get(goal_key, ""),
        })

    wm = st.get("printer_workmode") or {}
    noise = {"ok": False}
    if noise_map:
        try:
            noise = noise_map.map_summary()
        except Exception as ex:
            noise = {"ok": False, "error": str(ex)}
    return {
        "ok": True,
        "shaper": shaper,
        "mesh": mesh,
        "tilt": tilt,
        "tmc": tmc,
        "noise_map": noise,
        "workmode": wm.get("mode"),
        "error": raw.get("_error"),
    }


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        if not isinstance(body, (bytes, bytearray)):
            if not isinstance(body, str):
                body = json.dumps(body)
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self._send(204, b"")

    def _read_json(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n <= 0:
            return {}
        raw = self.rfile.read(n)
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path in ("/health", "/"):
            self._send(200, "ok", "text/plain; charset=utf-8")
            return
        if path == "/brightness":
            pct = read_brightness_pct()
            self._send(200, {"ok": True, "brightness": pct, "raw": open(BACKLIGHT).read().strip() if os.path.exists(BACKLIGHT) else None})
            return
        if path == "/settings":
            data = load_settings()
            # Prefer live backlight if readable
            try:
                data["brightness"] = read_brightness_pct()
            except Exception:
                pass
            self._send(200, data)
            return
        if path == "/calib/view":
            try:
                self._send(200, build_calib_view())
            except Exception as ex:
                self._send(500, {"ok": False, "error": str(ex)})
            return
        if path == "/noise_map":
            if not noise_map:
                self._send(500, {"ok": False, "error": "noise_map module missing"})
                return
            try:
                self._send(200, noise_map.map_summary())
            except Exception as ex:
                self._send(500, {"ok": False, "error": str(ex)})
            return
        if path == "/noise_map/job":
            if not noise_map:
                self._send(500, {"ok": False, "error": "noise_map module missing"})
                return
            self._send(200, {"ok": True, **noise_map.job_status()})
            return
        if path == "/ota/status":
            if not ota:
                self._send(500, {"ok": False, "error": "ota module missing"})
                return
            self._send(200, ota.status_payload())
            return
        if path == "/ota/history":
            if not ota:
                self._send(500, {"ok": False, "error": "ota module missing"})
                return
            self._send(200, {"ok": True, "history": ota.history_list(50), "backups": ota.list_backups()})
            return
        if path == "/network/status":
            if not net:
                self._send(500, {"ok": False, "error": "net module missing"})
                return
            self._send(200, net.network_overview())
            return
        if path == "/network/wifi/scan":
            if not net:
                self._send(500, {"ok": False, "error": "net module missing"})
                return
            wait = 3.0
            try:
                qs = parse_qs(parsed.query)
                if qs.get("wait"):
                    wait = float(qs["wait"][0])
            except Exception:
                pass
            self._send(200, net.wifi_scan(wait_sec=wait))
            return
        if path == "/network/proxy":
            if not net:
                self._send(500, {"ok": False, "error": "net module missing"})
                return
            self._send(200, net.proxy_status())
            return
        m = re.match(r"^/shaper/(x|y)(?:\.csv)?$", path)
        if m:
            axis = m.group(1)
            f = latest("calibration_data_%s_*.csv" % axis)
            if not f:
                f = latest("resonances_%s_*.csv" % axis)
            if not f:
                self._send(404, "missing %s" % axis, "text/plain; charset=utf-8")
                return
            with open(f, "rb") as fp:
                self._send(200, fp.read(), "text/csv; charset=utf-8")
            return
        self._send(404, "not found", "text/plain; charset=utf-8")

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        qs = parse_qs(parsed.query)
        body = self._read_json()

        if path == "/brightness":
            pct = body.get("brightness", qs.get("pct", [None])[0])
            if pct is None:
                self._send(400, {"ok": False, "error": "missing brightness"})
                return
            try:
                pct, val = write_brightness_pct(pct)
                save_settings({"brightness": pct})
                self._send(200, {"ok": True, "brightness": pct, "raw": val})
            except Exception as ex:
                self._send(500, {"ok": False, "error": str(ex)})
            return

        if path == "/settings":
            patch = {}
            if "brightness" in body:
                try:
                    pct, _ = write_brightness_pct(body["brightness"])
                    patch["brightness"] = pct
                except Exception as ex:
                    self._send(500, {"ok": False, "error": str(ex)})
                    return
            if "language" in body:
                lang = str(body["language"])
                if lang not in ("zh", "en"):
                    self._send(400, {"ok": False, "error": "bad language"})
                    return
                patch["language"] = lang
            data = save_settings(patch)
            self._send(200, {"ok": True, "settings": data})
            return

        if path.startswith("/network/"):
            if not net:
                self._send(500, {"ok": False, "error": "net module missing"})
                return
            try:
                if path == "/network/wifi/connect":
                    self._send(200, net.wifi_connect(
                        ssid=body.get("ssid"),
                        password=body.get("password") or "",
                        open_network=bool(body.get("open") or body.get("open_network")),
                        timeout_sec=float(body.get("timeout") or 25),
                    ))
                    return
                if path == "/network/wifi/disconnect":
                    self._send(200, net.wifi_disconnect())
                    return
                if path == "/network/wifi/reassociate":
                    self._send(200, net.wifi_reassociate())
                    return
                if path == "/network/wifi/scan":
                    self._send(200, net.wifi_scan(wait_sec=float(body.get("wait") or 3)))
                    return
                if path == "/network/proxy":
                    if body.get("clear"):
                        self._send(200, net.clear_proxy(stop=bool(body.get("stop"))))
                        return
                    # Flexible: share / subscribe / http / manual
                    if any(k in body for k in ("value", "vless", "url", "manual", "mode")):
                        value = body.get("value") or body.get("vless") or body.get("url") or ""
                        self._send(200, net.set_proxy_input(
                            value=value,
                            mode=body.get("mode") or "auto",
                            manual=body.get("manual") or {},
                            local_port=body.get("local_port"),
                            restart=body.get("restart", True),
                        ))
                        return
                    self._send(200, net.proxy_status())
                    return
            except Exception as ex:
                self._send(500, {"ok": False, "error": str(ex)})
                return

        if path.startswith("/noise_map"):
            if not noise_map:
                self._send(500, {"ok": False, "error": "noise_map module missing"})
                return
            try:
                if path == "/noise_map/run":
                    kwargs = {}
                    if body.get("velocities"):
                        kwargs["velocities"] = [
                            float(x) for x in body["velocities"]
                        ]
                    if body.get("accels"):
                        kwargs["accels"] = [float(x) for x in body["accels"]]
                    if "merge_seed" in body:
                        kwargs["merge_seed"] = bool(body["merge_seed"])
                    # Mark gcode status busy for panel pollers
                    try:
                        noise_map.gcode(
                            "SET_GCODE_VARIABLE MACRO=NCPSKY_NOISE_MAP_STATUS "
                            "VARIABLE=busy VALUE=1\n"
                            "SET_GCODE_VARIABLE MACRO=NCPSKY_NOISE_MAP_STATUS "
                            "VARIABLE=phase VALUE='\"sweep\"'\n"
                            "SET_GCODE_VARIABLE MACRO=NCPSKY_NOISE_MAP_STATUS "
                            "VARIABLE=err VALUE='\"\"'\n"
                            "UPDATE_DELAYED_GCODE ID=_NCPSKY_NOISE_MAP_FALLBACK DURATION=0"
                        )
                    except Exception:
                        pass
                    self._send(200, noise_map.start_sweep_async(**kwargs))
                    return
                if path == "/noise_map/apply":
                    data = noise_map.apply_noise_map()
                    self._send(200, {"ok": True, **noise_map.map_summary(data)})
                    return
                if path == "/noise_map/install_default":
                    path_out = noise_map.ensure_default_installed()
                    noise_map.sync_macro_variables(noise_map.load_map())
                    self._send(200, {"ok": True, "path": path_out, **noise_map.map_summary()})
                    return
            except Exception as ex:
                try:
                    noise_map.gcode(
                        "SET_GCODE_VARIABLE MACRO=NCPSKY_NOISE_MAP_STATUS "
                        "VARIABLE=busy VALUE=0\n"
                        "SET_GCODE_VARIABLE MACRO=NCPSKY_NOISE_MAP_STATUS "
                        "VARIABLE=phase VALUE='\"error\"'\n"
                        "SET_GCODE_VARIABLE MACRO=NCPSKY_NOISE_MAP_STATUS "
                        "VARIABLE=err VALUE=%s"
                        % ('"' + str(ex).replace('"', "")[:120] + '"')
                    )
                except Exception:
                    pass
                self._send(500, {"ok": False, "error": str(ex)})
                return

        if path.startswith("/ota/"):
            if not ota:
                self._send(500, {"ok": False, "error": "ota module missing"})
                return
            try:
                if path == "/ota/check":
                    self._send(200, ota.check_updates())
                    return
                if path == "/ota/channel":
                    self._send(200, ota.set_channel(body.get("channel")))
                    return
                if path == "/ota/source":
                    self._send(200, ota.set_source(body.get("source")))
                    return
                if path == "/ota/proxy":
                    self._send(200, ota.set_proxy(
                        enabled=body.get("enabled"),
                        url=body.get("url"),
                        github_mirror=body.get("github_mirror"),
                    ))
                    return
                if path == "/ota/config":
                    self._send(200, {"ok": True, "config": ota.save_config(body)})
                    return
                if path == "/ota/upgrade":
                    pkgs = body.get("packages") or body.get("ids") or []
                    confirm = bool(body.get("confirm_mcu"))
                    self._send(200, ota.start_upgrade(pkgs, confirm_mcu=confirm))
                    return
                if path == "/ota/confirm_mcu":
                    self._send(200, ota.confirm_mcu_flash())
                    return
                if path == "/ota/rollback":
                    self._send(200, ota.rollback(
                        kind=body.get("kind"),
                        backup_name=body.get("backup"),
                    ))
                    return
            except Exception as ex:
                self._send(500, {"ok": False, "error": str(ex)})
                return

        self._send(404, {"ok": False, "error": "not found"})


def main():
    # Apply saved brightness once at start (panel runs as root)
    try:
        cfg = load_settings()
        if "brightness" in cfg:
            write_brightness_pct(cfg["brightness"])
    except Exception:
        pass
    try:
        if ota:
            ota._ensure_dirs()
    except Exception:
        pass
    httpd = HTTPServer((HOST, PORT), Handler)
    httpd.serve_forever()


if __name__ == "__main__":
    main()
