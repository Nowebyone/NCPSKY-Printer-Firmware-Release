#!/usr/bin/env python3
"""NCPSKY OTA engine — manifest check, download, install, backup, rollback."""
from __future__ import annotations

import hashlib
import json
import logging
import os
import shutil
import subprocess
import tarfile
import tempfile
import threading
import time
import zipfile
from datetime import datetime, timezone
from urllib.error import HTTPError, URLError
from urllib.request import (
    HTTPSHandler,
    ProxyHandler,
    Request,
    build_opener,
    urlopen,
)

LOG = logging.getLogger("ncpsky_ota")
if not LOG.handlers:
    _handlers = [logging.StreamHandler()]
    try:
        _log_path = "/tmp/ncpsky_ota.log"
        os.makedirs(os.path.dirname(_log_path), exist_ok=True)
        _handlers.insert(0, logging.FileHandler(_log_path, encoding="utf-8"))
    except Exception:
        pass
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        handlers=_handlers,
    )

PANEL_ROOT = "/home/pi/ncpsky-panel"
OTA_ROOT = os.path.join(PANEL_ROOT, "ota")
CONFIG_PATH = os.path.join(OTA_ROOT, "config.json")
CONFIG_DEFAULT = os.path.join(OTA_ROOT, "config.default.json")
VERSIONS_PATH = os.path.join(OTA_ROOT, "versions.json")
HISTORY_PATH = os.path.join(OTA_ROOT, "history.json")
STAGING = os.path.join(OTA_ROOT, "staging")
BACKUP = os.path.join(OTA_ROOT, "backup")
MOONRAKER = "http://127.0.0.1:7125"
FIRMWARE_TARGET = "FLSun T1 Max"
PRODUCT = "NCPSKY ▲ DTMax"

_state_lock = threading.Lock()
_state = {
    "busy": False,
    "phase": "idle",
    "progress": 0.0,
    "message": "",
    "error": "",
    "current_package": None,
    "last_check": None,
    "available": [],
    "confirm_mcu": None,  # pending mcu package awaiting confirm
    "release_assets": None,  # github release asset name→url map
}


def _utc_now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _ensure_dirs():
    for d in (OTA_ROOT, STAGING, BACKUP):
        os.makedirs(d, exist_ok=True)
    if not os.path.exists(CONFIG_PATH) and os.path.exists(CONFIG_DEFAULT):
        shutil.copy2(CONFIG_DEFAULT, CONFIG_PATH)
    if not os.path.exists(VERSIONS_PATH):
        _save_json(VERSIONS_PATH, {
            "panel": _read_panel_version(),
            "stack": "2026.11.23.1",
            "system": "sys-none",
            "mcu": "mcu-unknown",
            "klipper_core": "0.14.0",
            "klipper_custom": "FLSunT1Max",
        })
    if not os.path.exists(HISTORY_PATH):
        _save_json(HISTORY_PATH, [])


def _load_json(path, default=None):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default if default is not None else {}


def _save_json(path, data):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")
    os.replace(tmp, path)


def _read_panel_version():
    ver = os.path.join(PANEL_ROOT, "VERSION")
    try:
        with open(ver, "r", encoding="utf-8") as f:
            return f.readline().strip() or "0.0.0"
    except Exception:
        return "0.0.0"


def _default_github():
    return {
        "owner": "Nowebyone",
        "repo": "NCPSKY-Printer-Firmware-Release",
        "ref": "main",
        "mode": "raw",  # raw | release
        "path_prefix": "ota/ncpsky-dtmax",
        "release_tag": {
            "stable": "ota-stable",
            "beta": "ota-beta",
            "dev": "ota-dev",
        },
    }


def _default_proxy():
    return {
        "enabled": False,
        "url": "http://127.0.0.1:7890",
        "github_mirror": "",  # e.g. https://ghfast.top/  (optional CDN front)
    }


def load_config():
    _ensure_dirs()
    cfg = _load_json(CONFIG_DEFAULT, {})
    # shallow then deep-merge nested dicts from user config
    user = _load_json(CONFIG_PATH, {})
    nested_keys = ("github", "proxy")
    for k, v in user.items():
        if k in nested_keys and isinstance(v, dict):
            base = dict(cfg.get(k) or {})
            base.update(v)
            cfg[k] = base
        else:
            cfg[k] = v
    cfg.setdefault("product", PRODUCT)
    cfg.setdefault("firmware_target", FIRMWARE_TARGET)
    cfg.setdefault("channel", "stable")
    cfg.setdefault("source", "http")  # http | github
    cfg.setdefault("base_url", "http://127.0.0.1:8765/ota/ncpsky-dtmax")
    cfg.setdefault("insecure_http", True)
    cfg.setdefault("backup_keep", 2)
    gh = dict(_default_github())
    gh.update(cfg.get("github") or {})
    if isinstance(gh.get("release_tag"), dict):
        tags = dict(_default_github()["release_tag"])
        tags.update(gh["release_tag"])
        gh["release_tag"] = tags
    cfg["github"] = gh
    px = dict(_default_proxy())
    px.update(cfg.get("proxy") or {})
    cfg["proxy"] = px
    if cfg.get("source") not in ("http", "github"):
        cfg["source"] = "http"
    return cfg


def save_config(patch):
    cfg = load_config()
    for k, v in (patch or {}).items():
        if k in ("github", "proxy") and isinstance(v, dict):
            base = dict(cfg.get(k) or {})
            # nested release_tag merge
            if k == "github" and isinstance(v.get("release_tag"), dict):
                tags = dict(base.get("release_tag") or {})
                tags.update(v["release_tag"])
                v = dict(v)
                v["release_tag"] = tags
            base.update(v)
            cfg[k] = base
        else:
            cfg[k] = v
    if cfg.get("source") not in ("http", "github"):
        cfg["source"] = "http"
    _save_json(CONFIG_PATH, cfg)
    return cfg


def load_versions():
    _ensure_dirs()
    v = _load_json(VERSIONS_PATH, {})
    v["panel"] = _read_panel_version()
    v.setdefault("klipper_core", "0.14.0")
    v.setdefault("klipper_custom", "FLSunT1Max")
    return v


def save_versions(patch):
    v = load_versions()
    v.update(patch or {})
    _save_json(VERSIONS_PATH, v)
    return v


def history_list(limit=30):
    items = _load_json(HISTORY_PATH, [])
    if not isinstance(items, list):
        items = []
    return items[:limit]


def _append_history(entry):
    items = history_list(200)
    items.insert(0, entry)
    _save_json(HISTORY_PATH, items[:100])


def _set_state(**kwargs):
    with _state_lock:
        _state.update(kwargs)
        return dict(_state)


def get_runtime_state():
    with _state_lock:
        return dict(_state)


def disk_free_mb(path="/home/pi"):
    try:
        st = os.statvfs(path)
        return int((st.f_bavail * st.f_frsize) / (1024 * 1024))
    except Exception:
        return 0


def _proxy_url(cfg=None):
    cfg = cfg or load_config()
    px = cfg.get("proxy") or {}
    if not px.get("enabled"):
        return None
    url = (px.get("url") or "").strip()
    return url or None


def _apply_github_mirror(url, cfg=None):
    """Optional China-friendly front for github.com / raw.githubusercontent.com."""
    cfg = cfg or load_config()
    mirror = ((cfg.get("proxy") or {}).get("github_mirror") or "").strip()
    if not mirror:
        return url
    if "github.com" not in url and "githubusercontent.com" not in url:
        return url
    return mirror.rstrip("/") + "/" + url


def _build_opener(insecure=True, proxy_url=None):
    handlers = []
    if proxy_url:
        handlers.append(ProxyHandler({
            "http": proxy_url,
            "https": proxy_url,
        }))
    else:
        # force direct (ignore process env proxies if any)
        handlers.append(ProxyHandler({}))
    if insecure:
        import ssl
        ctx = ssl._create_unverified_context()
        handlers.append(HTTPSHandler(context=ctx))
    return build_opener(*handlers)


def _http_get_bytes(url, timeout=60, insecure=True, cfg=None):
    cfg = cfg or load_config()
    url = _apply_github_mirror(url, cfg)
    proxy = _proxy_url(cfg)
    req = Request(url, headers={
        "User-Agent": "ncpsky-ota/1.0",
        "Accept": "application/octet-stream, application/json, */*",
    })
    opener = _build_opener(insecure=insecure, proxy_url=proxy)
    with opener.open(req, timeout=timeout) as r:
        return r.read()


def _http_get_json(url, timeout=30, insecure=True, cfg=None):
    raw = _http_get_bytes(url, timeout=timeout, insecure=insecure, cfg=cfg)
    return json.loads(raw.decode("utf-8"))


def _http_get_json_direct(url, timeout=10):
    """Local Moonraker calls — never via user proxy."""
    req = Request(url, headers={"User-Agent": "ncpsky-ota/1.0"})
    opener = _build_opener(insecure=True, proxy_url=None)
    with opener.open(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def moonraker_print_busy():
    try:
        data = _http_get_json_direct(
            MOONRAKER + "/printer/objects/query?print_stats",
            timeout=5,
        )
        st = (((data.get("result") or {}).get("status") or {}).get("print_stats") or {})
        state = (st.get("state") or "").lower()
        return state in ("printing", "paused")
    except Exception:
        return False


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def _resolve_url(base_url, url):
    if url.startswith("http://") or url.startswith("https://"):
        return url
    return base_url.rstrip("/") + "/" + url.lstrip("/")


def github_raw_base(cfg=None):
    cfg = cfg or load_config()
    gh = cfg.get("github") or {}
    owner = gh.get("owner") or "ncpsky"
    repo = gh.get("repo") or "ota"
    ref = gh.get("ref") or "main"
    prefix = (gh.get("path_prefix") or "ota/ncpsky-dtmax").strip("/")
    base = "https://raw.githubusercontent.com/%s/%s/%s" % (owner, repo, ref)
    if prefix:
        base = base + "/" + prefix
    return base


def github_release_tag(cfg=None, channel=None):
    cfg = cfg or load_config()
    gh = cfg.get("github") or {}
    channel = channel or cfg.get("channel") or "stable"
    tags = gh.get("release_tag") or {}
    return tags.get(channel) or ("ota-%s" % channel)


def github_api_release(cfg=None, channel=None):
    cfg = cfg or load_config()
    gh = cfg.get("github") or {}
    owner = gh.get("owner") or "ncpsky"
    repo = gh.get("repo") or "ota"
    tag = github_release_tag(cfg, channel)
    url = "https://api.github.com/repos/%s/%s/releases/tags/%s" % (owner, repo, tag)
    return _http_get_json(
        url,
        timeout=30,
        insecure=bool(cfg.get("insecure_http", True)),
        cfg=cfg,
    )


def _content_base(cfg=None):
    """Root URL for relative package paths (http base or github raw base)."""
    cfg = cfg or load_config()
    if (cfg.get("source") or "http") == "github":
        mode = ((cfg.get("github") or {}).get("mode") or "raw").lower()
        if mode == "release":
            # relative urls still resolved via asset map; fallback raw base unused
            return github_raw_base(cfg)
        return github_raw_base(cfg)
    return (cfg.get("base_url") or "").rstrip("/")


def _resolve_package_url(pkg, cfg=None, release_assets=None):
    cfg = cfg or load_config()
    url = pkg.get("url") or ""
    if url.startswith("http://") or url.startswith("https://"):
        return url
    source = cfg.get("source") or "http"
    if source == "github":
        mode = ((cfg.get("github") or {}).get("mode") or "raw").lower()
        if mode == "release" and release_assets is not None:
            name = os.path.basename(url)
            asset = release_assets.get(name) or release_assets.get(url)
            if asset:
                return asset
            raise RuntimeError("GitHub Release 中找不到资源: %s" % name)
        return _resolve_url(github_raw_base(cfg), url)
    return _resolve_url(cfg.get("base_url") or "", url)


def _semver_tuple(s):
    raw = (s or "0").strip()
    for prefix in ("sys-", "mcu-"):
        if raw.startswith(prefix):
            raw = raw[len(prefix):]
    core = raw.split("+")[0]
    # panel prerelease: 0.5.1-beta.1 → 0.5.1
    if "-" in core:
        left = core.split("-", 1)[0]
        if left[:1].isdigit() and "." in left:
            core = left
    parts = []
    for p in core.split("."):
        try:
            parts.append(int(p))
        except Exception:
            parts.append(0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


def _version_newer(remote, local):
    if not remote:
        return False
    if not local or local in ("—", "unknown", "mcu-unknown", "sys-none"):
        return True
    if str(remote) == str(local):
        return False
    try:
        rt, lt = _semver_tuple(remote), _semver_tuple(local)
        n = max(len(rt), len(lt))
        rt = rt + (0,) * (n - len(rt))
        lt = lt + (0,) * (n - len(lt))
        if rt != lt:
            return rt > lt
        return str(remote) > str(local)
    except Exception:
        return str(remote) != str(local)


def fetch_manifest(cfg=None):
    cfg = cfg or load_config()
    channel = cfg.get("channel") or "stable"
    insecure = bool(cfg.get("insecure_http", True))
    source = cfg.get("source") or "http"
    last_err = None

    if source == "github":
        gh = cfg.get("github") or {}
        mode = (gh.get("mode") or "raw").lower()
        if mode == "release":
            try:
                rel = github_api_release(cfg, channel)
                assets = {
                    a.get("name"): a.get("browser_download_url")
                    for a in (rel.get("assets") or [])
                    if a.get("name") and a.get("browser_download_url")
                }
                # Prefer channel-named manifest asset, then manifest.json
                for name in (
                    "channels-%s.json" % channel,
                    "%s.json" % channel,
                    "manifest.json",
                    "manifest.%s.json" % channel,
                ):
                    if name in assets:
                        man = _http_get_json(
                            assets[name], timeout=30, insecure=insecure, cfg=cfg
                        )
                        man["_fetched_from"] = assets[name]
                        man["_release_assets"] = assets
                        man["_release_tag"] = rel.get("tag_name")
                        return man
                # body may embed JSON (advanced); else fail
                raise RuntimeError(
                    "Release %s 无 manifest 资源（需要 manifest.json 或 channels-%s.json）"
                    % (rel.get("tag_name"), channel)
                )
            except Exception as ex:
                last_err = ex
                # fall through to raw as backup
                LOG.warning("github release manifest failed: %s — try raw", ex)

        base = github_raw_base(cfg)
        candidates = [
            "%s/channels/%s.json" % (base, channel),
            "%s/manifest.json" % base,
        ]
    else:
        base = (cfg.get("base_url") or "").rstrip("/")
        candidates = [
            "%s/channels/%s.json" % (base, channel),
            "%s/manifest.json" % base,
        ]

    for url in candidates:
        try:
            man = _http_get_json(url, timeout=20, insecure=insecure, cfg=cfg)
            man["_fetched_from"] = url
            return man
        except Exception as ex:
            last_err = ex
            continue
    raise RuntimeError("manifest fetch failed: %s" % last_err)


def check_updates(cfg=None):
    cfg = cfg or load_config()
    _set_state(phase="checking", message="正在检查更新…", error="", progress=0.05)
    try:
        man = fetch_manifest(cfg)
    except Exception as ex:
        _set_state(phase="idle", message="", error=str(ex), progress=0)
        return {"ok": False, "error": str(ex), "available": []}

    if man.get("firmware_target") != cfg.get("firmware_target", FIRMWARE_TARGET):
        err = "机型不匹配: manifest=%s local=%s" % (
            man.get("firmware_target"), cfg.get("firmware_target"))
        _set_state(phase="idle", error=err, progress=0)
        return {"ok": False, "error": err, "available": []}

    if man.get("product") and man.get("product") != cfg.get("product", PRODUCT):
        # soft warn only
        pass

    local = load_versions()
    available = []
    for pkg in man.get("packages") or []:
        kind = pkg.get("kind")
        ver = pkg.get("version")
        cur = local.get(kind, "")
        if _version_newer(ver, cur):
            item = dict(pkg)
            item["local_version"] = cur
            item["update"] = True
            available.append(item)

    _set_state(
        phase="idle",
        message="检查完成",
        error="",
        progress=0,
        last_check=_utc_now(),
        available=available,
        release_assets=man.get("_release_assets"),
    )
    return {
        "ok": True,
        "channel": man.get("channel") or cfg.get("channel"),
        "published_at": man.get("published_at"),
        "notes": man.get("notes") or "",
        "available": available,
        "manifest_url": man.get("_fetched_from"),
        "source": cfg.get("source") or "http",
    }


def status_payload():
    cfg = load_config()
    st = get_runtime_state()
    gh = cfg.get("github") or {}
    px = cfg.get("proxy") or {}
    return {
        "ok": True,
        "product": cfg.get("product"),
        "firmware_target": cfg.get("firmware_target"),
        "channel": cfg.get("channel"),
        "source": cfg.get("source") or "http",
        "base_url": cfg.get("base_url"),
        "github": {
            "owner": gh.get("owner"),
            "repo": gh.get("repo"),
            "ref": gh.get("ref"),
            "mode": gh.get("mode"),
            "path_prefix": gh.get("path_prefix"),
            "repo_slug": "%s/%s" % (gh.get("owner") or "", gh.get("repo") or ""),
        },
        "proxy": {
            "enabled": bool(px.get("enabled")),
            "url": px.get("url") or "",
            "github_mirror": px.get("github_mirror") or "",
        },
        "versions": load_versions(),
        "disk_free_mb": disk_free_mb(),
        "print_busy": moonraker_print_busy(),
        "busy": st.get("busy"),
        "phase": st.get("phase"),
        "progress": st.get("progress"),
        "message": st.get("message"),
        "error": st.get("error"),
        "current_package": st.get("current_package"),
        "last_check": st.get("last_check"),
        "available": st.get("available") or [],
        "confirm_mcu": st.get("confirm_mcu"),
        "history": history_list(10),
    }


def set_channel(channel):
    if channel not in ("stable", "beta", "dev"):
        return {"ok": False, "error": "bad channel"}
    cfg = save_config({"channel": channel})
    return {"ok": True, "channel": cfg["channel"]}


def set_source(source):
    if source not in ("http", "github"):
        return {"ok": False, "error": "bad source (http|github)"}
    cfg = save_config({"source": source})
    return {
        "ok": True,
        "source": cfg.get("source"),
        "base_url": cfg.get("base_url"),
        "github": status_payload().get("github"),
    }


def set_proxy(enabled=None, url=None, github_mirror=None):
    patch = {"proxy": {}}
    if enabled is not None:
        patch["proxy"]["enabled"] = bool(enabled)
    if url is not None:
        patch["proxy"]["url"] = str(url).strip()
    if github_mirror is not None:
        patch["proxy"]["github_mirror"] = str(github_mirror).strip()
    if not patch["proxy"]:
        return {"ok": False, "error": "empty proxy patch"}
    cfg = save_config(patch)
    px = cfg.get("proxy") or {}
    return {
        "ok": True,
        "proxy": {
            "enabled": bool(px.get("enabled")),
            "url": px.get("url") or "",
            "github_mirror": px.get("github_mirror") or "",
        },
    }


def _backup_kind(kind, version):
    os.makedirs(BACKUP, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    name = "%s-%s-%s.tar" % (kind, version or "unknown", stamp)
    path = os.path.join(BACKUP, name)
    if kind == "panel":
        with tarfile.open(path, "w") as tar:
            for rel in ("qml", "scripts", "bin", "VERSION", "ota/versions.json"):
                full = os.path.join(PANEL_ROOT, rel)
                if os.path.exists(full):
                    tar.add(full, arcname=rel)
    elif kind == "stack":
        # backup macros we manage + versions marker
        with tarfile.open(path, "w") as tar:
            for rel in (
                "/home/pi/printer_data/config/ncpsky_calib.cfg",
                "/home/pi/printer_data/config/tmc_autotune.cfg",
                VERSIONS_PATH,
            ):
                if os.path.exists(rel):
                    tar.add(rel, arcname=os.path.basename(rel))
    elif kind == "mcu":
        src = "/home/pi/klipper/out/klipper.bin"
        if os.path.exists(src):
            with tarfile.open(path, "w") as tar:
                tar.add(src, arcname="klipper.bin")
        else:
            # empty marker
            with tarfile.open(path, "w") as tar:
                info = tarfile.TarInfo(name="EMPTY")
                info.size = 0
                tar.addfile(info)
    else:
        with tarfile.open(path, "w") as tar:
            if os.path.exists(VERSIONS_PATH):
                tar.add(VERSIONS_PATH, arcname="versions.json")

    # prune old backups for kind
    cfg = load_config()
    keep = int(cfg.get("backup_keep") or 2)
    files = sorted(
        [os.path.join(BACKUP, f) for f in os.listdir(BACKUP) if f.startswith(kind + "-")],
        key=os.path.getmtime,
        reverse=True,
    )
    for old in files[keep:]:
        try:
            os.remove(old)
        except Exception:
            pass
    return path


def list_backups():
    _ensure_dirs()
    out = []
    for f in sorted(os.listdir(BACKUP), reverse=True):
        if not f.endswith(".tar"):
            continue
        full = os.path.join(BACKUP, f)
        out.append({
            "name": f,
            "path": full,
            "size": os.path.getsize(full),
            "mtime": int(os.path.getmtime(full)),
        })
    return out


def rollback(kind=None, backup_name=None):
    """Restore last backup for kind (panel/stack/mcu)."""
    if moonraker_print_busy():
        return {"ok": False, "error": "打印中禁止回滚"}
    backups = list_backups()
    if backup_name:
        match = [b for b in backups if b["name"] == backup_name]
    elif kind:
        match = [b for b in backups if b["name"].startswith(kind + "-")]
    else:
        match = backups
    if not match:
        return {"ok": False, "error": "没有可回滚备份"}
    b = match[0]
    path = b["path"]
    kind_guess = b["name"].split("-", 1)[0]
    try:
        if kind_guess == "panel":
            with tarfile.open(path, "r") as tar:
                tar.extractall(PANEL_ROOT)
            _restart_panel()
        elif kind_guess == "stack":
            with tarfile.open(path, "r") as tar:
                for m in tar.getmembers():
                    if m.name.endswith(".cfg"):
                        dest = os.path.join("/home/pi/printer_data/config", os.path.basename(m.name))
                        f = tar.extractfile(m)
                        if f:
                            with open(dest, "wb") as out:
                                out.write(f.read())
            _firmware_restart()
        elif kind_guess == "mcu":
            with tarfile.open(path, "r") as tar:
                for m in tar.getmembers():
                    if m.name == "klipper.bin":
                        f = tar.extractfile(m)
                        if f:
                            os.makedirs("/home/pi/klipper/out", exist_ok=True)
                            with open("/home/pi/klipper/out/klipper.bin", "wb") as out:
                                out.write(f.read())
        _append_history({
            "ts": _utc_now(),
            "action": "rollback",
            "backup": b["name"],
            "ok": True,
        })
        return {"ok": True, "restored": b["name"]}
    except Exception as ex:
        return {"ok": False, "error": str(ex)}


def _download_package(pkg, cfg, release_assets=None):
    url = _resolve_package_url(pkg, cfg, release_assets=release_assets)
    _set_state(phase="download", message="下载 %s" % pkg.get("id"), progress=0.15,
               current_package=pkg.get("id"))
    data = _http_get_bytes(
        url, timeout=300, insecure=bool(cfg.get("insecure_http", True)), cfg=cfg
    )
    digest = sha256_bytes(data)
    expect = (pkg.get("sha256") or "").lower()
    # allow all-zero placeholder only for local dry-run — reject otherwise
    if expect and expect != "0" * 64 and digest.lower() != expect:
        raise RuntimeError("sha256 mismatch for %s" % pkg.get("id"))
    free = disk_free_mb()
    need = int(pkg.get("min_free_mb") or 50)
    if free < need:
        raise RuntimeError("磁盘不足: free=%sMB need=%sMB" % (free, need))
    dest = os.path.join(STAGING, os.path.basename(pkg.get("url") or pkg["id"]))
    with open(dest, "wb") as f:
        f.write(data)
    _set_state(progress=0.45, message="校验完成")
    return dest, digest


def _install_panel(pkg, archive_path):
    local_ver = load_versions().get("panel", "unknown")
    _backup_kind("panel", local_ver)
    _set_state(phase="install", message="安装面板…", progress=0.55)
    persist = set(pkg.get("persistent_globs") or [])
    # extract to temp then copy
    tmp = tempfile.mkdtemp(prefix="ncpsky_panel_")
    try:
        with zipfile.ZipFile(archive_path, "r") as zf:
            zf.extractall(tmp)
        # zip root may be ncpsky-panel/ or flat
        root = tmp
        nested = os.path.join(tmp, "ncpsky-panel")
        if os.path.isdir(nested):
            root = nested
        for name in os.listdir(root):
            if name in ("ota", "settings.json"):
                # merge carefully
                continue
            src = os.path.join(root, name)
            dst = os.path.join(PANEL_ROOT, name)
            if os.path.isdir(src):
                if os.path.exists(dst):
                    # replace tree but keep ota backups if name==something
                    shutil.rmtree(dst)
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)
        # VERSION file
        ver_src = os.path.join(root, "VERSION")
        if os.path.exists(ver_src):
            shutil.copy2(ver_src, os.path.join(PANEL_ROOT, "VERSION"))
        save_versions({"panel": pkg.get("version") or _read_panel_version()})
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    _set_state(progress=0.85, message="重启面板…")
    _restart_panel()


def _install_stack(pkg, archive_path):
    local_ver = load_versions().get("stack", "unknown")
    _backup_kind("stack", local_ver)
    _set_state(phase="install", message="安装主机栈…", progress=0.55)
    tmp = tempfile.mkdtemp(prefix="ncpsky_stack_")
    try:
        with zipfile.ZipFile(archive_path, "r") as zf:
            zf.extractall(tmp)
        root = tmp
        for cand in ("stack", "ncpsky-stack"):
            if os.path.isdir(os.path.join(tmp, cand)):
                root = os.path.join(tmp, cand)
                break
        # macros / templates → printer_data/config
        cfg_dst = "/home/pi/printer_data/config"
        for sub in ("macros", "config_templates", "config"):
            src_dir = os.path.join(root, sub)
            if not os.path.isdir(src_dir):
                continue
            for fn in os.listdir(src_dir):
                if not (fn.endswith(".cfg") or fn.endswith(".conf")):
                    continue
                # never overwrite printer.cfg wholesale
                if fn == "printer.cfg":
                    continue
                shutil.copy2(os.path.join(src_dir, fn), os.path.join(cfg_dst, fn))
        # optional klipper/moonraker trees
        for name, dest in (("klipper", "/home/pi/klipper"), ("moonraker", "/home/pi/moonraker")):
            src = os.path.join(root, name)
            if os.path.isdir(src):
                # replace code dirs but keep env
                for item in os.listdir(src):
                    if item in (".git", "klippy-env", ".venv"):
                        continue
                    s = os.path.join(src, item)
                    d = os.path.join(dest, item)
                    if os.path.isdir(s):
                        if os.path.exists(d):
                            shutil.rmtree(d)
                        shutil.copytree(s, d)
                    else:
                        shutil.copy2(s, d)
        ver_patch = {"stack": pkg.get("version")}
        meta_path = os.path.join(root, "META.json")
        if os.path.exists(meta_path):
            try:
                meta = _load_json(meta_path, {})
                if meta.get("klipper_core"):
                    ver_patch["klipper_core"] = meta["klipper_core"]
                if meta.get("klipper_custom"):
                    ver_patch["klipper_custom"] = meta["klipper_custom"]
                if meta.get("mcu"):
                    ver_patch["mcu"] = meta["mcu"]
            except Exception:
                pass
        save_versions(ver_patch)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    _set_state(progress=0.85, message="重启 Klipper…")
    restart = pkg.get("restart") or "klipper"
    if restart == "moonraker":
        _restart_service("moonraker")
    else:
        _firmware_restart()


def _install_system(pkg, list_path):
    _set_state(phase="install", message="安装系统包…", progress=0.55)
    # file format: one "name=version" or "name" per line, # comments
    pkgs = []
    with open(list_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            pkgs.append(line)
    if not pkgs:
        raise RuntimeError("empty system package list")
    cmd = ["bash", "-lc", "DEBIAN_FRONTEND=noninteractive apt-get install -y --allow-downgrades %s"
           % " ".join(pkgs)]
    # may need sudo
    try:
        subprocess.check_call(
            ["sudo", "-n"] + cmd[0:1] + cmd[1:],
            timeout=1800,
        )
    except Exception:
        subprocess.check_call(
            ["bash", "-lc", "echo 1 | sudo -S DEBIAN_FRONTEND=noninteractive apt-get install -y --allow-downgrades "
             + " ".join(pkgs)],
            timeout=1800,
        )
    save_versions({"system": pkg.get("version")})
    _set_state(progress=0.9, message="系统包已安装，建议重启")


def _install_mcu(pkg, bin_path, confirmed=False):
    if not confirmed and not pkg.get("auto", False):
        _set_state(
            phase="await_mcu_confirm",
            message="等待确认刷写 MCU",
            progress=0.5,
            confirm_mcu=pkg,
        )
        return {"await_confirm": True}
    local_ver = load_versions().get("mcu", "unknown")
    _backup_kind("mcu", local_ver)
    _set_state(phase="install", message="刷写 MCU…", progress=0.6, confirm_mcu=None)
    os.makedirs("/home/pi/klipper/out", exist_ok=True)
    dest = "/home/pi/klipper/out/klipper.bin"
    shutil.copy2(bin_path, dest)
    # Prefer make flash if serial known
    serial = "/dev/serial/by-id/usb-1a86_USB_Serial-if00-port0"
    flash_ok = False
    err = ""
    try:
        # sdflash / make flash FLASH_DEVICE=
        r = subprocess.run(
            ["bash", "-lc",
             "cd /home/pi/klipper && make flash FLASH_DEVICE=%s" % serial],
            capture_output=True, text=True, timeout=300,
        )
        flash_ok = r.returncode == 0
        if not flash_ok:
            err = (r.stderr or r.stdout or "flash failed")[-500:]
    except Exception as ex:
        err = str(ex)
    if not flash_ok:
        # keep bin in place for manual retry
        raise RuntimeError("MCU 刷写失败: %s（bin 已保存至 %s）" % (err, dest))
    save_versions({"mcu": pkg.get("version")})
    _firmware_restart()
    return {"await_confirm": False}


def _restart_panel():
    subprocess.Popen(
        ["bash", "-lc",
         "sleep 1; echo 1 | sudo -S killall -9 ncpsky-panel qmlscene 2>/dev/null; "
         "echo 1 | sudo -S rm -f /tmp/ncpsky-panel.lock; "
         "echo 1 | sudo -S bash -c 'nohup /home/pi/qt/out_linux/startboot.sh >/tmp/ncpsky-panel.out 2>&1 &'"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )


def _restart_service(name):
    subprocess.call(
        ["bash", "-lc", "echo 1 | sudo -S systemctl restart %s" % name],
        timeout=60,
    )


def _firmware_restart():
    try:
        data = json.dumps({}).encode()
        req = Request(
            MOONRAKER + "/printer/firmware_restart",
            data=data,
            method="POST",
            headers={"Content-Type": "application/json"},
        )
        urlopen(req, timeout=30).read()
    except Exception:
        _restart_service("klipper")


def _run_upgrade_job(package_ids, confirm_mcu=False):
    cfg = load_config()
    st = get_runtime_state()
    available = {p.get("id"): p for p in (st.get("available") or [])}
    # if empty, re-check
    if not available:
        chk = check_updates(cfg)
        if not chk.get("ok"):
            _set_state(busy=False, phase="idle", error=chk.get("error") or "check failed")
            return
        available = {p.get("id"): p for p in (chk.get("available") or [])}

    pkgs = []
    for pid in package_ids:
        if pid in available:
            pkgs.append(available[pid])
        else:
            # allow full package dict passed via confirm
            if isinstance(pid, dict):
                pkgs.append(pid)

    if not pkgs:
        _set_state(busy=False, phase="idle", error="没有可升级的包")
        return

    if moonraker_print_busy():
        _set_state(busy=False, phase="idle", error="打印中禁止升级")
        return

    release_assets = st.get("release_assets")
    _set_state(busy=True, error="", progress=0.05)
    try:
        for pkg in pkgs:
            if pkg.get("requires_idle", True) and moonraker_print_busy():
                raise RuntimeError("打印中禁止升级")
            kind = pkg.get("kind")
            path, digest = _download_package(pkg, cfg, release_assets=release_assets)
            if kind == "panel":
                _install_panel(pkg, path)
            elif kind == "stack":
                _install_stack(pkg, path)
            elif kind == "system":
                _install_system(pkg, path)
            elif kind == "mcu":
                res = _install_mcu(pkg, path, confirmed=confirm_mcu or bool(pkg.get("auto")))
                if res and res.get("await_confirm"):
                    _set_state(busy=False)
                    _append_history({
                        "ts": _utc_now(), "action": "await_mcu", "package": pkg.get("id"), "ok": True
                    })
                    return
            else:
                raise RuntimeError("unknown kind %s" % kind)
            _append_history({
                "ts": _utc_now(),
                "action": "upgrade",
                "package": pkg.get("id"),
                "kind": kind,
                "version": pkg.get("version"),
                "sha256": digest,
                "ok": True,
            })
        _set_state(busy=False, phase="done", progress=1.0, message="更新完成", current_package=None)
    except Exception as ex:
        LOG.exception("upgrade failed")
        _append_history({
            "ts": _utc_now(),
            "action": "upgrade",
            "ok": False,
            "error": str(ex),
        })
        _set_state(busy=False, phase="error", error=str(ex), progress=0, message="")


def start_upgrade(packages, confirm_mcu=False):
    st = get_runtime_state()
    if st.get("busy"):
        return {"ok": False, "error": "已有更新任务进行中"}
    if moonraker_print_busy():
        return {"ok": False, "error": "打印中禁止升级"}
    ids = packages or []
    t = threading.Thread(target=_run_upgrade_job, args=(ids, confirm_mcu), daemon=True)
    t.start()
    return {"ok": True, "started": True}


def confirm_mcu_flash():
    st = get_runtime_state()
    pkg = st.get("confirm_mcu")
    if not pkg:
        return {"ok": False, "error": "没有待确认的 MCU 包"}
    # Pass full package dict so upgrade works even if available list was cleared
    return start_upgrade([pkg], confirm_mcu=True)


# init on import
try:
    _ensure_dirs()
except Exception:
    pass
