import QtQuick 2.15
import ".."

// One heater channel: big readout + target progress + preset chips
Item {
    id: root
    property string title: ""
    property real current: 0
    property real target: 0
    property color accent: Theme.accent
    property var presets: []  // [{label, value}]
    property bool showDivider: false

    signal setTemp(real value)

    readonly property bool heating: target > 0 && current < target - 1.5
    readonly property bool cooling: target > 0 && current > target + 2.5
    readonly property bool holding: target > 0 && !heating && !cooling
    readonly property real progress: {
        if (target <= 0) return 0
        var t = Math.max(1, target)
        return Math.max(0, Math.min(1, current / t))
    }
    readonly property string stateText: {
        if (target <= 0) return AppState.tr("device.off")
        if (heating) return AppState.language === "en" ? "Heating" : "加热中"
        if (cooling) return AppState.language === "en" ? "Cooling" : "冷却中"
        return AppState.language === "en" ? "Hold" : "恒温"
    }

    Rectangle {
        visible: root.showDivider
        anchors.left: parent.left
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        anchors.topMargin: 10
        anchors.bottomMargin: 10
        width: 1
        color: Theme.lineSoft
    }

    Column {
        anchors.fill: parent
        anchors.leftMargin: root.showDivider ? 14 : 12
        anchors.rightMargin: 10
        anchors.topMargin: 10
        anchors.bottomMargin: 10
        spacing: 6

        Row {
            width: parent.width
            spacing: 8
            Text {
                text: root.title
                color: Theme.textMute
                font.pixelSize: Theme.fontSmall
                font.letterSpacing: 0.6
            }
            Rectangle {
                anchors.verticalCenter: parent.verticalCenter
                visible: root.target > 0
                width: 6
                height: 6
                radius: 3
                color: root.heating ? root.accent
                     : (root.cooling ? Theme.warn : Theme.accent)
                opacity: root.holding ? 0.55 : (0.75 + 0.25 * root.phase)
            }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: root.stateText
                color: root.target > 0 ? root.accent : Theme.textMute
                font.pixelSize: Theme.fontSmall
                opacity: root.target > 0 ? 0.9 : 0.7
            }
        }

        Row {
            spacing: 8
            Text {
                id: bigTemp
                text: Math.round(root.current) + "°"
                color: root.target > 0 ? root.accent : Theme.textPrimary
                font.pixelSize: 34
                font.family: Theme.fontFamily
                font.weight: Theme.fontWeight
                font.letterSpacing: -0.5
            }
            Column {
                anchors.bottom: parent.bottom
                anchors.bottomMargin: 6
                spacing: 1
                Text {
                    text: root.target > 0
                          ? ("→ " + Math.round(root.target) + "°")
                          : " "
                    color: Theme.textSecondary
                    font.pixelSize: Theme.fontBody
                }
            }
        }

        Item {
            width: parent.width
            height: 4
            Rectangle {
                anchors.fill: parent
                radius: 2
                color: "#1A1F24"
            }
            Rectangle {
                width: parent.width * root.progress
                height: parent.height
                radius: 2
                color: root.accent
                opacity: root.target > 0 ? 0.85 : 0.15
                Behavior on width { NumberAnimation { duration: 280 } }
            }
        }

        Item { width: 1; height: 2 }

        // 2×2 preset grid — even, no Flow wrap surprises
        Grid {
            width: parent.width
            columns: 2
            rowSpacing: 6
            columnSpacing: 6
            Repeater {
                model: root.presets
                delegate: Item {
                    width: (parent.width - 6) / 2
                    height: 36
                    property bool on: Math.round(root.target) === Math.round(modelData.value)
                    Rectangle {
                        anchors.fill: parent
                        radius: Theme.radius
                        color: {
                            if (chipTouch.pressed) return Theme.bgTilePressed
                            if (on) return Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.18)
                            return Theme.bgTile
                        }
                        border.width: on ? 0 : 1
                        border.color: Theme.lineSoft
                    }
                    Text {
                        anchors.centerIn: parent
                        width: parent.width - 6
                        horizontalAlignment: Text.AlignHCenter
                        elide: Text.ElideRight
                        text: modelData.label
                        color: on ? root.accent : Theme.textSecondary
                        font.pixelSize: Theme.fontSmall
                        font.weight: on ? Theme.fontWeight : Theme.fontWeight
                    }
                    TouchArea {
                        id: chipTouch
                        anchors.fill: parent
                        onClicked: root.setTemp(modelData.value)
                    }
                }
            }
        }
    }

    property real _pulseT: 0
    readonly property real phase: 0.5 + 0.5 * Math.sin(root._pulseT)
    Timer {
        interval: 80
        running: root.visible && (root.heating || root.cooling)
        repeat: true
        onTriggered: root._pulseT += 0.35
    }
}
