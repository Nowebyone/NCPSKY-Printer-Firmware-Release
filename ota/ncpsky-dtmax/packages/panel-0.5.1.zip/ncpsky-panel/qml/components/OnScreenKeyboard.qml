import QtQuick 2.15
import ".."

Item {
    id: kb
    anchors.fill: parent
    visible: open
    z: 200

    property bool open: false
    property string title: ""
    property string text: ""
    property bool password: false
    property bool multilineHint: false
    property var _rowsLower: [
        ["1","2","3","4","5","6","7","8","9","0"],
        ["q","w","e","r","t","y","u","i","o","p"],
        ["a","s","d","f","g","h","j","k","l"],
        ["z","x","c","v","b","n","m",".","/",":"]
    ]
    property var _rowsUpper: [
        ["!","@","#","$","%","^","&","*","(",")"],
        ["Q","W","E","R","T","Y","U","I","O","P"],
        ["A","S","D","F","G","H","J","K","L"],
        ["Z","X","C","V","B","N","M","-","_","="]
    ]
    property bool shift: false
    property bool symbols: false

    signal accepted(string value)
    signal cancelled()

    function show(opts) {
        opts = opts || {}
        title = opts.title || ""
        text = opts.text || ""
        password = !!opts.password
        shift = false
        symbols = false
        open = true
        AppState.pageLocked = true
    }

    function hide(commit) {
        open = false
        AppState.pageLocked = AppState.otaBusy || !!AppState.otaConfirmMcu
        if (commit)
            accepted(text)
        else
            cancelled()
    }

    function _rows() {
        return shift ? _rowsUpper : _rowsLower
    }

    Rectangle {
        anchors.fill: parent
        color: "#E0080A0B"
        MouseArea {
            anchors.fill: parent
            onClicked: { /* swallow */ }
        }
    }

    Rectangle {
        id: card
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.margins: 4
        height: Math.min(parent.height - 4, 210)
        radius: Theme.radiusLg
        color: Theme.bgElevated
        border.width: 1
        border.color: Theme.line

        Column {
            anchors.fill: parent
            anchors.margins: 6
            spacing: 4

            Row {
                width: parent.width
                spacing: 6
                Text {
                    text: kb.title
                    color: Theme.textPrimary
                    font.pixelSize: Theme.fontSmall
                    font.family: Theme.fontFamily
                    font.weight: Theme.fontWeight
                    width: parent.width - 120
                    elide: Text.ElideRight
                }
                PrimaryButton {
                    text: AppState.tr("kb.cancel")
                    primary: false
                    height: 28
                    width: 52
                    onClicked: kb.hide(false)
                }
                PrimaryButton {
                    text: AppState.tr("kb.ok")
                    height: 28
                    width: 52
                    onClicked: kb.hide(true)
                }
            }

            Rectangle {
                width: parent.width
                height: 28
                radius: Theme.radius
                color: Theme.bg
                border.width: 1
                border.color: Theme.line
                Text {
                    anchors.fill: parent
                    anchors.margins: 6
                    text: kb.password
                          ? (kb.text.length ? Array(Math.min(kb.text.length, 24) + 1).join("•") : AppState.tr("kb.placeholder"))
                          : (kb.text.length ? kb.text : AppState.tr("kb.placeholder"))
                    color: kb.text.length ? Theme.textPrimary : Theme.textMute
                    font.pixelSize: Theme.fontBody
                    elide: Text.ElideLeft
                    verticalAlignment: Text.AlignVCenter
                }
            }

            Repeater {
                model: kb._rows()
                Row {
                    property var rowKeys: modelData
                    spacing: 3
                    anchors.horizontalCenter: parent.horizontalCenter
                    Repeater {
                        model: rowKeys
                        PadKey {
                            text: modelData
                            width: 34
                            height: 28
                            onClicked: kb.text = kb.text + modelData
                        }
                    }
                }
            }

            Row {
                spacing: 4
                anchors.horizontalCenter: parent.horizontalCenter
                PadKey {
                    text: kb.shift ? "abc" : "ABC"
                    width: 44
                    height: 28
                    primary: true
                    onClicked: kb.shift = !kb.shift
                }
                PadKey {
                    text: "空格"
                    width: 120
                    height: 28
                    onClicked: kb.text = kb.text + " "
                }
                PadKey {
                    text: "删"
                    width: 44
                    height: 28
                    primary: true
                    onClicked: {
                        if (kb.text.length)
                            kb.text = kb.text.substring(0, kb.text.length - 1)
                    }
                }
                PadKey {
                    text: "清"
                    width: 36
                    height: 28
                    onClicked: kb.text = ""
                }
            }
        }
    }
}
