import QtQuick 2.15
import QtQuick.Window 2.15
import "."
import "components"
import "pages"

Window {
    id: root
    width: Theme.screenW
    height: Theme.screenH
    visible: true
    visibility: Window.FullScreen
    color: Theme.bg
    title: "NCPSKY ▲ DTMax"
    flags: Qt.FramelessWindowHint | Qt.Window

    // Bare Window has no font prop — pin app default to the Bold CJK face in FONDIR
    Component.onCompleted: {
        Qt.application.font.family = Theme.fontFamily
        Qt.application.font.weight = Theme.fontWeight
    }

    // Soft brand wash — one composition
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#12101A" }
            GradientStop { position: 0.55; color: Theme.bg }
            GradientStop { position: 1.0; color: Theme.bg }
        }
    }
    Rectangle {
        width: 220
        height: 220
        radius: 110
        x: parent.width - 140
        y: -80
        color: Theme.accent
        opacity: 0.045
    }

    Rectangle {
        id: banner
        z: 50
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        height: AppState.connected ? 0 : 22
        color: Theme.danger
        visible: height > 0
        Behavior on height { NumberAnimation { duration: Theme.animFast } }
        Text {
            anchors.centerIn: parent
            text: "连接中断，正在重连…"
            color: "#fff"
            font.pixelSize: Theme.fontSmall
            visible: parent.height > 0
        }
    }

    Item {
        id: shell
        anchors.fill: parent
        anchors.topMargin: banner.height
        // Rise in as Splash crossfades out
        opacity: AppState.splashDone ? 1 : 0
        scale: AppState.splashDone ? 1 : 0.97
        transformOrigin: Item.Center
        Behavior on opacity { NumberAnimation { duration: 480; easing.type: Easing.OutCubic } }
        Behavior on scale { NumberAnimation { duration: 520; easing.type: Easing.OutCubic } }

        Row {
            anchors.fill: parent

            NavRail {
                id: nav
                height: parent.height
                // Only hide after calibration run starts (not on confirm dialog)
                width: AppState.calibrating ? 0 : Theme.navW
                visible: !AppState.calibrating
                enabled: !AppState.calibrating && !AppState.pageLocked
                         && !AppState.printSessionActive()
                clip: true
                Behavior on width { NumberAnimation { duration: Theme.animPage } }
            }

            Column {
                width: parent.width - nav.width
                height: parent.height

                TopBar {
                    id: top
                    width: parent.width
                }

                Item {
                    id: content
                    width: parent.width
                    height: parent.height - top.height

                    HomePage {
                        anchors.fill: parent
                        visible: AppState.page === "home"
                        opacity: visible ? 1 : 0
                        Behavior on opacity { NumberAnimation { duration: Theme.animPage } }
                    }
                    ControlsPage {
                        anchors.fill: parent
                        visible: AppState.page === "device"
                        opacity: visible ? 1 : 0
                        Behavior on opacity { NumberAnimation { duration: Theme.animPage } }
                    }
                    FilamentPage {
                        anchors.fill: parent
                        visible: AppState.page === "filament"
                        opacity: visible ? 1 : 0
                        Behavior on opacity { NumberAnimation { duration: Theme.animPage } }
                    }
                    CalibratePage {
                        anchors.fill: parent
                        visible: AppState.page === "calibrate"
                        opacity: visible ? 1 : 0
                        Behavior on opacity { NumberAnimation { duration: Theme.animPage } }
                    }
                    SettingsPage {
                        anchors.fill: parent
                        visible: AppState.page === "settings"
                        opacity: visible ? 1 : 0
                        Behavior on opacity { NumberAnimation { duration: Theme.animPage } }
                    }
                    HmsPage {
                        anchors.fill: parent
                        visible: AppState.page === "alerts"
                        opacity: visible ? 1 : 0
                        Behavior on opacity { NumberAnimation { duration: Theme.animPage } }
                    }
                    FilesPage {
                        anchors.fill: parent
                        visible: AppState.page === "files"
                        opacity: visible ? 1 : 0
                        Behavior on opacity { NumberAnimation { duration: Theme.animPage } }
                    }
                    PrintPage {
                        anchors.fill: parent
                        visible: AppState.page === "print"
                        opacity: visible ? 1 : 0
                        Behavior on opacity { NumberAnimation { duration: Theme.animPage } }
                    }
                }
            }
        }
    }

    MessageToast {
        id: msgToast
        anchors.fill: parent
    }

    Connections {
        target: AppState
        function onHmsPushed(item) { msgToast.enqueue(item) }
        function onToast(msg) {
            msgToast.enqueue({
                severity: "info",
                title: "",
                message: msg
            })
        }
    }

    Splash {
        anchors.fill: parent
    }

}
