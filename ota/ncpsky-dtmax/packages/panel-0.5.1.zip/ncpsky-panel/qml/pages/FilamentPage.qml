import QtQuick 2.15
import "../components"
import ".."

Item {
    id: page
    property int step: 0
    property string action: "load"  // load | unload

    Column {
        anchors.fill: parent
        anchors.margins: 14
        spacing: 10

        PageHeader {
            title: "耗材"
            subtitle: page.step === 0 ? "更换或装入耗材"
                     : page.step === 1 ? "正在预热喷嘴…"
                     : (page.action === "load" ? "请将耗材插入，直到咬入" : "请抽出耗材")
            width: parent.width
        }

        InsetPanel {
            width: parent.width
            height: 54
            Row {
                anchors.fill: parent
                Item {
                    width: parent.width / 3
                    height: parent.height
                    Column {
                        anchors.centerIn: parent
                        spacing: 2
                        Text { anchors.horizontalCenter: parent.horizontalCenter; text: "当前"; color: Theme.textMute; font.pixelSize: Theme.fontSmall }
                        Text { anchors.horizontalCenter: parent.horizontalCenter; text: AppState.filamentType; color: Theme.textPrimary; font.family: Theme.fontFamily; font.pixelSize: 16; font.weight: Theme.fontWeight }
                    }
                }
                Rectangle { anchors.verticalCenter: parent.verticalCenter; width: 1; height: 24; color: Theme.lineSoft }
                Item {
                    width: parent.width / 3
                    height: parent.height
                    Column {
                        anchors.centerIn: parent
                        spacing: 2
                        Text { anchors.horizontalCenter: parent.horizontalCenter; text: "建议温度"; color: Theme.textMute; font.pixelSize: Theme.fontSmall }
                        Text { anchors.horizontalCenter: parent.horizontalCenter; text: AppState.filamentTemp + "°"; color: Theme.accent; font.family: Theme.fontFamily; font.pixelSize: 16; font.weight: Theme.fontWeight }
                    }
                }
                Rectangle { anchors.verticalCenter: parent.verticalCenter; width: 1; height: 24; color: Theme.lineSoft }
                Item {
                    width: parent.width / 3 - 2
                    height: parent.height
                    Column {
                        anchors.centerIn: parent
                        spacing: 2
                        Text { anchors.horizontalCenter: parent.horizontalCenter; text: "喷嘴"; color: Theme.textMute; font.pixelSize: Theme.fontSmall }
                        Text { anchors.horizontalCenter: parent.horizontalCenter; text: Math.round(AppState.extruderTemp) + "°"; color: Theme.textPrimary; font.family: Theme.fontFamily; font.pixelSize: 16; font.weight: Theme.fontWeight }
                    }
                }
            }
        }

        Text {
            visible: page.step === 0
            text: "材料类型"
            color: Theme.textMute
            font.pixelSize: Theme.fontSmall
        }
        Row {
            visible: page.step === 0
            spacing: 8
            SegButton { text: "PLA"; height: 38; width: 56; active: AppState.filamentType === "PLA"; onClicked: { AppState.filamentType = "PLA"; AppState.filamentTemp = 210 } }
            SegButton { text: "PETG"; height: 38; width: 60; active: AppState.filamentType === "PETG"; onClicked: { AppState.filamentType = "PETG"; AppState.filamentTemp = 240 } }
            SegButton { text: "ABS"; height: 38; width: 56; active: AppState.filamentType === "ABS"; onClicked: { AppState.filamentType = "ABS"; AppState.filamentTemp = 250 } }
            SegButton { text: "TPU"; height: 38; width: 56; active: AppState.filamentType === "TPU"; onClicked: { AppState.filamentType = "TPU"; AppState.filamentTemp = 220 } }
        }

        Row {
            spacing: 10
            visible: page.step === 0
            PrimaryButton {
                text: "装入耗材"
                width: 120
                height: Theme.touchMin - 4
                onClicked: {
                    page.action = "load"
                    page.step = 1
                    AppState.setExtruderTemp(AppState.filamentTemp)
                    AppState.gcode("M302 P1")
                }
            }
            PrimaryButton {
                text: "退出耗材"
                primary: false
                width: 120
                height: Theme.touchMin - 4
                onClicked: {
                    page.action = "unload"
                    page.step = 1
                    AppState.setExtruderTemp(AppState.filamentTemp)
                    AppState.gcode("M302 P1")
                }
            }
        }

        Row {
            spacing: 10
            visible: page.step > 0
            PrimaryButton {
                text: page.step === 1 ? "已预热，继续" : "完成"
                width: 140
                height: Theme.touchMin - 4
                onClicked: {
                    if (page.step === 1) {
                        AppState.extrude(page.action === "load" ? 50 : -50)
                        page.step = 2
                    } else {
                        page.step = 0
                        AppState.setExtruderTemp(0)
                    }
                }
            }
            PrimaryButton {
                text: "取消"
                danger: true
                height: Theme.touchMin - 4
                onClicked: {
                    page.step = 0
                    AppState.setExtruderTemp(0)
                }
            }
        }
    }
}
