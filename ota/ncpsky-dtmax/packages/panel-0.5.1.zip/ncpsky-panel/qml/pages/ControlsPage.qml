import QtQuick 2.15
import "../components"
import ".."

// C-端「设备」页 — 一屏可用，不依赖滚动
Item {
    id: page
    property real moveStep: 10
    property string section: "temp"  // temp | move | extrude

    Column {
        anchors.fill: parent
        anchors.leftMargin: 10
        anchors.rightMargin: 10
        anchors.topMargin: 4
        anchors.bottomMargin: 6
        spacing: 6

        // 标题 + 分段同一行，省掉独立 PageHeader 高度
        Row {
            width: parent.width
            height: 34
            spacing: 10

            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: AppState.tr("device.title")
                color: Theme.textPrimary
                font.pixelSize: Theme.fontTitle
                font.family: Theme.fontFamily
                font.weight: Theme.fontWeight
                font.letterSpacing: 0.4
            }

            Item { width: 4; height: 1 }

            SegButton {
                text: AppState.tr("device.temp")
                width: 64
                height: 32
                active: page.section === "temp"
                onClicked: page.section = "temp"
            }
            SegButton {
                text: AppState.tr("device.move")
                width: 64
                height: 32
                active: page.section === "move"
                onClicked: page.section = "move"
            }
            SegButton {
                text: AppState.tr("device.extrude")
                width: 64
                height: 32
                active: page.section === "extrude"
                onClicked: page.section = "extrude"
            }
        }

        // 内容区填满剩余高度
        Item {
            width: parent.width
            height: parent.height - 40

            // —— 温度：单井双通道，读数 + 进度 + 预设 ——
            InsetPanel {
                anchors.fill: parent
                visible: page.section === "temp"

                Row {
                    anchors.fill: parent
                    TempChannel {
                        width: parent.width / 2
                        height: parent.height
                        title: AppState.tr("device.nozzle")
                        current: AppState.extruderTemp
                        target: AppState.extruderTarget
                        accent: Theme.accent
                        presets: [
                            { label: AppState.tr("device.off"), value: 0 },
                            { label: AppState.tr("device.preset.pla"), value: 210 },
                            { label: AppState.tr("device.preset.petg"), value: 240 },
                            { label: AppState.tr("device.preset.abs"), value: 250 }
                        ]
                        onSetTemp: AppState.setExtruderTemp(value)
                    }
                    TempChannel {
                        width: parent.width / 2
                        height: parent.height
                        title: AppState.tr("device.bed")
                        current: AppState.bedTemp
                        target: AppState.bedTarget
                        accent: Theme.warn
                        showDivider: true
                        presets: [
                            { label: AppState.tr("device.off"), value: 0 },
                            { label: AppState.tr("device.bed.pla"), value: 60 },
                            { label: AppState.tr("device.bed.petg"), value: 80 },
                            { label: AppState.tr("device.bed.abs"), value: 100 }
                        ]
                        onSetTemp: AppState.setBedTemp(value)
                    }
                }
            }

            // —— 移动：摇杆 + 升降/步距并排 ——
            Row {
                anchors.fill: parent
                spacing: 10
                visible: page.section === "move"

                InsetPanel {
                    width: Math.min(196, parent.width * 0.48)
                    height: parent.height
                    Column {
                        anchors.centerIn: parent
                        spacing: 4
                        Row {
                            spacing: 4
                            Item { width: 48; height: 1 }
                            PadKey {
                                text: AppState.tr("device.front")
                                width: 48
                                height: 42
                                onClicked: AppState.moveAxis("Y", page.moveStep)
                            }
                        }
                        Row {
                            spacing: 4
                            PadKey {
                                text: AppState.tr("device.left")
                                width: 48
                                height: 42
                                onClicked: AppState.moveAxis("X", -page.moveStep)
                            }
                            PadKey {
                                text: AppState.tr("device.xyz.home")
                                width: 48
                                height: 42
                                primary: true
                                onClicked: AppState.homeAll()
                            }
                            PadKey {
                                text: AppState.tr("device.right")
                                width: 48
                                height: 42
                                onClicked: AppState.moveAxis("X", page.moveStep)
                            }
                        }
                        Row {
                            spacing: 4
                            Item { width: 48; height: 1 }
                            PadKey {
                                text: AppState.tr("device.back")
                                width: 48
                                height: 42
                                onClicked: AppState.moveAxis("Y", -page.moveStep)
                            }
                        }
                    }
                }

                Column {
                    width: parent.width - Math.min(196, parent.width * 0.48) - 10
                    height: parent.height
                    spacing: 8

                    Text {
                        text: AppState.tr("device.step")
                        color: Theme.textMute
                        font.pixelSize: Theme.fontSmall
                    }
                    Row {
                        spacing: 6
                        PadKey {
                            text: AppState.tr("device.up")
                            width: 56
                            height: 40
                            onClicked: AppState.moveAxis("Z", page.moveStep)
                        }
                        PadKey {
                            text: AppState.tr("device.down")
                            width: 56
                            height: 40
                            onClicked: AppState.moveAxis("Z", -page.moveStep)
                        }
                    }
                    Row {
                        spacing: 6
                        SegButton {
                            text: "1"
                            width: 44
                            height: 34
                            active: page.moveStep === 1
                            onClicked: page.moveStep = 1
                        }
                        SegButton {
                            text: "10"
                            width: 44
                            height: 34
                            active: page.moveStep === 10
                            onClicked: page.moveStep = 10
                        }
                        SegButton {
                            text: "50"
                            width: 44
                            height: 34
                            active: page.moveStep === 50
                            onClicked: page.moveStep = 50
                        }
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            text: "mm"
                            color: Theme.textMute
                            font.pixelSize: Theme.fontSmall
                        }
                    }
                    Item { width: 1; height: 4 }
                    PrimaryButton {
                        text: AppState.tr("device.homeall")
                        primary: false
                        width: parent.width
                        height: 36
                        onClicked: AppState.homeAll()
                    }
                }
            }

            // —— 出料 ——
            Column {
                anchors.fill: parent
                spacing: 10
                visible: page.section === "extrude"

                Text {
                    width: parent.width
                    text: AppState.tr("device.extrude.hint")
                    color: Theme.textSecondary
                    font.pixelSize: Theme.fontBody
                    wrapMode: Text.Wrap
                }
                Row {
                    spacing: 8
                    PrimaryButton {
                        text: AppState.tr("device.extrude10")
                        width: 118
                        height: 44
                        onClicked: AppState.extrude(10)
                    }
                    PrimaryButton {
                        text: AppState.tr("device.retract10")
                        primary: false
                        width: 118
                        height: 44
                        onClicked: AppState.extrude(-10)
                    }
                    PrimaryButton {
                        text: AppState.tr("device.extrude50")
                        primary: false
                        width: 118
                        height: 44
                        onClicked: AppState.extrude(50)
                    }
                }
                Text {
                    text: AppState.tr("device.nozzle") + " " + Math.round(AppState.extruderTemp) + "°"
                           + (AppState.extruderTarget > 0
                              ? (" → " + Math.round(AppState.extruderTarget) + "°")
                              : (" · " + AppState.tr("device.notheated")))
                    color: AppState.extruderTarget > 0 ? Theme.accent : Theme.textMute
                    font.pixelSize: Theme.fontSmall
                }
            }
        }
    }
}
