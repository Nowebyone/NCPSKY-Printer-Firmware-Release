#!/usr/bin/env python3
"""
Apply L1 exclusive modules onto flsun-t1max as one commit (or per-file).
Does not touch the printer.
"""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "overlays" / "l1-exclusive"
DEST = ROOT / "klippy" / "extras"

FILES = [
    "box_light.py",
    "flsun_warning.py",
    "locate_printing_gcode.py",
    "power_loss_recover.py",
    "printer_workmode.py",
    "rotate_logger.py",
    "save_temp_variables.py",
]


def sh(*args: str) -> None:
    print("+", " ".join(args))
    subprocess.check_call(args, cwd=ROOT)


def main() -> None:
    branch = subprocess.check_output(
        ["git", "branch", "--show-current"], cwd=ROOT, text=True
    ).strip()
    if branch != "flsun-t1max":
        raise SystemExit(f"switch to flsun-t1max first (now on {branch})")

    DEST.mkdir(parents=True, exist_ok=True)
    added = []
    for name in FILES:
        src = SRC / name
        if not src.exists():
            raise SystemExit(f"missing overlay {src}")
        dst = DEST / name
        shutil.copy2(src, dst)
        sh("git", "add", str(dst.relative_to(ROOT).as_posix()))
        added.append(name)

    msg = (
        "feat(flsun): add exclusive extras (L1)\n"
        "\n"
        "Carry FLSun-only modules from T1 Max snapshot without upstream counterparts:\n"
        + "".join(f"- {n}\n" for n in added)
    )
    # Windows-friendly commit without bash heredoc
    subprocess.check_call(["git", "commit", "-m", msg], cwd=ROOT)
    print("committed L1 on", branch)


if __name__ == "__main__":
    main()
