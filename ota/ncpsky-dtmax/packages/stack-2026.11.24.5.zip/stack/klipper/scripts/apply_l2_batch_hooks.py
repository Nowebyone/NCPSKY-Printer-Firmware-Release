#!/usr/bin/env python3
"""Apply remaining portable FLSun L2 hooks onto tip tree (idempotent).

Skips: delta_split_offset FFI, x/y_size_offset C helper, /home/pi shell scripts,
       full RunoutDebounceHelper rewrite (adds lighter locate hooks instead).
"""
from __future__ import annotations

import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def patch(rel: str, old: str, new: str, label: str) -> bool:
    path = ROOT / rel
    text = path.read_text(encoding="utf-8")
    marker = f"flsun L2[{label}]"
    if marker in text:
        print("skip", label, "(already)")
        return False
    if old not in text:
        raise SystemExit(f"anchor missing for {label} in {rel}")
    if marker not in new:
        # inject marker into first flsun L2 comment or append as comment line
        new = new.replace("flsun L2:", f"flsun L2[{label}]:", 1)
        if marker not in new:
            # ensure marker exists somewhere in replacement
            new = new.rstrip("\n") + f"  # {marker}\n"
    path.write_bytes(text.replace(old, new, 1).encode("utf-8"))
    print("ok", label)
    return True


def main() -> None:
    changed = False

    # --- virtual_sdcard ---
    changed |= patch(
        "klippy/extras/virtual_sdcard.py",
        "        self.file_position = self.file_size = 0\n"
        "        # Print Stat Tracking\n",
        "        self.file_position = self.file_size = 0\n"
        "        self.power_loss_restart = 0  # flsun L2: power_loss\n"
        "        # Print Stat Tracking\n",
        "vsd-init",
    )
    changed |= patch(
        "klippy/extras/virtual_sdcard.py",
        "        self.current_file = f\n"
        "        self.file_position = 0\n"
        "        self.file_size = fsize\n"
        "        self.print_stats.set_current_file(filename)\n",
        "        self.current_file = f\n"
        "        # flsun L2: power_loss / START_PRINT\n"
        "        filepos = gcmd.get_int('FILE_POSITION', 0, minval=0)\n"
        "        self.file_position = filepos\n"
        "        self.file_size = fsize\n"
        "        self.print_stats.set_current_file(filename)\n"
        "        if self.file_position == 0:\n"
        "            self.power_loss_restart = 0\n"
        "            try:\n"
        "                self.gcode.run_script_from_command('START_PRINT')\n"
        "            except self.gcode.error:\n"
        "                logging.exception('virtual_sdcard START_PRINT')\n"
        "        else:\n"
        "            self.power_loss_restart = 1\n",
        "vsd-load",
    )
    changed |= patch(
        "klippy/extras/virtual_sdcard.py",
        "            self.work_timer = None\n"
        "            return self.reactor.NEVER\n"
        "        self.print_stats.note_start()\n"
        "        gcode_mutex = self.gcode.get_mutex()\n",
        "            self.work_timer = None\n"
        "            self.power_loss_restart = 0\n"
        "            return self.reactor.NEVER\n"
        "        self.print_stats.note_start()\n"
        "        # flsun L2: power_loss resume\n"
        "        if self.power_loss_restart:\n"
        "            self.power_loss_restart = 0\n"
        "            try:\n"
        "                self.gcode.run_script('F102')\n"
        "            except Exception:\n"
        "                logging.exception('virtual_sdcard F102 resume')\n"
        "                self.work_timer = None\n"
        "                self.print_stats.note_error('F102 resume failed')\n"
        "                return self.reactor.NEVER\n"
        "        gcode_mutex = self.gcode.get_mutex()\n"
        "        locate_printing_gcode = self.printer.lookup_object(\n"
        "            'locate_printing_gcode', None)\n",
        "vsd-resume",
    )
    changed |= patch(
        "klippy/extras/virtual_sdcard.py",
        "            try:\n"
        "                self.gcode.run_script(line)\n"
        "            except self.gcode.error as e:\n",
        "            try:\n"
        "                # flsun L2: locate_printing\n"
        "                if locate_printing_gcode is not None:\n"
        "                    locate_printing_gcode.record_gcode_begin(\n"
        "                        line, self.file_position)\n"
        "                self.gcode.run_script(line)\n"
        "                if locate_printing_gcode is not None:\n"
        "                    locate_printing_gcode.record_gcode_end()\n"
        "            except self.gcode.error as e:\n",
        "vsd-locate",
    )
    changed |= patch(
        "klippy/extras/virtual_sdcard.py",
        "        else:\n"
        "            self.print_stats.note_complete()\n"
        "        return self.reactor.NEVER\n",
        "        else:\n"
        "            self.print_stats.note_complete()\n"
        "            # flsun L2: END_PRINT\n"
        "            try:\n"
        "                self.gcode.run_script_from_command('END_PRINT')\n"
        "            except self.gcode.error:\n"
        "                logging.exception('virtual_sdcard END_PRINT')\n"
        "        return self.reactor.NEVER\n",
        "vsd-end",
    )

    # --- gcode_move ---
    changed |= patch(
        "klippy/extras/gcode_move.py",
        "    def _handle_ready(self):\n"
        "        self.is_printer_ready = True\n"
        "        if self.move_transform is None:\n",
        "    def _handle_ready(self):\n"
        "        self.is_printer_ready = True\n"
        "        # flsun L2: workmode\n"
        "        self.printer_workmode = self.printer.lookup_object(\n"
        "            'printer_workmode', None)\n"
        "        self.first_layer_detect = False\n"
        "        if self.move_transform is None:\n",
        "gmove-ready",
    )
    changed |= patch(
        "klippy/extras/gcode_move.py",
        "    def reset_last_position(self):\n"
        "        if self.is_printer_ready:\n"
        "            self.last_position = self.position_with_transform()\n",
        "    def set_first_layer_detect(self):\n"
        "        # flsun L2: called from G28\n"
        "        self.first_layer_detect = True\n"
        "    def reset_last_position(self):\n"
        "        if self.is_printer_ready:\n"
        "            self.last_position = self.position_with_transform()\n",
        "gmove-fld",
    )
    changed |= patch(
        "klippy/extras/gcode_move.py",
        "        except ValueError as e:\n"
        "            raise gcmd.error(\"Unable to parse move '%s'\"\n"
        "                             % (gcmd.get_commandline(),))\n"
        "        self.move_with_transform(self.last_position, self.speed)\n",
        "        except ValueError as e:\n"
        "            raise gcmd.error(\"Unable to parse move '%s'\"\n"
        "                             % (gcmd.get_commandline(),))\n"
        "        # flsun L2: M=3 pace limit for travel\n"
        "        if (self.printer_workmode is not None and 'E' not in params\n"
        "                and self.printer_workmode.get_workmode() == 3):\n"
        "            pace = getattr(self.printer_workmode, 'pace_speed', None)\n"
        "            if pace is not None and self.speed > pace:\n"
        "                self.speed = pace\n"
        "        self.move_with_transform(self.last_position, self.speed)\n",
        "gmove-pace",
    )

    # --- homing ---
    changed |= patch(
        "klippy/extras/homing.py",
        "    def cmd_G28(self, gcmd):\n"
        "        # Move to origin\n"
        "        axes = []\n",
        "    def cmd_G28(self, gcmd):\n"
        "        # Move to origin\n"
        "        # flsun L2: first layer detect\n"
        "        gcode_move = self.printer.lookup_object('gcode_move')\n"
        "        if hasattr(gcode_move, 'set_first_layer_detect'):\n"
        "            gcode_move.set_first_layer_detect()\n"
        "        axes = []\n",
        "homing-g28",
    )

    # --- display_status ---
    changed |= patch(
        "klippy/extras/display_status.py",
        "    def cmd_M117(self, gcmd):\n"
        "        msg = gcmd.get_raw_command_parameters() or None\n"
        "        self.message = msg\n",
        "    def cmd_M117(self, gcmd):\n"
        "        msg = gcmd.get_raw_command_parameters() or None\n"
        "        self.message = msg\n"
        "        # flsun L2: echo to web/console\n"
        "        if msg:\n"
        "            gcmd.respond_info(msg)\n",
        "display-m117",
    )

    # --- verify_heater ---
    changed |= patch(
        "klippy/extras/verify_heater.py",
        "        if self.heater_name == 'heater_bed':\n"
        "            default_gain_time = 60.\n"
        "        self.check_gain_time = config.getfloat(\n",
        "        if self.heater_name == 'heater_bed':\n"
        "            default_gain_time = 60.\n"
        "        if self.heater_name == 'extruder':  # flsun L2\n"
        "            self.hysteresis = 6\n"
        "            self.max_error = 150\n"
        "        self.check_gain_time = config.getfloat(\n",
        "verify-extruder",
    )

    # --- exclude_object ---
    changed |= patch(
        "klippy/extras/exclude_object.py",
        "        self.current_object = name\n"
        "        self.was_excluded_at_start = self._test_in_excluded_region()\n"
        "\n"
        "    cmd_EXCLUDE_OBJECT_END_help",
        "        self.current_object = name\n"
        "        self.was_excluded_at_start = self._test_in_excluded_region()\n"
        "        # flsun L2: delay when starting excluded object\n"
        "        if self.was_excluded_at_start:\n"
        "            reactor = self.printer.get_reactor()\n"
        "            reactor.pause(reactor.monotonic() + 0.02)\n"
        "\n"
        "    cmd_EXCLUDE_OBJECT_END_help",
        "exclude-delay",
    )

    # --- heaters ---
    changed |= patch(
        "klippy/extras/heaters.py",
        "        self.last_temp = self.smoothed_temp = self.target_temp = 0.\n"
        "        self.last_temp_time = 0.\n",
        "        self.last_temp = self.smoothed_temp = self.target_temp = 0.\n"
        "        self.last_temp_time = 0.\n"
        "        # flsun L2: temp warn flags\n"
        "        self.min_temp_warning = True\n"
        "        self.max_temp_warning = True\n",
        "heat-flags",
    )
    changed |= patch(
        "klippy/extras/heaters.py",
        "        is_active = target_temp or last_temp > 50.\n"
        "        return is_active, '%s: target=%.0f temp=%.1f pwm=%.3f' % (\n"
        "            self.short_name, target_temp, last_temp, last_pwm_value)\n",
        "        is_active = target_temp or last_temp > 50.\n"
        "        # flsun L2: soft min warn / hard max shutdown\n"
        "        if last_temp > self.min_temp and last_temp < self.max_temp:\n"
        "            self.min_temp_warning = True\n"
        "            self.max_temp_warning = True\n"
        "        if last_temp < self.min_temp and self.min_temp_warning:\n"
        "            flog = self.printer.lookup_object('rotate_logger', None)\n"
        "            if flog is not None:\n"
        "                flog.error(self.name + ' min temp warning', 'None',\n"
        "                           notify=True)\n"
        "            self.min_temp_warning = False\n"
        "        if last_temp > self.max_temp and self.max_temp_warning:\n"
        "            self.printer.invoke_shutdown(self.name + '  MAX TEMP')\n"
        "            self.max_temp_warning = False\n"
        "        return is_active, '%s: target=%.0f temp=%.1f pwm=%.3f' % (\n"
        "            self.short_name, target_temp, last_temp, last_pwm_value)\n",
        "heat-stats",
    )
    changed |= patch(
        "klippy/extras/heaters.py",
        "    def cmd_SET_HEATER_TEMPERATURE(self, gcmd):\n"
        "        temp = gcmd.get_float('TARGET', 0.)\n"
        "        pheaters = self.printer.lookup_object('heaters')\n"
        "        pheaters.set_temperature(self, temp)\n",
        "    def cmd_SET_HEATER_TEMPERATURE(self, gcmd):\n"
        "        temp = gcmd.get_float('TARGET', 0.)\n"
        "        wait = gcmd.get_int('WAIT', 0)  # flsun L2\n"
        "        if 'extruder' in self.name and temp > 0.5:\n"
        "            try:\n"
        "                self.printer.lookup_object('gcode').run_script_from_command(\n"
        "                    'relay_on')\n"
        "            except Exception:\n"
        "                pass\n"
        "        pheaters = self.printer.lookup_object('heaters')\n"
        "        pheaters.set_temperature(self, temp, wait=bool(wait))\n",
        "heat-set",
    )
    changed |= patch(
        "klippy/extras/heaters.py",
        "PID_SETTLE_DELTA = 1.\n",
        "PID_SETTLE_DELTA = 3.  # flsun L2\n",
        "heat-pid",
    )
    changed |= patch(
        "klippy/extras/heaters.py",
        "import os, logging, threading\n",
        "import os, logging, threading\n"
        "heat_break = 0  # flsun L2: interrupt heater wait\n",
        "heat-break-global",
    )
    changed |= patch(
        "klippy/extras/heaters.py",
        "        while not self.printer.is_shutdown() and heater.check_busy(eventtime):\n",
        "        global heat_break\n"
        "        # flsun L2: honor heat_break\n"
        "        while (not self.printer.is_shutdown()\n"
        "               and heater.check_busy(eventtime) and not heat_break):\n",
        "heat-wait",
    )

    # --- gcode rotate_logger ---
    changed |= patch(
        "klippy/gcode.py",
        "    def _respond_error(self, msg):\n"
        "        logging.warning(msg)\n"
        "        lines = msg.strip().split('\\n')\n",
        "    def _respond_error(self, msg):\n"
        "        logging.warning(msg)\n"
        "        # flsun L2: rotate_logger\n"
        "        flog = self.printer.lookup_object('rotate_logger', None)\n"
        "        if flog is not None:\n"
        "            try:\n"
        "                flog.error(msg, 'None')\n"
        "            except Exception:\n"
        "                pass\n"
        "        lines = msg.strip().split('\\n')\n",
        "gcode-log",
    )

    # --- toolhead M108 / M205 ---
    changed |= patch(
        "klippy/toolhead.py",
        "        gcode.register_command('G4', self.cmd_G4)\n"
        "        gcode.register_command('M400', self.cmd_M400)\n"
        "        gcode.register_command('SET_VELOCITY_LIMIT',\n"
        "                               self.cmd_SET_VELOCITY_LIMIT,\n"
        "                               desc=self.cmd_SET_VELOCITY_LIMIT_help)\n"
        "        gcode.register_command('M204', self.cmd_M204)\n",
        "        gcode.register_command('G4', self.cmd_G4)\n"
        "        gcode.register_command('M400', self.cmd_M400)\n"
        "        gcode.register_command('SET_VELOCITY_LIMIT',\n"
        "                               self.cmd_SET_VELOCITY_LIMIT,\n"
        "                               desc=self.cmd_SET_VELOCITY_LIMIT_help)\n"
        "        gcode.register_command('M204', self.cmd_M204)\n"
        "        # flsun L2\n"
        "        gcode.register_command('M108', self.cmd_M108)\n"
        "        gcode.register_command('M205', self.cmd_M205)\n",
        "tool-reg",
    )
    changed |= patch(
        "klippy/toolhead.py",
        "    def cmd_M400(self, gcmd):\n"
        "        # Wait for current moves to finish\n"
        "        self.toolhead.wait_moves()\n",
        "    def cmd_M400(self, gcmd):\n"
        "        # Wait for current moves to finish\n"
        "        self.toolhead.wait_moves()\n"
        "    def cmd_M108(self, gcmd):\n"
        "        # flsun L2: soft interrupt / power-loss path\n"
        "        self.printer.invoke_shutdown('M108 shutdown')\n"
        "    def cmd_M205(self, gcmd):\n"
        "        # flsun L2: jerk via square_corner_velocity\n"
        "        scv = gcmd.get_float('X', None, above=0.)\n"
        "        if scv is not None:\n"
        "            self.toolhead.set_max_velocities(None, None, scv, None)\n",
        "tool-cmds",
    )

    # --- filament locate hooks (light) ---
    changed |= patch(
        "klippy/extras/filament_switch_sensor.py",
        "    def _handle_ready(self):\n"
        "        self.min_event_systime = self.reactor.monotonic() + 2.\n",
        "    def _handle_ready(self):\n"
        "        self.min_event_systime = self.reactor.monotonic() + 2.\n"
        "        # flsun L2\n"
        "        self.locate_printing_gcode = self.printer.lookup_object(\n"
        "            'locate_printing_gcode', None)\n",
        "fil-ready",
    )
    changed |= patch(
        "klippy/extras/filament_switch_sensor.py",
        "        elif is_printing and self.runout_gcode is not None:\n"
        "            # runout detected\n"
        "            self.min_event_systime = self.reactor.NEVER\n"
        "            logging.info(\n"
        "                \"Filament Sensor %s: runout event detected, Time %.2f\" %\n"
        "                (self.name, now))\n"
        "            self.reactor.register_callback(self._runout_event_handler)\n",
        "        elif is_printing and self.runout_gcode is not None:\n"
        "            # runout detected\n"
        "            # flsun L2: save locate state\n"
        "            if getattr(self, 'locate_printing_gcode', None) is not None:\n"
        "                self.locate_printing_gcode.save_runing_info(\n"
        "                    'RunoutHelper', now)\n"
        "            self.min_event_systime = self.reactor.NEVER\n"
        "            logging.info(\n"
        "                \"Filament Sensor %s: runout event detected, Time %.2f\" %\n"
        "                (self.name, now))\n"
        "            self.reactor.register_callback(self._runout_event_handler)\n",
        "fil-runout",
    )

    if not changed:
        print("nothing changed")
        return

    files = [
        "klippy/extras/virtual_sdcard.py",
        "klippy/extras/gcode_move.py",
        "klippy/extras/homing.py",
        "klippy/extras/display_status.py",
        "klippy/extras/verify_heater.py",
        "klippy/extras/exclude_object.py",
        "klippy/extras/heaters.py",
        "klippy/gcode.py",
        "klippy/toolhead.py",
        "klippy/extras/filament_switch_sensor.py",
    ]
    subprocess.check_call(["git", "add", *files], cwd=ROOT)
    subprocess.check_call(
        [
            "git",
            "commit",
            "-m",
            "feat(flsun): batch L2 hooks for L1 integration",
        ],
        cwd=ROOT,
    )
    print("committed", subprocess.check_output(
        ["git", "log", "-1", "--oneline"], cwd=ROOT, text=True
    ).strip())


if __name__ == "__main__":
    main()
