#!/usr/bin/env python3
"""Upload fork klippy to /tmp on T1Max and run debugoutput sim (does not touch live stack)."""
from __future__ import annotations

import io
import sys
import tarfile
from pathlib import Path

import paramiko

HOST = "192.168.2.228"
USER = "pi"
PASSWORD = "1"
ROOT = Path(__file__).resolve().parents[1]
REMOTE = "/tmp/klipper-flsun-sim"
SRC_CFG = Path(r"H:\printer\t1max-firmware-backup\config_snapshot_20261122\printer.cfg")


def build_tar() -> bytes:
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        for rel in ("klippy", "scripts", "sim"):
            path = ROOT / rel
            if path.exists():
                tar.add(path, arcname=rel)
    return buf.getvalue()


def main() -> int:
    sys.path.insert(0, str(ROOT / "scripts"))
    import sim_klippy_batch as skb

    out_dir = ROOT / "sim" / "t1max-batch"
    if out_dir.exists():
        import shutil
        shutil.rmtree(out_dir)
    skb.sanitize(SRC_CFG, out_dir)
    (out_dir / "smoke.gcode").write_text("M115\nM114\n", encoding="utf-8")
    print("sanitized", out_dir / "printer.cfg")

    print("packing...")
    blob = build_tar()
    print("tar bytes", len(blob))

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASSWORD, timeout=20)
    try:
        def run(cmd: str, timeout: int = 180) -> int:
            print("SSH>", cmd[:200])
            _, stdout, stderr = client.exec_command(cmd, timeout=timeout)
            out = stdout.read().decode("utf-8", "replace")
            err = stderr.read().decode("utf-8", "replace")
            code = stdout.channel.recv_exit_status()
            if out.strip():
                print(out[-5000:])
            if err.strip():
                print(err[-3000:])
            return code

        run(f"rm -rf {REMOTE} && mkdir -p {REMOTE}")
        remote_tar = "/tmp/klipper-flsun-sim.tgz"
        import base64
        print("uploading via base64 stdin...")
        stdin, stdout, stderr = client.exec_command(
            f"base64 -d > {remote_tar}", timeout=120
        )
        stdin.write(base64.b64encode(blob))
        stdin.channel.shutdown_write()
        _ = stdout.read()
        err = stderr.read().decode("utf-8", "replace")
        up_code = stdout.channel.recv_exit_status()
        if up_code != 0:
            print("upload failed", up_code, err)
            return up_code
        run(f"ls -la {remote_tar} && tar -xzf {remote_tar} -C {REMOTE}")
        py = "/home/pi/klippy-env/bin/python"
        # compile tip chelper on ARM host
        run(
            f"cd {REMOTE}/klippy && {py} -c \"from chelper import get_ffi; get_ffi(); print('chelper ok')\"",
            timeout=300,
        )
        code = run(
            f"cd {REMOTE} && {py} klippy/klippy.py sim/t1max-batch/printer.cfg "
            f"-i sim/t1max-batch/smoke.gcode "
            f"-d /tmp/klipper-flsun-sim.dict "
            f"-l /tmp/klipper-flsun-sim.log",
            timeout=180,
        )
        run("tail -n 100 /tmp/klipper-flsun-sim.log || true")
        print("remote sim exit", code)
        return code
    finally:
        client.close()


if __name__ == "__main__":
    raise SystemExit(main())
