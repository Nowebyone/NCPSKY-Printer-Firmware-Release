#!/usr/bin/env python3
"""Inject FLSun PROBE_HEIGHT into tip bed_mesh.py (L2, surgical)."""
from __future__ import annotations

import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / "klippy" / "extras" / "bed_mesh.py"

REGISTER = """\
        self.gcode.register_command(
            'BED_MESH_OFFSET', self.cmd_BED_MESH_OFFSET,
            desc=self.cmd_BED_MESH_OFFSET_help)
"""

REGISTER_WITH = """\
        self.gcode.register_command(
            'BED_MESH_OFFSET', self.cmd_BED_MESH_OFFSET,
            desc=self.cmd_BED_MESH_OFFSET_help)
        self.gcode.register_command(   # flsun L2
            'PROBE_HEIGHT', self.cmd_PROBE_HEIGHT,
            desc=self.cmd_PROBE_HEIGHT_help)
"""

METHOD_ANCHOR = "    def get_mesh(self):\n        return self.z_mesh\n"

METHOD = '''\
    def get_mesh(self):
        return self.z_mesh
    cmd_PROBE_HEIGHT_help = "calibrate height before every print"
    def cmd_PROBE_HEIGHT(self, gcmd):  # flsun L2
        if self.z_mesh is None:
            raise gcmd.error("Bed has not been probed")
        probe = self.printer.lookup_object('probe', None)
        if probe is None:
            raise gcmd.error("Probe not configured")
        toolhead = self.printer.lookup_object('toolhead')
        probexy = toolhead.get_position()[:2]
        height = []
        for _i in range(10):
            pos = probe.run_probe(gcmd)
            toolhead.manual_move(probexy + [pos[2] + 5], 10)
            height.append(pos[2])
        average = (sum(height) - max(height) - min(height)) / 8
        offset = probe.get_offsets()
        center_z_offset = self.z_mesh.calc_z(0.0, 0.0)
        mesh_matrix = self.z_mesh.get_mesh_matrix()
        gcode_move = self.printer.lookup_object('gcode_move')
        gcode_offset = gcode_move.get_status()['homing_origin'][2]
        logging.info(
            "PROBE_HEIGHT average=%f offset[2]=%f center_z=%f gcode_offset=%f",
            average, offset[2], center_z_offset, gcode_offset)
        if mesh_matrix is not None:
            adjust = average - offset[2] - center_z_offset - gcode_offset
            self.gcode.run_script_from_command(
                "_SET_GCODE_OFFSET Z_ADJUST=%f MOVE=1" % (adjust))
'''


def main() -> None:
    text = TARGET.read_text(encoding="utf-8")
    if "cmd_PROBE_HEIGHT" in text:
        print("PROBE_HEIGHT already present")
        return
    if REGISTER not in text:
        raise SystemExit("register anchor not found")
    if METHOD_ANCHOR not in text:
        raise SystemExit("method anchor not found")
    text = text.replace(REGISTER, REGISTER_WITH, 1)
    text = text.replace(METHOD_ANCHOR, METHOD, 1)
    TARGET.write_bytes(text.encode("utf-8"))
    print("patched", TARGET.relative_to(ROOT))
    subprocess.check_call(["git", "add", "klippy/extras/bed_mesh.py"], cwd=ROOT)
    subprocess.check_call(
        [
            "git",
            "commit",
            "-m",
            "feat(flsun): port PROBE_HEIGHT to bed_mesh (L2)",
        ],
        cwd=ROOT,
    )
    print("committed L2 PROBE_HEIGHT on", subprocess.check_output(
        ["git", "branch", "--show-current"], cwd=ROOT, text=True
    ).strip())


if __name__ == "__main__":
    main()
