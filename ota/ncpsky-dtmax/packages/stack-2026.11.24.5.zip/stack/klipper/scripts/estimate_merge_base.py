#!/usr/bin/env python3
"""
Estimate a plausible upstream commit for FLSun snapshot by scoring
klippy/*.py similarity (no FLSun git history available).

Uses already-fetched upstream commits reachable from upstream/master.
"""
from __future__ import annotations

import hashlib
import subprocess
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SNAP = ROOT / "vendor" / "flsun-snapshot" / "klippy"
OUT = ROOT / "docs" / "MERGE_BASE_ESTIMATE.md"

# Representative files: less likely fully rewritten by FLSun branding
PROBE_RELS = [
    "klippy/mcu.py",
    "klippy/toolhead.py",
    "klippy/chelper/__init__.py",
    "klippy/kinematics/delta.py",
    "klippy/extras/bus.py",
    "klippy/extras/probe.py",
    "klippy/extras/tmc5160.py",
    "klippy/extras/tmc2130.py",
    "klippy/extras/heaters.py",
    "klippy/extras/virtual_sdcard.py",
    "klippy/extras/bed_mesh.py",
    "klippy/configfile.py",
    "klippy/gcode.py",
    "klippy/reactor.py",
]


def sh(*args: str) -> str:
    return subprocess.check_output(args, cwd=ROOT, text=True, errors="replace").strip()


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def snap_hash(rel: str) -> str | None:
    p = ROOT / "vendor" / "flsun-snapshot" / rel
    if not p.exists():
        return None
    return sha_bytes(p.read_bytes())


def main() -> None:
    # Use up to N commits from upstream/master
    commits = sh("git", "rev-list", "--max-count=400", "upstream/master").splitlines()
    if not commits:
        raise SystemExit("no upstream commits; fetch first")

    snap_hashes = {rel: snap_hash(rel) for rel in PROBE_RELS}
    present = {r: h for r, h in snap_hashes.items() if h}
    print(f"probe files present in snapshot: {len(present)}/{len(PROBE_RELS)}")
    print(f"scoring {len(commits)} upstream commits...")

    scores: list[tuple[int, str, str]] = []
    # Precompute which commits contain exact blob matches via git cat-file is slow;
    # instead: for each probe file, git log -S or git rev-list with blob.
    # Faster approach: for each commit, hash tree paths with git show COMMIT:path

    # Batch by walking commits sparsely first (every commit is ok for 400 * 14 shows)
    for i, c in enumerate(commits):
        match = 0
        for rel, want in present.items():
            try:
                blob = subprocess.check_output(
                    ["git", "show", f"{c}:{rel}"],
                    cwd=ROOT,
                    stderr=subprocess.DEVNULL,
                )
            except subprocess.CalledProcessError:
                continue
            if sha_bytes(blob) == want:
                match += 1
        if match:
            subj = sh("git", "log", "-1", "--format=%cs %s", c)
            scores.append((match, c, subj))
        if (i + 1) % 50 == 0:
            print(f"  scanned {i+1}/{len(commits)}, hits so far {len(scores)}")

    scores.sort(key=lambda x: (-x[0], commits.index(x[1])))
    top = scores[:25]

    lines = [
        "# Merge-base 估算（内容指纹）",
        "",
        "FLSun 真机树无 git 历史，无法 `merge-base`。",
        "本报告用快照与 `upstream/master` 已抓取提交的**文件内容 SHA256 精确匹配数**打分。",
        "",
        f"- 探测文件数：{len(present)}",
        f"- 扫描提交数：{len(commits)}",
        f"- 有任意命中的提交：{len(scores)}",
        "",
        "## Top 候选（匹配文件数越多越接近）",
        "",
        "| matches | commit | subject |",
        "|---|---|---|",
    ]
    for m, c, subj in top:
        lines.append(f"| {m}/{len(present)} | `{c[:12]}` | {subj} |")

    lines += [
        "",
        "## 解读",
        "",
        "- 若 Top1 matches 很低：说明 FLSun 相对官方 tip **分叉很深或整树改写**，应选较旧 tag 作基线再叠 L1。",
        "- 后续可对 Top 候选做 `git diff` 聚焦 L2 文件，选补丁量最小的点作为 `flsun-base`。",
        "",
    ]
    OUT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"wrote {OUT}")
    if top:
        print("best", top[0])
    else:
        print("no exact file matches in scanned history")


if __name__ == "__main__":
    main()
