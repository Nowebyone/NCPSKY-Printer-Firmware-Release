#!/usr/bin/env python3
"""Compare stock vs FLSun-edge point counts for round bed_mesh."""
from __future__ import annotations

import math


def gen(radius: float, x_cnt: int = 7, edge: bool = True):
    min_x = min_y = -radius
    max_x = max_y = radius
    x_dist = (max_x - min_x) / (x_cnt - 1)
    x_dist = math.floor(x_dist * 100) / 100
    y_dist = x_dist
    new_r = (x_cnt // 2) * x_dist
    min_x = min_y = -new_r
    max_x = max_y = new_r
    pos_y = min_y
    points = []
    y_cnt = x_cnt
    for i in range(y_cnt):
        for j in range(x_cnt):
            pos_x = min_x + j * x_dist if i % 2 == 0 else max_x - j * x_dist
            dist = math.sqrt(pos_x * pos_x + pos_y * pos_y)
            if not edge:
                if dist <= radius:
                    points.append((pos_x, pos_y))
            else:
                bx = (
                    math.sqrt(radius * radius - pos_y * pos_y)
                    if abs(pos_y) <= radius
                    else None
                )
                by = (
                    math.sqrt(radius * radius - pos_x * pos_x)
                    if abs(pos_x) <= radius
                    else None
                )
                if dist <= radius:
                    points.append((pos_x, pos_y))
                    continue
                if bx is not None and pos_x < -bx and x_dist + pos_x + bx > 10:
                    points.append((-bx, pos_y))
                    continue
                if bx is not None and pos_x > bx and x_dist + bx - pos_x > 10:
                    points.append((bx, pos_y))
                    continue
                if i == 0 and by is not None:
                    if (
                        dist > radius
                        and pos_x * pos_x + (pos_y + y_dist) ** 2
                        <= radius * radius
                        and -by < (pos_y + y_dist - 0.1)
                    ):
                        points.append((pos_x, -by))
                        continue
                if i == y_cnt - 1 and by is not None:
                    if (
                        dist > radius
                        and pos_x * pos_x + (pos_y - y_dist) ** 2
                        <= radius * radius
                        and by > (pos_y - y_dist + 0.1)
                    ):
                        points.append((pos_x, by))
                        continue
        pos_y += y_dist
    return points


def main() -> None:
    for r in (140.0, 150.0, 120.0):
        a = len(gen(r, edge=False))
        b = len(gen(r, edge=True))
        print(f"radius={r}: stock={a} edge={b} delta={b - a}")
        if b < a:
            raise SystemExit("edge produced fewer points than stock")


if __name__ == "__main__":
    main()
