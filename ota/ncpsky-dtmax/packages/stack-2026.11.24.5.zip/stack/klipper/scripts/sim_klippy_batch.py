#!/usr/bin/env python3
"""Sanitize T1Max printer.cfg and run klippy in debugoutput (no MCU/no printer)."""
from __future__ import annotations

import argparse
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SRC = Path(
    r"H:\printer\t1max-firmware-backup\config_snapshot_20261122\printer.cfg"
)


def sanitize(src: Path, out_dir: Path) -> Path:
    out_dir.mkdir(parents=True, exist_ok=True)
    text = src.read_text(encoding="utf-8", errors="replace")

    # rewrite home paths to sim dir
    gcode_dir = out_dir / "gcodes"
    gcode_dir.mkdir(exist_ok=True)
    (gcode_dir / ".keep").write_text("", encoding="utf-8")
    log_dir = out_dir / "logs"
    log_dir.mkdir(exist_ok=True)
    temp_dir = out_dir / "temp"
    temp_dir.mkdir(exist_ok=True)

    # Prefer paths relative to cfg dir so the same tree works on Win sanitize + Pi sim
    text = text.replace("~/printer_data/gcodes", "gcodes")
    text = text.replace("~/klipper_logs/mylog.txt", "logs/mylog.txt")
    text = text.replace("~/savedVariables1.cfg", "savedVariables1.cfg")
    text = text.replace("~/temp/tempVariables.cfg", "temp/tempVariables.cfg")

    # drop includes that are empty / host-only / may pull unavailable modules
    text = re.sub(
        r"(?m)^\[include timelapse\.cfg\].*$",
        "# [include timelapse.cfg]  # stripped for sim",
        text,
    )
    # copy adaptive + tmc_autotune beside sanitized cfg
    snap_dir = src.parent
    for name in ("adaptive_bed_mesh.cfg", "tmc_autotune.cfg"):
        sp = snap_dir / name
        if sp.exists():
            shutil.copy2(sp, out_dir / name)

    # host / mcu temp sensors often fail offline — comment sections
    for sec in ("temperature_sensor Armv7 mcu", "temperature_sensor mcu_temp"):
        text = re.sub(
            rf"(?ms)^\[{re.escape(sec)}\][^\[]*",
            f"# [{sec}]  # stripped for sim\n",
            text,
        )

    # resonance / adxl optional for config parse but needs chip — strip for faster sim
    for sec in ("resonance_tester", "adxl345", "input_shaper"):
        text = re.sub(
            rf"(?ms)^\[{re.escape(sec)}\][^\[]*",
            f"# [{sec}]  # stripped for sim\n",
            text,
        )

    # fake serial; debugoutput ignores real device
    text = re.sub(
        r"(?m)^(serial:\s*).*$",
        r"\1/tmp/klipper_sim_serial",
        text,
        count=1,
    )

    cfg = out_dir / "printer.cfg"
    cfg.write_text(text, encoding="utf-8")
    return cfg


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", type=Path, default=DEFAULT_SRC)
    ap.add_argument("--keep", action="store_true", help="keep sim dir under sim/")
    args = ap.parse_args()
    if not args.src.exists():
        print("missing source cfg", args.src)
        return 2

    if args.keep:
        out_dir = ROOT / "sim" / "t1max-batch"
        if out_dir.exists():
            shutil.rmtree(out_dir)
        out_dir.mkdir(parents=True)
    else:
        out_dir = Path(tempfile.mkdtemp(prefix="klipper-sim-"))

    cfg = sanitize(args.src, out_dir)
    dict_out = out_dir / "klipper.dict"
    log_out = out_dir / "klippy.log"
    gcode_in = out_dir / "smoke.gcode"
    gcode_in.write_text(
        "M115\nM114\nBED_MESH_OUTPUT\nPRINTER_WORKMODE\n",
        encoding="utf-8",
    )

    # -o enables MCU file/debugoutput mode; -d needs a firmware dictionary
    serial_out = out_dir / "klipper.serial"
    cmd = [
        sys.executable,
        str(ROOT / "klippy" / "klippy.py"),
        str(cfg),
        "-i",
        str(gcode_in),
        "-o",
        str(serial_out),
        "-d",
        str(dict_out),
        "-l",
        str(log_out),
    ]
    print("RUN", " ".join(cmd))
    print("CFG", cfg)
    proc = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    print("exit", proc.returncode)
    if proc.stdout:
        print("--- stdout (tail) ---")
        print("\n".join(proc.stdout.splitlines()[-40:]))
    if proc.stderr:
        print("--- stderr (tail) ---")
        print("\n".join(proc.stderr.splitlines()[-40:]))
    if log_out.exists():
        lines = log_out.read_text(encoding="utf-8", errors="replace").splitlines()
        print("--- log (tail) ---")
        print("\n".join(lines[-60:]))
        # success heuristic
        joined = "\n".join(lines)
        if "Unhandled exception during connect" in joined or "Config error" in joined:
            return 1
        if "Start printer at" in joined or "webhooks:" in joined or dict_out.exists():
            print("SIM OK", out_dir)
            return 0
    return proc.returncode or 1


if __name__ == "__main__":
    raise SystemExit(main())
