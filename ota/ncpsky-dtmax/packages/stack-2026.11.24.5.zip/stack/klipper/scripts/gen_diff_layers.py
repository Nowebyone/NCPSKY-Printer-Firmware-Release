#!/usr/bin/env python3
"""Compare FLSun snapshot vs upstream Klipper tree; emit layered inventory."""
from __future__ import annotations

import hashlib
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SNAP = ROOT / "vendor" / "flsun-snapshot"
UP = ROOT  # current checkout should be upstream-based branch
OUT = ROOT / "docs" / "DIFF_LAYERS.md"

MARKERS = (
    "flsun",
    "潮阔",
    "郑州",
    "hzk",
    "power_loss",
    "workmode",
    "locate_printing",
    "box_light",
    "probe_height",
    "save_temp",
    "rotate_logger",
    "printer_workmode",
)

EXCLUSIVE_HINTS = {
    "power_loss_recover.py",
    "printer_workmode.py",
    "locate_printing_gcode.py",
    "box_light.py",
    "flsun_warning.py",
    "save_temp_variables.py",
    "rotate_logger.py",
}

USER_PLUGIN_HINTS = {
    "autotune_tmc.py",
    "motor_constants.py",
    "motor_database.cfg",
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()[:12]


def file_map(base: Path, sub: str) -> dict[str, Path]:
    root = base / sub
    out: dict[str, Path] = {}
    if not root.exists():
        return out
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        if "__pycache__" in p.parts or p.suffix == ".pyc":
            continue
        rel = p.relative_to(base).as_posix()
        out[rel] = p
    return out


def has_marker(text: str) -> list[str]:
    low = text.lower()
    return [m for m in MARKERS if m.lower() in low]


def main() -> None:
    snap = file_map(SNAP, "klippy")
    up = file_map(UP, "klippy")

    only_snap = sorted(set(snap) - set(up))
    only_up = sorted(set(up) - set(snap))
    both = sorted(set(snap) & set(up))

    identical = []
    modified = []
    for rel in both:
        if sha256(snap[rel]) == sha256(up[rel]):
            identical.append(rel)
        else:
            modified.append(rel)

    exclusive = []
    user_plugins = []
    for rel in only_snap:
        name = Path(rel).name
        if name in USER_PLUGIN_HINTS or "autotune" in name:
            user_plugins.append(rel)
        else:
            exclusive.append(rel)

    # classify modified extras
    l2_core = []
    l2_light = []
    for rel in modified:
        if not rel.startswith("klippy/extras/"):
            l2_core.append(rel)
            continue
        text = snap[rel].read_text(encoding="utf-8", errors="ignore")
        marks = has_marker(text)
        name = Path(rel).name
        if name in EXCLUSIVE_HINTS:
            exclusive.append(rel)  # shouldn't happen if only_snap
        row = (rel, marks, len(text), sha256(snap[rel]), sha256(up[rel]))
        if marks or name in {
            "bed_mesh.py",
            "tmc.py",
            "virtual_sdcard.py",
            "gcode_move.py",
            "heaters.py",
            "homing.py",
            "exclude_object.py",
            "filament_switch_sensor.py",
            "display_status.py",
            "verify_heater.py",
            "bed_screws.py",
        }:
            l2_light.append(row)
        else:
            l2_core.append(rel)

    # Also scan snap-only extras under markers
    exclusive_marked = []
    for rel in exclusive:
        p = snap[rel]
        if p.suffix != ".py":
            exclusive_marked.append((rel, [], p.stat().st_size))
            continue
        text = p.read_text(encoding="utf-8", errors="ignore")
        exclusive_marked.append((rel, has_marker(text), len(text)))

    lines: list[str] = []
    lines.append("# FLSun T1Max Klipper — 差异分层清单")
    lines.append("")
    lines.append("生成脚本：`scripts/gen_diff_layers.py`")
    lines.append("")
    lines.append("对比对象：")
    lines.append("- `vendor/flsun-snapshot`：真机 `/home/pi/klipper` 快照")
    lines.append("- 当前分支上游树（`flsun-t1max` / `upstream-master` tip）")
    lines.append("")
    lines.append("## 汇总")
    lines.append("")
    lines.append(f"| 类别 | 数量 |")
    lines.append(f"|---|---|")
    lines.append(f"| 仅快照有（候选独占/插件） | {len(only_snap)} |")
    lines.append(f"| 仅上游有 | {len(only_up)} |")
    lines.append(f"| 双方都有且相同 | {len(identical)} |")
    lines.append(f"| 双方都有但内容不同 | {len(modified)} |")
    lines.append("")
    lines.append("## L1 — 独占模块（整文件携带，优先独立 commit）")
    lines.append("")
    lines.append("这些文件在上游不存在，或明确为 FLSun 业务：")
    lines.append("")
    for rel, marks, n in exclusive_marked:
        if Path(rel).name in USER_PLUGIN_HINTS:
            continue
        lines.append(f"- `{rel}` ({n} bytes) markers={marks}")
    lines.append("")
    lines.append("## L3 — 用户插件（已装在真机，同步时单独层）")
    lines.append("")
    for rel in user_plugins:
        lines.append(f"- `{rel}`")
    # also list from snap extras even if compared as modified symlink targets
    for name in sorted(USER_PLUGIN_HINTS):
        rel = f"klippy/extras/{name}"
        if rel in snap and rel not in user_plugins:
            lines.append(f"- `{rel}` (present in snapshot)")
    lines.append("")
    lines.append("## L2 — 上游文件魔改（高风险，应拆成小补丁）")
    lines.append("")
    lines.append("### extras 内、带定制痕迹或关键核心")
    lines.append("")
    lines.append("| 文件 | markers | snap sha | upstream sha |")
    lines.append("|---|---|---|---|")
    for rel, marks, n, s_sha, u_sha in sorted(l2_light):
        lines.append(f"| `{rel}` | {marks} | `{s_sha}` | `{u_sha}` |")
    lines.append("")
    lines.append("### 其他双方内容不同的 klippy 文件（节选前 80）")
    lines.append("")
    other_mod = [r for r in modified if r not in {x[0] for x in l2_light}]
    for rel in other_mod[:80]:
        lines.append(
            f"- `{rel}` snap=`{sha256(snap[rel])}` up=`{sha256(up[rel])}`"
        )
    if len(other_mod) > 80:
        lines.append(f"- … 另有 {len(other_mod) - 80} 个文件")
    lines.append("")
    lines.append("## 建议移植顺序")
    lines.append("")
    lines.append("1. L1 独占模块整文件迁入 `flsun-t1max`（单独 commits）")
    lines.append("2. L2 中优先处理：`bed_mesh.py`（PROBE_HEIGHT）、`virtual_sdcard.py`、`gcode_move.py`、`tmc.py`")
    lines.append("3. 能拆外挂的不要整文件覆盖（PROBE_HEIGHT → 独立 extras 包装）")
    lines.append("4. L3 用户插件最后叠（autotune 已有 FLSun shim）")
    lines.append("5. 本机 config dry-run / 冒烟通过后再谈真机切换")
    lines.append("")
    lines.append("## 仅上游有的路径（快照落后官方的能力面，节选）")
    lines.append("")
    for rel in only_up[:60]:
        if "extras/" in rel or rel.endswith(".py"):
            lines.append(f"- `{rel}`")
    lines.append("")

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"wrote {OUT}")
    print(
        f"only_snap={len(only_snap)} only_up={len(only_up)} "
        f"identical={len(identical)} modified={len(modified)}"
    )


if __name__ == "__main__":
    main()
