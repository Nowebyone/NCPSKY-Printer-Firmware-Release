#!/usr/bin/env python3
"""Install arm-none-eabi gcc on T1Max, build tip stm32f103 dict, run looped sims."""
from __future__ import annotations

import base64
import io
import tarfile
import time
from pathlib import Path

import paramiko

HOST = "192.168.2.228"
USER = "pi"
PASSWORD = "1"
ROOT = Path(__file__).resolve().parents[1]
REMOTE = "/tmp/klipper-flsun-sim"
PY = "/home/pi/klippy-env/bin/python"
DEB = ROOT / "sim" / "debs" / "gcc-arm-none-eabi_7-2018-q2-6_armhf.deb"
SEED = ROOT / "sim" / "t1max-stm32f103.config"


def run(client, cmd, timeout=900):
    print("SSH>", cmd[:240])
    _, o, e = client.exec_command(cmd, timeout=timeout)
    chan = o.channel
    parts = []
    t0 = time.time()
    while True:
        if chan.recv_ready():
            parts.append(chan.recv(16384).decode("utf-8", "replace"))
        if chan.recv_stderr_ready():
            parts.append(chan.recv_stderr(16384).decode("utf-8", "replace"))
        if chan.exit_status_ready() and not chan.recv_ready() and not chan.recv_stderr_ready():
            break
        if time.time() - t0 > timeout:
            parts.append("\nTIMEOUT\n")
            break
        time.sleep(0.3)
    code = chan.recv_exit_status() if chan.exit_status_ready() else -1
    text = "".join(parts)
    print(text[-10000:])
    print("exit", code)
    return code, text


def upload(client, data: bytes, remote: str):
    stdin, o, e = client.exec_command(f"base64 -d > {remote}", timeout=600)
    stdin.write(base64.b64encode(data))
    stdin.channel.shutdown_write()
    return o.channel.recv_exit_status()


def ensure_tree(client):
    # refresh tip tree if missing chelper so
    code, _ = run(client, f"test -x {REMOTE}/klippy/chelper/c_helper.so && echo HAS_SO || echo NO_SO")
    if "HAS_SO" in _:
        return
    # pack and upload
    import sys, shutil
    sys.path.insert(0, str(ROOT / "scripts"))
    import sim_klippy_batch as skb
    out = ROOT / "sim" / "t1max-batch"
    if out.exists():
        shutil.rmtree(out)
    skb.sanitize(
        Path(r"H:\printer\t1max-firmware-backup\config_snapshot_20261122\printer.cfg"),
        out,
    )
    (out / "smoke.gcode").write_text(
        "M115\nM114\nBED_MESH_OUTPUT\nM220 S100\n", encoding="utf-8"
    )
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        tar.add(ROOT / "klippy", arcname="klippy")
        tar.add(out, arcname="sim/t1max-batch")
        tar.add(SEED, arcname="sim/t1max-stm32f103.config")
    print("upload tree", len(buf.getvalue()))
    run(client, f"rm -rf {REMOTE} && mkdir -p {REMOTE}")
    upload(client, buf.getvalue(), "/tmp/klipper-flsun-sim.tgz")
    run(client, f"tar -xzf /tmp/klipper-flsun-sim.tgz -C {REMOTE}")
    run(client, f"rm -f {REMOTE}/klippy/chelper/c_helper.so")
    run(
        client,
        f"cd {REMOTE}/klippy && PYTHONPATH=. {PY} -c 'import chelper; chelper.get_ffi(); print(123)'",
        timeout=600,
    )


def main() -> int:
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASSWORD, timeout=20)
    try:
        print("upload gcc-arm-none-eabi deb", DEB.stat().st_size)
        upload(client, DEB.read_bytes(), "/tmp/gcc-debs/gcc-arm-none-eabi_7-2018-q2-6_armhf.deb")
        run(
            client,
            "echo 1 | sudo -S dpkg -i /tmp/gcc-debs/gcc-arm-none-eabi_7-2018-q2-6_armhf.deb 2>&1 | tail -40",
            timeout=300,
        )
        run(client, "arm-none-eabi-gcc --version | head -2; which arm-none-eabi-gcc")

        ensure_tree(client)

        # build firmware dict in sim tree
        run(
            client,
            f"cd {REMOTE} && cp -f sim/t1max-stm32f103.config .config && "
            f"make olddefconfig && make -j2 2>&1 | tail -50",
            timeout=900,
        )
        run(client, f"ls -la {REMOTE}/out/klipper.dict {REMOTE}/out/klipper.bin")

        # simulate
        code, _ = run(
            client,
            f"cd {REMOTE} && {PY} klippy/klippy.py sim/t1max-batch/printer.cfg "
            f"-i sim/t1max-batch/smoke.gcode "
            f"-o /tmp/klipper-flsun-sim.serial "
            f"-d {REMOTE}/out/klipper.dict "
            f"-l /tmp/klipper-flsun-sim-loop.log",
            timeout=180,
        )
        run(client, "tail -n 100 /tmp/klipper-flsun-sim-loop.log")
        run(
            client,
            "python3 -c \"from pathlib import Path; t=Path('/tmp/klipper-flsun-sim-loop.log').read_text(errors='replace'); "
            "print('HAS_CONFIG_ERROR', 'Config error' in t); "
            "print('HAS_UNHANDLED', 'Unhandled exception' in t); "
            "print('HAS_READY', 'Ready.' in t); "
            "print('HAS_MCU_CONNECT', \\\"Unable to connect\\\" in t); "
            "errs=[l for l in t.splitlines() if 'Error' in l or 'error' in l][-15:]; print('ERRS', errs)\"",
        )
        print("FINAL", code)
        return code
    finally:
        client.close()


if __name__ == "__main__":
    raise SystemExit(main())
