#!/usr/bin/env python3
"""
Config / import smoke test for flsun-t1max tree (no printer, no MCU).

What it does:
1. Parse-import critical extras (L1 exclusive + tmc/bed_mesh)
2. Optionally run klippy in batch mode with a sanitized printer.cfg

Usage:
  python scripts/dry_run_config.py
  python scripts/dry_run_config.py --cfg path/to/printer.cfg
"""
from __future__ import annotations

import argparse
import ast
import importlib.util
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXTRAS = ROOT / "klippy" / "extras"

L1 = [
    "box_light.py",
    "flsun_warning.py",
    "locate_printing_gcode.py",
    "power_loss_recover.py",
    "printer_workmode.py",
    "rotate_logger.py",
    "save_temp_variables.py",
]


def check_syntax(path: Path) -> None:
    src = path.read_text(encoding="utf-8", errors="replace")
    ast.parse(src, filename=str(path))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--cfg", type=Path, default=None)
    args = ap.parse_args()

    errors: list[str] = []

    print("== syntax: L1 exclusive ==")
    for name in L1:
        # prefer tree copy, else overlay
        p = EXTRAS / name
        if not p.exists():
            p = ROOT / "overlays" / "l1-exclusive" / name
        try:
            check_syntax(p)
            print("OK", p.relative_to(ROOT))
        except Exception as e:
            errors.append(f"{p}: {e}")
            print("FAIL", p, e)

    print("== syntax: tip bed_mesh (L2 port target) ==")
    tip_bed = EXTRAS / "bed_mesh.py"
    try:
        check_syntax(tip_bed)
        src = tip_bed.read_text(encoding="utf-8", errors="replace")
        if "cmd_PROBE_HEIGHT" in src:
            print("OK tip bed_mesh.py (+PROBE_HEIGHT)")
        else:
            print("OK tip bed_mesh.py (PROBE_HEIGHT missing)")
    except Exception as e:
        errors.append(f"tip bed_mesh: {e}")
        print("FAIL tip bed_mesh", e)

    print("== syntax: key L2 candidates from snapshot (read-only check) ==")
    snap_extras = ROOT / "vendor" / "flsun-snapshot" / "klippy" / "extras"
    for name in [
        "bed_mesh.py",
        "virtual_sdcard.py",
        "gcode_move.py",
        "tmc.py",
        "tmc5160.py",
        "homing.py",
    ]:
        p = snap_extras / name
        if not p.exists():
            print("SKIP missing", name)
            continue
        try:
            check_syntax(p)
            print("OK snap", name)
        except Exception as e:
            errors.append(f"snap {name}: {e}")
            print("FAIL snap", name, e)

    print("== syntax: L3 overlays ==")
    for name in ["autotune_tmc.py", "motor_constants.py"]:
        p = ROOT / "overlays" / "l3-user" / name
        try:
            check_syntax(p)
            print("OK", p.relative_to(ROOT))
        except Exception as e:
            errors.append(f"{p}: {e}")
            print("FAIL", p, e)

    if args.cfg:
        print("== sanitize cfg presence ==")
        text = args.cfg.read_text(encoding="utf-8", errors="replace")
        # crude checks only
        for needle in [
            "[mcu]",
            "[printer]",
            "[tmc5160 stepper_a]",
            "power_loss_recover",
            "printer_workmode",
        ]:
            print(("FOUND" if needle in text else "MISS "), needle)

    if errors:
        print("\nFAILED", len(errors))
        for e in errors:
            print(" -", e)
        return 1
    print("\nALL SMOKE CHECKS PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
