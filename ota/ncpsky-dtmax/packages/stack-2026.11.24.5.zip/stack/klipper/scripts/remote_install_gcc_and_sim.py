#!/usr/bin/env python3
"""Upload archive.debian.org gcc-8 debs, install, rebuild tip chelper, run sim."""
from __future__ import annotations

import base64
import io
import tarfile
import time
from pathlib import Path

import paramiko

HOST = "192.168.2.228"
USER = "pi"
PASSWORD = "1"
ROOT = Path(__file__).resolve().parents[1]
REMOTE = "/tmp/klipper-flsun-sim"
PY = "/home/pi/klippy-env/bin/python"
DEBS = ROOT / "sim" / "debs"


def run(client, cmd, timeout=600):
    print("SSH>", cmd[:240])
    _, o, e = client.exec_command(cmd, timeout=timeout)
    chan = o.channel
    parts = []
    t0 = time.time()
    while True:
        if chan.recv_ready():
            parts.append(chan.recv(8192).decode("utf-8", "replace"))
        if chan.recv_stderr_ready():
            parts.append(chan.recv_stderr(8192).decode("utf-8", "replace"))
        if chan.exit_status_ready() and not chan.recv_ready() and not chan.recv_stderr_ready():
            break
        if time.time() - t0 > timeout:
            parts.append("\nTIMEOUT\n")
            break
        time.sleep(0.25)
    code = chan.recv_exit_status() if chan.exit_status_ready() else -1
    text = "".join(parts)
    print(text[-8000:])
    print("exit", code)
    return code, text


def upload_bytes(client, data: bytes, remote_path: str):
    stdin, o, e = client.exec_command(f"base64 -d > {remote_path}", timeout=300)
    stdin.write(base64.b64encode(data))
    stdin.channel.shutdown_write()
    o.channel.recv_exit_status()


def main() -> int:
    # sanitize cfg
    import sys
    sys.path.insert(0, str(ROOT / "scripts"))
    import sim_klippy_batch as skb
    import shutil
    out = ROOT / "sim" / "t1max-batch"
    if out.exists():
        shutil.rmtree(out)
    skb.sanitize(
        Path(r"H:\printer\t1max-firmware-backup\config_snapshot_20261122\printer.cfg"),
        out,
    )
    (out / "smoke.gcode").write_text("M115\nM114\n", encoding="utf-8")

    # pack tree
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        for rel in ("klippy", "sim/t1max-batch"):
            p = ROOT / rel
            tar.add(p, arcname=rel if not rel.startswith("sim/") else rel)
    # fix arcname for sim
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        tar.add(ROOT / "klippy", arcname="klippy")
        tar.add(out, arcname="sim/t1max-batch")
    blob = buf.getvalue()
    print("tree tar", len(blob))

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASSWORD, timeout=20)
    try:
        run(client, "mkdir -p /tmp/gcc-debs")
        for deb in sorted(DEBS.glob("*.deb")):
            print("upload", deb.name, deb.stat().st_size)
            upload_bytes(client, deb.read_bytes(), f"/tmp/gcc-debs/{deb.name}")
        run(
            client,
            "echo 1 | sudo -S dpkg -i /tmp/gcc-debs/*.deb 2>&1 | tail -60",
            timeout=300,
        )
        run(client, "ls -l /usr/bin/gcc /usr/bin/gcc-8 /usr/bin/arm-linux-gnueabihf-gcc-8; gcc --version | head -1")
        run(client, f"rm -rf {REMOTE} && mkdir -p {REMOTE}")
        upload_bytes(client, blob, "/tmp/klipper-flsun-sim.tgz")
        run(client, f"tar -xzf /tmp/klipper-flsun-sim.tgz -C {REMOTE}")
        run(client, f"rm -f {REMOTE}/klippy/chelper/c_helper.so")
        run(
            client,
            "python3 -c \"open('/tmp/build_chelper.py','w').write('from chelper import get_ffi\\nget_ffi()\\nprint(123)\\n')\"",
        )
        code, _ = run(client, f"cd {REMOTE}/klippy && {PY} /tmp/build_chelper.py", timeout=600)
        if code != 0:
            return code
        code, _ = run(
            client,
            f"cd {REMOTE} && {PY} klippy/klippy.py sim/t1max-batch/printer.cfg "
            f"-i sim/t1max-batch/smoke.gcode -d /tmp/klipper-flsun-sim.dict "
            f"-l /tmp/klipper-flsun-sim.log",
            timeout=180,
        )
        run(client, "tail -n 100 /tmp/klipper-flsun-sim.log")
        run(
            client,
            "python3 -c \"from pathlib import Path; t=Path('/tmp/klipper-flsun-sim.log').read_text(errors='replace'); "
            "print('HAS_CONFIG_ERROR', 'Config error' in t); "
            "print('HAS_UNHANDLED', 'Unhandled exception' in t); "
            "print('HAS_DICT', Path('/tmp/klipper-flsun-sim.dict').exists())\"",
        )
        print("FINAL", code)
        return code
    finally:
        client.close()


if __name__ == "__main__":
    raise SystemExit(main())
