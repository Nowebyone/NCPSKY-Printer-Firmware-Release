#!/usr/bin/env python3
import time
from pathlib import Path

import paramiko

HOST = "192.168.2.228"
USER = "pi"
PASSWORD = "1"
REMOTE = "/tmp/klipper-flsun-sim"
PY = "/home/pi/klippy-env/bin/python"


def run(client, cmd, timeout=600):
    print("SSH>", cmd[:240])
    _, o, e = client.exec_command(cmd, timeout=timeout)
    chan = o.channel
    parts = []
    t0 = time.time()
    while True:
        if chan.recv_ready():
            parts.append(chan.recv(8192).decode("utf-8", "replace"))
        if chan.recv_stderr_ready():
            parts.append(chan.recv_stderr(8192).decode("utf-8", "replace"))
        if chan.exit_status_ready() and not chan.recv_ready() and not chan.recv_stderr_ready():
            break
        if time.time() - t0 > timeout:
            parts.append("\nTIMEOUT\n")
            break
        time.sleep(0.25)
    code = chan.recv_exit_status() if chan.exit_status_ready() else -1
    text = "".join(parts)
    print(text[-8000:])
    print("exit", code)
    return code, text


def main():
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    client.connect(HOST, username=USER, password=PASSWORD, timeout=20)
    try:
        run(
            client,
            "echo 1 | sudo -S apt-get install -y --reinstall gcc-8 build-essential 2>&1 | tail -50",
            timeout=600,
        )
        run(client, "ls -l /usr/bin/gcc /usr/bin/gcc-8; /usr/bin/gcc --version | head -1")
        run(client, f"rm -f {REMOTE}/klippy/chelper/c_helper.so {REMOTE}/klippy/chelper/_temp_c_helper.so")
        # upload tiny builder via python -c with simple quotes
        run(
            client,
            "python3 -c \"open('/tmp/build_chelper.py','w').write('from chelper import get_ffi\\nget_ffi()\\nprint(123)\\n')\"",
        )
        code, _ = run(client, f"cd {REMOTE}/klippy && {PY} /tmp/build_chelper.py", timeout=600)
        if code != 0:
            return code
        code, _ = run(
            client,
            f"cd {REMOTE} && {PY} klippy/klippy.py sim/t1max-batch/printer.cfg "
            f"-i sim/t1max-batch/smoke.gcode -d /tmp/klipper-flsun-sim.dict "
            f"-l /tmp/klipper-flsun-sim.log",
            timeout=180,
        )
        run(client, "tail -n 120 /tmp/klipper-flsun-sim.log")
        run(
            client,
            "python3 -c \"from pathlib import Path; t=Path('/tmp/klipper-flsun-sim.log').read_text(errors='replace'); "
            "print('HAS_CONFIG_ERROR', 'Config error' in t); "
            "print('HAS_UNHANDLED', 'Unhandled exception' in t); "
            "print('HAS_DICT', Path('/tmp/klipper-flsun-sim.dict').exists()); "
            "print('TAIL_OK', 'Option' not in t[-200:] )\"",
        )
        print("FINAL", code)
        return code
    finally:
        client.close()


if __name__ == "__main__":
    raise SystemExit(main())
