#!/usr/bin/env python3
"""Refresh vendor/flsun-snapshot from the live T1 Max over SSH (read-only on printer)."""
from __future__ import annotations

import io
import shutil
import tarfile
from pathlib import Path

import paramiko

HOST = "192.168.2.228"
USER = "pi"
PASSWORD = "1"
OUT = Path(__file__).resolve().parents[1] / "vendor" / "flsun-snapshot"


def main() -> None:
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)

    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(HOST, username=USER, password=PASSWORD, timeout=20)
    cmd = (
        "cd /home/pi && tar -cf - "
        "--exclude='klipper/**/__pycache__' "
        "--exclude='klipper/**/*.pyc' "
        "klipper"
    )
    stdin, stdout, stderr = c.exec_command(cmd, timeout=180)
    data = stdout.read()
    err = stderr.read().decode("utf-8", "replace")
    code = stdout.channel.recv_exit_status()
    c.close()
    if code != 0 or len(data) < 1000:
        raise SystemExit(f"tar failed code={code} err={err}")

    with tarfile.open(fileobj=io.BytesIO(data), mode="r:") as tf:
        for m in tf.getmembers():
            if not m.name.startswith("klipper/"):
                continue
            rel = m.name[len("klipper/") :]
            if not rel or "__pycache__" in rel or rel.endswith(".pyc"):
                continue
            m.name = rel
            tf.extract(m, path=OUT)
    print("refreshed", OUT, "bytes_tar", len(data))


if __name__ == "__main__":
    main()
