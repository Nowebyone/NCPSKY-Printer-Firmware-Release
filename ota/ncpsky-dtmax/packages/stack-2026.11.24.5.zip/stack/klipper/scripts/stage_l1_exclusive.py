#!/usr/bin/env python3
"""Copy FLSun exclusive extras into overlays/l1-exclusive for later commits."""
from __future__ import annotations

import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SNAP = ROOT / "vendor" / "flsun-snapshot" / "klippy" / "extras"
DEST = ROOT / "overlays" / "l1-exclusive"

FILES = [
    "box_light.py",
    "flsun_warning.py",
    "locate_printing_gcode.py",
    "power_loss_recover.py",
    "printer_workmode.py",
    "rotate_logger.py",
    "save_temp_variables.py",
]


def main() -> None:
    if DEST.exists():
        shutil.rmtree(DEST)
    DEST.mkdir(parents=True)
    for name in FILES:
        src = SNAP / name
        if not src.exists():
            print("MISSING", src)
            continue
        shutil.copy2(src, DEST / name)
        print("staged", name, src.stat().st_size)
    (DEST / "README.md").write_text(
        "\n".join(
            [
                "# L1 exclusive overlays",
                "",
                "整文件来自真机 FLSun 快照，上游不存在。",
                "后续合入 `flsun-t1max` 时作为独立 commits 拷入 `klippy/extras/`。",
                "",
            ]
        ),
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
