#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export PATH="/c/ST/STM32CubeCLT_1.18.0/GNU-tools-for-STM32/bin:/f/Software/DPJ/STM32/MinGW/bin:$PATH"
MAKE=make
command -v make >/dev/null || MAKE=mingw32-make
cp -f sim/t1max-stm32f103.config .config
"$MAKE" olddefconfig
"$MAKE" -j4
ls -la out/klipper.dict out/klipper.elf out/klipper.bin
echo "BUILD_OK"
