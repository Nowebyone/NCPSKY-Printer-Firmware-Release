#!/usr/bin/env python3
"""Fuzzy similarity of key files vs upstream tags / sampled commits."""
from __future__ import annotations

import difflib
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs" / "MERGE_BASE_ESTIMATE.md"
SNAP = ROOT / "vendor" / "flsun-snapshot"

RELS = [
    "klippy/mcu.py",
    "klippy/toolhead.py",
    "klippy/kinematics/delta.py",
    "klippy/extras/tmc5160.py",
    "klippy/extras/probe.py",
    "klippy/gcode.py",
]


def sh(*args: str) -> str:
    return subprocess.check_output(args, cwd=ROOT, text=True, errors="replace").strip()


def git_show(rev: str, rel: str) -> str | None:
    try:
        return subprocess.check_output(
            ["git", "show", f"{rev}:{rel}"],
            cwd=ROOT,
            text=True,
            errors="replace",
            stderr=subprocess.DEVNULL,
        )
    except subprocess.CalledProcessError:
        return None


def score_rev(rev: str) -> tuple[float, dict[str, float]]:
    parts: dict[str, float] = {}
    vals = []
    for rel in RELS:
        snap = (SNAP / rel).read_text(encoding="utf-8", errors="replace")
        up = git_show(rev, rel)
        if up is None:
            parts[rel] = 0.0
            continue
        # Normalize newlines
        a = snap.replace("\r\n", "\n")
        b = up.replace("\r\n", "\n")
        r = difflib.SequenceMatcher(None, a, b).ratio()
        parts[rel] = r
        vals.append(r)
    avg = sum(vals) / len(vals) if vals else 0.0
    return avg, parts


def main() -> None:
    # Ensure some older tags exist locally
    tags = []
    for t in ["v0.13.0", "v0.12.0", "v0.11.0", "v0.10.0", "v0.9.0"]:
        try:
            sh("git", "rev-parse", t)
            tags.append(t)
        except subprocess.CalledProcessError:
            try:
                subprocess.check_call(
                    ["git", "fetch", "upstream", "tag", t, "--depth", "1"],
                    cwd=ROOT,
                )
                tags.append(t)
            except Exception as e:
                print("skip tag", t, e)

    revs = [("upstream/master", "upstream/master")] + [(t, t) for t in tags]
    # also sample older commits if history deep enough
    commits = sh("git", "rev-list", "--max-count=20", "upstream/master").splitlines()
    # take evenly spaced from available history
    allc = sh("git", "rev-list", "--max-count=800", "upstream/master").splitlines()
    if len(allc) > 20:
        step = max(1, len(allc) // 15)
        sample = allc[::step][:15]
        for c in sample:
            subj = sh("git", "log", "-1", "--format=%cs %s", c)
            revs.append((c, subj))

    rows = []
    for rev, label in revs:
        avg, parts = score_rev(rev)
        rows.append((avg, rev, label, parts))
        print(f"{avg:.4f} {label[:80]}")

    rows.sort(key=lambda x: -x[0])
    lines = [
        "# Merge-base 估算（模糊相似度）",
        "",
        "精确 SHA 匹配在近 400 个 tip 提交中为 0，改为 `difflib` 比例（1.0=相同）。",
        "",
        "| avg | ref | notes |",
        "|---|---|---|",
    ]
    for avg, rev, label, parts in rows[:20]:
        detail = ", ".join(f"{Path(k).name}:{v:.2f}" for k, v in parts.items())
        lines.append(f"| {avg:.4f} | `{rev[:12] if len(rev)>12 else rev}` / {label[:60]} | {detail} |")
    lines += [
        "",
        "## 建议",
        "",
        "- 选 avg 最高的 tag/commit 作为 `flsun-base` 试验点。",
        "- 若最高仍明显 < 0.9：按「上游 tip + L1 外挂 + L2 手工移植」推进，不强求祖先点。",
        "",
    ]
    OUT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("wrote", OUT)
    print("best", rows[0][:3])


if __name__ == "__main__":
    main()
