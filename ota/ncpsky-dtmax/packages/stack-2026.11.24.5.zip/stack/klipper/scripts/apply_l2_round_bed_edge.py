#!/usr/bin/env python3
"""Port FLSun round-bed edge probe points + arc-row Y equalize (L2).

delta_split_offset / chelper get_offset+adjust_matrix are NOT included —
those need the closed C helper from FLSun and stay deferred.
"""
from __future__ import annotations

import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / "klippy" / "extras" / "bed_mesh.py"

OLD_ROUND = """\
                else:
                    # round bed, check distance from origin
                    dist_from_origin = math.sqrt(pos_x*pos_x + pos_y*pos_y)
                    if dist_from_origin <= radius:
                        points.append(
                            (origin[0] + pos_x, origin[1] + pos_y))
            pos_y += y_dist
"""

NEW_ROUND = """\
                else:
                    # round bed, check distance from origin
                    dist_from_origin = math.sqrt(pos_x*pos_x + pos_y*pos_y)
                    # flsun L2: add points on the circle edge
                    if abs(pos_y) <= radius:
                        border_x = math.sqrt(radius*radius - pos_y*pos_y)
                    else:
                        border_x = None
                    if abs(pos_x) <= radius:
                        border_y = math.sqrt(radius*radius - pos_x*pos_x)
                    else:
                        border_y = None
                    if dist_from_origin <= radius:
                        points.append(
                            (origin[0] + pos_x, origin[1] + pos_y))
                        continue
                    # If grid point is just outside, snap to chord edge
                    if (border_x is not None and pos_x < -border_x and
                            x_dist + pos_x + border_x > 10):
                        points.append(
                            (origin[0] + (-border_x), origin[1] + pos_y))
                        continue
                    if (border_x is not None and pos_x > border_x and
                            x_dist + border_x - pos_x > 10):
                        points.append(
                            (origin[0] + border_x, origin[1] + pos_y))
                        continue
                    # First/last row: project onto arc to gain edge samples
                    if i == 0 and border_y is not None:
                        if (dist_from_origin > radius and
                                pos_x*pos_x + (pos_y+y_dist)*(pos_y+y_dist)
                                <= radius*radius and
                                -border_y < (pos_y + y_dist - 0.1)):
                            points.append(
                                (origin[0] + pos_x,
                                 origin[1] + (-border_y)))
                            continue
                    if i == y_cnt - 1 and border_y is not None:
                        if (dist_from_origin > radius and
                                pos_x*pos_x + (pos_y-y_dist)*(pos_y-y_dist)
                                <= radius*radius and
                                border_y > (pos_y - y_dist + 0.1)):
                            points.append(
                                (origin[0] + pos_x,
                                 origin[1] + border_y))
                            continue
            pos_y += y_dist
"""

OLD_FINALIZE = """\
        probed_matrix = []
        row = []
        prev_pos = base_points[0]
        for pos, result in zip(base_points, positions):
"""

NEW_FINALIZE = """\
        # flsun L2: first/last arc rows have unequal Y; equalize for matrix
        work_points = [list(p) for p in base_points]
        if self.radius is not None and self.origin is not None and y_cnt > 1:
            y_step = 2. * self.radius / (y_cnt - 1)
            ox, oy = self.origin
            for p in work_points:
                ry = p[1] - oy
                if (ry >= -self.radius - 0.1 and
                        ry < -self.radius + y_step - 0.1):
                    p[1] = oy - self.radius
                elif (ry <= self.radius + 0.1 and
                        ry > self.radius - y_step + 0.1):
                    p[1] = oy + self.radius

        probed_matrix = []
        row = []
        prev_pos = work_points[0]
        for pos, result in zip(work_points, positions):
"""


def main() -> None:
    text = TARGET.read_text(encoding="utf-8")
    if "flsun L2: add points on the circle edge" in text:
        print("round-bed edge already present")
        return
    if OLD_ROUND not in text:
        raise SystemExit("round-bed generate_points anchor not found")
    if OLD_FINALIZE not in text:
        raise SystemExit("probe_finalize anchor not found")
    text = text.replace(OLD_ROUND, NEW_ROUND, 1)
    text = text.replace(OLD_FINALIZE, NEW_FINALIZE, 1)
    TARGET.write_bytes(text.encode("utf-8"))
    print("patched", TARGET.relative_to(ROOT))
    subprocess.check_call(["git", "add", "klippy/extras/bed_mesh.py"], cwd=ROOT)
    subprocess.check_call(
        [
            "git",
            "commit",
            "-m",
            "feat(flsun): round-bed edge probe points (L2)",
        ],
        cwd=ROOT,
    )
    print("committed on", subprocess.check_output(
        ["git", "branch", "--show-current"], cwd=ROOT, text=True
    ).strip())


if __name__ == "__main__":
    main()
