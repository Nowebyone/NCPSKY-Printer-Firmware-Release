#!/usr/bin/env python3
"""Publish OTA artifacts: compute sha256, merge manifest, upload.

Upload backends (pick one via --method):
  copy   — copy into a local/nfs dir that is already HTTP-served
  scp    — scp to user@host:remote_dir
  rclone — rclone copy to remote:path
  s3     — aws s3 cp (requires aws CLI)

Example:
  python publish.py --channel beta --dist ../dist \\
    --method copy --dest /var/www/ncpsky-ota \\
    --panel-zip ../dist/panel-0.5.1.zip \\
    --stack-zip ../dist/stack-2026.11.23.1.zip
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone


PRODUCT = "NCPSKY ▲ DTMax"
FIRMWARE_TARGET = "FLSun T1 Max"


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def load_json(path, default=None):
    if not path or not os.path.exists(path):
        return default if default is not None else {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_json(path, data):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")
    os.replace(tmp, path)


def pkg_entry(kind, version, file_path, notes="", restart=None, auto=True, min_free_mb=80):
    digest = sha256_file(file_path)
    size = os.path.getsize(file_path)
    name = os.path.basename(file_path)
    restart = restart or {
        "panel": "panel",
        "stack": "klipper",
        "system": "reboot",
        "platform": "reboot",
        "mcu": "mcu_flash",
        "factory": "reboot",
    }.get(kind, "panel")
    # Avoid mcu-mcu-YYYY when version already starts with kind-
    pkg_id = version if str(version).startswith("%s-" % kind) else "%s-%s" % (kind, version)
    entry = {
        "id": pkg_id,
        "kind": kind,
        "version": version,
        "url": "packages/%s" % name,
        "sha256": digest,
        "size": size,
        "min_free_mb": min_free_mb,
        "requires_idle": True,
        "auto": auto if kind not in ("mcu", "factory") else False,
        "restart": restart,
        "notes": notes,
    }
    if kind == "panel":
        entry["persistent_globs"] = [
            "settings.json",
            "ota/config.json",
            "ota/backup/**",
            "ota/versions.json",
            "ota/history.json",
            "ota/persist_profile.json",
        ]
    if kind == "stack":
        entry["printer_cfg_replace"] = True
        entry["printer_cfg_merge"] = False
    return entry, name, digest


def merge_packages(existing, new_pkgs):
    by_kind = {}
    for p in existing:
        by_kind[p.get("kind")] = p
    for p in new_pkgs:
        by_kind[p.get("kind")] = p
    # install-oriented publish order (engine sorts again on device)
    order = ["system", "platform", "stack", "panel", "mcu", "factory"]
    out = []
    for k in order:
        if k in by_kind:
            out.append(by_kind.pop(k))
    out.extend(by_kind.values())
    return out


def upload_copy(files, dest_root):
    pkg_dir = os.path.join(dest_root, "packages")
    os.makedirs(pkg_dir, exist_ok=True)
    for src in files:
        shutil.copy2(src, os.path.join(pkg_dir, os.path.basename(src)))
        side = src + ".sha256"
        if os.path.exists(side):
            shutil.copy2(side, os.path.join(pkg_dir, os.path.basename(side)))


def upload_scp(files, dest):
    # dest = user@host:/path/ncpsky-ota
    remote_pkg = dest.rstrip("/") + "/packages/"
    subprocess.check_call(["ssh", dest.split(":")[0], "mkdir -p %s/packages" % dest.split(":", 1)[1]])
    for src in files:
        subprocess.check_call(["scp", src, remote_pkg])
        side = src + ".sha256"
        if os.path.exists(side):
            subprocess.check_call(["scp", side, remote_pkg])


def upload_rclone(files, dest):
    # dest = remote:path/ncpsky-ota
    for src in files:
        subprocess.check_call(["rclone", "copy", src, dest.rstrip("/") + "/packages/"])
        side = src + ".sha256"
        if os.path.exists(side):
            subprocess.check_call(["rclone", "copy", side, dest.rstrip("/") + "/packages/"])


def upload_s3(files, dest):
    # dest = s3://bucket/ncpsky-ota
    for src in files:
        subprocess.check_call([
            "aws", "s3", "cp", src, dest.rstrip("/") + "/packages/" + os.path.basename(src)
        ])


def main():
    ap = argparse.ArgumentParser(description="Publish NCPSKY OTA packages")
    ap.add_argument(
        "--channel",
        default="beta",
        choices=("stable", "beta", "dev", "factory"),
    )
    ap.add_argument("--method", default="copy", choices=("copy", "scp", "rclone", "s3"))
    ap.add_argument("--dest", required=True, help="upload destination root (ncpsky-ota)")
    ap.add_argument("--manifest", help="existing manifest to merge")
    ap.add_argument("--panel-zip")
    ap.add_argument("--panel-version")
    ap.add_argument("--stack-zip")
    ap.add_argument("--stack-version")
    ap.add_argument("--system-list", help="legacy .list OR system-*.tar.gz from build_system_pkg")
    ap.add_argument("--system-version")
    ap.add_argument("--platform-tar")
    ap.add_argument("--platform-version")
    ap.add_argument("--factory-tar")
    ap.add_argument("--factory-version")
    ap.add_argument("--mcu-bin")
    ap.add_argument("--mcu-version")
    ap.add_argument("--firmware-version", default="", help="user-facing product version")
    ap.add_argument("--notes", default="")
    ap.add_argument("--min-panel", default="0.5.0")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    here = os.path.dirname(os.path.abspath(__file__))
    examples = os.path.join(here, "..", "examples")
    base_man = load_json(
        args.manifest
        or os.path.join(examples, "manifest.%s.json" % args.channel),
        {
            "product": PRODUCT,
            "firmware_target": FIRMWARE_TARGET,
            "channel": args.channel,
            "packages": [],
        },
    )

    new_pkgs = []
    upload_files = []

    def add(kind, version, path, **kw):
        if not path:
            return
        if not os.path.exists(path):
            raise SystemExit("missing %s" % path)
        ver = version
        if not ver:
            # infer from filename panel-0.5.1.zip
            base = os.path.basename(path)
            stem = os.path.splitext(base)[0]
            ver = stem.split("-", 1)[-1]
        entry, name, digest = pkg_entry(kind, ver, path, notes=args.notes, **kw)
        new_pkgs.append(entry)
        upload_files.append(path)
        with open(path + ".sha256", "w", encoding="utf-8") as f:
            f.write("%s  %s\n" % (digest, name))

    add("panel", args.panel_version, args.panel_zip, min_free_mb=80)
    add("stack", args.stack_version, args.stack_zip, min_free_mb=400)
    add("system", args.system_version, args.system_list, min_free_mb=300)
    add("platform", args.platform_version, args.platform_tar, min_free_mb=200)
    add("mcu", args.mcu_version, args.mcu_bin, min_free_mb=20, auto=False)
    if args.channel == "factory" or args.factory_tar:
        add("factory", args.factory_version, args.factory_tar, min_free_mb=500, auto=False)

    man = dict(base_man)
    man["product"] = PRODUCT
    man["firmware_target"] = FIRMWARE_TARGET
    man["channel"] = args.channel
    man["published_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    man["min_panel"] = args.min_panel
    if args.firmware_version:
        man["version"] = args.firmware_version
    if args.notes:
        man["notes"] = args.notes
    man["packages"] = merge_packages(man.get("packages") or [], new_pkgs)

    dist = os.path.join(here, "..", "dist")
    os.makedirs(dist, exist_ok=True)
    man_path = os.path.join(dist, "manifest.%s.json" % args.channel)
    save_json(man_path, man)
    # also write channel slice + root name used by devices
    channel_slice = {
        "channel": args.channel,
        "manifest": "channels/%s.json" % args.channel,
        "redirect": "manifest.json" if args.channel == "stable" else None,
    }
    print(json.dumps(man, indent=2, ensure_ascii=False))

    if args.dry_run:
        print("dry-run: wrote", man_path)
        return 0

    if args.method == "copy":
        upload_copy(upload_files, args.dest)
        os.makedirs(os.path.join(args.dest, "channels"), exist_ok=True)
        save_json(os.path.join(args.dest, "channels", "%s.json" % args.channel), man)
        if args.channel == "stable":
            save_json(os.path.join(args.dest, "manifest.json"), man)
        else:
            # keep root manifest as stable if present; else write this channel
            root_man = os.path.join(args.dest, "manifest.json")
            if not os.path.exists(root_man):
                save_json(root_man, man)
    elif args.method == "scp":
        upload_scp(upload_files, args.dest)
        # write manifests via temp + scp
        tmp_ch = man_path
        host, rpath = args.dest.split(":", 1)
        subprocess.check_call(["ssh", host, "mkdir -p %s/channels %s/packages" % (rpath, rpath)])
        subprocess.check_call(["scp", tmp_ch, "%s:%s/channels/%s.json" % (host, rpath, args.channel)])
        if args.channel == "stable":
            subprocess.check_call(["scp", tmp_ch, "%s:%s/manifest.json" % (host, rpath)])
    elif args.method == "rclone":
        upload_rclone(upload_files, args.dest)
        subprocess.check_call(["rclone", "copy", man_path, args.dest.rstrip("/") + "/channels/"])
        # rename remotely is awkward; also copy as manifest if stable
        if args.channel == "stable":
            subprocess.check_call([
                "rclone", "copyto", man_path, args.dest.rstrip("/") + "/manifest.json"
            ])
    elif args.method == "s3":
        upload_s3(upload_files, args.dest)
        subprocess.check_call([
            "aws", "s3", "cp", man_path,
            args.dest.rstrip("/") + "/channels/%s.json" % args.channel,
        ])
        if args.channel == "stable":
            subprocess.check_call([
                "aws", "s3", "cp", man_path, args.dest.rstrip("/") + "/manifest.json"
            ])

    print("Published channel=%s method=%s dest=%s" % (args.channel, args.method, args.dest))
    print("channel_slice", channel_slice)
    return 0


if __name__ == "__main__":
    sys.exit(main())
