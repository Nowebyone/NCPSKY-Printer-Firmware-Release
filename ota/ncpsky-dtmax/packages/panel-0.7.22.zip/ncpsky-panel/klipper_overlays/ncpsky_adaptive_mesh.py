# NCPSKY adaptive bed mesh for delta beds.
# Reads the running gcode file (first-layer extrusion, else EXCLUDE_OBJECT
# polygons) and probes only that circle. No slicer start-gcode placeholders.
import json
import logging
import math
import os
import re

WORD_RE = re.compile(r'([A-Za-z])([+-]?(?:\d+(?:\.\d*)?|\.\d+))')
LAYER_CHANGE_RE = re.compile(r'^;\s*LAYER_CHANGE\s*$', re.I)
LAYER_NUM_RE = re.compile(r'^;\s*LAYER\s*:\s*(\d+)\s*$', re.I)
POLYGON_RE = re.compile(r'POLYGON\s*=\s*(\[\[.*?\]\])', re.I)


def plan_adaptive_mesh(xmin, xmax, ymin, ymax, margin, max_r, min_r,
                       min_n, max_n, spacing):
    """Circle that covers the rectangle, clamped to the probeable radius."""
    if max_n % 2 == 0:
        max_n -= 1
    if min_n < 3:
        min_n = 3
    if min_n % 2 == 0:
        min_n += 1
    if max_n < min_n:
        max_n = min_n
    if spacing < 5.0:
        spacing = 45.0
    if min_r < 5.0:
        min_r = 20.0
    if margin < 0.0:
        margin = 0.0
    ox = (xmin + xmax) / 2.0
    oy = (ymin + ymax) / 2.0
    half_x = (xmax - xmin) / 2.0 + margin
    half_y = (ymax - ymin) / 2.0 + margin
    radius = math.sqrt(half_x * half_x + half_y * half_y)
    if radius < min_r:
        radius = min_r
    origin_dist = math.hypot(ox, oy)
    if origin_dist + radius > max_r:
        radius = max(max_r - origin_dist, min_r)
    origin_dist = math.hypot(ox, oy)
    if origin_dist + radius > max_r and origin_dist > 0.01:
        allow = max(max_r - radius, 0.0)
        scale = allow / origin_dist
        ox *= scale
        oy *= scale
    radius = min(radius, max_r)
    radius = int(radius * 10) / 10.0
    if radius < min_r <= max_r:
        radius = int(min_r * 10) / 10.0
        origin_dist = math.hypot(ox, oy)
        if origin_dist + radius > max_r and origin_dist > 0.01:
            allow = max(max_r - radius, 0.0)
            scale = allow / origin_dist
            ox *= scale
            oy *= scale
    count = _probe_count(radius * 2.0, spacing, min_n, max_n, radius)
    limit2 = radius * radius + 0.25
    covered = True
    for px, py in ((xmin, ymin), (xmin, ymax), (xmax, ymin), (xmax, ymax)):
        dx = px - ox
        dy = py - oy
        if dx * dx + dy * dy > limit2:
            covered = False
            break
    return {
        'origin_x': ox,
        'origin_y': oy,
        'radius': radius,
        'probe_count': count,
        'covered': covered,
    }


def fused_probe_count(base_span, base_count, local_span, local_count, cap=31):
    """Grid count for a fused mesh. Finer of the two spacings wins."""
    base_count = max(3, int(base_count))
    local_count = max(3, int(local_count))
    base_spacing = float(base_span) / max(1, base_count - 1)
    local_spacing = float(local_span) / max(1, local_count - 1)
    spacing = min(base_spacing, local_spacing)
    if spacing < 5.0:
        spacing = 5.0
    count = int(math.ceil(float(base_span) / spacing)) + 1
    if count % 2 == 0:
        count += 1
    if count < base_count:
        count = base_count if base_count % 2 else base_count + 1
    if count > cap:
        count = cap if cap % 2 else cap - 1
    if count < 3:
        count = 3
    return count


def blend_z(base_z, local_z, dist, radius, blend):
    """Inside the new probe circle, replace Z. Blend at the rim. Outside, keep base."""
    if radius <= 0.0 or dist >= radius:
        return base_z, False
    if blend < 0.5:
        blend = 0.5
    if dist <= radius - blend:
        return local_z, True
    span = radius - (radius - blend)
    t = (radius - dist) / span
    return base_z + (local_z - base_z) * t, True


def plan_line_lift(cur, newpos, saw_line, hopped, lift_z=10.0):
    """After the purge line, travel at lift_z to the next XY instead of dragging.

    Returns (saw_line, inserts). inserts are moves to run before newpos.
    """
    if hopped or cur is None or len(cur) < 4 or len(newpos) < 4:
        return saw_line, []
    dist = math.hypot(newpos[0] - cur[0], newpos[1] - cur[1])
    edelta = newpos[3] - cur[3]
    low = cur[2] < 3.0 and newpos[2] < 3.0
    if (not saw_line and edelta > 0.05 and low and dist > 2.0):
        return True, []
    sparse = edelta <= 0.05 or (dist > 1.0 and edelta / dist < 0.015)
    if not (saw_line and low and dist >= 20.0 and sparse):
        return saw_line, []
    lift = [cur[0], cur[1], lift_z, cur[3]]
    travel = [newpos[0], newpos[1], lift_z, cur[3]]
    return saw_line, [(lift, 80.0), (travel, 100.0)]


def full_mesh(max_r, max_n):
    if max_n % 2 == 0:
        max_n -= 1
    if max_n < 3:
        max_n = 3
    return {
        'origin_x': 0.0,
        'origin_y': 0.0,
        'radius': int(max_r * 10) / 10.0,
        'probe_count': max_n,
        'covered': True,
    }


def _probe_count(diameter, spacing, min_n, max_n, radius):
    intervals = diameter / spacing
    nint = int(intervals)
    if intervals > nint:
        nint += 1
    raw = nint + 1
    if raw < min_n:
        raw = min_n
    if raw > max_n:
        raw = max_n
    if raw % 2 == 0:
        if raw + 1 <= max_n:
            raw += 1
        elif raw - 1 >= min_n:
            raw -= 1
    max_fit = int(radius * 2.0) + 1
    if max_fit % 2 == 0:
        max_fit -= 1
    if max_fit < 3:
        max_fit = 3
    if raw > max_fit:
        raw = max_fit
    if raw % 2 == 0:
        raw -= 1
    if raw < 3:
        raw = 3
    return raw


def scan_gcode(path, max_header=8 * 1024 * 1024, max_layer=16 * 1024 * 1024):
    """Return (xmin, ymin, xmax, ymax, source) or None.

    First-layer extruding moves win. The purge in the start gcode is ignored
    because it sits before the first layer marker. EXCLUDE_OBJECT polygons are
    the fallback when the file has no layer comments.
    """
    bounds = _Bounds()
    exclude = _Bounds()
    state = _Motion()
    in_layer = False
    seen_layer = False
    read_bytes = 0
    with open(path, 'r', encoding='utf-8', errors='replace') as handle:
        for raw in handle:
            read_bytes += len(raw)
            line = raw.split(';', 1)[0].strip()
            comment = raw.strip()
            if _layer_edge(comment, in_layer, seen_layer):
                if not seen_layer:
                    seen_layer = True
                    in_layer = True
                else:
                    break
                if line:
                    state.feed(line, None)
                continue
            if not seen_layer and read_bytes <= max_header:
                _note_exclude(comment, exclude)
            if in_layer and read_bytes > max_layer:
                break
            if not seen_layer and read_bytes > max_header:
                break
            if line:
                state.feed(line, bounds if in_layer else None)
    if bounds.ready:
        return (bounds.xmin, bounds.ymin, bounds.xmax, bounds.ymax, 'first_layer')
    if exclude.ready:
        return (exclude.xmin, exclude.ymin, exclude.xmax, exclude.ymax, 'exclude_object')
    return None


def _layer_edge(comment, in_layer, seen_layer):
    if LAYER_CHANGE_RE.match(comment):
        return True
    match = LAYER_NUM_RE.match(comment)
    if not match:
        return False
    num = int(match.group(1))
    if not seen_layer:
        return num == 0
    return num >= 1


def _note_exclude(comment, bounds):
    if 'EXCLUDE_OBJECT_DEFINE' not in comment.upper():
        return
    match = POLYGON_RE.search(comment)
    if not match:
        return
    try:
        points = json.loads(match.group(1))
    except (TypeError, ValueError):
        return
    for pt in points:
        if isinstance(pt, (list, tuple)) and len(pt) >= 2:
            bounds.add(float(pt[0]), float(pt[1]))


class _Bounds:
    def __init__(self):
        self.ready = False
        self.xmin = self.ymin = self.xmax = self.ymax = 0.0

    def add(self, x, y):
        if not self.ready:
            self.xmin = self.xmax = x
            self.ymin = self.ymax = y
            self.ready = True
            return
        self.xmin = min(self.xmin, x)
        self.xmax = max(self.xmax, x)
        self.ymin = min(self.ymin, y)
        self.ymax = max(self.ymax, y)

    def add_arc(self, x0, y0, x1, y1, i, j, clockwise):
        self.add(x0, y0)
        self.add(x1, y1)
        cx = x0 + i
        cy = y0 + j
        radius = math.hypot(i, j)
        if radius < 1e-6:
            return
        a0 = math.atan2(y0 - cy, x0 - cx)
        a1 = math.atan2(y1 - cy, x1 - cx)
        if clockwise:
            sweep = (a0 - a1) % (2.0 * math.pi)
        else:
            sweep = (a1 - a0) % (2.0 * math.pi)
        if sweep < 1e-9:
            sweep = 2.0 * math.pi
        for ang in (0.0, math.pi / 2.0, math.pi, 3.0 * math.pi / 2.0):
            if clockwise:
                delta = (a0 - ang) % (2.0 * math.pi)
            else:
                delta = (ang - a0) % (2.0 * math.pi)
            if delta <= sweep + 1e-6:
                self.add(cx + radius * math.cos(ang), cy + radius * math.sin(ang))


class _Motion:
    def __init__(self):
        self.x = self.y = self.z = self.e = 0.0
        self.abs_xyz = True
        self.abs_e = True

    def feed(self, line, bounds):
        parts = line.split()
        if not parts:
            return
        cmd = parts[0].upper()
        if cmd in ('G90',):
            self.abs_xyz = True
            self.abs_e = True
            return
        if cmd in ('G91',):
            self.abs_xyz = False
            self.abs_e = False
            return
        if cmd in ('M82',):
            self.abs_e = True
            return
        if cmd in ('M83',):
            self.abs_e = False
            return
        words = {}
        for match in WORD_RE.finditer(line):
            words[match.group(1).upper()] = float(match.group(2))
        if cmd == 'G92':
            if 'X' in words:
                self.x = words['X']
            if 'Y' in words:
                self.y = words['Y']
            if 'Z' in words:
                self.z = words['Z']
            if 'E' in words:
                self.e = words['E']
            return
        if cmd not in ('G0', 'G00', 'G1', 'G01', 'G2', 'G02', 'G3', 'G03'):
            return
        nx, ny = self.x, self.y
        if 'X' in words:
            nx = words['X'] if self.abs_xyz else self.x + words['X']
        if 'Y' in words:
            ny = words['Y'] if self.abs_xyz else self.y + words['Y']
        if 'Z' in words:
            self.z = words['Z'] if self.abs_xyz else self.z + words['Z']
        extruded = 0.0
        if 'E' in words:
            if self.abs_e:
                extruded = words['E'] - self.e
                self.e = words['E']
            else:
                extruded = words['E']
                self.e += words['E']
        moved = abs(nx - self.x) > 1e-6 or abs(ny - self.y) > 1e-6
        travel = cmd in ('G0', 'G00')
        if bounds is not None and moved and extruded > 1e-6 and not travel:
            dist = math.hypot(nx - self.x, ny - self.y)
            # A long, nearly dry move is the hop off the purge line, not the part.
            sparse = dist > 20.0 and extruded / dist < 0.01
            if cmd in ('G2', 'G02', 'G3', 'G03') and not sparse:
                i = words.get('I', 0.0)
                j = words.get('J', 0.0)
                bounds.add_arc(self.x, self.y, nx, ny, i, j, cmd in ('G2', 'G02'))
            elif sparse:
                bounds.add(nx, ny)
            else:
                bounds.add(self.x, self.y)
                bounds.add(nx, ny)
        self.x, self.y = nx, ny


class NcpskyAdaptiveMesh:
    def __init__(self, config):
        self.printer = config.get_printer()
        self.margin = config.getfloat('margin', 10.0)
        self.min_radius = config.getfloat('min_radius', 20.0, above=0.)
        self.min_probe = config.getint('min_probe', 3, minval=3)
        self.spacing = config.getfloat('target_spacing', 45.0, above=1.)
        self.max_radius = config.getfloat('max_radius', 0.0)
        self.max_probe = config.getint('max_probe', 0)
        self.enabled = config.getboolean('enabled', True)
        self._meshed_path = None
        self._saw_line = False
        self._hopped = False
        self.gcode = self.printer.lookup_object('gcode')
        gcode_move = self.printer.load_object(config, 'gcode_move')
        self.next_transform = gcode_move.set_move_transform(self, force=True)
        self.gcode.register_command(
            'ADAPTIVE_BED_MESH', self.cmd_ADAPTIVE_BED_MESH,
            desc=self.cmd_ADAPTIVE_BED_MESH_help)
        self.gcode.register_command(
            'SET_ADAPTIVE_BED_MESH', self.cmd_SET_ADAPTIVE_BED_MESH,
            desc=self.cmd_SET_ADAPTIVE_BED_MESH_help)
        self.printer.register_event_handler(
            'virtual_sdcard:reset_file', self._on_reset_file)

    def _on_reset_file(self):
        self._meshed_path = None
        self._saw_line = False
        self._hopped = False

    def get_position(self):
        return self.next_transform.get_position()

    def move(self, newpos, speed):
        # Purge line stays on the bed. The travel to the model does not.
        if not self._hopped:
            try:
                state = self.printer.lookup_object('print_stats').get_status(
                    self.printer.get_reactor().monotonic()).get('state')
            except Exception:
                state = None
            if state != 'printing':
                self._saw_line = False
            else:
                cur = self.get_position()
                self._saw_line, inserts = plan_line_lift(
                    cur, newpos, self._saw_line, self._hopped)
                for pos, spd in inserts:
                    self.next_transform.move(pos, spd)
                    self._hopped = True
        self.next_transform.move(newpos, speed)

    def _bed_limits(self):
        eventtime = self.printer.get_reactor().monotonic()
        settings = self.printer.lookup_object('configfile').get_status(eventtime)
        mesh = settings.get('settings', {}).get('bed_mesh', {})
        cfg_r = float(mesh.get('mesh_radius') or 135.0)
        cfg_n = int(mesh.get('round_probe_count') or 7)
        max_r = cfg_r
        if self.max_radius > 1.0:
            max_r = min(self.max_radius, cfg_r)
        max_n = cfg_n
        if self.max_probe >= 3:
            max_n = min(self.max_probe, cfg_n)
        return max_r, max_n

    def _gcode_path(self):
        vsd = self.printer.lookup_object('virtual_sdcard', None)
        if vsd is None:
            return None
        path = vsd.file_path()
        if path and os.path.isfile(path):
            return path
        eventtime = self.printer.get_reactor().monotonic()
        filename = self.printer.lookup_object('print_stats').get_status(eventtime).get('filename') or ''
        dirname = getattr(vsd, 'sdcard_dirname', '') or ''
        if filename and dirname:
            cand = os.path.join(dirname, filename)
            if os.path.isfile(cand):
                return cand
        return None

    cmd_ADAPTIVE_BED_MESH_help = "Mesh only the area this gcode actually prints"

    def cmd_ADAPTIVE_BED_MESH(self, gcmd):
        if not self.enabled and 'X_MIN' not in gcmd.get_command_parameters():
            gcmd.respond_info("ADAPTIVE_BED_MESH: disabled, skip")
            return
        path = self._gcode_path()
        params = gcmd.get_command_parameters()
        explicit = all(k in params for k in ('X_MIN', 'X_MAX', 'Y_MIN', 'Y_MAX'))
        if path and path == self._meshed_path and not explicit:
            gcmd.respond_info("ADAPTIVE_BED_MESH: already meshed this file")
            return
        max_r, max_n = self._bed_limits()
        if 'MAX_RADIUS' in params:
            max_r = min(gcmd.get_float('MAX_RADIUS'), max_r)
        if 'MAX_PROBE' in params:
            max_n = min(gcmd.get_int('MAX_PROBE', minval=3), max_n)
        margin = gcmd.get_float('MARGIN', self.margin)
        spacing = gcmd.get_float('SPACING', self.spacing)
        min_r = gcmd.get_float('MIN_RADIUS', self.min_radius)
        min_n = gcmd.get_int('MIN_PROBE', self.min_probe, minval=3)
        source = 'none'
        planned = None
        if explicit:
            xmin = min(gcmd.get_float('X_MIN'), gcmd.get_float('X_MAX'))
            xmax = max(gcmd.get_float('X_MIN'), gcmd.get_float('X_MAX'))
            ymin = min(gcmd.get_float('Y_MIN'), gcmd.get_float('Y_MAX'))
            ymax = max(gcmd.get_float('Y_MIN'), gcmd.get_float('Y_MAX'))
            source = 'params'
            planned = plan_adaptive_mesh(
                xmin, xmax, ymin, ymax, margin, max_r, min_r, min_n, max_n, spacing)
        else:
            scanned = None
            if path:
                try:
                    scanned = scan_gcode(path)
                except Exception:
                    logging.exception("ncpsky adaptive mesh scan failed")
                    gcmd.respond_info("ADAPTIVE_BED_MESH: gcode scan failed, full mesh")
            if scanned:
                xmin, ymin, xmax, ymax, source = scanned
                planned = plan_adaptive_mesh(
                    xmin, xmax, ymin, ymax, margin, max_r, min_r, min_n, max_n, spacing)
                gcmd.respond_info(
                    "ADAPTIVE_BED_MESH[%s]: bounds (%.1f,%.1f)-(%.1f,%.1f) margin=%.1f "
                    "-> ORIGIN=%.2f,%.2f R=%.1f N=%d covered=%d"
                    % (source, xmin, ymin, xmax, ymax, margin,
                       planned['origin_x'], planned['origin_y'],
                       planned['radius'], planned['probe_count'],
                       1 if planned['covered'] else 0))
            else:
                planned = full_mesh(max_r, max_n)
                gcmd.respond_info(
                    "ADAPTIVE_BED_MESH: no print bounds, full mesh R=%.1f N=%d"
                    % (planned['radius'], planned['probe_count']))
        if explicit:
            gcmd.respond_info(
                "ADAPTIVE_BED_MESH[params]: ORIGIN=%.2f,%.2f R=%.1f N=%d covered=%d"
                % (planned['origin_x'], planned['origin_y'], planned['radius'],
                   planned['probe_count'], 1 if planned['covered'] else 0))
        self._run_mesh(gcmd, planned)
        if path:
            self._meshed_path = path

    def _run_mesh(self, gcmd, planned):
        toolhead = self.printer.lookup_object('toolhead')
        eventtime = self.printer.get_reactor().monotonic()
        status = toolhead.get_status(eventtime)
        if 'xyz' not in status.get('homed_axes', ''):
            self.gcode.run_script_from_command('G28')
            eventtime = self.printer.get_reactor().monotonic()
            status = toolhead.get_status(eventtime)
        sav_vel = status['max_velocity']
        sav_accel = status['max_accel']
        sav_mcr = self._cruise_ratio(status)
        bedmesh = self.printer.lookup_object('bed_mesh', None)
        base_mesh = bedmesh.get_mesh() if bedmesh is not None else None
        if base_mesh is None:
            try:
                self.gcode.run_script_from_command(
                    'BED_MESH_PROFILE LOAD=default')
            except Exception:
                logging.exception("ncpsky adaptive mesh: no default profile")
            if bedmesh is not None:
                base_mesh = bedmesh.get_mesh()
        try:
            self.gcode.run_script_from_command('_NCPSKY_QUIET_TRAVEL_LIMIT')
            # Quiet travel caps velocity near 120. Mesh XY uses bed_mesh speed.
            self.gcode.run_script_from_command(
                'SET_VELOCITY_LIMIT VELOCITY=500 ACCEL=8000 MINIMUM_CRUISE_RATIO=0.5')
            self.gcode.run_script_from_command(
                "SET_GCODE_VARIABLE MACRO=NCPSKY_MOTION_STATUS VARIABLE=phase VALUE='\"level\"'")
            self.gcode.run_script_from_command(
                "BED_MESH_CALIBRATE PROFILE=adaptive MESH_ORIGIN=%.2f,%.2f "
                "MESH_RADIUS=%.1f ROUND_PROBE_COUNT=%d"
                % (planned['origin_x'], planned['origin_y'],
                   planned['radius'], planned['probe_count']))
            self._fuse_local_mesh(gcmd, bedmesh, base_mesh)
            self.gcode.run_script_from_command('G1 X0 Y0 Z20 F3000')
        finally:
            self._saw_line = False
            self._hopped = False
            self.gcode.run_script_from_command(
                "SET_GCODE_VARIABLE MACRO=NCPSKY_MOTION_STATUS VARIABLE=phase VALUE='\"idle\"'")
            self.gcode.run_script_from_command(
                "SET_VELOCITY_LIMIT VELOCITY=%s ACCEL=%s MINIMUM_CRUISE_RATIO=%s"
                % (sav_vel, sav_accel, sav_mcr))

    def _fuse_local_mesh(self, gcmd, bedmesh, base_mesh):
        if bedmesh is None or base_mesh is None:
            gcmd.respond_info("ADAPTIVE_BED_MESH: no saved mesh to fuse")
            return
        local = bedmesh.get_mesh()
        if local is None or local is base_mesh:
            return
        bp = base_mesh.get_mesh_params()
        lp = local.get_mesh_params()
        base_w = float(bp['max_x']) - float(bp['min_x'])
        base_h = float(bp['max_y']) - float(bp['min_y'])
        local_w = float(lp['max_x']) - float(lp['min_x'])
        local_h = float(lp['max_y']) - float(lp['min_y'])
        if local_w >= base_w - 5.0 and local_h >= base_h - 5.0:
            gcmd.respond_info("ADAPTIVE_BED_MESH: full-bed probe, mesh replaced")
            return
        nx = fused_probe_count(base_w, bp['x_count'], local_w, lp['x_count'])
        ny = fused_probe_count(base_h, bp['y_count'], local_h, lp['y_count'])
        params = dict(bp)
        params['x_count'] = nx
        params['y_count'] = ny
        params['min_x'] = float(bp['min_x'])
        params['max_x'] = float(bp['max_x'])
        params['min_y'] = float(bp['min_y'])
        params['max_y'] = float(bp['max_y'])
        algo = str(params.get('algo') or 'bicubic')
        if algo == 'lagrange' and max(nx, ny) > 6:
            algo = 'bicubic'
        if algo == 'bicubic' and min(nx, ny) < 4:
            algo = 'lagrange'
        params['algo'] = algo
        if 'tension' not in params:
            params['tension'] = 0.2
        params['mesh_x_pps'] = min(int(params.get('mesh_x_pps') or 2), 2)
        params['mesh_y_pps'] = min(int(params.get('mesh_y_pps') or 2), 2)
        cx = (float(lp['min_x']) + float(lp['max_x'])) / 2.0
        cy = (float(lp['min_y']) + float(lp['max_y'])) / 2.0
        radius = 0.5 * min(local_w, local_h)
        blend = min(12.0, max(4.0, radius * 0.2))
        matrix = []
        replaced = 0
        for j in range(ny):
            y = params['min_y'] + base_h * (float(j) / (ny - 1))
            row = []
            for i in range(nx):
                x = params['min_x'] + base_w * (float(i) / (nx - 1))
                dist = math.hypot(x - cx, y - cy)
                z, updated = blend_z(
                    base_mesh.calc_z(x, y), local.calc_z(x, y),
                    dist, radius, blend)
                if updated:
                    replaced += 1
                row.append(z)
            matrix.append(row)
        fused = type(base_mesh)(params, 'fused')
        try:
            fused.build_mesh(matrix)
            bedmesh.set_mesh(fused)
        except Exception:
            logging.exception("ncpsky adaptive mesh fuse failed")
            try:
                bedmesh.set_mesh(local)
            except Exception:
                logging.exception("ncpsky adaptive mesh restore failed")
            gcmd.respond_info("ADAPTIVE_BED_MESH: fuse failed, local mesh kept")
            return
        gcmd.respond_info(
            "ADAPTIVE_BED_MESH: fused %d/%d points into %dx%d mesh "
            "(local R=%.1f, spacing follows the finer grid)"
            % (replaced, nx * ny, nx, ny, radius))

    def _cruise_ratio(self, status):
        if 'minimum_cruise_ratio' in status:
            return float(status['minimum_cruise_ratio'])
        accel = float(status.get('max_accel') or 1.)
        legacy = status.get('max_accel_to_decel')
        if legacy is None or accel <= 0:
            return 0.5
        return max(0., min(0.99, 1. - (float(legacy) / accel)))

    cmd_SET_ADAPTIVE_BED_MESH_help = "Enable adaptive mesh and tune margin / spacing"

    def cmd_SET_ADAPTIVE_BED_MESH(self, gcmd):
        params = gcmd.get_command_parameters()
        if 'ENABLE' in params:
            self.enabled = bool(gcmd.get_int('ENABLE'))
        if 'MARGIN' in params:
            self.margin = gcmd.get_float('MARGIN')
        if 'SPACING' in params:
            self.spacing = gcmd.get_float('SPACING', above=1.)
        if 'MIN_RADIUS' in params:
            self.min_radius = gcmd.get_float('MIN_RADIUS', above=0.)
        if 'MAX_RADIUS' in params:
            self.max_radius = gcmd.get_float('MAX_RADIUS')
        if 'MAX_PROBE' in params:
            self.max_probe = gcmd.get_int('MAX_PROBE', minval=0)
        gcmd.respond_info(
            "ADAPTIVE_BED_MESH settings: enabled=%s margin=%s spacing=%s "
            "min_radius=%s max_radius=%s max_probe=%s"
            % (self.enabled, self.margin, self.spacing,
               self.min_radius, self.max_radius, self.max_probe))

    def get_status(self, eventtime):
        return {
            'enabled': self.enabled,
            'margin': self.margin,
            'spacing': self.spacing,
            'min_radius': self.min_radius,
        }


def load_config(config):
    return NcpskyAdaptiveMesh(config)
