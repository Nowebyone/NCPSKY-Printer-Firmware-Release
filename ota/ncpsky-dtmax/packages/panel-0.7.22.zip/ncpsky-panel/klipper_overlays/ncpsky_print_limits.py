# Print-time accel ceiling from input-shaper calibration.
# Travel and homing keep the printer max_accel. A cap of 0 means
# shaper calibration has not produced a number yet.
import logging


class NcpskyPrintLimits:
    def __init__(self, config):
        self.printer = config.get_printer()
        self.cap = config.getfloat('max_accel', 0., minval=0.)
        self.travel_accel = config.getsection('printer').getfloat(
            'max_accel', above=0.)
        self._pending = None
        self._m204 = None
        self._set_velocity = None
        self.gcode = self.printer.lookup_object('gcode')
        self.gcode.register_command(
            'NCPSKY_PRINT_LIMITS_BEGIN', self.cmd_BEGIN,
            desc=self.cmd_BEGIN_help)
        self.printer.register_event_handler('klippy:connect', self._connect)

    def _connect(self):
        gcode = self.gcode
        self._m204 = gcode.register_command('M204', None)
        if self._m204 is not None:
            gcode.register_command('M204', self.cmd_M204)
        self._set_velocity = gcode.register_command('SET_VELOCITY_LIMIT', None)
        if self._set_velocity is not None:
            gcode.register_command(
                'SET_VELOCITY_LIMIT', self.cmd_SET_VELOCITY_LIMIT)
        stats = self.printer.lookup_object('print_stats', None)
        if stats is None:
            return
        orig_start = stats.note_start
        orig_finish = stats._note_finish

        def note_start():
            orig_start()
            self.apply_cap()

        def note_finish(state, error_message=''):
            orig_finish(state, error_message)
            if stats.state in ('complete', 'error', 'cancelled'):
                self.restore_travel()

        stats.note_start = note_start
        stats._note_finish = note_finish

    def _printing(self):
        stats = self.printer.lookup_object('print_stats', None)
        if stats is None:
            return False
        return stats.state in ('printing', 'paused')

    def clamp_accel(self, accel):
        if accel is None or self.cap <= 0. or not self._printing():
            return accel
        if accel > self.cap:
            return self.cap
        return accel

    def _clamp_param(self, gcmd, name):
        params = gcmd.get_command_parameters()
        raw = params.get(name)
        if raw is None:
            return
        try:
            value = float(raw)
        except ValueError:
            return
        capped = self.clamp_accel(value)
        if capped != value:
            params[name] = '%.6f' % (capped,)

    def cmd_M204(self, gcmd):
        self._clamp_param(gcmd, 'S')
        self._clamp_param(gcmd, 'P')
        self._clamp_param(gcmd, 'T')
        self._m204(gcmd)

    def cmd_SET_VELOCITY_LIMIT(self, gcmd):
        self._clamp_param(gcmd, 'ACCEL')
        self._set_velocity(gcmd)

    def apply_cap(self):
        if self.cap <= 0.:
            return
        toolhead = self.printer.lookup_object('toolhead')
        eventtime = self.printer.get_reactor().monotonic()
        current = toolhead.get_status(eventtime)['max_accel']
        if current > self.cap:
            toolhead.set_max_velocities(None, self.cap, None, None)
            logging.info("ncpsky print accel cap %.0f", self.cap)

    def restore_travel(self):
        toolhead = self.printer.lookup_object('toolhead')
        toolhead.set_max_velocities(None, self.travel_accel, None, None)

    cmd_BEGIN_help = "Start a shaper pass so the print accel cap is recomputed"

    def cmd_BEGIN(self, gcmd):
        self._pending = None
        gcmd.respond_info("NCPSKY print accel cap will be recomputed")

    def note_shaper_accel(self, accel):
        rounded = round(float(accel) / 100.) * 100.
        if rounded < 100.:
            rounded = 100.
        if self._pending is None:
            self._pending = rounded
        else:
            self._pending = min(self._pending, rounded)
        self.cap = self._pending
        configfile = self.printer.lookup_object('configfile')
        configfile.set('ncpsky_print_limits', 'max_accel', '%.0f' % (self.cap,))
        self.gcode.respond_info(
            "NCPSKY print accel cap %.0f mm/s^2" % (self.cap,))


def load_config(config):
    return NcpskyPrintLimits(config)
