#!/bin/bash
# Start NCPSKY panel. Always invoke via bash so OTA zip +x loss cannot brick splash.
export HOME=/home/pi
# Belt-and-suspenders: stop any leftover bootloop from old builds
if [ -f /tmp/ncpsky_bootloop.pid ]; then
  kill "$(cat /tmp/ncpsky_bootloop.pid)" 2>/dev/null || true
  rm -f /tmp/ncpsky_bootloop.pid
fi
pkill -x TUI 2>/dev/null || true
pkill -x TestApp 2>/dev/null || true
cd /home/pi/qt/out_linux || true
exec bash /home/pi/ncpsky-panel/scripts/run_panel.sh
