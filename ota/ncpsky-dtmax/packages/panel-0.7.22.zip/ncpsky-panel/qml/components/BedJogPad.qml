import QtQuick 2.15
import ".."

// Top-down heated-bed disk: drag finger, release → absolute XY move
Item {
    id: root

    property real bedRadius: 145
    property real toolX: 0
    property real toolY: 0
    property real targetX: 0
    property real targetY: 0
    property bool dragging: false
    property bool showLabels: true

    signal moveRequested(real x, real y)
    signal homeRequested()

    // Printer mm → canvas px (top of disk = +Y / 前)
    function bedToPx(mx, my) {
        var r = _rBed()
        var c = _center()
        return {
            x: c.x + (mx / Math.max(1, root.bedRadius)) * r,
            y: c.y - (my / Math.max(1, root.bedRadius)) * r
        }
    }

    function pxToBed(px, py) {
        var r = _rBed()
        var c = _center()
        if (r < 1)
            return { x: 0, y: 0 }
        var mx = ((px - c.x) / r) * root.bedRadius
        var my = ((c.y - py) / r) * root.bedRadius
        return _clampBed(mx, my)
    }

    function _clampBed(mx, my) {
        var d = Math.sqrt(mx * mx + my * my)
        var lim = Math.max(1, root.bedRadius) * 0.995
        if (d > lim && d > 0) {
            mx = mx * lim / d
            my = my * lim / d
        }
        return { x: mx, y: my }
    }

    function _center() {
        return { x: width * 0.5, y: height * 0.5 }
    }

    function _rBed() {
        return Math.min(width, height) * 0.42
    }

    function _setTargetFromPoint(px, py) {
        var p = pxToBed(px, py)
        root.targetX = p.x
        root.targetY = p.y
        canvas.requestPaint()
    }

    onToolXChanged: canvas.requestPaint()
    onToolYChanged: canvas.requestPaint()
    onBedRadiusChanged: canvas.requestPaint()
    onWidthChanged: canvas.requestPaint()
    onHeightChanged: canvas.requestPaint()

    Canvas {
        id: canvas
        anchors.fill: parent
        antialiasing: true

        onPaint: {
            var ctx = getContext("2d")
            var w = width, h = height
            if (w < 4 || h < 4)
                return
            ctx.clearRect(0, 0, w, h)

            var c = root._center()
            var r = root._rBed()
            var cx = c.x, cy = c.y

            // Soft plate fill
            ctx.beginPath()
            ctx.arc(cx, cy, r, 0, Math.PI * 2)
            ctx.fillStyle = "#151A1F"
            ctx.fill()
            ctx.strokeStyle = "#2A3138"
            ctx.lineWidth = 1.6
            ctx.stroke()

            // Concentric rings
            ctx.strokeStyle = "#1E242A"
            ctx.lineWidth = 1
            for (var g = 1; g <= 3; g++) {
                ctx.beginPath()
                ctx.arc(cx, cy, r * g / 3, 0, Math.PI * 2)
                ctx.stroke()
            }

            // Crosshair
            ctx.strokeStyle = "#262C33"
            ctx.beginPath()
            ctx.moveTo(cx - r, cy)
            ctx.lineTo(cx + r, cy)
            ctx.moveTo(cx, cy - r)
            ctx.lineTo(cx, cy + r)
            ctx.stroke()

            // Center tick
            ctx.beginPath()
            ctx.arc(cx, cy, 2.2, 0, Math.PI * 2)
            ctx.fillStyle = "#5A6169"
            ctx.fill()

            // Cardinal labels (前 = +Y top)
            if (root.showLabels) {
                ctx.fillStyle = "#5A6169"
                ctx.font = "11px sans-serif"
                ctx.textAlign = "center"
                ctx.textBaseline = "middle"
                ctx.fillText(AppState.tr("device.front"), cx, cy - r - 10)
                ctx.fillText(AppState.tr("device.back"), cx, cy + r + 10)
                ctx.textAlign = "right"
                ctx.fillText(AppState.tr("device.left"), cx - r - 8, cy)
                ctx.textAlign = "left"
                ctx.fillText(AppState.tr("device.right"), cx + r + 8, cy)
            }

            // Live nozzle
            var nz = root.bedToPx(root.toolX, root.toolY)
            ctx.beginPath()
            ctx.arc(nz.x, nz.y, 5, 0, Math.PI * 2)
            ctx.fillStyle = "#A78BFA"
            ctx.fill()
            ctx.strokeStyle = "#C4B5FD"
            ctx.lineWidth = 1
            ctx.stroke()

            // Drag / pending target
            if (root.dragging) {
                var tg = root.bedToPx(root.targetX, root.targetY)
                ctx.beginPath()
                ctx.moveTo(nz.x, nz.y)
                ctx.lineTo(tg.x, tg.y)
                ctx.strokeStyle = "rgba(167,139,250,0.45)"
                ctx.lineWidth = 1.2
                ctx.stroke()

                ctx.beginPath()
                ctx.arc(tg.x, tg.y, 7, 0, Math.PI * 2)
                ctx.strokeStyle = "#A78BFA"
                ctx.lineWidth = 1.8
                ctx.stroke()
                ctx.beginPath()
                ctx.arc(tg.x, tg.y, 2.5, 0, Math.PI * 2)
                ctx.fillStyle = "#F0F2F4"
                ctx.fill()
            }
        }
    }

    // Coord readout
    Text {
        anchors.left: parent.left
        anchors.bottom: parent.bottom
        anchors.margins: 4
        text: root.dragging
              ? ("→ " + root.targetX.toFixed(0) + ", " + root.targetY.toFixed(0))
              : (root.toolX.toFixed(0) + ", " + root.toolY.toFixed(0))
        color: root.dragging ? Theme.accent : Theme.textMute
        font.pixelSize: 10
        font.family: Theme.fontFamily
        font.weight: Theme.fontWeight
    }

    // Center home tap target (small, doesn't block disk drag elsewhere)
    Item {
        id: homeHit
        width: 36
        height: 36
        anchors.centerIn: parent
        z: 2

        Rectangle {
            anchors.centerIn: parent
            width: 28
            height: 22
            radius: 4
            color: homeTouch.pressed ? Theme.bgTilePressed : Theme.accentSoft
            opacity: 0.92
        }
        Text {
            anchors.centerIn: parent
            text: AppState.tr("device.xyz.home")
            color: Theme.accent
            font.pixelSize: 10
            font.family: Theme.fontFamily
            font.weight: Theme.fontWeight
        }
        TouchArea {
            id: homeTouch
            anchors.fill: parent
            onClicked: root.homeRequested()
        }
    }

    TouchArea {
        id: drag
        anchors.fill: parent
        // Leave center home button usable
        z: 1

        function hitHome(px, py) {
            var dx = px - (homeHit.x + homeHit.width / 2)
            var dy = py - (homeHit.y + homeHit.height / 2)
            return (dx * dx + dy * dy) < 18 * 18
        }

        onPressed: {
            if (hitHome(mouse.x, mouse.y)) {
                mouse.accepted = false
                return
            }
            root.dragging = true
            root._setTargetFromPoint(mouse.x, mouse.y)
        }
        onPositionChanged: {
            if (!root.dragging)
                return
            root._setTargetFromPoint(mouse.x, mouse.y)
        }
        onReleased: {
            if (!root.dragging)
                return
            root.dragging = false
            root._setTargetFromPoint(mouse.x, mouse.y)
            root.moveRequested(root.targetX, root.targetY)
            canvas.requestPaint()
        }
        onCanceled: {
            root.dragging = false
            canvas.requestPaint()
        }
    }
}
