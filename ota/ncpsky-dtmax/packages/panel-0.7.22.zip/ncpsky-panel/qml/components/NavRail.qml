import QtQuick 2.15
import ".."

Item {
    id: rail
    // width set by main.qml (0 while calibrating fullscreen)
    height: parent.height

    // C-end IA: 首页 / 设备 / 耗材 / 校准 / 设置（消息在顶栏气泡）
    property var items: [
        { id: "home", icon: "home" },
        { id: "device", icon: "device" },
        { id: "filament", icon: "filament" },
        { id: "calibrate", icon: "calibrate" },
        { id: "settings", icon: "settings" }
    ]

    readonly property int itemH: Math.max(40, Math.floor((height - 10) / items.length))

    Rectangle {
        anchors.fill: parent
        color: Theme.bgPanel
    }
    Rectangle {
        anchors.right: parent.right
        width: 1
        height: parent.height
        color: Theme.lineSoft
    }

    Column {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: parent.top
        anchors.topMargin: 4
        spacing: 0

        Repeater {
            model: rail.items
            delegate: Item {
                width: Theme.navW - 2
                height: rail.itemH
                property bool active: AppState.page === modelData.id
                    || (modelData.id === "home" && (AppState.page === "files" || AppState.page === "print"))

                Rectangle {
                    anchors.fill: parent
                    anchors.margins: 2
                    radius: Theme.radius
                    color: active ? Theme.bgTile : (touch.pressed ? Theme.bgTilePressed : "transparent")
                }
                Rectangle {
                    anchors.left: parent.left
                    anchors.verticalCenter: parent.verticalCenter
                    width: 2
                    height: active ? 18 : 0
                    radius: 1
                    color: Theme.accent
                    Behavior on height { NumberAnimation { duration: Theme.animFast } }
                }
                NavIcon {
                    anchors.centerIn: parent
                    name: modelData.icon
                    ink: active ? Theme.textPrimary : Theme.textMute
                }
                TouchArea {
                    id: touch
                    anchors.fill: parent
                    onClicked: AppState.go(modelData.id)
                }
            }
        }
    }
}
