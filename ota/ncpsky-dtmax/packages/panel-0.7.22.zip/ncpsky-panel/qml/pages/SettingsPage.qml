import QtQuick 2.15
import "../components"
import ".."

Item {
    id: page
    // tabs: wifi | proxy | update | display | more
    property string tab: "wifi"
    property string pendingWifiSsid: ""
    property bool pendingWifiOpen: false
    property string editTarget: ""
    property string proxyInputMode: "share"
    property bool proxyAdvanced: false

    readonly property var tabs: [
        { id: "wifi", label: AppState.tr("settings.tab.wifi") },
        { id: "proxy", label: AppState.tr("settings.tab.proxy") },
        { id: "update", label: AppState.tr("settings.tab.update") },
        { id: "display", label: AppState.tr("settings.tab.display") },
        { id: "more", label: AppState.tr("settings.tab.more") }
    ]

    function switchTab(id) {
        page.tab = id
        page.proxyAdvanced = false
        // Drop leftover scroll from Wi‑Fi list — avoids speckles / clipped tiles on linuxfb
        pane.contentY = 0
        if (id === "wifi")
            AppState.refreshWifi()
        if (id === "update" || id === "more")
            AppState.refreshOtaStatus()
        if (id === "proxy")
            AppState.refreshWifi()
    }

    function openEditor(target, title, value, isPassword) {
        page.editTarget = target
        kb.show({ title: title, text: value || "", password: !!isPassword })
    }

    function onEditorAccepted(value) {
        var t = page.editTarget
        page.editTarget = ""
        if (t === "wifi_password") {
            AppState.wifiConnect(page.pendingWifiSsid, value, page.pendingWifiOpen && !value)
            return
        }
        if (t === "proxy_paste") {
            AppState.setProxyConfig(value, page.proxyInputMode, null)
            return
        }
        if (t === "proxy_port") {
            AppState.proxyLocalPort = value || "7890"
            return
        }
        if (t === "m_server") { AppState.proxyManualServer = value; return }
        if (t === "m_port") { AppState.proxyManualPort = value; return }
        if (t === "m_uuid") { AppState.proxyManualUuid = value; return }
        if (t === "m_sni") { AppState.proxyManualSni = value; return }
        if (t === "m_pbk") { AppState.proxyManualPbk = value; return }
        if (t === "m_sid") { AppState.proxyManualSid = value; return }
    }

    function connectWifi(ssid, security) {
        page.pendingWifiSsid = ssid
        page.pendingWifiOpen = (security === "open")
        if (page.pendingWifiOpen) {
            AppState.wifiConnect(ssid, "", true)
            return
        }
        openEditor("wifi_password", AppState.tr("settings.wifi.password") + " · " + ssid, "", true)
    }

    function proxyStatusText() {
        if (AppState.proxySingboxActive && AppState.proxyLocalListening)
            return AppState.tr("settings.proxy.ready")
        if (AppState.proxyConfigured)
            return AppState.tr("settings.proxy.configured")
        return AppState.tr("settings.proxy.none")
    }

    function proxyPasteTitle() {
        if (page.proxyInputMode === "subscribe")
            return AppState.tr("settings.proxy.sub")
        if (page.proxyInputMode === "http")
            return AppState.tr("settings.proxy.http")
        if (page.proxyInputMode === "manual")
            return AppState.tr("settings.proxy.manual")
        return AppState.tr("settings.proxy.share")
    }

    function applyManualProxy() {
        AppState.setProxyConfig("", "manual", {
            type: "vless",
            server: AppState.proxyManualServer,
            server_port: parseInt(AppState.proxyManualPort) || 443,
            uuid: AppState.proxyManualUuid,
            sni: AppState.proxyManualSni,
            server_name: AppState.proxyManualSni,
            pbk: AppState.proxyManualPbk,
            public_key: AppState.proxyManualPbk,
            sid: AppState.proxyManualSid,
            short_id: AppState.proxyManualSid,
            security: "reality"
        })
    }

    function wifiSummary() {
        if (!AppState.wifiSsid)
            return AppState.tr("settings.wifi.disconnected")
        var s = AppState.wifiSsid
        if (AppState.wifiIp)
            s += "  ·  " + AppState.wifiIp
        return s
    }

    Column {
        id: rootCol
        anchors.fill: parent
        anchors.leftMargin: 8
        anchors.rightMargin: 8
        anchors.topMargin: 4
        anchors.bottomMargin: 4
        spacing: 4

        // Title row
        Text {
            id: titleText
            text: AppState.tr("settings.title")
            color: Theme.textPrimary
            font.pixelSize: Theme.fontTitle
            font.family: Theme.fontFamily
            font.weight: Theme.fontWeight
            font.letterSpacing: 0.3
        }

        // Category tabs — one job at a time
        Row {
            id: tabRow
            width: parent.width
            spacing: 4
            Repeater {
                model: page.tabs
                delegate: Rectangle {
                    width: Math.floor((tabRow.width - 16) / page.tabs.length)
                    height: 30
                    radius: Theme.radius
                    color: page.tab === modelData.id
                           ? Theme.accentSoft
                           : (tabTouch.pressed ? Theme.bgTilePressed : Theme.bgTile)
                    border.width: page.tab === modelData.id ? 0 : 1
                    border.color: Theme.lineSoft
                    Text {
                        anchors.centerIn: parent
                        text: modelData.label
                        color: page.tab === modelData.id ? Theme.accent : Theme.textSecondary
                        font.pixelSize: Theme.fontSmall
                        font.weight: page.tab === modelData.id ? Theme.fontWeight : Theme.fontWeight
                    }
                    TouchArea {
                        id: tabTouch
                        anchors.fill: parent
                        onClicked: page.switchTab(modelData.id)
                    }
                }
            }
        }

        // Content pane — height from remaining space so bottom controls aren't clipped
        Flickable {
            id: pane
            width: parent.width
            height: Math.max(80, rootCol.height - titleText.height - tabRow.height - 8)
            contentWidth: width
            contentHeight: Math.max(height, body.height + 16)
            clip: true
            boundsBehavior: Flickable.StopAtBounds
            pressDelay: 80
            interactive: !kb.open && contentHeight > height + 2

            Column {
                id: body
                width: parent.width
                spacing: 6

                // ========== Wi‑Fi ==========
                Column {
                    width: parent.width
                    spacing: 8
                    visible: page.tab === "wifi"
                    height: visible ? implicitHeight : 0
                    clip: true

                    Rectangle {
                        width: parent.width
                        height: 40
                        radius: Theme.radiusLg
                        color: Theme.bgElevated
                        border.width: 1
                        border.color: Theme.lineSoft
                        Text {
                            anchors.left: parent.left
                            anchors.leftMargin: 12
                            anchors.verticalCenter: parent.verticalCenter
                            width: parent.width - 24
                            text: page.wifiSummary()
                            color: AppState.wifiSsid ? Theme.textPrimary : Theme.textMute
                            font.pixelSize: Theme.fontBody
                            elide: Text.ElideRight
                        }
                    }

                    Row {
                        spacing: 6
                        PrimaryButton {
                            text: AppState.tr("settings.wifi.scan")
                            height: 34
                            enabled: !AppState.wifiBusy
                            onClicked: AppState.wifiScan()
                        }
                        PrimaryButton {
                            text: AppState.tr("settings.wifi.disconnect")
                            primary: false
                            height: 34
                            enabled: !!AppState.wifiSsid
                            onClicked: AppState.wifiDisconnect()
                        }
                    }

                    Text {
                        width: parent.width
                        visible: !!AppState.wifiMessage || AppState.wifiList.length === 0
                        text: AppState.wifiBusy
                              ? AppState.tr("settings.wifi.scanning")
                              : (AppState.wifiMessage || AppState.tr("settings.wifi.empty"))
                        color: Theme.textMute
                        font.pixelSize: Theme.fontSmall
                    }

                    Repeater {
                        model: AppState.wifiList
                        delegate: Rectangle {
                            width: body.width
                            height: 40
                            radius: Theme.radius
                            color: wTouch.pressed ? Theme.bgTilePressed : Theme.bgTile
                            border.width: modelData.connected ? 1 : 0
                            border.color: Theme.accent
                            Column {
                                anchors.left: parent.left
                                anchors.leftMargin: 10
                                anchors.verticalCenter: parent.verticalCenter
                                spacing: 1
                                Text {
                                    text: modelData.ssid + (modelData.connected ? "  *" : "")
                                    color: Theme.textPrimary
                                    font.pixelSize: Theme.fontBody
                                    elide: Text.ElideRight
                                    width: body.width - 90
                                }
                                Text {
                                    text: (modelData.security === "open"
                                           ? AppState.tr("wifi.open") : AppState.tr("wifi.secure"))
                                          + "  " + modelData.signal + "dBm"
                                          + (modelData.freq >= 5000 ? "  5G" : "  2.4G")
                                    color: Theme.textMute
                                    font.pixelSize: 10
                                }
                            }
                            Text {
                                anchors.right: parent.right
                                anchors.rightMargin: 10
                                anchors.verticalCenter: parent.verticalCenter
                                text: modelData.connected ? "" : AppState.tr("settings.wifi.connect")
                                color: Theme.accent
                                font.pixelSize: Theme.fontSmall
                            }
                            TouchArea {
                                id: wTouch
                                anchors.fill: parent
                                enabled: !AppState.wifiBusy && !modelData.connected
                                onClicked: page.connectWifi(modelData.ssid, modelData.security)
                            }
                        }
                    }
                }

                // ========== Proxy ==========
                Column {
                    width: parent.width
                    spacing: 8
                    visible: page.tab === "proxy"
                    height: visible ? implicitHeight : 0
                    clip: true

                    Rectangle {
                        width: parent.width
                        height: 44
                        radius: Theme.radiusLg
                        color: Theme.bgElevated
                        border.width: 1
                        border.color: Theme.lineSoft
                        Column {
                            anchors.left: parent.left
                            anchors.leftMargin: 12
                            anchors.verticalCenter: parent.verticalCenter
                            spacing: 2
                            Text {
                                text: page.proxyStatusText()
                                color: (AppState.proxySingboxActive && AppState.otaProxyEnabled)
                                       ? Theme.accent : Theme.textPrimary
                                font.pixelSize: Theme.fontBody
                                font.family: Theme.fontFamily
                                font.weight: Theme.fontWeight
                            }
                            Text {
                                width: body.width - 24
                                visible: AppState.proxyConfigured
                                text: (AppState.proxyType ? (AppState.proxyType + " · ") : "")
                                      + (AppState.proxyLabel || AppState.proxyVlessHost || "")
                                color: Theme.textMute
                                font.pixelSize: 10
                                elide: Text.ElideMiddle
                            }
                        }
                    }

                    Row {
                        width: parent.width
                        spacing: 8
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            text: AppState.tr("settings.proxy.enable")
                            color: Theme.textSecondary
                            font.pixelSize: Theme.fontSmall
                            width: 88
                        }
                        SegButton {
                            text: AppState.tr("settings.ota.proxy.on")
                            height: 32
                            width: 56
                            active: AppState.otaProxyEnabled
                            onClicked: AppState.otaSetProxyEnabled(true)
                        }
                        SegButton {
                            text: AppState.tr("settings.ota.proxy.off")
                            height: 32
                            width: 56
                            active: !AppState.otaProxyEnabled
                            onClicked: AppState.otaSetProxyEnabled(false)
                        }
                    }

                    PrimaryButton {
                        text: AppState.proxyConfigured
                              ? AppState.tr("settings.proxy.reconfig")
                              : AppState.tr("settings.proxy.setup")
                        height: 36
                        width: Math.min(parent.width, 200)
                        onClicked: {
                            page.proxyInputMode = "share"
                            page.openEditor("proxy_paste",
                                            AppState.tr("settings.proxy.setup"),
                                            "", false)
                        }
                    }

                    Text {
                        width: parent.width
                        text: AppState.tr("settings.proxy.hint.simple")
                        color: Theme.textMute
                        font.pixelSize: Theme.fontSmall
                        wrapMode: Text.Wrap
                    }

                    // Advanced (collapsed)
                    Rectangle {
                        width: parent.width
                        height: 32
                        radius: Theme.radius
                        color: advTouch.pressed ? Theme.bgTilePressed : Theme.bgTile
                        Text {
                            anchors.left: parent.left
                            anchors.leftMargin: 10
                            anchors.verticalCenter: parent.verticalCenter
                            text: AppState.tr("settings.proxy.advanced")
                            color: Theme.textSecondary
                            font.pixelSize: Theme.fontSmall
                        }
                        Text {
                            anchors.right: parent.right
                            anchors.rightMargin: 10
                            anchors.verticalCenter: parent.verticalCenter
                            text: page.proxyAdvanced ? "v" : ">"
                            color: Theme.textMute
                        }
                        TouchArea {
                            id: advTouch
                            anchors.fill: parent
                            onClicked: page.proxyAdvanced = !page.proxyAdvanced
                        }
                    }

                    Column {
                        width: parent.width
                        spacing: 6
                        visible: page.proxyAdvanced

                        Row {
                            spacing: 4
                            SegButton {
                                text: AppState.tr("settings.proxy.share")
                                height: 28
                                active: page.proxyInputMode === "share"
                                onClicked: page.proxyInputMode = "share"
                            }
                            SegButton {
                                text: AppState.tr("settings.proxy.sub")
                                height: 28
                                active: page.proxyInputMode === "subscribe"
                                onClicked: page.proxyInputMode = "subscribe"
                            }
                            SegButton {
                                text: "HTTP"
                                height: 28
                                active: page.proxyInputMode === "http"
                                onClicked: page.proxyInputMode = "http"
                            }
                            SegButton {
                                text: AppState.tr("settings.proxy.manual")
                                height: 28
                                active: page.proxyInputMode === "manual"
                                onClicked: page.proxyInputMode = "manual"
                            }
                        }

                        PrimaryButton {
                            visible: page.proxyInputMode !== "manual"
                            text: page.proxyPasteTitle()
                            height: 32
                            width: Math.min(parent.width, 180)
                            primary: false
                            onClicked: page.openEditor("proxy_paste", page.proxyPasteTitle(), "", false)
                        }

                        Column {
                            width: parent.width
                            spacing: 4
                            visible: page.proxyInputMode === "manual"
                            Repeater {
                                model: [
                                    { key: "m_server", label: AppState.tr("settings.proxy.server"), value: AppState.proxyManualServer },
                                    { key: "m_port", label: "Port", value: AppState.proxyManualPort },
                                    { key: "m_uuid", label: AppState.tr("settings.proxy.uuid"), value: AppState.proxyManualUuid },
                                    { key: "m_sni", label: "SNI", value: AppState.proxyManualSni },
                                    { key: "m_pbk", label: "pbk", value: AppState.proxyManualPbk },
                                    { key: "m_sid", label: "sid", value: AppState.proxyManualSid }
                                ]
                                delegate: Rectangle {
                                    width: body.width
                                    height: 32
                                    radius: Theme.radius
                                    color: mTouch.pressed ? Theme.bgTilePressed : Theme.bgTile
                                    Text {
                                        anchors.left: parent.left
                                        anchors.leftMargin: 8
                                        anchors.verticalCenter: parent.verticalCenter
                                        text: modelData.label
                                        color: Theme.textMute
                                        font.pixelSize: 10
                                        width: 56
                                    }
                                    Text {
                                        anchors.left: parent.left
                                        anchors.leftMargin: 68
                                        anchors.right: parent.right
                                        anchors.rightMargin: 8
                                        anchors.verticalCenter: parent.verticalCenter
                                        text: modelData.value || "—"
                                        color: Theme.textPrimary
                                        font.pixelSize: Theme.fontSmall
                                        elide: Text.ElideMiddle
                                    }
                                    TouchArea {
                                        id: mTouch
                                        anchors.fill: parent
                                        onClicked: page.openEditor(modelData.key, modelData.label, modelData.value, false)
                                    }
                                }
                            }
                            PrimaryButton {
                                text: AppState.tr("settings.proxy.apply")
                                height: 32
                                width: 100
                                onClicked: page.applyManualProxy()
                            }
                        }

                        Row {
                            spacing: 6
                            Text {
                                anchors.verticalCenter: parent.verticalCenter
                                text: AppState.tr("settings.proxy.port")
                                color: Theme.textMute
                                font.pixelSize: Theme.fontSmall
                            }
                            Rectangle {
                                width: 64
                                height: 28
                                radius: Theme.radius
                                color: pTouch.pressed ? Theme.bgTilePressed : Theme.bgTile
                                Text {
                                    anchors.centerIn: parent
                                    text: AppState.proxyLocalPort
                                    color: Theme.textPrimary
                                    font.pixelSize: Theme.fontSmall
                                }
                                TouchArea {
                                    id: pTouch
                                    anchors.fill: parent
                                    onClicked: page.openEditor("proxy_port",
                                                               AppState.tr("settings.proxy.port"),
                                                               AppState.proxyLocalPort, false)
                                }
                            }
                        }
                    }
                }

                // ========== Update (toC) — compact, fits one pane ==========
                Column {
                    id: updateCol
                    width: parent.width
                    spacing: 6
                    visible: page.tab === "update"
                    // Collapse fully when hidden so Wi‑Fi tile fragments cannot bleed
                    height: visible ? implicitHeight : 0
                    clip: true

                    InsetPanel {
                        width: parent.width
                        height: updateInner.height + 16
                        clip: true
                        Column {
                            id: updateInner
                            width: parent.width - 16
                            x: 8
                            y: 8
                            spacing: 4

                            // Current version + edition at a glance
                            Row {
                                width: parent.width
                                spacing: 8
                                Text {
                                    anchors.verticalCenter: parent.verticalCenter
                                    text: AppState.tr("settings.ota.current")
                                    color: Theme.textMute
                                    font.pixelSize: Theme.fontSmall
                                    width: 56
                                }
                                Text {
                                    anchors.verticalCenter: parent.verticalCenter
                                    text: "v" + AppState.firmwareVersion
                                    color: Theme.textPrimary
                                    font.pixelSize: Theme.fontTitle
                                    font.family: Theme.fontFamily
                                    font.weight: Theme.fontWeight
                                }
                                Item {
                                    width: Math.max(4, parent.width - 220)
                                    height: 1
                                    // spacer only — never paint
                                }
                                Text {
                                    anchors.verticalCenter: parent.verticalCenter
                                    visible: AppState.otaCheckStatus === "latest"
                                    text: AppState.tr("settings.ota.none")
                                    color: Theme.ok
                                    font.pixelSize: Theme.fontSmall
                                }
                            }
                            Row {
                                width: parent.width
                                spacing: 8
                                Text {
                                    anchors.verticalCenter: parent.verticalCenter
                                    text: AppState.tr("settings.ota.channel")
                                    color: Theme.textMute
                                    font.pixelSize: Theme.fontSmall
                                    width: 56
                                }
                                Text {
                                    anchors.verticalCenter: parent.verticalCenter
                                    text: AppState.otaChannelLabel
                                    color: AppState.otaChannel === "stable" ? Theme.textPrimary : Theme.accent
                                    font.pixelSize: Theme.fontBody
                                    font.family: Theme.fontFamily
                                    font.weight: Theme.fontWeight
                                }
                            }
                            Text {
                                width: parent.width
                                visible: AppState.printing || AppState.printPaused
                                height: visible ? implicitHeight : 0
                                text: AppState.tr("settings.ota.hint")
                                color: Theme.warn
                                font.pixelSize: Theme.fontSmall
                            }
                            Text {
                                text: AppState.tr("settings.ota.channel.switch")
                                      + " · " + AppState.tr("settings.ota.channel.hint")
                                color: Theme.textMute
                                font.pixelSize: 10
                                width: parent.width
                                elide: Text.ElideRight
                            }
                            Row {
                                spacing: 5
                                width: parent.width
                                SegButton {
                                    text: AppState.tr("settings.ota.stable")
                                    height: 30
                                    width: Math.floor((parent.width - 10) / 3)
                                    active: AppState.otaChannel === "stable"
                                    enabled: !AppState.otaBusy
                                    onClicked: AppState.otaSetChannel("stable")
                                }
                                SegButton {
                                    text: AppState.tr("settings.ota.beta")
                                    height: 30
                                    width: Math.floor((parent.width - 10) / 3)
                                    active: AppState.otaChannel === "beta"
                                    enabled: !AppState.otaBusy
                                    onClicked: AppState.otaSetChannel("beta")
                                }
                                SegButton {
                                    text: AppState.tr("settings.ota.dev")
                                    height: 30
                                    width: Math.floor((parent.width - 10) / 3)
                                    active: AppState.otaChannel === "dev"
                                    enabled: !AppState.otaBusy
                                    onClicked: AppState.otaSetChannel("dev")
                                }
                            }
                        }
                    }

                    PrimaryButton {
                        text: AppState.otaCheckStatus === "checking"
                              ? (AppState.tr("settings.ota.check") + "…")
                              : AppState.tr("settings.ota.check")
                        width: parent.width
                        height: 40
                        enabled: !AppState.otaBusy && !AppState.printing && !AppState.printPaused
                                 && AppState.otaCheckStatus !== "checking"
                        onClicked: {
                            AppState.otaCheckStatus = ""
                            AppState.otaCheck()
                        }
                    }

                    Text {
                        width: parent.width
                        visible: !!AppState.otaError && !AppState.otaBusy
                        height: visible ? implicitHeight : 0
                        text: AppState.otaError
                        color: Theme.danger
                        font.pixelSize: Theme.fontSmall
                        wrapMode: Text.Wrap
                    }
                }

                // ========== Display ==========
                Column {
                    width: parent.width
                    spacing: 10
                    visible: page.tab === "display"
                    height: visible ? implicitHeight : 0
                    clip: true

                    Text {
                        text: AppState.tr("settings.brightness")
                        color: Theme.textMute
                        font.pixelSize: Theme.fontSmall
                    }
                    Row {
                        spacing: 6
                        SegButton {
                            text: AppState.tr("settings.dim")
                            height: 36
                            width: 72
                            active: AppState.brightness <= 40
                            onClicked: AppState.setBrightness(30)
                        }
                        SegButton {
                            text: AppState.tr("settings.mid")
                            height: 36
                            width: 72
                            active: AppState.brightness > 40 && AppState.brightness < 85
                            onClicked: AppState.setBrightness(60)
                        }
                        SegButton {
                            text: AppState.tr("settings.bright")
                            height: 36
                            width: 72
                            active: AppState.brightness >= 85
                            onClicked: AppState.setBrightness(100)
                        }
                    }

                    Text {
                        text: AppState.tr("settings.language")
                        color: Theme.textMute
                        font.pixelSize: Theme.fontSmall
                        topPadding: 4
                    }
                    Row {
                        spacing: 6
                        SegButton {
                            text: "中文"
                            height: 36
                            width: 80
                            active: AppState.language === "zh"
                            onClicked: AppState.setLanguage("zh")
                        }
                        SegButton {
                            text: "English"
                            height: 36
                            width: 96
                            active: AppState.language === "en"
                            onClicked: AppState.setLanguage("en")
                        }
                    }
                }

                // ========== More: about + maintain ==========
                Column {
                    width: parent.width
                    spacing: 8
                    visible: page.tab === "more"
                    height: visible ? implicitHeight : 0
                    clip: true

                    InsetPanel {
                        width: parent.width
                        height: aboutCol.height + 14
                        Column {
                            id: aboutCol
                            width: parent.width - 18
                            x: 9
                            y: 7
                            spacing: 4
                            Text {
                                text: AppState.machineName
                                color: Theme.textPrimary
                                font.pixelSize: Theme.fontBody
                                font.family: Theme.fontFamily
                                font.weight: Theme.fontWeight
                            }
                            Text {
                                width: parent.width
                                text: AppState.tr("settings.ver.firmware") + "  v" + AppState.firmwareVersion
                                      + "  ·  " + AppState.otaChannelLabel
                                      + "  ·  " + AppState.panelBuild
                                color: Theme.textSecondary
                                font.pixelSize: Theme.fontSmall
                            }
                            Text {
                                width: parent.width
                                text: AppState.tr("settings.ver.target") + "  " + AppState.firmwareTarget
                                color: Theme.accent
                                font.pixelSize: Theme.fontSmall
                            }
                            Text {
                                width: parent.width
                                text: AppState.tr("settings.ver.klipper_custom") + "  "
                                      + (AppState.klipperCustomVersion !== "—"
                                         ? AppState.klipperCustomVersion : AppState.klipperVersion)
                                      + "  ·  Core " + AppState.klipperCoreVersion
                                color: Theme.textSecondary
                                font.pixelSize: Theme.fontSmall
                                elide: Text.ElideRight
                            }
                        }
                    }

                    Text {
                        width: parent.width
                        text: AppState.tr("settings.maintain.hint")
                        color: Theme.textMute
                        font.pixelSize: Theme.fontSmall
                        wrapMode: Text.Wrap
                    }
                    Row {
                        spacing: 6
                        PrimaryButton {
                            text: AppState.tr("settings.reboot")
                            danger: true
                            height: 36
                            onClicked: AppState.firmwareRestart()
                        }
                        PrimaryButton {
                            text: AppState.tr("settings.estop")
                            danger: true
                            height: 36
                            onClicked: AppState.emergencyStop()
                        }
                    }
                }
            }
        }
    }

    OnScreenKeyboard {
        id: kb
        anchors.fill: parent
        onAccepted: page.onEditorAccepted(value)
        onCancelled: page.editTarget = ""
    }

    Component.onCompleted: {
        AppState.refreshVersionInfo()
        AppState.refreshOtaStatus()
        AppState.refreshWifi()
    }
}
