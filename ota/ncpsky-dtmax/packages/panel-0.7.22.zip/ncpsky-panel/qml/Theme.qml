pragma Singleton
import QtQuick 2.15

QtObject {
    readonly property int screenW: 480
    readonly property int screenH: 272
    readonly property int navW: 52
    readonly property int touchMin: 48

    readonly property color bg: "#080A0B"
    readonly property color bgPanel: "#0B0E10"
    readonly property color bgElevated: "#101316"
    readonly property color bgTile: "#14181C"
    readonly property color bgTilePressed: "#1E242A"
    readonly property color line: "#262C33"
    readonly property color lineSoft: "#181C20"
    readonly property color textPrimary: "#F0F2F4"
    readonly property color textSecondary: "#8A9199"
    readonly property color textMute: "#5A6169"
    // Soft violet — readable on dark, not neon
    readonly property color accent: "#A78BFA"
    readonly property color accentDim: "#2A2340"
    readonly property color accentSoft: "#3D3558"
    readonly property color warn: "#D4A017"
    readonly property color danger: "#D94B4B"
    readonly property color ok: "#A78BFA"

    // Device QT_QPA_FONTDIR only ships Source Han Sans CN Bold — never request
    // Light/Medium or Qt falls back to Latin fonts and CJK becomes □X tofu.
    readonly property string fontFamily: "Source Han Sans CN"
    readonly property int fontWeight: Font.Bold

    readonly property int fontTitle: 15
    readonly property int fontBody: 13
    readonly property int fontSmall: 11
    readonly property int fontHuge: 28
    readonly property int fontDisplay: 24

    readonly property int animFast: 90
    readonly property int animPage: 140
    readonly property int animSlow: 360
    readonly property int radius: 8
    readonly property int radiusLg: 10
    readonly property int gap: 8
}
