# NCPSKY OTA（全功能固件更新）

产品：`NCPSKY ▲ DTMax` · 适用机型：`FLSun T1 Max`  
机上更新器：`scripts/ncpsky_ota.py`，由 `local_fileserver.py`（7126）暴露 HTTP API。  
发布源：自建 HTTP 静态站（`manifest.json` + `packages/`），不依赖 GitHub。

## 版本规矩

| 字段 | 规则 | 示例 |
|------|------|------|
| firmware | semver，界面上的总版本 | `0.7.0` |
| panel | semver，面板组件 | `0.5.1` |
| stack | 日历+序号 | `2026.11.23.1` |
| system | apt 快照 id | `sys-2026.11.23` |
| platform | 平台运行时 | `plat-2026.11.24.1` |
| mcu | 代号 + bin sha256 | `mcu-20261122` |
| factory | 出厂整包（非日常） | `factory-2026.11.24` |
| klipper_core | 对齐的上游 Klipper 代际 | `0.14.0` |
| klipper_custom | FLSun/NCPSKY 定制号 | `FLSunT1Max-20261122` |
| channel | `stable` / `beta` / `dev`（+ 服务用 `factory`） | |

机上本地版本：`ota/versions.json`（panel 以 `VERSION` 为准）。  
设置页同时展示 **定制版本** 与 **KlipperCore**。

### 从真机抽出基线包（T1 Max）

```bash
python ota/tools/extract_t1max_firmware.py --host 192.168.2.228
# → ota/dist/stack-2026.11.23.1.zip
# → ota/dist/mcu-20261122.bin
# → ota/dist/manifest.baseline.json
# → ota/dist/ncpsky-dtmax/  (→ 同步到 firmware-release/ota/ncpsky-dtmax/)
```

后续 T1 Max 固件迭代以该 baseline stack 为起点改、再 `publish.py`。

### MCU 本机编译（Windows）

不依赖 T1 / WSL。工具：`ota/tools/build_mcu_bin.py`（自动注入 `vendor/kconfiglib` + `msgproto`）。

```powershell
python ota/tools/build_mcu_bin.py --version mcu-20261129
# → ota/dist/mcu-20261129.bin
```

详见 `products/ncpsky-dtmax/mcu/README.md`。

## 远端目录（按 product_id 分类，多产品共用一仓）

```text
/ota/<product_id>/          # 例 ota/ncpsky-dtmax
  manifest.json              # 通常 = stable
  channels/stable.json
  channels/beta.json
  channels/dev.json
  channels/factory.json          # 服务/翻机；日常检查不拉
  packages/panel-0.5.1.zip
  packages/stack-2026.11.23.1.zip   # 含 config/printer.cfg（无 SAVE_CONFIG）
  packages/system-sys-2026.11.24.tar.gz
  packages/platform-plat-2026.11.24.1.tar.gz
  packages/mcu-r1.bin
```

机上配置：`/home/pi/ncpsky-panel/ota/config.json`（首次从 `config.default.json` 复制）  
`github.path_prefix` 必须等于 `ota/<product_id>`。

### 自建 HTTP

```json
{
  "source": "http",
  "base_url": "https://ota.example.com/ota/ncpsky-dtmax",
  "channel": "stable",
  "insecure_http": false,
  "proxy": { "enabled": false, "url": "http://127.0.0.1:7890" }
}
```

### GitHub（推荐 · 公开仓）

仓库目录约定：`ota/<product_id>/channels/*.json` + `packages/`。

```json
{
  "source": "github",
  "channel": "beta",
  "product_id": "ncpsky-dtmax",
  "github": {
    "owner": "Nowebyone",
    "repo": "NCPSKY-Printer-Firmware-Release",
    "ref": "main",
    "mode": "raw",
    "path_prefix": "ota/ncpsky-dtmax",
    "release_tag": {
      "stable": "ota-stable",
      "beta": "ota-beta",
      "dev": "ota-dev"
    }
  },
  "proxy": {
    "enabled": true,
    "url": "http://127.0.0.1:7890",
    "github_mirror": ""
  }
}
```

- `mode: "raw"`：从 `raw.githubusercontent.com/.../ref/path_prefix/` 拉 manifest 与包。  
- `mode: "release"`：按频道读 Release 标签（如 `ota-beta`），资源名需含 `manifest.json` / `channels-beta.json` 与各 zip/bin。  
- **代理**：面板可开关；地址在 `proxy.url`（常见本机 clash/sing-box `7890`）。本地 Moonraker 请求不走代理。  
- **镜像**（可选）：`proxy.github_mirror` 如 `https://ghfast.top/`，会给 github/githubusercontent URL 加前缀（无本地代理时可用）。  
- 内网无 HTTPS 或板载 CA 损坏时，可 `"insecure_http": true`（仍强制 sha256）。

面板设置页可切换 **自建站 / GitHub** 与 **代理开/关**；仓库名与代理 URL 仍在 `config.json` 里改。

## 机上 API（7126）

| 方法 | 路径 | 作用 |
|------|------|------|
| GET | `/ota/status` | 版本、频道、进度、可更新列表 |
| POST | `/ota/check` | 拉 manifest，算可更新 |
| POST | `/ota/channel` | `{ "channel": "beta" }` |
| POST | `/ota/source` | `{ "source": "http"\|"github" }` |
| POST | `/ota/proxy` | `{ "enabled": true, "url"?: "...", "github_mirror"?: "..." }` |
| POST | `/ota/upgrade` | `{ "packages": ["panel-0.5.1"] }` |
| POST | `/ota/confirm_mcu` | MCU 二次确认后刷写 |
| GET | `/ota/history` | 历史 + 备份列表 |
| POST | `/ota/rollback` | `{ "kind": "panel" }` |

打印中（Moonraker `print_stats` printing/paused）拒绝升级/回滚。  
每次成功升级前备份到 `ota/backup/`（保留最近 2 份）。panel 失败可回滚上一份。

## 包种类（安装顺序）

`system → platform → stack → panel → mcu`（factory 仅 factory 通道）

1. **panel** — zip 覆盖面板；保留 `settings.json`、`ota/config.json`、backup/history。  
2. **stack** — macros + 可选 klipper/moonraker；`printer.cfg` 正文换成固件（手改的电流等不保留），**保留** SAVE_CONFIG 里的床网和自动标定，并回写 serial / canbus_uuid / uuid。  
3. **system** — apt pin（`.list`）或 `build_system_pkg.py` 的 tar（`packages.list` + 可选 `debs/`）。  
4. **platform** — Qt/tslib/fonts/hooks（`build_platform_tar.py`）。  
5. **mcu** — bin；整包确认后刷写。  
6. **factory** — 整包/镜像；日常检查更新不拉取。

保全：`persist_profile.json`。合并单测：`ota/tools/test_printer_cfg_merge.py`。

## 发布流水线

在开发机 / CI：

```bash
# 1) 打 panel 包
python ota/tools/build_panel_zip.py

# 2) 打 stack（默认打入 printer.cfg.ota，自动剥 SAVE_CONFIG）
python ota/tools/build_stack_zip.py --version 2026.11.23.1 \
  --macros-dir /path/to/macros

# 3) system / platform
python ota/tools/build_system_pkg.py --version sys-2026.11.24 \
  --list ota/examples/system-sys-2026.11.24.list
python ota/tools/build_platform_tar.py --version plat-2026.11.24.1

# 4) 可选 ed25519（首期非必须；面板仍以 sha256 为准）
python ota/tools/sign.py keygen --out-dir ./keys
python ota/tools/sign.py sign --key ./keys/ota_ed25519 --file ota/dist/panel-0.5.1.zip

# 5) 合并 manifest 并上传
python ota/tools/publish.py --channel beta --method copy \
  --dest /var/www/ota/ncpsky-dtmax \
  --panel-zip ota/dist/panel-0.5.1.zip \
  --stack-zip ota/dist/stack-2026.11.23.1.zip \
  --system-list ota/dist/system-sys-2026.11.24.tar.gz \
  --platform-tar ota/dist/platform-plat-2026.11.24.1.tar.gz \
  --notes "beta bake on test printer"

# 本地模拟 CDN
python ota/tools/serve_local.py --root ota/dist --port 8765
# 机上 config.base_url = http://<dev-pc>:8765/ota/ncpsky-dtmax
```

上传也可用 `--method scp|rclone|s3`。

## beta → stable 流程

1. 测试机频道设为 **beta**，检查更新并装完 panel/stack（MCU 单独确认）。  
2. 打印与校准回归（床网 / Input Shaper / 面板重启）。  
3. 确认无回滚需求后，用**同一批 artifacts** 再发一次：

```bash
python ota/tools/publish.py --channel stable --method copy \
  --dest /var/www/ota/ncpsky-dtmax \
  --panel-zip ota/dist/panel-0.5.1.zip \
  --stack-zip ota/dist/stack-2026.11.23.1.zip \
  --notes "promoted from beta"
```

4. 量产机只开 **stable**；内测机可留 beta/dev。

## 与 Moonraker update_manager

保留板上 `[update_manager]`，**不作为 NCPSKY 主通道**（无 git / SSL 问题）。  
设置页文案为「NCPSKY 更新」，与 Mainsail「系统组件」分离。

## 安全清单

- 机型锁：`firmware_target` 必须为 `FLSun T1 Max`  
- 打印锁、磁盘预检、`sha256`、备份回滚  
- MCU 永不静默自动刷（`auto: false` + UI 确认）  
- 日志：`/tmp/ncpsky_ota.log` + `ota/history.json`

## Schema / 示例

- `manifest.schema.json`  
- `examples/manifest.stable.json`  
- `examples/manifest.beta.json`  
- `config.default.json`
