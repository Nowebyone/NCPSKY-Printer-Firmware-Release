#!/usr/bin/env python3
"""Pull live T1 Max firmware into NCPSKY OTA baseline packages.

Produces under ota/dist/:
  stack-<ver>.zip          — host Klipper + Moonraker + macros (+ slim lib for F103 rebuild)
  mcu-<ver>.bin            — flashed MCU image
  packages/ + channels/baseline manifest via publish helpers

Defaults match NCPSKY ▲ DTMax / FLSun T1 Max / KlipperCore 0.14.0.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import tarfile
import tempfile
import zipfile
from datetime import datetime, timezone

import paramiko

HOST = "192.168.2.228"
USER = "pi"
PASSWORD = "1"

PRODUCT = "NCPSKY ▲ DTMax"
PRODUCT_ID = "ncpsky-dtmax"
FIRMWARE_TARGET = "FLSun T1 Max"
KLIPPER_CORE = "0.14.0"
KLIPPER_CUSTOM = "FLSunT1Max-20261122"


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def stream_cmd_to_file(c, cmd, dest, timeout=600):
    print("REMOTE:", cmd[:120], "...")
    _, stdout, stderr = c.exec_command(cmd, timeout=timeout, get_pty=False)
    n = 0
    with open(dest, "wb") as f:
        while True:
            chunk = stdout.read(65536)
            if not chunk:
                break
            f.write(chunk)
            n += len(chunk)
            if n and n % (8 << 20) < 65536:
                print("  ... %d MB" % (n // (1 << 20)))
    err = stderr.read().decode(errors="replace")
    if err.strip():
        print("stderr:", err[-500:])
    print("wrote", dest, n, "bytes")
    return n


def add_tree(zf, src_root, arc_prefix, skip_dir_names=None, skip_file_suffix=None):
    skip_dir_names = set(skip_dir_names or [])
    skip_file_suffix = tuple(skip_file_suffix or (".pyc", ".o", ".a", ".elf"))
    n = 0
    for dirpath, dirnames, filenames in os.walk(src_root):
        dirnames[:] = [d for d in dirnames if d not in skip_dir_names]
        for fn in filenames:
            if fn.endswith(skip_file_suffix):
                continue
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, src_root).replace("\\", "/")
            zf.write(full, "%s/%s" % (arc_prefix, rel))
            n += 1
    return n


def slim_klipper_lib(src_lib, dst_lib):
    """Keep only STM32F1 (+ shared) libs for T1 Max MCU rebuild."""
    keep = {
        "stm32f1", "cmsis-core", "kconfiglib", "README",
        "bossac", "hidflash", "fast-hash",
    }
    os.makedirs(dst_lib, exist_ok=True)
    if not os.path.isdir(src_lib):
        return
    for name in os.listdir(src_lib):
        if name not in keep:
            continue
        s = os.path.join(src_lib, name)
        d = os.path.join(dst_lib, name)
        if os.path.isdir(s):
            shutil.copytree(s, d, dirs_exist_ok=True)
        else:
            shutil.copy2(s, d)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default=HOST)
    ap.add_argument("--stack-version", default="2026.11.23.1")
    ap.add_argument("--mcu-version", default="mcu-20261122")
    ap.add_argument("--klipper-core", default=KLIPPER_CORE)
    ap.add_argument("--klipper-custom", default=KLIPPER_CUSTOM)
    ap.add_argument("--panel-root", default=None)
    args = ap.parse_args()

    here = os.path.dirname(os.path.abspath(__file__))
    panel_root = args.panel_root or os.path.abspath(os.path.join(here, "..", ".."))
    dist = os.path.join(panel_root, "ota", "dist")
    work = os.path.join(dist, "_extract_work")
    os.makedirs(dist, exist_ok=True)
    if os.path.isdir(work):
        shutil.rmtree(work, ignore_errors=True)
    os.makedirs(work, exist_ok=True)

    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    c.connect(args.host, username=USER, password=PASSWORD, timeout=30)

    # 1) Stream slim klipper tarball (exclude heavy unrelated MCU libs + build objs)
    klip_tar = os.path.join(work, "klipper.tgz")
    klip_cmd = r"""
cd /home/pi && tar czf - \
  --exclude='klipper/lib/stm32h7' \
  --exclude='klipper/lib/stm32l4' \
  --exclude='klipper/lib/stm32f4' \
  --exclude='klipper/lib/stm32f7' \
  --exclude='klipper/lib/stm32g4' \
  --exclude='klipper/lib/stm32g0' \
  --exclude='klipper/lib/stm32f0' \
  --exclude='klipper/lib/stm32f2' \
  --exclude='klipper/lib/pico-sdk' \
  --exclude='klipper/lib/same70b' \
  --exclude='klipper/lib/same54' \
  --exclude='klipper/lib/same51' \
  --exclude='klipper/lib/samd51' \
  --exclude='klipper/lib/samd21' \
  --exclude='klipper/lib/samc21' \
  --exclude='klipper/lib/sam4s' \
  --exclude='klipper/lib/sam4e' \
  --exclude='klipper/lib/sam3x' \
  --exclude='klipper/lib/hc32f460' \
  --exclude='klipper/lib/n32g45x' \
  --exclude='klipper/lib/lpc176x' \
  --exclude='klipper/lib/ar100' \
  --exclude='klipper/lib/pru_rpmsg' \
  --exclude='klipper/lib/rp2040_flash' \
  --exclude='klipper/lib/katapult' \
  --exclude='klipper/lib/fatfs' \
  --exclude='klipper/out/src' \
  --exclude='klipper/out/lib' \
  --exclude='klipper/out/*.o' \
  --exclude='klipper/out/*.elf' \
  --exclude='klipper/**/__pycache__' \
  --exclude='klipper/**/*.pyc' \
  --exclude='klipper/.config.bak*' \
  --exclude='klipper/.config.old' \
  --exclude='klipper/logs' \
  --exclude='klipper/temp' \
  klipper
"""
    stream_cmd_to_file(c, klip_cmd, klip_tar, timeout=900)

    mr_tar = os.path.join(work, "moonraker.tgz")
    mr_cmd = r"""
cd /home/pi && tar czf - \
  --exclude='moonraker/.git' \
  --exclude='moonraker/**/__pycache__' \
  --exclude='moonraker/**/*.pyc' \
  --exclude='moonraker/tests' \
  --exclude='moonraker/.venv' \
  moonraker
"""
    stream_cmd_to_file(c, mr_cmd, mr_tar, timeout=300)

    cfg_tar = os.path.join(work, "config.tgz")
    cfg_cmd = r"""
cd /home/pi/printer_data && tar czf - \
  --exclude='config/printer.cfg' \
  --exclude='config/*.bak' \
  --exclude='config/.git' \
  config
"""
    stream_cmd_to_file(c, cfg_cmd, cfg_tar, timeout=120)

    # Pull live printer.cfg separately — OTA ships SAVE_CONFIG-stripped baseline only
    live_cfg_local = os.path.join(work, "printer.cfg.live")
    try:
        stream_cmd_to_file(
            c,
            "cat /home/pi/printer_data/config/printer.cfg",
            live_cfg_local,
            timeout=60,
        )
    except Exception as ex:
        print("WARN: could not fetch live printer.cfg:", ex)
        live_cfg_local = None

    # MCU bin raw
    mcu_bin_local = os.path.join(work, "klipper.bin")
    stream_cmd_to_file(
        c,
        "cat /home/pi/klipper/out/klipper.bin",
        mcu_bin_local,
        timeout=60,
    )
    c.close()

    # 2) Unpack
    kdir = os.path.join(work, "klipper")
    mdir = os.path.join(work, "moonraker")
    cdir = os.path.join(work, "config")
    with tarfile.open(klip_tar, "r:gz") as t:
        t.extractall(work)
    with tarfile.open(mr_tar, "r:gz") as t:
        t.extractall(work)
    with tarfile.open(cfg_tar, "r:gz") as t:
        t.extractall(work)

    # Slim lib further if still fat
    lib = os.path.join(kdir, "lib")
    if os.path.isdir(lib):
        slim = os.path.join(work, "lib_slim")
        if os.path.isdir(slim):
            shutil.rmtree(slim)
        slim_klipper_lib(lib, slim)
        shutil.rmtree(lib)
        shutil.move(slim, lib)

    # 3) Build stack zip
    stack_ver = args.stack_version
    stack_zip = os.path.join(dist, "stack-%s.zip" % stack_ver)
    meta = {
        "product": PRODUCT,
        "firmware_target": FIRMWARE_TARGET,
        "stack": stack_ver,
        "klipper_core": args.klipper_core,
        "klipper_custom": args.klipper_custom,
        "mcu": args.mcu_version,
        "mcu_chip": "stm32f103xe",
        "extracted_from": args.host,
        "extracted_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "notes": "Baseline T1 Max firmware snapshot for NCPSKY OTA; FLSun-patched host near upstream 0.14.0",
    }
    with zipfile.ZipFile(stack_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        ver_txt = (
            "product=%s\n"
            "firmware_target=%s\n"
            "stack=%s\n"
            "klipper_core=%s\n"
            "klipper_custom=%s\n"
            "mcu=%s\n"
            % (PRODUCT, FIRMWARE_TARGET, stack_ver,
               args.klipper_core, args.klipper_custom, args.mcu_version)
        )
        zf.writestr("stack/VERSION", ver_txt.encode("utf-8"))
        zf.writestr("stack/META.json", json.dumps(meta, indent=2, ensure_ascii=False) + "\n")

        add_tree(
            zf, kdir, "stack/klipper",
            skip_dir_names={"__pycache__", ".git", "logs", "temp"},
        )
        for overlay_name in ("ncpsky_adaptive_mesh.py", "ncpsky_print_limits.py"):
            overlay = os.path.normpath(os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                "..", "..", "klipper_overlays", overlay_name,
            ))
            if os.path.isfile(overlay):
                zf.write(overlay, "stack/klipper_extras/%s" % overlay_name)
        add_tree(
            zf, mdir, "stack/moonraker",
            skip_dir_names={"__pycache__", ".git", "tests", ".venv"},
        )
        # macros / configs — ship SAVE_CONFIG-stripped printer.cfg baseline for merge install
        if os.path.isdir(cdir):
            for fn in os.listdir(cdir):
                if not (fn.endswith(".cfg") or fn.endswith(".conf") or fn.endswith(".json")):
                    continue
                if fn.startswith("printer-"):
                    continue
                if fn in ("moonraker.conf", "moonraker.asvc", "secrets.json", "password.cfg"):
                    continue
                if ".bak" in fn or fn.endswith(".bak") or "secret" in fn.lower() or "password" in fn.lower():
                    continue
                if fn in ("noise_map.json",):  # measured map may contain device paths
                    continue
                if fn == "printer.cfg":
                    continue  # handled below after SAVE_CONFIG strip
                zf.write(os.path.join(cdir, fn), "stack/macros/%s" % fn)
        # SAVE_CONFIG-stripped baseline from separately fetched live printer.cfg
        cfg_src = live_cfg_local if live_cfg_local and os.path.isfile(live_cfg_local) else None
        if not cfg_src:
            # optional repo template
            here = os.path.dirname(os.path.abspath(__file__))
            tmpl = os.path.join(here, "..", "stack_templates", "config", "printer.cfg.ota")
            if os.path.isfile(tmpl):
                cfg_src = tmpl
        if cfg_src:
            try:
                scripts = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "scripts"))
                if scripts not in sys.path:
                    sys.path.insert(0, scripts)
                from printer_cfg_merge import strip_save_config
                with open(cfg_src, "r", encoding="utf-8", errors="replace") as f:
                    body = strip_save_config(f.read())
                has_marker = any(
                    ln.strip().startswith("#*#") and "SAVE_CONFIG" in ln.upper()
                    for ln in body.splitlines()
                )
                if body.strip() and not has_marker:
                    zf.writestr("stack/config/printer.cfg", body)
                    zf.writestr("stack/config/printer.cfg.ota", body)
                else:
                    print("WARN: stripped printer.cfg empty or still has SAVE_CONFIG marker")
            except Exception as ex:
                print("WARN: could not strip printer.cfg SAVE_CONFIG:", ex)
        include_snip = (
            "# NCPSKY stack includes — managed by OTA; do not put SAVE_CONFIG here\n"
            "[include ncpsky_calib.cfg]\n"
        )
        zf.writestr("stack/config_templates/ncpsky_includes.cfg", include_snip)

    digest = sha256_file(stack_zip)
    with open(stack_zip + ".sha256", "w", encoding="utf-8") as f:
        f.write("%s  %s\n" % (digest, os.path.basename(stack_zip)))

    # 4) MCU package
    mcu_ver = args.mcu_version
    mcu_out = os.path.join(dist, "%s.bin" % mcu_ver)
    shutil.copy2(mcu_bin_local, mcu_out)
    # also copy defconfig alongside in a tiny zip? OTA mcu kind expects .bin — keep bin + sidecar json
    mcu_meta = {
        "id": mcu_ver,
        "kind": "mcu",
        "version": mcu_ver,
        "klipper_core": args.klipper_core,
        "klipper_custom": args.klipper_custom,
        "chip": "stm32f103xe",
        "sha256": sha256_file(mcu_out),
        "size": os.path.getsize(mcu_out),
        "auto": False,
    }
    with open(mcu_out + ".json", "w", encoding="utf-8") as f:
        json.dump(mcu_meta, f, indent=2, ensure_ascii=False)
        f.write("\n")
    with open(mcu_out + ".sha256", "w", encoding="utf-8") as f:
        f.write("%s  %s\n" % (mcu_meta["sha256"], os.path.basename(mcu_out)))

    # 5) Baseline channel manifest
    man = {
        "product": PRODUCT,
        "firmware_target": FIRMWARE_TARGET,
        "channel": "dev",
        "published_at": meta["extracted_at"],
        "min_panel": "0.5.0",
        "notes": "T1 Max baseline from live printer — KlipperCore %s / custom %s"
                 % (args.klipper_core, args.klipper_custom),
        "klipper_core": args.klipper_core,
        "klipper_custom": args.klipper_custom,
        "packages": [
            {
                "id": "stack-%s" % stack_ver,
                "kind": "stack",
                "version": stack_ver,
                "url": "packages/stack-%s.zip" % stack_ver,
                "sha256": digest,
                "size": os.path.getsize(stack_zip),
                "min_free_mb": 400,
                "requires_idle": True,
                "auto": True,
                "restart": "klipper",
                "notes": "Host stack baseline (KlipperCore %s)" % args.klipper_core,
            },
            {
                "id": mcu_ver,
                "kind": "mcu",
                "version": mcu_ver,
                "url": "packages/%s.bin" % mcu_ver,
                "sha256": mcu_meta["sha256"],
                "size": mcu_meta["size"],
                "min_free_mb": 20,
                "requires_idle": True,
                "auto": False,
                "restart": "mcu_flash",
                "notes": "MCU image; UI confirm required",
            },
        ],
    }
    man_path = os.path.join(dist, "manifest.baseline.json")
    with open(man_path, "w", encoding="utf-8") as f:
        json.dump(man, f, indent=2, ensure_ascii=False)
        f.write("\n")

    # stage publish-ready tree → copy to firmware-release/ota/<product_id>/
    pub = os.path.join(dist, PRODUCT_ID)
    pkg = os.path.join(pub, "packages")
    ch = os.path.join(pub, "channels")
    os.makedirs(pkg, exist_ok=True)
    os.makedirs(ch, exist_ok=True)
    shutil.copy2(stack_zip, os.path.join(pkg, os.path.basename(stack_zip)))
    shutil.copy2(stack_zip + ".sha256", os.path.join(pkg, os.path.basename(stack_zip) + ".sha256"))
    shutil.copy2(mcu_out, os.path.join(pkg, os.path.basename(mcu_out)))
    shutil.copy2(mcu_out + ".sha256", os.path.join(pkg, os.path.basename(mcu_out) + ".sha256"))
    with open(os.path.join(ch, "dev.json"), "w", encoding="utf-8") as f:
        json.dump(man, f, indent=2, ensure_ascii=False)
        f.write("\n")
    # also write versions seed for devices
    versions_seed = {
        "panel": "0.5.0",
        "stack": stack_ver,
        "system": "sys-none",
        "mcu": mcu_ver,
        "klipper_core": args.klipper_core,
        "klipper_custom": args.klipper_custom,
    }
    with open(os.path.join(dist, "versions.baseline.json"), "w", encoding="utf-8") as f:
        json.dump(versions_seed, f, indent=2, ensure_ascii=False)
        f.write("\n")

    print(json.dumps({
        "stack_zip": stack_zip,
        "stack_sha256": digest,
        "stack_size": os.path.getsize(stack_zip),
        "mcu_bin": mcu_out,
        "mcu_sha256": mcu_meta["sha256"],
        "manifest": man_path,
        "publish_root": pub,
        "meta": meta,
    }, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
