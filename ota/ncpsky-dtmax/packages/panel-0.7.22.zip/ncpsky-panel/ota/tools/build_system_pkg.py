#!/usr/bin/env python3
"""Build system OTA package: apt pin list and/or offline debs.

Output: system-<version>.tar.gz containing:
  system/META.json
  system/packages.list
  system/debs/*.deb   (optional)
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import tarfile
from datetime import datetime, timezone


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser(description="Build NCPSKY system OTA package")
    ap.add_argument("--version", required=True, help="e.g. sys-2026.11.24")
    ap.add_argument("--list", required=True, help="apt packages.list (name or name=ver)")
    ap.add_argument("--debs-dir", help="optional directory of .deb files")
    ap.add_argument("--out", help="output tar.gz")
    ap.add_argument("--notes", default="")
    args = ap.parse_args()

    here = os.path.dirname(os.path.abspath(__file__))
    panel_root = os.path.abspath(os.path.join(here, "..", ".."))
    out_dir = os.path.join(panel_root, "ota", "dist")
    os.makedirs(out_dir, exist_ok=True)
    out = args.out or os.path.join(out_dir, "system-%s.tar.gz" % args.version)

    if not os.path.isfile(args.list):
        raise SystemExit("missing list: %s" % args.list)

    with open(args.list, "r", encoding="utf-8") as f:
        list_body = f.read()

    meta = {
        "product": "NCPSKY ▲ DTMax",
        "firmware_target": "FLSun T1 Max",
        "kind": "system",
        "version": args.version,
        "notes": args.notes,
        "built_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }

    with tarfile.open(out, "w:gz") as tf:
        def add_bytes(name, data: bytes):
            info = tarfile.TarInfo(name=name)
            info.size = len(data)
            import io
            tf.addfile(info, io.BytesIO(data))

        add_bytes("system/META.json", (json.dumps(meta, indent=2, ensure_ascii=False) + "\n").encode())
        add_bytes("system/packages.list", list_body.encode("utf-8"))
        if args.debs_dir and os.path.isdir(args.debs_dir):
            for fn in sorted(os.listdir(args.debs_dir)):
                if not fn.endswith(".deb"):
                    continue
                full = os.path.join(args.debs_dir, fn)
                tf.add(full, arcname="system/debs/%s" % fn)

    digest = sha256_file(out)
    with open(out + ".sha256", "w", encoding="utf-8") as f:
        f.write("%s  %s\n" % (digest, os.path.basename(out)))
    print(json.dumps({
        "id": "system-%s" % args.version if not str(args.version).startswith("system-") else args.version,
        "kind": "system",
        "version": args.version,
        "file": os.path.basename(out),
        "sha256": digest,
        "size": os.path.getsize(out),
    }, indent=2, ensure_ascii=False))
    print("Wrote", out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
