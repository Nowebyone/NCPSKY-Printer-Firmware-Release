#!/usr/bin/env python3
"""Detect the printer MCU over ST-Link and map it to an ncpsky MCU profile.

Uses STM32CubeProgrammer CLI (SWD). Does not flash or change the printer OS.

  python detect_mcu_chip.py
  python detect_mcu_chip.py --json
"""
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
from mcu_profiles import default_profile_id, match_profile_from_probe  # noqa: E402

PROGRAMMER = os.environ.get(
    "STM32_PROGRAMMER_CLI",
    r"C:\Program Files\STMicroelectronics\STM32Cube\STM32CubeProgrammer\bin\STM32_Programmer_CLI.exe",
)


def die(msg, code=1):
    sys.stderr.write("ERROR: %s\n" % msg)
    raise SystemExit(code)


def run_cli(args):
    if not os.path.isfile(PROGRAMMER):
        die("STM32_Programmer_CLI not found: %s" % PROGRAMMER)
    cmd = [PROGRAMMER] + args
    proc = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    text = (proc.stdout or "") + "\n" + (proc.stderr or "")
    return proc.returncode, text


def parse_device_id(text: str) -> str:
    for pat in (
        r"Device ID\s*[:=]\s*(0x[0-9A-Fa-f]+)",
        r"Device id\s*[:=]\s*(0x[0-9A-Fa-f]+)",
        r"\bID\s*:\s*(0x[0-9A-Fa-f]+)",
    ):
        m = re.search(pat, text, re.I)
        if m:
            return m.group(1)
    return ""


def parse_device_name(text: str) -> str:
    for pat in (
        r"Device name\s*[:=]\s*([^\r\n]+)",
        r"Board\s*[:=]\s*([^\r\n]+)",
        r"(GD32F[0-9A-Z]+)",
        r"(STM32F[0-9A-Z]+)",
    ):
        m = re.search(pat, text, re.I)
        if m:
            return m.group(1).strip()
    return ""


def parse_flash_kb_from_text(text: str):
    m = re.search(r"Flash size\s*[:=]\s*(\d+)\s*K", text, re.I)
    if m:
        return int(m.group(1))
    m = re.search(r"(\d+)\s*KBytes?\s*of\s*Flash", text, re.I)
    if m:
        return int(m.group(1))
    return None


def read_flash_size_kb():
    """STM32F1 / GD32F3 flash-size register (KB) at 0x1FFFF7E0."""
    code, text = run_cli(["-c", "port=SWD", "freq=4000", "-r32", "0x1FFFF7E0", "1"])
    if code != 0:
        return None, text
    # Typical: 0x1FFFF7E0 : 00000200  → 0x0200 = 512 KB for GD32
    m = re.search(r"0x1FFFF7E0\s*:\s*([0-9A-Fa-f]+)", text)
    if not m:
        m = re.search(r":\s*([0-9A-Fa-f]{8})", text)
    if not m:
        return None, text
    raw = int(m.group(1), 16)
    # Register is often in KB already (low 16 bits)
    kb = raw & 0xFFFF
    if kb in (0, 0xFFFF):
        return None, text
    # Some tools return bytes
    if kb > 2048:
        kb = kb // 1024
    return kb, text


def detect():
    code, text = run_cli(["-c", "port=SWD", "freq=4000"])
    if code != 0 and "Error" in text and "No STM32" in text:
        die("ST-Link 未连上 MCU（SWD）。接好 SWDIO/SWCLK/GND，板子自供电后再试。\n" + text[-800:])
    if code != 0 and "Unable to connect" in text:
        die("ST-Link 无法连接：\n" + text[-800:])

    device_id = parse_device_id(text)
    device_name = parse_device_name(text)
    flash_kb = parse_flash_kb_from_text(text)
    reg_text = ""
    if flash_kb is None:
        flash_kb, reg_text = read_flash_size_kb()

    profile = match_profile_from_probe(
        device_text=device_name + "\n" + text,
        device_id=device_id,
        flash_kb=flash_kb,
    )
    result = {
        "ok": True,
        "device_id": device_id,
        "device_name": device_name,
        "flash_kb": flash_kb,
        "profile": profile.get("id"),
        "label": profile.get("label"),
        "flash_address": profile.get("flash_address"),
        "default_profile": default_profile_id(),
        "raw_connect_tail": text[-1200:],
        "raw_flash_reg_tail": (reg_text or "")[-400:],
    }
    return result


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--json", action="store_true")
    ap.add_argument(
        "--assume-default",
        action="store_true",
        help="If ST-Link missing, return product default profile instead of failing",
    )
    args = ap.parse_args()
    try:
        result = detect()
    except SystemExit:
        if not args.assume_default:
            raise
        pid = default_profile_id()
        result = {
            "ok": False,
            "assumed": True,
            "profile": pid,
            "label": "assumed default (no ST-Link)",
            "flash_address": "0x08000000",
            "default_profile": pid,
        }
    if args.json:
        json.dump(result, sys.stdout, indent=2, ensure_ascii=False)
        sys.stdout.write("\n")
    else:
        print("device_id", result.get("device_id") or "-")
        print("device_name", result.get("device_name") or "-")
        print("flash_kb", result.get("flash_kb") if result.get("flash_kb") is not None else "-")
        print("profile", result.get("profile"))
        print("label", result.get("label"))
        print("flash_address", result.get("flash_address"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
