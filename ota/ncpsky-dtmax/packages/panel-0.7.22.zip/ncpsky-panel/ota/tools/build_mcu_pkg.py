#!/usr/bin/env python3
"""Build an OTA MCU package that can compile/flash for the detected chip.

Output: ota/dist/mcu-<version>.tar.gz containing:
  META.json          build=on_device|auto, default_profile
  profiles.json
  profiles/<id>/defconfig
  profiles/<id>/profile.json
  profiles/<id>/klipper.bin   (optional prebuilt for that profile)

  python build_mcu_pkg.py --version mcu-20261125 --profile gd32f303vet6 --build-bin
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
OTA_ROOT = os.path.abspath(os.path.join(HERE, ".."))
DIST = os.path.join(OTA_ROOT, "dist")
if HERE not in sys.path:
    sys.path.insert(0, HERE)
from mcu_profiles import get_profile, list_profiles, load_registry  # noqa: E402


def die(msg, code=1):
    sys.stderr.write("ERROR: %s\n" % msg)
    raise SystemExit(code)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--version", required=True, help="e.g. mcu-20261125")
    ap.add_argument(
        "--profile",
        action="append",
        default=[],
        help="Profile id to include (repeatable). Default: all known.",
    )
    ap.add_argument(
        "--build",
        choices=("on_device", "auto", "prebuilt"),
        default="on_device",
        help="on_device: printer always compiles; auto: use prebuilt if present; "
        "prebuilt: require bins",
    )
    ap.add_argument(
        "--build-bin",
        action="store_true",
        help="Also run build_mcu_bin.py for each profile and embed klipper.bin",
    )
    ap.add_argument("--notes", default="")
    args = ap.parse_args()

    all_p = list_profiles()
    pids = args.profile or list(all_p.keys())
    for pid in pids:
        if pid not in all_p:
            die("unknown profile %s" % pid)

    ver = args.version
    if not ver.startswith("mcu-"):
        ver = "mcu-%s" % ver

    staging = tempfile.mkdtemp(prefix="mcu-pkg-")
    try:
        root = os.path.join(staging, "mcu")
        os.makedirs(root, exist_ok=True)
        reg = load_registry()
        reg_out = {
            "product_id": reg.get("product_id"),
            "default_profile": reg.get("default_profile") or pids[0],
            "profiles": {pid: all_p[pid] for pid in pids},
        }
        # strip absolute paths from embedded registry
        for pid, meta in reg_out["profiles"].items():
            meta = dict(meta)
            meta.pop("defconfig", None)
            reg_out["profiles"][pid] = meta
        with open(os.path.join(root, "profiles.json"), "w", encoding="utf-8") as f:
            json.dump(reg_out, f, indent=2, ensure_ascii=False)
            f.write("\n")

        for pid in pids:
            p = get_profile(pid)
            dest_dir = os.path.join(root, "profiles", pid)
            os.makedirs(dest_dir, exist_ok=True)
            shutil.copy2(p["defconfig"], os.path.join(dest_dir, "defconfig"))
            pj = os.path.join(os.path.dirname(p["defconfig"]), "profile.json")
            if os.path.isfile(pj):
                shutil.copy2(pj, os.path.join(dest_dir, "profile.json"))
            else:
                with open(os.path.join(dest_dir, "profile.json"), "w", encoding="utf-8") as f:
                    json.dump(p, f, indent=2, ensure_ascii=False)
                    f.write("\n")

            if args.build_bin or args.build == "prebuilt":
                bin_ver = "%s-%s" % (ver, pid)
                cmd = [
                    sys.executable,
                    os.path.join(HERE, "build_mcu_bin.py"),
                    "--version",
                    bin_ver,
                    "--profile",
                    pid,
                ]
                print("BUILD", " ".join(cmd))
                rc = subprocess.call(cmd)
                if rc != 0:
                    die("build_mcu_bin failed for %s" % pid, rc)
                built = os.path.join(DIST, "%s.bin" % bin_ver)
                if not os.path.isfile(built):
                    die("missing %s" % built)
                shutil.copy2(built, os.path.join(dest_dir, "klipper.bin"))

        meta = {
            "kind": "mcu",
            "version": ver,
            "build": args.build,
            "default_profile": reg_out["default_profile"],
            "profiles": pids,
            "built_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "notes": args.notes
            or "Detect MCU profile on device, compile matching firmware, then flash.",
        }
        with open(os.path.join(root, "META.json"), "w", encoding="utf-8") as f:
            json.dump(meta, f, indent=2, ensure_ascii=False)
            f.write("\n")

        os.makedirs(DIST, exist_ok=True)
        out = os.path.join(DIST, "%s.tar.gz" % ver)
        with tarfile.open(out, "w:gz") as tf:
            tf.add(root, arcname="mcu")
        digest = sha256_file(out)
        open(out + ".sha256", "w", encoding="utf-8").write(
            "%s  %s\n" % (digest, os.path.basename(out))
        )
        with open(out + ".json", "w", encoding="utf-8") as f:
            json.dump(
                {
                    "kind": "mcu",
                    "version": ver,
                    "file": os.path.basename(out),
                    "sha256": digest,
                    "size": os.path.getsize(out),
                    "build": args.build,
                    "profiles": pids,
                    "built_at": meta["built_at"],
                    "notes": meta["notes"],
                },
                f,
                indent=2,
                ensure_ascii=False,
            )
            f.write("\n")
        print("OUT", out)
        print("SHA", digest)
        print("SIZE", os.path.getsize(out))
    finally:
        shutil.rmtree(staging, ignore_errors=True)


if __name__ == "__main__":
    main()
