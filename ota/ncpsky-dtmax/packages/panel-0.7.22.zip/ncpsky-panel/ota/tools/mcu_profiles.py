#!/usr/bin/env python3
"""MCU profile helpers for ncpsky-dtmax (detect / build / flash addressing)."""
from __future__ import annotations

import json
import os
import re
from typing import Any, Dict, Optional

HERE = os.path.dirname(os.path.abspath(__file__))
OTA_ROOT = os.path.abspath(os.path.join(HERE, ".."))
PANEL_ROOT = os.path.abspath(os.path.join(OTA_ROOT, ".."))
REPO_ROOT = os.path.abspath(os.path.join(PANEL_ROOT, ".."))

PROFILE_SEARCH = [
    os.path.join(OTA_ROOT, "mcu_profiles"),
    os.path.join(REPO_ROOT, "products", "ncpsky-dtmax", "mcu"),
    "/home/pi/ncpsky-panel/ota/mcu_profiles",
]


def _load_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def find_profiles_root(extra: Optional[str] = None) -> str:
    cands = []
    if extra:
        cands.append(extra)
    cands.extend(PROFILE_SEARCH)
    for root in cands:
        if not root:
            continue
        # products/.../mcu has profiles.json at root
        if os.path.isfile(os.path.join(root, "profiles.json")):
            return root
        nested = os.path.join(root, "profiles")
        if os.path.isfile(os.path.join(nested, "profiles.json")):
            return nested
        # panel ota/mcu_profiles
        if os.path.isdir(os.path.join(root, "gd32f303vet6")) and os.path.isfile(
            os.path.join(root, "profiles.json")
        ):
            return root
    raise FileNotFoundError(
        "MCU profiles not found (expected ota/mcu_profiles or products/ncpsky-dtmax/mcu)"
    )


def load_registry(extra: Optional[str] = None) -> Dict[str, Any]:
    root = find_profiles_root(extra)
    path = os.path.join(root, "profiles.json")
    if not os.path.isfile(path):
        # products layout: profiles.json next to profiles/
        alt = os.path.join(os.path.dirname(root), "profiles.json")
        if os.path.isfile(os.path.join(root if root.endswith("mcu") else os.path.dirname(root), "profiles.json")):
            pass
        prod = os.path.join(REPO_ROOT, "products", "ncpsky-dtmax", "mcu", "profiles.json")
        if os.path.isfile(prod):
            path = prod
            root = os.path.dirname(path)
    data = _load_json(path)
    data["_root"] = os.path.dirname(path)
    return data


def list_profiles(extra: Optional[str] = None) -> Dict[str, Dict[str, Any]]:
    reg = load_registry(extra)
    root = reg.get("_root") or find_profiles_root(extra)
    out: Dict[str, Dict[str, Any]] = {}
    embedded = reg.get("profiles") or {}
    for pid, meta in embedded.items():
        p = dict(meta)
        p["id"] = pid
        candidates = [
            os.path.join(root, "profiles", pid, "defconfig"),
            os.path.join(root, pid, "defconfig"),
            os.path.join(REPO_ROOT, "products", "ncpsky-dtmax", "mcu", "profiles", pid, "defconfig"),
            os.path.join(OTA_ROOT, "mcu_profiles", pid, "defconfig"),
        ]
        for dc in candidates:
            if os.path.isfile(dc):
                p["defconfig"] = dc
                break
        if p.get("defconfig"):
            pj = os.path.join(os.path.dirname(p["defconfig"]), "profile.json")
            if os.path.isfile(pj):
                for k, v in _load_json(pj).items():
                    if k not in p or k == "autoconf_force":
                        p[k] = v
        out[pid] = p
    return out


def get_profile(profile_id: Optional[str] = None, extra: Optional[str] = None) -> Dict[str, Any]:
    reg = load_registry(extra)
    pid = profile_id or reg.get("default_profile") or "gd32f303vet6"
    profiles = list_profiles(extra)
    if pid not in profiles:
        raise KeyError("Unknown MCU profile: %s (have %s)" % (pid, ", ".join(sorted(profiles))))
    return profiles[pid]


def default_profile_id(extra: Optional[str] = None) -> str:
    reg = load_registry(extra)
    return str(reg.get("default_profile") or "gd32f303vet6")


def patch_autoconf(path: str, force: Dict[str, str]) -> None:
    text = open(path, "r", encoding="utf-8", errors="replace").read()
    for key, val in force.items():
        text2, n = re.subn(
            r"(?m)^#define %s .*$" % re.escape(key),
            "#define %s %s" % (key, val),
            text,
        )
        if n != 1:
            raise RuntimeError("failed to patch %s in %s (matches=%s)" % (key, path, n))
        text = text2
    open(path, "w", encoding="utf-8", newline="\n").write(text)


def match_profile_from_probe(
    device_text: str = "",
    device_id: str = "",
    flash_kb: Optional[int] = None,
    extra: Optional[str] = None,
) -> Dict[str, Any]:
    """Pick a profile from ST-Link / probe hints. Defaults to product primary."""
    profiles = list_profiles(extra)
    text = "%s %s" % (device_text or "", device_id or "")
    text_u = text.upper()

    # Explicit silkscreen / name hits first
    for pid, p in profiles.items():
        for token in p.get("silkscreen") or []:
            if str(token).upper() in text_u:
                return p
        if "GD32" in text_u and "gd32" in pid:
            return p

    # Device ID + flash size heuristic (GD32F303 often enumerates as 0x414 like F103)
    for pid, p in profiles.items():
        ids = [str(x).lower().replace("0x", "") for x in (p.get("device_ids") or [])]
        did = str(device_id or "").lower().replace("0x", "")
        if did and did in ids:
            min_kb = int(p.get("min_flash_kb") or 0)
            if flash_kb is None or flash_kb >= min_kb:
                return p

    if flash_kb is not None:
        for pid, p in profiles.items():
            min_kb = int(p.get("min_flash_kb") or 0)
            if min_kb and flash_kb >= min_kb:
                return p

    return get_profile(None, extra)


def read_saved_profile(path: str = "/home/pi/ncpsky-panel/ota/mcu_profile.json") -> Optional[Dict[str, Any]]:
    if not os.path.isfile(path):
        return None
    try:
        data = _load_json(path)
    except Exception:
        return None
    pid = data.get("profile") or data.get("id")
    if not pid:
        return None
    try:
        p = get_profile(str(pid))
        p = dict(p)
        p["detected_via"] = data.get("detected_via") or "saved"
        return p
    except Exception:
        return None


def write_profile_record(path: str, profile: Dict[str, Any], detected_via: str = "") -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    payload = {
        "profile": profile.get("id"),
        "label": profile.get("label"),
        "flash_address": profile.get("flash_address"),
        "klipper_mcu": profile.get("klipper_mcu"),
        "detected_via": detected_via or profile.get("detected_via") or "",
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)
        f.write("\n")
