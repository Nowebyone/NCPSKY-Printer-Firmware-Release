#!/usr/bin/env python3
"""Build factory-channel bundle (not used by daily check-update).

Contains META.json + optional nested kind archives + optional disk image reference.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import tarfile
from datetime import datetime, timezone


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser(description="Build NCPSKY factory OTA bundle")
    ap.add_argument("--version", required=True, help="e.g. factory-2026.11.24")
    ap.add_argument("--out")
    ap.add_argument("--panel-zip")
    ap.add_argument("--stack-zip")
    ap.add_argument("--system-pkg")
    ap.add_argument("--platform-pkg")
    ap.add_argument("--mcu-bin")
    ap.add_argument("--disk-image", help="optional raw/img path packaged inside")
    ap.add_argument("--wipe-save-config", action="store_true")
    ap.add_argument("--notes", default="Factory image — service channel only")
    args = ap.parse_args()

    here = os.path.dirname(os.path.abspath(__file__))
    panel_root = os.path.abspath(os.path.join(here, "..", ".."))
    out_dir = os.path.join(panel_root, "ota", "dist")
    os.makedirs(out_dir, exist_ok=True)
    out = args.out or os.path.join(out_dir, "factory-%s.tar.gz" % args.version)

    meta = {
        "product": "NCPSKY ▲ DTMax",
        "firmware_target": "FLSun T1 Max",
        "kind": "factory",
        "version": args.version,
        "wipe_save_config": bool(args.wipe_save_config),
        "apply_order": ["system", "platform", "stack", "panel", "mcu"],
        "disk_image": os.path.basename(args.disk_image) if args.disk_image else "",
        "notes": args.notes,
        "built_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }

    with tarfile.open(out, "w:gz") as tf:
        data = (json.dumps(meta, indent=2, ensure_ascii=False) + "\n").encode()
        info = tarfile.TarInfo(name="factory/META.json")
        info.size = len(data)
        tf.addfile(info, io.BytesIO(data))
        for kind, path in (
            ("panel", args.panel_zip),
            ("stack", args.stack_zip),
            ("system", args.system_pkg),
            ("platform", args.platform_pkg),
            ("mcu", args.mcu_bin),
        ):
            if not path:
                continue
            if not os.path.isfile(path):
                raise SystemExit("missing %s" % path)
            tf.add(path, arcname="factory/%s-%s" % (kind, os.path.basename(path)))
        if args.disk_image:
            if not os.path.isfile(args.disk_image):
                raise SystemExit("missing disk image")
            tf.add(args.disk_image, arcname="factory/%s" % os.path.basename(args.disk_image))

    digest = sha256_file(out)
    with open(out + ".sha256", "w", encoding="utf-8") as f:
        f.write("%s  %s\n" % (digest, os.path.basename(out)))
    print(json.dumps({
        "id": "factory-%s" % args.version
        if not str(args.version).startswith("factory-") else args.version,
        "kind": "factory",
        "version": args.version,
        "file": os.path.basename(out),
        "sha256": digest,
        "size": os.path.getsize(out),
        "channel": "factory",
    }, indent=2, ensure_ascii=False))
    print("Wrote", out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
