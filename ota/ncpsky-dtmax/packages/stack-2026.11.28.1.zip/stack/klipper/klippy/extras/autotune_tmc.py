import contextlib
import logging
import math
import os
from enum import Enum
from inspect import signature

try:
    from klippy.extras import tmc  # Kalico
except ImportError:
    from . import tmc  # Klipper

from . import motor_constants

# Autotune config parameters
TUNING_GOAL = "auto"
EXTRA_HYSTERESIS = 0
TBL = 1
TOFF = 0
SGT = 1
SG4_THRS = 40
VOLTAGE = 24.0
OVERVOLTAGE_VTH = None

# Generic tuning parameters
COOLSTEP_THRS_FACTOR = 0.75
FULLSTEP_THRS_FACTOR = 1.2
MULTISTEP_FILT = True

# 2240-specific parameters
SLOPE_CONTROL = 3
TMC2240_OVERTEMP_PREWARNING_VTH = 0x0B92  # 120C

# PWM parameters
PWM_AUTOSCALE = True  # Setup pwm autoscale even if we won't use PWM, because it
# gives more data about the motor and is needed for CoolStep.
PWM_AUTOGRAD = True
PWM_REG = 15
PWM_LIM = 4

# SpreadCycle parameters
TPFD = 0

# CoolStep parameters
FAST_STANDSTILL = True
SMALL_HYSTERESIS = False
SEMIN = 2
SEMAX = 4
SEUP = 3
SEDN = 2
SEIMIN = 1  # If we drop to 1/4 current, high accels don't work right
SFILT = 0
IHOLDDELAY = 12
IRUNDELAY = 0

# High speed parameters
VHIGHFS = False
VHIGHCHM = False  # Even though we are fullstepping, we want SpreadCycle control


TRINAMIC_DRIVERS = ["tmc2130", "tmc2208", "tmc2209", "tmc2240", "tmc2660", "tmc5160"]
PWM_FREQ_TARGETS = {
    "tmc2130": 55e3,
    "tmc2208": 55e3,
    "tmc2209": 55e3,
    "tmc2240": 20e3,  # 2240s run very hot at high frequencies
    "tmc2660": 20e3,  # 2660s and 5160s run very hot at high frequencies
    "tmc5160": 20e3,
}


AUTO_PERFORMANCE_MOTORS = {
    "stepper_x",
    "stepper_y",
    "dual_carriage",
    "stepper_x1",
    "stepper_y1",
    "stepper_a",
    "stepper_b",
    "stepper_c",
}


class TuningGoal(str, Enum):
    # This is the default: automatically choose SILENT for Z and PERFORMANCE for X/Y
    AUTO = "auto"
    # Experimental mode that uses StealthChop at low speed and switches to
    # SpreadCycle when needed
    AUTOSWITCH = "autoswitch"
    SILENT = "silent"  # StealthChop at all speeds
    PERFORMANCE = "performance"  # SpreadCycle at all speeds


class AutotuneTMC:
    def __init__(self, config):
        self.printer = config.get_printer()

        # Load motor database
        pconfig = self.printer.lookup_object("configfile")
        dirname = os.path.dirname(os.path.realpath(__file__))
        filename = os.path.join(dirname, "motor_database.cfg")
        try:
            motor_db = pconfig.read_config(filename)
        except Exception:
            raise config.error(f"Cannot load config '{filename}'") from None
        for motor in motor_db.get_prefix_sections("motor_constants"):
            self.printer.load_object(motor_db, motor.get_name())
        for alias in motor_db.get_prefix_sections("motor_alias"):
            alias_obj = motor_constants.MotorAlias(alias)
            self.printer.objects[alias.get_name()] = alias_obj

        # Now find our stepper and driver in the running Klipper config
        self.name = config.get_name().split(None, 1)[-1]
        if not config.has_section(self.name):
            raise config.error(
                f"Could not find stepper config section '[{self.name}]' "
                "required by TMC autotuning"
            )
        self.tmc_section = None
        for driver in TRINAMIC_DRIVERS:
            driver_name = f"{driver} {self.name}"
            if config.has_section(driver_name):
                self.tmc_section = config.getsection(driver_name)
                self.driver_name = driver_name
                self.driver_type = driver
                break
        if self.tmc_section is None:
            raise config.error(
                f"Could not find any TMC driver config section for '{self.name}' "
                "required by TMC autotuning"
            )
        # TMCtstepHelper may have two signatures, let's pick an implementation.
        # FLSun stock Klipper ships without TMCtstepHelper — inject an old-style
        # helper so autotune can run on T1/T1 Max forks.
        if not hasattr(tmc, "TMCtstepHelper"):
            def TMCtstepHelper(step_dist, mres, tmc_freq, velocity):
                if velocity is None or velocity <= 0.0 or velocity > 999999.0:
                    return 0xFFFFF
                step_dist_256 = step_dist / (1 << mres)
                threshold = int(tmc_freq * step_dist_256 / velocity + 0.5)
                return max(0, min(0xFFFFF, threshold))

            tmc.TMCtstepHelper = TMCtstepHelper
            logging.info(
                "autotune_tmc: injected TMCtstepHelper for FLSun-compatible Klipper"
            )
        if "pstepper" in signature(tmc.TMCtstepHelper).parameters:
            self._set_driver_velocity_field = self._set_driver_velocity_field_new
        else:
            self._set_driver_velocity_field = self._set_driver_velocity_field_old
        # AutotuneTMC config parameters
        self.motor = config.get("motor")
        self.motor_name = "motor_constants " + self.motor
        tgoal = config.get("tuning_goal", default=TUNING_GOAL).lower()
        try:
            self.tuning_goal = TuningGoal(tgoal)
        except ValueError:
            raise config.error(
                f"Tuning goal '{tgoal}' is invalid for TMC autotuning"
            ) from None
        self.auto_silent = False  # Auto silent off by default
        self.tmc_object = None  # look this up at connect time
        self.tmc_cmdhelper = None  # Ditto
        self.run_current = 0.0
        self.fclk = None
        self.motor_object = None
        self.extra_hysteresis = config.getint(
            "extra_hysteresis", default=EXTRA_HYSTERESIS, minval=0, maxval=8
        )
        self.tbl = config.getint("tbl", default=TBL, minval=0, maxval=3)
        self.toff = config.getint("toff", default=TOFF, minval=0, maxval=15)
        self.tpfd = config.getint("tpfd", default=None, minval=0, maxval=15)
        self.sgt = config.getint("sgt", default=SGT, minval=-64, maxval=63)
        # TMC2240: default sg4_thrs to 0 so Klipper uses the SGT homing path,
        # which is compatible with autotune's SpreadCycle and CoolStep config.
        # Users can still set sg4_thrs explicitly to opt into SG4 homing.
        sg4_thrs_default = 0 if self.driver_type == "tmc2240" else SG4_THRS
        self.sg4_thrs = config.getint(
            "sg4_thrs", default=sg4_thrs_default, minval=0, maxval=255
        )
        # Coolstep Tunables
        self.se_min = config.getint("semin", default=SEMIN, minval=0, maxval=15)
        self.se_max = config.getint("semax", default=SEMAX, minval=0, maxval=15)
        self.se_up = config.getint("seup", default=SEUP, minval=0, maxval=3)
        self.se_down = config.getint("sedn", default=SEDN, minval=0, maxval=3)
        self.se_imin = config.getint("seimin", default=SEIMIN, minval=0, maxval=1)

        self.voltage = config.getfloat(
            "voltage", default=VOLTAGE, above=0.0, maxval=60.0
        )
        # A zero threshold asserts the overvoltage condition continuously, and
        # values above the TMC2240 absolute maximum cannot protect it in time.
        # Leaving the option unset preserves the driver's hardware default.
        self.overvoltage_vth = config.getfloat(
            "overvoltage_vth", default=OVERVOLTAGE_VTH, above=0.0, maxval=41.0
        )
        # Only the TMC2240 has a programmable overvoltage threshold; reject the
        # option on other drivers instead of silently ignoring it.
        if self.overvoltage_vth is not None and self.driver_type != "tmc2240":
            raise config.error(
                "overvoltage_vth is only supported on TMC2240, but the driver "
                f"for '{self.name}' is {self.driver_type}."
            )
        self.pwm_freq_target = config.getfloat(
            "pwm_freq_target",
            default=PWM_FREQ_TARGETS[self.driver_type],
            minval=10e3,
            maxval=100e3,
        )
        # TMC2160 external FETs tolerate a higher bin than integrated 5160s.
        # 8 is below the stock 15 so the regulator hunts less (less howl)
        # while still tracking T1 Max accelerations.
        self.pwm_reg = config.getint("pwm_reg", default=PWM_REG, minval=1, maxval=15)
        self.pwm_lim = config.getint("pwm_lim", default=PWM_LIM, minval=0, maxval=15)
        self.iholddelay = config.getint(
            "iholddelay", default=IHOLDDELAY, minval=0, maxval=15
        )
        self.pwm_freq_sel = 0
        self.pwm_freq_hz = None
        self.printer.register_event_handler("klippy:connect", self.handle_connect)
        self.printer.register_event_handler("klippy:ready", self.handle_ready)
        # Register command
        gcode = self.printer.lookup_object("gcode")
        gcode.register_mux_command(
            "AUTOTUNE_TMC",
            "STEPPER",
            self.name,
            self.cmd_AUTOTUNE_TMC,
            desc=self.cmd_AUTOTUNE_TMC_help,
        )

    def handle_connect(self):
        # Register aliases now that all user motor_constants are loaded
        for _name, obj in list(self.printer.objects.items()):
            if isinstance(obj, motor_constants.MotorAlias):
                obj.register(self.printer)
        self.tmc_object = self.printer.lookup_object(self.driver_name)
        # The cmdhelper itself isn't a member... but we can still get to it.
        self.tmc_cmdhelper = self.tmc_object.get_status.__self__
        try:
            self.motor_object = self.printer.lookup_object(self.motor_name)
        except self.printer.config_error:
            raise self.printer.config_error(
                f"Could not find motor definition '[{self.motor_name}]' required "
                "by TMC autotuning. It is not part of the database, please "
                "define it in your config!"
            ) from None
        alias_obj = self.printer.lookup_object(
            "motor_alias " + self.motor, default=None
        )
        if alias_obj is not None and alias_obj.deprecated:
            alias_target = self.printer.lookup_object(
                "motor_constants " + alias_obj.motor, default=None
            )
            if self.motor_object is alias_target:
                pconfig = self.printer.lookup_object("configfile")
                msg = (
                    f"Motor name '{self.motor}' is deprecated, please update "
                    f"your config to use '{alias_obj.motor}' instead."
                )
                if hasattr(pconfig, "runtime_warning"):
                    pconfig.runtime_warning(msg)
                else:
                    logging.warning(msg)
        if self.tuning_goal == TuningGoal.AUTO:
            # Very small motors may not run in silent mode.
            self.auto_silent = (
                self.name not in AUTO_PERFORMANCE_MOTORS
                and self.motor_object.holding_torque > 0.3
            )
            self.tuning_goal = (
                TuningGoal.SILENT if self.auto_silent else TuningGoal.PERFORMANCE
            )

    def handle_ready(self):
        # klippy:ready handlers are limited in what they may do. Communicating
        # with a MCU will pause the reactor and is thus forbidden. That code has
        # to run outside of the event handler.
        self.printer.reactor.register_callback(self._handle_ready_deferred)

    def _handle_ready_deferred(self, eventtime):
        with contextlib.suppress(AttributeError):
            self.fclk = self.tmc_object.mcu_tmc.get_tmc_frequency()
        if self.fclk is None:
            # TMC2160/5160 on FLSun boards use 12 MHz; fall back accordingly.
            self.fclk = 12.0e6 if self.driver_type in ("tmc5160", "tmc2130") else 12.5e6
        self.tune_driver()
        # Klipper's TMCCommandHelper snapshots TOFF at klippy:connect time (before
        # autotune has computed its value) for steppers using virtual/soft enable,
        # and restores that stale snapshot on every re-enable. Reapply our tuned
        # value afterward so it isn't clobbered; see GH-354.
        try:
            enable_line = self.tmc_cmdhelper.stepper_enable.lookup_enable(
                self.tmc_cmdhelper.stepper_name
            )
            if hasattr(enable_line, "has_dedicated_enable") and (
                not enable_line.has_dedicated_enable()
            ):
                enable_line.register_state_callback(self._handle_stepper_enable)
        except Exception as exc:
            logging.info("autotune_tmc: skip enable callback hook: %s", exc)

    def _handle_stepper_enable(self, print_time, is_enable):
        if not is_enable:
            return

        def reapply_toff(eventtime):
            self._set_driver_field("toff", self.toff)

        self.printer.reactor.register_callback(reapply_toff)

    cmd_AUTOTUNE_TMC_help = "Apply autotuning configuration to TMC stepper driver"

    def cmd_AUTOTUNE_TMC(self, gcmd):
        logging.info("AUTOTUNE_TMC %s", self.name)
        tgoal = gcmd.get("TUNING_GOAL", None)
        if tgoal is not None:
            try:
                self.tuning_goal = TuningGoal(tgoal)
            except ValueError:
                raise gcmd.error(
                    "Invalid tuning goal '{}', must be one of: {}".format(
                        tgoal, ", ".join(g.value for g in TuningGoal)
                    )
                ) from None
            if self.tuning_goal == TuningGoal.AUTO:
                self.tuning_goal = (
                    TuningGoal.SILENT if self.auto_silent else TuningGoal.PERFORMANCE
                )
        semin = gcmd.get_int("SEMIN", None, minval=0, maxval=15)
        if semin is not None:
            self.se_min = semin
        extra_hysteresis = gcmd.get_int("EXTRA_HYSTERESIS", None)
        if extra_hysteresis is not None:
            if extra_hysteresis >= 0 and extra_hysteresis <= 8:
                self.extra_hysteresis = extra_hysteresis
            else:
                gcmd.respond_info(
                    f"EXTRA_HYSTERESIS={extra_hysteresis} out of range (0-8), ignored"
                )
        tbl = gcmd.get_int("TBL", None)
        if tbl is not None:
            if tbl >= 0 and tbl <= 3:
                self.tbl = tbl
            else:
                gcmd.respond_info(f"TBL={tbl} out of range (0-3), ignored")
        toff = gcmd.get_int("TOFF", None)
        if toff is not None:
            if toff >= 0 and toff <= 15:
                self.toff = toff
            else:
                gcmd.respond_info(f"TOFF={toff} out of range (0-15), ignored")
        tpfd = gcmd.get_int("TPFD", None)
        if tpfd is not None:
            if tpfd >= 0 and tpfd <= 15:
                self.tpfd = tpfd
            else:
                gcmd.respond_info(f"TPFD={tpfd} out of range (0-15), ignored")
        sgt = gcmd.get_int("SGT", None)
        if sgt is not None:
            if sgt >= -64 and sgt <= 63:
                self.sgt = sgt
            else:
                gcmd.respond_info(f"SGT={sgt} out of range (-64 to 63), ignored")
        sg4_thrs = gcmd.get_int("SG4_THRS", None)
        if sg4_thrs is not None:
            if sg4_thrs >= 0 and sg4_thrs <= 255:
                self.sg4_thrs = sg4_thrs
            else:
                gcmd.respond_info(f"SG4_THRS={sg4_thrs} out of range (0-255), ignored")
        voltage = gcmd.get_float("VOLTAGE", None)
        if voltage is not None:
            if voltage > 0.0 and voltage <= 60.0:
                self.voltage = voltage
            else:
                gcmd.respond_info(f"VOLTAGE={voltage:.1f} out of range (0-60), ignored")
        overvoltage_vth = gcmd.get_float("OVERVOLTAGE_VTH", None)
        if overvoltage_vth is not None:
            if self.driver_type != "tmc2240":
                gcmd.respond_info(
                    "OVERVOLTAGE_VTH is only supported on TMC2240, ignored"
                )
            elif overvoltage_vth > 0.0 and overvoltage_vth <= 41.0:
                self.overvoltage_vth = overvoltage_vth
            else:
                gcmd.respond_info(
                    f"OVERVOLTAGE_VTH={overvoltage_vth:.1f} out of range "
                    "(0-41), ignored"
                )
        self.tune_driver()

    def tune_driver(self):
        if not self.fclk:
            # A home macro can call AUTOTUNE before the ready callback
            # stores the TMC clock. None used to raise inside the gcode
            # command and shut the whole printer down.
            self.fclk = (
                12.0e6 if self.driver_type in ("tmc5160", "tmc2130") else 12.5e6
            )
        _currents = self.tmc_cmdhelper.current_helper.get_current()
        self.run_current = _currents[0]
        # Validate before any hardware write: out-of-range values would be masked
        # into the 8-bit fields and also drive maxpwmrps() negative.
        self._check_pwm_field_ranges()
        # Program the overvoltage threshold before any other register write, so a
        # rejected value cannot leave the driver partially retuned. Quantize
        # upward and validate the value that actually reaches the register: a
        # flooring conversion could otherwise program a threshold below the supply
        # and assert the overvoltage condition continuously. Done here rather than
        # at parse time so a runtime VOLTAGE change is also covered.
        if self.overvoltage_vth is not None:
            vth = math.ceil(self.overvoltage_vth / 0.009732)
            if vth * 0.009732 <= self.voltage:
                raise self.printer.command_error(
                    f"Autotune {self.name}: overvoltage_vth={self.overvoltage_vth:.3f} "
                    f"V programs {vth * 0.009732:.3f} V, which does not exceed "
                    f"the supply voltage {self.voltage:.1f} V; the overvoltage "
                    "condition would assert continuously."
                )
            self._set_overvoltage_vth(vth)
        self._set_pwmfreq()
        self._setup_spreadcycle()
        self._set_hysteresis(self.run_current)
        self._set_sg4thrs()
        motor = self.motor_object
        maxpwmrps = motor.maxpwmrps(
            fclk=self.fclk, volts=self.voltage, current=self.run_current
        )
        rdist, _ = self.tmc_cmdhelper.stepper.get_rotation_distance()
        # Speed at which we run out of PWM control and should switch to fullstep
        vmaxpwm = maxpwmrps * rdist
        logging.info("autotune_tmc using max PWM speed %f", vmaxpwm)
        coolthrs = COOLSTEP_THRS_FACTOR * rdist
        self._setup_pwm(self.tuning_goal, self._pwmthrs(vmaxpwm, coolthrs))
        # One revolution every two seconds is about as slow as coolstep can go
        self._setup_coolstep(coolthrs)
        self._setup_highspeed(FULLSTEP_THRS_FACTOR * vmaxpwm)
        self._set_driver_field("multistep_filt", MULTISTEP_FILT)
        # Cool down 2240s
        self._set_driver_field("slope_control", SLOPE_CONTROL)

    def _check_pwm_field_ranges(self):
        # PWM_OFS and PWM_GRAD are 8-bit fields. Klipper's FieldHelper.set_field()
        # masks values into the field width rather than validating them, so an
        # out-of-range result would wrap. Drivers without StealthChop (e.g.
        # tmc2660) have neither field, so skip a check when the field is absent.
        motor = self.motor_object
        fields = self.tmc_object.fields
        if fields.lookup_register("pwm_ofs", None) is not None:
            # PWM_OFS must stay below 255: at 255 there is no headroom and
            # maxpwmrps() collapses to zero. It scales with run current.
            pwm_ofs = motor.pwmofs(volts=self.voltage, current=self.run_current)
            if not 0 <= pwm_ofs < 255:
                raise self.printer.command_error(
                    f"Autotune {self.name}: computed PWM_OFS={pwm_ofs} leaves no "
                    f"headroom below the 8-bit limit for motor '{self.motor}' at "
                    f"{self.voltage:.1f} V and {self.run_current:.2f} A. Lower the "
                    "run current or raise the supply voltage."
                )
        if fields.lookup_register("pwm_grad", None) is not None:
            # PWM_GRAD depends on back-EMF and supply voltage, not run current.
            pwm_grad = motor.pwmgrad(volts=self.voltage, fclk=self.fclk)
            if not 0 <= pwm_grad <= 255:
                raise self.printer.command_error(
                    f"Autotune {self.name}: computed PWM_GRAD={pwm_grad} exceeds "
                    f"the 8-bit field for motor '{self.motor}' at "
                    f"{self.voltage:.1f} V. Raise the supply voltage."
                )

    def _set_driver_field(self, field, arg):
        tmco = self.tmc_object
        register = tmco.fields.lookup_register(field, None)
        # Just bail if the field doesn't exist.
        if register is None:
            return
        logging.info("autotune_tmc set %s %s=%s", self.name, field, repr(arg))
        val = tmco.fields.set_field(field, arg)
        tmco.mcu_tmc.set_register(register, val, None)

    def _set_overvoltage_vth(self, arg):
        tmco = self.tmc_object
        register = tmco.fields.lookup_register("overvoltage_vth", None)
        if register is None:
            return
        otpw_register = tmco.fields.lookup_register("overtempprewarning_vth", None)
        if self.driver_type == "tmc2240" and otpw_register == register:
            reg_val = tmco.fields.registers.get(register)
            if reg_val is None:
                try:
                    reg_val = tmco.mcu_tmc.get_register(register)
                except self.printer.command_error:
                    reg_val = 0
            otpw_vth = tmco.fields.get_field(
                "overtempprewarning_vth", reg_val, register
            )
            if not otpw_vth:
                reg_val = tmco.fields.set_field(
                    "overtempprewarning_vth",
                    TMC2240_OVERTEMP_PREWARNING_VTH,
                    reg_val,
                    register,
                )
            logging.info("autotune_tmc set %s overvoltage_vth=%s", self.name, repr(arg))
            val = tmco.fields.set_field("overvoltage_vth", arg, reg_val, register)
            tmco.mcu_tmc.set_register(register, val, None)
            return
        self._set_driver_field("overvoltage_vth", arg)

    def _set_driver_velocity_field_new(self, field, velocity):
        tmco = self.tmc_object
        register = tmco.fields.lookup_register(field, None)
        # Just bail if the field doesn't exist.
        if register is None:
            return
        arg = tmc.TMCtstepHelper(
            tmco.mcu_tmc, velocity, pstepper=self.tmc_cmdhelper.stepper
        )
        logging.info(
            "autotune_tmc set %s %s=%s(%s)", self.name, field, repr(arg), repr(velocity)
        )
        val = tmco.fields.set_field(field, arg)
        tmco.mcu_tmc.set_register(register, val, None)

    def _set_driver_velocity_field_old(self, field, velocity):
        tmco = self.tmc_object
        register = tmco.fields.lookup_register(field, None)
        # Just bail if the field doesn't exist.
        if register is None:
            return
        step_dist = self.tmc_cmdhelper.stepper.get_step_dist()
        mres = tmco.fields.get_field("mres")
        arg = tmc.TMCtstepHelper(step_dist, mres, self.fclk, velocity)
        logging.info(
            "autotune_tmc set %s %s=%s(%s)", self.name, field, repr(arg), repr(velocity)
        )
        val = tmco.fields.set_field(field, arg)
        # FLSun SPI path: flush register immediately so CoolStep/Stealth thresholds apply
        tmco.mcu_tmc.set_register(register, val, None)

    def _set_pwmfreq(self):
        # Highest bin at or below pwm_freq_target.
        # 12 MHz: 23.4 / 35.1 / 46.9 / 58.5 kHz. The 0.0 row is the fallback.
        chosen = next(
            i
            for i in [
                (3, 2.0 / 410),
                (2, 2.0 / 512),
                (1, 2.0 / 683),
                (0, 2.0 / 1024),
                (0, 0.0),
            ]
            if self.fclk * i[1] <= self.pwm_freq_target
        )
        self.pwm_freq_sel = chosen[0]
        self.pwm_freq_hz = self.fclk * chosen[1] if chosen[1] else self.fclk * 2.0 / 1024
        logging.info(
            "autotune_tmc %s pwm_freq=%s actual_hz=%.0f target=%.0f",
            self.name,
            self.pwm_freq_sel,
            self.pwm_freq_hz,
            self.pwm_freq_target,
        )
        self._set_driver_field("pwm_freq", self.pwm_freq_sel)

    def _tblank_cycles(self):
        if self.driver_type in ["tmc2208", "tmc2209"]:
            tblank_cycles = [16, 24, 32, 40]
        else:
            tblank_cycles = [16, 24, 36, 54]
        return tblank_cycles[self.tbl]

    def _set_hysteresis(self, run_current):
        hstrt, hend = self.motor_object.hysteresis(
            volts=self.voltage,
            current=run_current,
            tblank_cycles=self._tblank_cycles(),
            toff=self.toff,
            fclk=self.fclk,
            extra=self.extra_hysteresis,
        )
        self._set_driver_field("hstrt", hstrt)
        self._set_driver_field("hend", hend)

    def _set_sg4thrs(self):
        if self.tmc_object.fields.lookup_register("sg4_thrs", None) is not None:
            # we have SG4
            self._set_driver_field("sg4_thrs", self.sg4_thrs)
            self._set_driver_field("sg4_filt_en", True)
        elif self.tmc_object.fields.lookup_register("sgthrs", None) is not None:
            # With SG4 on 2209, pwmthrs should be greater than coolthrs
            self._set_driver_field("sgthrs", self.sg4_thrs)
        else:
            # We do not have SG4
            pass

    def _pwmthrs(self, vmaxpwm, coolthrs):
        if self.tmc_object.fields.lookup_register("sg4_thrs", None) is not None:
            # we have SG4
            # 2240 doesn't care about pwmthrs vs coolthrs ordering, but this is
            # desirable
            return max(0.2 * vmaxpwm, 1.125 * coolthrs)
        elif self.tmc_object.fields.lookup_register("sgthrs", None) is not None:
            # With SG4 on 2209, pwmthrs should be greater than coolthrs
            return max(0.2 * vmaxpwm, 1.125 * coolthrs)
        else:
            # No SG4 — set pwmthrs for autoswitch mode transition
            return 0.5 * vmaxpwm

    def _setup_pwm(self, tgoal, pwmthrs):
        motor = self.motor_object
        pwmgrad = motor.pwmgrad(volts=self.voltage, fclk=self.fclk)
        pwmofs = motor.pwmofs(volts=self.voltage, current=self.run_current)
        self._set_driver_field("pwm_autoscale", PWM_AUTOSCALE)
        self._set_driver_field("pwm_autograd", PWM_AUTOGRAD)
        self._set_driver_field("pwm_grad", pwmgrad)
        self._set_driver_field("pwm_ofs", pwmofs)
        self._set_driver_field("pwm_reg", self.pwm_reg)
        self._set_driver_field("pwm_lim", self.pwm_lim)
        # 0 = normal PWM hold. Freewheel / coil-short drops delta position.
        if tgoal == TuningGoal.AUTOSWITCH:
            logging.info(
                "autotune_tmc set %s autoswitch velocity limit to %.3f",
                self.name,
                pwmthrs,
            )
            self._set_driver_velocity_field("tpwmthrs", pwmthrs)
            self._set_driver_field("en_pwm_mode", True)
            self._set_driver_field(
                "en_spreadcycle", False
            )  # TMC2208 use en_spreadcycle instead of en_pwm_mode
        elif tgoal == TuningGoal.SILENT:
            self._set_driver_field("tpwmthrs", 0)
            self._set_driver_field("en_pwm_mode", True)
            self._set_driver_field(
                "en_spreadcycle", False
            )  # TMC2208 use en_spreadcycle instead of en_pwm_mode
        elif tgoal == TuningGoal.PERFORMANCE:
            self._set_driver_field("tpwmthrs", 0xFFFFF)
            self._set_driver_field("en_pwm_mode", False)
            self._set_driver_field(
                "en_spreadcycle", True
            )  # TMC2208 use en_spreadcycle instead of en_pwm_mode
        self._set_driver_field("freewheel", 0)

    def _setup_spreadcycle(self):
        # Match the chopper period to the bin actually programmed, not the target.
        freq = self.pwm_freq_hz or self.pwm_freq_target
        ncycles = math.ceil(self.fclk / freq)
        sdcycles = ncycles / 4
        if self.toff == 0:
            # About half the cycle should be taken by the two slow decay cycles
            self.toff = max(min(math.ceil(max(sdcycles - 24, 0) / 32), 15), 1)

        if self.toff == 1 and self.tbl == 0:
            # blank time of 16 cycles will not work in this case
            self.tbl = 1

        pfdcycles = ncycles - (24 + 32 * self.toff) * 2 - self._tblank_cycles()
        if self.tpfd is None:
            self.tpfd = max(0, min(15, math.ceil(pfdcycles / 128)))

        logging.info(
            "autotune_tmc %s ncycles=%d pfdcycles=%d", self.name, ncycles, pfdcycles
        )

        self._set_driver_field("tpfd", self.tpfd)
        self._set_driver_field("tbl", self.tbl)
        self._set_driver_field("toff", self.toff)

    def _setup_coolstep(self, coolthrs):
        self._set_driver_velocity_field("tcoolthrs", coolthrs)
        self._set_driver_field("sgt", self.sgt)
        self._set_driver_field("faststandstill", FAST_STANDSTILL)
        self._set_driver_field("small_hysteresis", SMALL_HYSTERESIS)
        self._set_driver_field("semin", self.se_min)
        self._set_driver_field("semax", self.se_max)
        self._set_driver_field("seup", self.se_up)
        self._set_driver_field("sedn", self.se_down)
        self._set_driver_field("seimin", self.se_imin)
        self._set_driver_field("sfilt", SFILT)
        self._set_driver_field("iholddelay", self.iholddelay)
        self._set_driver_field("irundelay", IRUNDELAY)

    def _setup_highspeed(self, vhigh):
        self._set_driver_velocity_field("thigh", vhigh)
        self._set_driver_field("vhighfs", VHIGHFS)
        self._set_driver_field("vhighchm", VHIGHCHM)


def load_config_prefix(config):
    return AutotuneTMC(config)
