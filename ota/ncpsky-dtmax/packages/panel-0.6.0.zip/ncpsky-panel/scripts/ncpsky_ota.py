#!/usr/bin/env python3
"""NCPSKY OTA engine — manifest check, download, install, backup, rollback."""
from __future__ import annotations

import hashlib
import json
import logging
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
import zipfile
from datetime import datetime, timezone
from urllib.error import HTTPError, URLError
from urllib.request import (
    HTTPSHandler,
    ProxyHandler,
    Request,
    build_opener,
    urlopen,
)

LOG = logging.getLogger("ncpsky_ota")
if not LOG.handlers:
    _handlers = [logging.StreamHandler()]
    try:
        _log_path = "/tmp/ncpsky_ota.log"
        os.makedirs(os.path.dirname(_log_path), exist_ok=True)
        _handlers.insert(0, logging.FileHandler(_log_path, encoding="utf-8"))
    except Exception:
        pass
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        handlers=_handlers,
    )

PANEL_ROOT = "/home/pi/ncpsky-panel"
OTA_ROOT = os.path.join(PANEL_ROOT, "ota")
CONFIG_PATH = os.path.join(OTA_ROOT, "config.json")
CONFIG_DEFAULT = os.path.join(OTA_ROOT, "config.default.json")
VERSIONS_PATH = os.path.join(OTA_ROOT, "versions.json")
HISTORY_PATH = os.path.join(OTA_ROOT, "history.json")
PERSIST_PROFILE_PATH = os.path.join(OTA_ROOT, "persist_profile.json")
STAGING = os.path.join(OTA_ROOT, "staging")
BACKUP = os.path.join(OTA_ROOT, "backup")
PENDING_CLEANUP = os.path.join(OTA_ROOT, "pending_cleanup.json")
# User data that must survive panel OTA (WiFi is OS-level; proxy lives under ota/)
PERSIST_PANEL_FILES = (
    "settings.json",
)
PERSIST_OTA_FILES = (
    "config.json",
    "proxy.json",
    "proxy.vless",
    "versions.json",
    "history.json",
)
DAILY_CHANNELS = ("stable", "beta", "dev")
ALL_CHANNELS = ("stable", "beta", "dev", "factory")
SKIP_CONFIG_OVERWRITE = (
    "moonraker.conf",
    "moonraker.asvc",
    "secrets.json",
)
PRINTER_CFG_LIVE = "/home/pi/printer_data/config/printer.cfg"
MOONRAKER = "http://127.0.0.1:7125"
FIRMWARE_TARGET = "FLSun T1 Max"
PRODUCT = "NCPSKY ▲ DTMax"

_state_lock = threading.Lock()
_state = {
    "busy": False,
    "phase": "idle",
    "progress": 0.0,
    "message": "",
    "error": "",
    "current_package": None,
    "last_check": None,
    "available": [],
    "notes": "",
    "update_available": False,
    "version_label": "",
    "confirm_mcu": None,  # pending mcu package awaiting confirm
    "release_assets": None,  # github release asset name→url map
}


def _utc_now():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _ensure_dirs():
    for d in (OTA_ROOT, STAGING, BACKUP):
        os.makedirs(d, exist_ok=True)
    if not os.path.exists(CONFIG_PATH) and os.path.exists(CONFIG_DEFAULT):
        shutil.copy2(CONFIG_DEFAULT, CONFIG_PATH)
    if not os.path.exists(VERSIONS_PATH):
        _save_json(VERSIONS_PATH, {
            "panel": _read_panel_version(),
            "stack": "2026.11.23.1",
            "system": "sys-none",
            "platform": "plat-none",
            "mcu": "mcu-unknown",
            "factory": "factory-none",
            "klipper_core": "0.14.0",
            "klipper_custom": "FLSunT1Max",
        })
    if not os.path.exists(HISTORY_PATH):
        _save_json(HISTORY_PATH, [])
    # Ship persist_profile.json next to engine defaults when missing
    bundled = os.path.join(os.path.dirname(CONFIG_DEFAULT), "persist_profile.json")
    if not os.path.exists(PERSIST_PROFILE_PATH) and os.path.exists(bundled):
        try:
            shutil.copy2(bundled, PERSIST_PROFILE_PATH)
        except Exception:
            pass


def load_persist_profile():
    """Load absolute_keep / merge_update rules for OTA installs."""
    profile = _load_json(PERSIST_PROFILE_PATH, None)
    if not profile:
        bundled = os.path.join(os.path.dirname(CONFIG_DEFAULT), "persist_profile.json")
        profile = _load_json(bundled, {})
    return profile or {}


def identity_keys_from_profile():
    profile = load_persist_profile()
    cfg = ((profile.get("absolute_keep") or {}).get("printer_cfg") or {})
    keys = cfg.get("identity_keys") or ["serial", "canbus_uuid", "uuid"]
    return list(keys)


def _load_json(path, default=None):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default if default is not None else {}


def _save_json(path, data):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")
    os.replace(tmp, path)


def _read_panel_version():
    ver = os.path.join(PANEL_ROOT, "VERSION")
    try:
        with open(ver, "r", encoding="utf-8") as f:
            return f.readline().strip() or "0.0.0"
    except Exception:
        return "0.0.0"


def _default_github():
    return {
        "owner": "Nowebyone",
        "repo": "NCPSKY-Printer-Firmware-Release",
        "ref": "main",
        "mode": "raw",  # raw | release
        "path_prefix": "ota/ncpsky-dtmax",
        "release_tag": {
            "stable": "ota-stable",
            "beta": "ota-beta",
            "dev": "ota-dev",
        },
    }


def _default_proxy():
    return {
        "enabled": False,
        "url": "http://127.0.0.1:7890",
        "github_mirror": "",  # e.g. https://ghfast.top/  (optional CDN front)
    }


def load_config():
    _ensure_dirs()
    cfg = _load_json(CONFIG_DEFAULT, {})
    # shallow then deep-merge nested dicts from user config
    user = _load_json(CONFIG_PATH, {})
    nested_keys = ("github", "proxy")
    for k, v in user.items():
        if k in nested_keys and isinstance(v, dict):
            base = dict(cfg.get(k) or {})
            base.update(v)
            cfg[k] = base
        else:
            cfg[k] = v
    cfg.setdefault("product", PRODUCT)
    cfg.setdefault("firmware_target", FIRMWARE_TARGET)
    cfg.setdefault("channel", "stable")
    cfg.setdefault("source", "http")  # http | github
    cfg.setdefault("base_url", "http://127.0.0.1:8765/ota/ncpsky-dtmax")
    cfg.setdefault("insecure_http", True)
    cfg.setdefault("backup_keep", 2)
    gh = dict(_default_github())
    gh.update(cfg.get("github") or {})
    if isinstance(gh.get("release_tag"), dict):
        tags = dict(_default_github()["release_tag"])
        tags.update(gh["release_tag"])
        gh["release_tag"] = tags
    cfg["github"] = gh
    px = dict(_default_proxy())
    px.update(cfg.get("proxy") or {})
    cfg["proxy"] = px
    if cfg.get("source") not in ("http", "github"):
        cfg["source"] = "http"
    return cfg


def save_config(patch):
    cfg = load_config()
    for k, v in (patch or {}).items():
        if k in ("github", "proxy") and isinstance(v, dict):
            base = dict(cfg.get(k) or {})
            # nested release_tag merge
            if k == "github" and isinstance(v.get("release_tag"), dict):
                tags = dict(base.get("release_tag") or {})
                tags.update(v["release_tag"])
                v = dict(v)
                v["release_tag"] = tags
            base.update(v)
            cfg[k] = base
        else:
            cfg[k] = v
    if cfg.get("source") not in ("http", "github"):
        cfg["source"] = "http"
    _save_json(CONFIG_PATH, cfg)
    return cfg


def load_versions():
    _ensure_dirs()
    v = _load_json(VERSIONS_PATH, {})
    v["panel"] = _read_panel_version()
    v.setdefault("stack", "unknown")
    v.setdefault("system", "sys-none")
    v.setdefault("platform", "plat-none")
    v.setdefault("mcu", "mcu-unknown")
    v.setdefault("factory", "factory-none")
    v.setdefault("klipper_core", "0.14.0")
    v.setdefault("klipper_custom", "FLSunT1Max")
    return v


def component_versions_summary(local=None):
    """toC-facing component lines for status / update UI."""
    local = local or load_versions()
    return {
        "panel": str(local.get("panel") or ""),
        "stack": str(local.get("stack") or ""),
        "system": str(local.get("system") or ""),
        "platform": str(local.get("platform") or ""),
        "mcu": str(local.get("mcu") or ""),
        "klipper_core": str(local.get("klipper_core") or ""),
        "klipper_custom": str(local.get("klipper_custom") or ""),
    }


def save_versions(patch):
    v = load_versions()
    v.update(patch or {})
    _save_json(VERSIONS_PATH, v)
    return v


def history_list(limit=30):
    items = _load_json(HISTORY_PATH, [])
    if not isinstance(items, list):
        items = []
    return items[:limit]


def _append_history(entry):
    items = history_list(200)
    items.insert(0, entry)
    _save_json(HISTORY_PATH, items[:100])


def _set_state(**kwargs):
    with _state_lock:
        _state.update(kwargs)
        return dict(_state)


def get_runtime_state():
    with _state_lock:
        return dict(_state)


def disk_free_mb(path="/home/pi"):
    try:
        st = os.statvfs(path)
        return int((st.f_bavail * st.f_frsize) / (1024 * 1024))
    except Exception:
        return 0


def _proxy_url(cfg=None):
    cfg = cfg or load_config()
    px = cfg.get("proxy") or {}
    if not px.get("enabled"):
        return None
    url = (px.get("url") or "").strip()
    return url or None


def _apply_github_mirror(url, cfg=None):
    """Optional China-friendly front for github.com / raw.githubusercontent.com."""
    cfg = cfg or load_config()
    mirror = ((cfg.get("proxy") or {}).get("github_mirror") or "").strip()
    if not mirror:
        return url
    if "github.com" not in url and "githubusercontent.com" not in url:
        return url
    return mirror.rstrip("/") + "/" + url


def _build_opener(insecure=True, proxy_url=None):
    handlers = []
    if proxy_url:
        handlers.append(ProxyHandler({
            "http": proxy_url,
            "https": proxy_url,
        }))
    else:
        # force direct (ignore process env proxies if any)
        handlers.append(ProxyHandler({}))
    if insecure:
        import ssl
        ctx = ssl._create_unverified_context()
        handlers.append(HTTPSHandler(context=ctx))
    return build_opener(*handlers)


def _http_get_bytes(url, timeout=60, insecure=True, cfg=None):
    cfg = cfg or load_config()
    url = _apply_github_mirror(url, cfg)
    proxy = _proxy_url(cfg)
    req = Request(url, headers={
        "User-Agent": "ncpsky-ota/1.0",
        "Accept": "application/octet-stream, application/json, */*",
    })
    opener = _build_opener(insecure=insecure, proxy_url=proxy)
    with opener.open(req, timeout=timeout) as r:
        return r.read()


def _http_get_json(url, timeout=30, insecure=True, cfg=None):
    raw = _http_get_bytes(url, timeout=timeout, insecure=insecure, cfg=cfg)
    return json.loads(raw.decode("utf-8"))


def _http_get_json_direct(url, timeout=10):
    """Local Moonraker calls — never via user proxy."""
    req = Request(url, headers={"User-Agent": "ncpsky-ota/1.0"})
    opener = _build_opener(insecure=True, proxy_url=None)
    with opener.open(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def moonraker_print_busy():
    try:
        data = _http_get_json_direct(
            MOONRAKER + "/printer/objects/query?print_stats",
            timeout=5,
        )
        st = (((data.get("result") or {}).get("status") or {}).get("print_stats") or {})
        state = (st.get("state") or "").lower()
        return state in ("printing", "paused")
    except Exception:
        return False


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def _resolve_url(base_url, url):
    if url.startswith("http://") or url.startswith("https://"):
        return url
    return base_url.rstrip("/") + "/" + url.lstrip("/")


def github_raw_base(cfg=None):
    cfg = cfg or load_config()
    gh = cfg.get("github") or {}
    owner = gh.get("owner") or "ncpsky"
    repo = gh.get("repo") or "ota"
    ref = gh.get("ref") or "main"
    prefix = (gh.get("path_prefix") or "ota/ncpsky-dtmax").strip("/")
    base = "https://raw.githubusercontent.com/%s/%s/%s" % (owner, repo, ref)
    if prefix:
        base = base + "/" + prefix
    return base


def github_release_tag(cfg=None, channel=None):
    cfg = cfg or load_config()
    gh = cfg.get("github") or {}
    channel = channel or cfg.get("channel") or "stable"
    tags = gh.get("release_tag") or {}
    return tags.get(channel) or ("ota-%s" % channel)


def github_api_release(cfg=None, channel=None):
    cfg = cfg or load_config()
    gh = cfg.get("github") or {}
    owner = gh.get("owner") or "ncpsky"
    repo = gh.get("repo") or "ota"
    tag = github_release_tag(cfg, channel)
    url = "https://api.github.com/repos/%s/%s/releases/tags/%s" % (owner, repo, tag)
    return _http_get_json(
        url,
        timeout=30,
        insecure=bool(cfg.get("insecure_http", True)),
        cfg=cfg,
    )


def _content_base(cfg=None):
    """Root URL for relative package paths (http base or github raw base)."""
    cfg = cfg or load_config()
    if (cfg.get("source") or "http") == "github":
        mode = ((cfg.get("github") or {}).get("mode") or "raw").lower()
        if mode == "release":
            # relative urls still resolved via asset map; fallback raw base unused
            return github_raw_base(cfg)
        return github_raw_base(cfg)
    return (cfg.get("base_url") or "").rstrip("/")


def _resolve_package_url(pkg, cfg=None, release_assets=None):
    cfg = cfg or load_config()
    url = pkg.get("url") or ""
    if url.startswith("http://") or url.startswith("https://"):
        return url
    source = cfg.get("source") or "http"
    if source == "github":
        mode = ((cfg.get("github") or {}).get("mode") or "raw").lower()
        if mode == "release" and release_assets is not None:
            name = os.path.basename(url)
            asset = release_assets.get(name) or release_assets.get(url)
            if asset:
                return asset
            raise RuntimeError("GitHub Release 中找不到资源: %s" % name)
        return _resolve_url(github_raw_base(cfg), url)
    return _resolve_url(cfg.get("base_url") or "", url)


def _semver_tuple(s):
    raw = (s or "0").strip()
    for prefix in ("sys-", "mcu-", "plat-", "platform-", "factory-", "stack-"):
        if raw.startswith(prefix):
            raw = raw[len(prefix):]
            break
    core = raw.split("+")[0]
    # panel prerelease: 0.5.1-beta.1 → 0.5.1
    if "-" in core:
        left = core.split("-", 1)[0]
        if left[:1].isdigit() and "." in left:
            core = left
    parts = []
    for p in core.split("."):
        try:
            parts.append(int(p))
        except Exception:
            parts.append(0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


def _version_newer(remote, local):
    if not remote:
        return False
    if not local or local in (
        "—", "unknown", "mcu-unknown", "sys-none", "plat-none", "factory-none"
    ):
        return True
    if str(remote) == str(local):
        return False
    try:
        rt, lt = _semver_tuple(remote), _semver_tuple(local)
        n = max(len(rt), len(lt))
        rt = rt + (0,) * (n - len(rt))
        lt = lt + (0,) * (n - len(lt))
        if rt != lt:
            return rt > lt
        return str(remote) > str(local)
    except Exception:
        return str(remote) != str(local)


def fetch_manifest(cfg=None):
    cfg = cfg or load_config()
    channel = cfg.get("channel") or "stable"
    insecure = bool(cfg.get("insecure_http", True))
    source = cfg.get("source") or "http"
    last_err = None

    if source == "github":
        gh = cfg.get("github") or {}
        mode = (gh.get("mode") or "raw").lower()
        if mode == "release":
            try:
                rel = github_api_release(cfg, channel)
                assets = {
                    a.get("name"): a.get("browser_download_url")
                    for a in (rel.get("assets") or [])
                    if a.get("name") and a.get("browser_download_url")
                }
                # Prefer channel-named manifest asset, then manifest.json
                for name in (
                    "channels-%s.json" % channel,
                    "%s.json" % channel,
                    "manifest.json",
                    "manifest.%s.json" % channel,
                ):
                    if name in assets:
                        man = _http_get_json(
                            assets[name], timeout=30, insecure=insecure, cfg=cfg
                        )
                        man["_fetched_from"] = assets[name]
                        man["_release_assets"] = assets
                        man["_release_tag"] = rel.get("tag_name")
                        return man
                # body may embed JSON (advanced); else fail
                raise RuntimeError(
                    "Release %s 无 manifest 资源（需要 manifest.json 或 channels-%s.json）"
                    % (rel.get("tag_name"), channel)
                )
            except Exception as ex:
                last_err = ex
                # fall through to raw as backup
                LOG.warning("github release manifest failed: %s — try raw", ex)

        base = github_raw_base(cfg)
        candidates = [
            "%s/channels/%s.json" % (base, channel),
            "%s/manifest.json" % base,
        ]
    else:
        base = (cfg.get("base_url") or "").rstrip("/")
        candidates = [
            "%s/channels/%s.json" % (base, channel),
            "%s/manifest.json" % base,
        ]

    for url in candidates:
        try:
            man = _http_get_json(url, timeout=20, insecure=insecure, cfg=cfg)
            man["_fetched_from"] = url
            return man
        except Exception as ex:
            last_err = ex
            continue
    raise RuntimeError("manifest fetch failed: %s" % last_err)


def _version_label_from(local=None, available=None, man=None):
    local = local or load_versions()
    # Prefer panel semver for user-facing label
    if available:
        for kind in ("panel", "stack", "platform", "system", "mcu"):
            for p in available:
                if p.get("kind") == kind and p.get("version"):
                    return str(p.get("version"))
    if man and man.get("packages"):
        for kind in ("panel", "stack", "platform"):
            for p in man.get("packages") or []:
                if p.get("kind") == kind and p.get("version"):
                    return str(p.get("version"))
    return str(local.get("panel") or local.get("stack") or "")


def _pkg_allowed_on_channel(pkg, channel):
    """Daily channels never pull factory images; factory channel is opt-in only."""
    kind = (pkg.get("kind") or "").lower()
    if kind == "factory":
        return channel == "factory"
    if channel == "factory":
        return True
    return kind in ("panel", "stack", "system", "platform", "mcu")


def check_updates(cfg=None):
    cfg = cfg or load_config()
    _set_state(phase="checking", message="正在检查更新…", error="", progress=0.05)
    try:
        man = fetch_manifest(cfg)
    except Exception as ex:
        _set_state(phase="idle", message="", error=str(ex), progress=0,
                   update_available=False, notes="")
        return {"ok": False, "error": str(ex), "available": [],
                "update_available": False, "notes": ""}

    if man.get("firmware_target") != cfg.get("firmware_target", FIRMWARE_TARGET):
        err = "机型不匹配"
        _set_state(phase="idle", error=err, progress=0, update_available=False)
        return {"ok": False, "error": err, "available": [],
                "update_available": False, "notes": ""}

    channel = man.get("channel") or cfg.get("channel") or "stable"
    local = load_versions()
    available = []
    for pkg in man.get("packages") or []:
        kind = pkg.get("kind")
        if not _pkg_allowed_on_channel(pkg, channel):
            continue
        ver = pkg.get("version")
        cur = local.get(kind, "")
        if _version_newer(ver, cur):
            item = dict(pkg)
            item["local_version"] = cur
            item["update"] = True
            available.append(item)

    notes = (man.get("notes") or "").strip()
    label = _version_label_from(local, available, man)
    has = len(available) > 0
    _set_state(
        phase="idle",
        message="已是最新" if not has else "发现新版本",
        error="",
        progress=0,
        last_check=_utc_now(),
        available=available,
        notes=notes,
        update_available=has,
        version_label=label,
        release_assets=man.get("_release_assets"),
    )
    return {
        "ok": True,
        "channel": channel,
        "published_at": man.get("published_at"),
        "notes": notes,
        "update_available": has,
        "version_label": label,
        "local_version": str(local.get("panel") or ""),
        "components": component_versions_summary(local),
        # keep available for engine; UI must not list packages
        "available": available,
        "manifest_url": man.get("_fetched_from"),
        "source": cfg.get("source") or "http",
    }


def status_payload():
    cfg = load_config()
    st = get_runtime_state()
    gh = cfg.get("github") or {}
    px = cfg.get("proxy") or {}
    return {
        "ok": True,
        "product": cfg.get("product"),
        "firmware_target": cfg.get("firmware_target"),
        "channel": cfg.get("channel"),
        "source": cfg.get("source") or "http",
        "base_url": cfg.get("base_url"),
        "github": {
            "owner": gh.get("owner"),
            "repo": gh.get("repo"),
            "ref": gh.get("ref"),
            "mode": gh.get("mode"),
            "path_prefix": gh.get("path_prefix"),
            "repo_slug": "%s/%s" % (gh.get("owner") or "", gh.get("repo") or ""),
        },
        "proxy": {
            "enabled": bool(px.get("enabled")),
            "url": px.get("url") or "",
            "github_mirror": px.get("github_mirror") or "",
        },
        "versions": load_versions(),
        "components": component_versions_summary(),
        "disk_free_mb": disk_free_mb(),
        "print_busy": moonraker_print_busy(),
        "busy": st.get("busy"),
        "phase": st.get("phase"),
        "progress": st.get("progress"),
        "message": st.get("message"),
        "error": st.get("error"),
        "current_package": st.get("current_package"),
        "last_check": st.get("last_check"),
        "available": st.get("available") or [],
        "update_available": bool(st.get("update_available")),
        "notes": st.get("notes") or "",
        "version_label": st.get("version_label") or str((load_versions() or {}).get("panel") or ""),
        "confirm_mcu": st.get("confirm_mcu"),
        "history": history_list(10),
        "channels_ui": list(DAILY_CHANNELS),
    }


def set_channel(channel):
    # UI exposes only daily channels; factory is API/opt-in for service tools.
    if channel not in ALL_CHANNELS:
        return {"ok": False, "error": "bad channel"}
    cfg = save_config({"channel": channel})
    return {"ok": True, "channel": cfg["channel"]}


def set_source(source):
    if source not in ("http", "github"):
        return {"ok": False, "error": "bad source (http|github)"}
    cfg = save_config({"source": source})
    return {
        "ok": True,
        "source": cfg.get("source"),
        "base_url": cfg.get("base_url"),
        "github": status_payload().get("github"),
    }


def set_proxy(enabled=None, url=None, github_mirror=None):
    patch = {"proxy": {}}
    if enabled is not None:
        patch["proxy"]["enabled"] = bool(enabled)
    if url is not None:
        patch["proxy"]["url"] = str(url).strip()
    if github_mirror is not None:
        patch["proxy"]["github_mirror"] = str(github_mirror).strip()
    if not patch["proxy"]:
        return {"ok": False, "error": "empty proxy patch"}
    cfg = save_config(patch)
    px = cfg.get("proxy") or {}
    return {
        "ok": True,
        "proxy": {
            "enabled": bool(px.get("enabled")),
            "url": px.get("url") or "",
            "github_mirror": px.get("github_mirror") or "",
        },
    }


def _backup_kind(kind, version):
    os.makedirs(BACKUP, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    name = "%s-%s-%s.tar" % (kind, version or "unknown", stamp)
    path = os.path.join(BACKUP, name)
    if kind == "panel":
        with tarfile.open(path, "w") as tar:
            for rel in ("qml", "scripts", "bin", "VERSION", "ota/versions.json"):
                full = os.path.join(PANEL_ROOT, rel)
                if os.path.exists(full):
                    tar.add(full, arcname=rel)
    elif kind == "stack":
        # backup macros we manage + live printer.cfg + versions marker
        with tarfile.open(path, "w") as tar:
            for rel in (
                "/home/pi/printer_data/config/ncpsky_calib.cfg",
                "/home/pi/printer_data/config/tmc_autotune.cfg",
                PRINTER_CFG_LIVE,
                VERSIONS_PATH,
            ):
                if os.path.exists(rel):
                    tar.add(rel, arcname=os.path.basename(rel))
    elif kind == "platform":
        with tarfile.open(path, "w") as tar:
            for rel in (
                "/home/pi/qt/out_linux/startboot.sh",
                VERSIONS_PATH,
            ):
                if os.path.exists(rel):
                    tar.add(rel, arcname=os.path.basename(rel))
    elif kind == "mcu":
        src = "/home/pi/klipper/out/klipper.bin"
        if os.path.exists(src):
            with tarfile.open(path, "w") as tar:
                tar.add(src, arcname="klipper.bin")
        else:
            # empty marker
            with tarfile.open(path, "w") as tar:
                info = tarfile.TarInfo(name="EMPTY")
                info.size = 0
                tar.addfile(info)
    else:
        with tarfile.open(path, "w") as tar:
            if os.path.exists(VERSIONS_PATH):
                tar.add(VERSIONS_PATH, arcname="versions.json")

    # prune old backups for kind
    cfg = load_config()
    keep = int(cfg.get("backup_keep") or 2)
    files = sorted(
        [os.path.join(BACKUP, f) for f in os.listdir(BACKUP) if f.startswith(kind + "-")],
        key=os.path.getmtime,
        reverse=True,
    )
    for old in files[keep:]:
        try:
            os.remove(old)
        except Exception:
            pass
    return path


def list_backups():
    _ensure_dirs()
    out = []
    for f in sorted(os.listdir(BACKUP), reverse=True):
        if not f.endswith(".tar"):
            continue
        full = os.path.join(BACKUP, f)
        out.append({
            "name": f,
            "path": full,
            "size": os.path.getsize(full),
            "mtime": int(os.path.getmtime(full)),
        })
    return out


def rollback(kind=None, backup_name=None):
    """Restore last backup for kind (panel/stack/mcu)."""
    if moonraker_print_busy():
        return {"ok": False, "error": "打印中禁止回滚"}
    backups = list_backups()
    if backup_name:
        match = [b for b in backups if b["name"] == backup_name]
    elif kind:
        match = [b for b in backups if b["name"].startswith(kind + "-")]
    else:
        match = backups
    if not match:
        return {"ok": False, "error": "没有可回滚备份"}
    b = match[0]
    path = b["path"]
    kind_guess = b["name"].split("-", 1)[0]
    try:
        if kind_guess == "panel":
            with tarfile.open(path, "r") as tar:
                tar.extractall(PANEL_ROOT)
            _restart_panel()
        elif kind_guess == "stack":
            with tarfile.open(path, "r") as tar:
                for m in tar.getmembers():
                    if m.name.endswith(".cfg"):
                        dest = os.path.join("/home/pi/printer_data/config", os.path.basename(m.name))
                        f = tar.extractfile(m)
                        if f:
                            with open(dest, "wb") as out:
                                out.write(f.read())
            _firmware_restart()
        elif kind_guess == "mcu":
            with tarfile.open(path, "r") as tar:
                for m in tar.getmembers():
                    if m.name == "klipper.bin":
                        f = tar.extractfile(m)
                        if f:
                            os.makedirs("/home/pi/klipper/out", exist_ok=True)
                            with open("/home/pi/klipper/out/klipper.bin", "wb") as out:
                                out.write(f.read())
        _append_history({
            "ts": _utc_now(),
            "action": "rollback",
            "backup": b["name"],
            "ok": True,
        })
        return {"ok": True, "restored": b["name"]}
    except Exception as ex:
        return {"ok": False, "error": str(ex)}


def _download_package(pkg, cfg, release_assets=None, progress=0.15):
    url = _resolve_package_url(pkg, cfg, release_assets=release_assets)
    _set_state(phase="download", message="正在下载更新…", progress=progress,
               current_package=None)
    data = _http_get_bytes(
        url, timeout=300, insecure=bool(cfg.get("insecure_http", True)), cfg=cfg
    )
    digest = sha256_bytes(data)
    expect = (pkg.get("sha256") or "").lower()
    # allow all-zero placeholder only for local dry-run — reject otherwise
    if expect and expect != "0" * 64 and digest.lower() != expect:
        raise RuntimeError("更新包校验失败")
    free = disk_free_mb()
    need = int(pkg.get("min_free_mb") or 50)
    if free < need:
        raise RuntimeError("磁盘空间不足，请清理后重试")
    dest = os.path.join(STAGING, os.path.basename(pkg.get("url") or pkg["id"]))
    with open(dest, "wb") as f:
        f.write(data)
    return dest, digest


def _ensure_panel_exec_bits(panel_root):
    """Force +x on launchers after zip install (Windows-built zips lose mode)."""
    targets = []
    scripts = os.path.join(panel_root, "scripts")
    bindir = os.path.join(panel_root, "bin")
    if os.path.isdir(scripts):
        for fn in os.listdir(scripts):
            if fn.endswith((".sh", ".py")):
                targets.append(os.path.join(scripts, fn))
    if os.path.isdir(bindir):
        for fn in os.listdir(bindir):
            targets.append(os.path.join(bindir, fn))
    for path in targets:
        try:
            if not os.path.isfile(path):
                continue
            mode = os.stat(path).st_mode
            os.chmod(path, mode | 0o111)
        except Exception as exc:
            LOG.warning("chmod +x failed %s: %s", path, exc)


def _write_startboot_wrapper():
    """Keep /home/pi/qt/out_linux/startboot.sh calling bash run_panel.sh.

    This path is outside the panel tree and is what /etc/monitor restarts.
    Invoking via bash means a 0644 run_panel.sh cannot brick the splash.
    """
    path = "/home/pi/qt/out_linux/startboot.sh"
    body = (
        "#!/bin/bash\n"
        "# NCPSKY panel boot — bash invoke (OTA +x loss safe)\n"
        "export HOME=/home/pi\n"
        "cd /home/pi/qt/out_linux || true\n"
        "pkill -x TUI 2>/dev/null || true\n"
        "exec bash /home/pi/ncpsky-panel/scripts/run_panel.sh\n"
    )
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8", newline="\n") as f:
            f.write(body)
        os.chmod(path, 0o755)
        LOG.info("rewrote startboot wrapper %s", path)
    except Exception as exc:
        LOG.warning("startboot rewrite failed: %s", exc)


def _install_panel(pkg, archive_path, do_restart=False):
    local_ver = load_versions().get("panel", "unknown")
    _backup_kind("panel", local_ver)
    _set_state(phase="install", message="正在安装更新…", progress=0.7)
    # Preserve user settings / proxy before tree replace
    saved = {}
    for rel in PERSIST_PANEL_FILES:
        full = os.path.join(PANEL_ROOT, rel)
        if os.path.isfile(full):
            with open(full, "rb") as f:
                saved[rel] = f.read()
    for rel in PERSIST_OTA_FILES:
        full = os.path.join(OTA_ROOT, rel)
        if os.path.isfile(full):
            with open(full, "rb") as f:
                saved["ota/" + rel] = f.read()

    tmp = tempfile.mkdtemp(prefix="ncpsky_panel_")
    try:
        with zipfile.ZipFile(archive_path, "r") as zf:
            zf.extractall(tmp)
        root = tmp
        nested = os.path.join(tmp, "ncpsky-panel")
        if os.path.isdir(nested):
            root = nested
        for name in os.listdir(root):
            if name in ("ota", "settings.json"):
                continue
            src = os.path.join(root, name)
            dst = os.path.join(PANEL_ROOT, name)
            if os.path.isdir(src):
                if os.path.exists(dst):
                    shutil.rmtree(dst)
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)
        # Merge non-secret defaults from zip ota/ (config.default etc.) without wiping user ota/
        ota_src = os.path.join(root, "ota")
        if os.path.isdir(ota_src):
            os.makedirs(OTA_ROOT, exist_ok=True)
            for fn in os.listdir(ota_src):
                if fn in PERSIST_OTA_FILES or fn in ("backup", "staging", "dist"):
                    continue
                s = os.path.join(ota_src, fn)
                d = os.path.join(OTA_ROOT, fn)
                if os.path.isdir(s):
                    continue
                shutil.copy2(s, d)
        ver_src = os.path.join(root, "VERSION")
        if os.path.exists(ver_src):
            shutil.copy2(ver_src, os.path.join(PANEL_ROOT, "VERSION"))
        # Restore persisted user data
        for rel, blob in saved.items():
            dest = os.path.join(PANEL_ROOT, rel)
            os.makedirs(os.path.dirname(dest) or PANEL_ROOT, exist_ok=True)
            with open(dest, "wb") as f:
                f.write(blob)
        # Zip extract often drops +x (esp. packages built on Windows).
        # Without run_panel.sh executable, monitor loops forever on splash.
        _ensure_panel_exec_bits(PANEL_ROOT)
        _write_startboot_wrapper()
        # OTA often runs as root via fileserver — keep launchers owned by pi
        try:
            subprocess.call(
                ["bash", "-lc",
                 "echo 1 | sudo -S chown -R pi:pi %s/scripts %s/bin %s/qml %s/VERSION "
                 "2>/dev/null || chown -R pi:pi %s/scripts %s/bin %s/qml %s/VERSION"
                 % ((PANEL_ROOT,) * 8)],
                timeout=30,
            )
        except Exception as exc:
            LOG.warning("chown panel failed: %s", exc)
        save_versions({"panel": pkg.get("version") or _read_panel_version()})
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    if do_restart:
        _set_state(progress=0.95, message="正在重启…")
        _restart_panel()


def _preserve_klippy_chelper():
    """Keep prebuilt c_helper.so usable after stack tree copy."""
    chelper = "/home/pi/klipper/klippy/chelper"
    so = os.path.join(chelper, "c_helper.so")
    try:
        subprocess.call(
            ["bash", "-lc",
             "echo 1 | sudo -S chown -R pi:pi /home/pi/klipper/klippy "
             "2>/dev/null || chown -R pi:pi /home/pi/klipper/klippy"],
            timeout=60,
        )
    except Exception as exc:
        LOG.warning("chown klippy failed: %s", exc)
    if not os.path.isfile(so):
        LOG.warning("c_helper.so missing after stack install: %s", so)
        return
    try:
        # Make .so newer than sources so Klippy skips on-device rebuild
        now = time.time()
        os.utime(so, (now, now))
        LOG.info("touched %s to skip chelper rebuild", so)
    except Exception as exc:
        LOG.warning("touch c_helper.so failed: %s", exc)


def _find_incoming_printer_cfg(root):
    """Locate OTA-managed printer.cfg baseline inside extracted stack zip."""
    candidates = (
        os.path.join(root, "config", "printer.cfg"),
        os.path.join(root, "config", "printer.cfg.ota"),
        os.path.join(root, "config_templates", "printer.cfg"),
        os.path.join(root, "config_templates", "printer.cfg.ota"),
        os.path.join(root, "macros", "printer.cfg.ota"),
    )
    for path in candidates:
        if os.path.isfile(path):
            return path
    return None


def _merge_live_printer_cfg(incoming_path):
    """Backup live printer.cfg and merge managed body + SAVE_CONFIG + identity."""
    scripts_dir = os.path.dirname(os.path.abspath(__file__))
    if scripts_dir not in sys.path:
        sys.path.insert(0, scripts_dir)
    from printer_cfg_merge import merge_printer_cfg_files  # local sibling module

    live = PRINTER_CFG_LIVE
    if not os.path.isfile(live):
        # First boot / missing — install baseline as-is (still no moonraker secrets)
        os.makedirs(os.path.dirname(live), exist_ok=True)
        shutil.copy2(incoming_path, live)
        LOG.info("installed baseline printer.cfg (no prior live file)")
        return live
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    bak = os.path.join(BACKUP, "printer.cfg.%s" % stamp)
    os.makedirs(BACKUP, exist_ok=True)
    keys = identity_keys_from_profile()
    merge_printer_cfg_files(
        live, incoming_path, dest_path=live, backup_path=bak, identity_keys=keys
    )
    LOG.info("merged printer.cfg (backup %s)", bak)
    return live


def _install_stack(pkg, archive_path, do_restart=False):
    local_ver = load_versions().get("stack", "unknown")
    _backup_kind("stack", local_ver)
    _set_state(phase="install", message="正在安装更新…", progress=0.65)
    tmp = tempfile.mkdtemp(prefix="ncpsky_stack_")
    try:
        with zipfile.ZipFile(archive_path, "r") as zf:
            zf.extractall(tmp)
        root = tmp
        for cand in ("stack", "ncpsky-stack"):
            if os.path.isdir(os.path.join(tmp, cand)):
                root = os.path.join(tmp, cand)
                break
        cfg_dst = "/home/pi/printer_data/config"
        os.makedirs(cfg_dst, exist_ok=True)
        for sub in ("macros", "config_templates", "config"):
            src_dir = os.path.join(root, sub)
            if not os.path.isdir(src_dir):
                continue
            for fn in os.listdir(src_dir):
                if not (fn.endswith(".cfg") or fn.endswith(".conf") or fn.endswith(".json")
                        or fn.endswith(".ota")):
                    continue
                # moonraker / secrets never overwritten by stack
                base = fn[:-4] if fn.endswith(".ota") else fn
                if base in SKIP_CONFIG_OVERWRITE or fn in SKIP_CONFIG_OVERWRITE:
                    continue
                if fn.startswith("printer-") or "password" in fn.lower():
                    continue
                # printer.cfg handled via merge below
                if base == "printer.cfg" or fn in ("printer.cfg", "printer.cfg.ota"):
                    continue
                shutil.copy2(os.path.join(src_dir, fn), os.path.join(cfg_dst, fn if not fn.endswith(".ota") else base))

        incoming_cfg = _find_incoming_printer_cfg(root)
        if incoming_cfg:
            try:
                _merge_live_printer_cfg(incoming_cfg)
            except Exception as ex:
                LOG.exception("printer.cfg merge failed")
                raise RuntimeError("printer.cfg 合并失败，已回滚：%s" % ex)

        for name, dest in (("klipper", "/home/pi/klipper"), ("moonraker", "/home/pi/moonraker")):
            src = os.path.join(root, name)
            if os.path.isdir(src):
                for item in os.listdir(src):
                    if item in (".git", "klippy-env", ".venv", "database", ".database"):
                        continue
                    s = os.path.join(src, item)
                    d = os.path.join(dest, item)
                    if os.path.isdir(s):
                        if os.path.exists(d):
                            shutil.rmtree(d)
                        shutil.copytree(s, d)
                    else:
                        shutil.copy2(s, d)
        # Stack zip often refreshes chelper sources with newer mtimes than c_helper.so.
        # Device has no libc headers → rebuild fails → Moonraker shows offline forever.
        _preserve_klippy_chelper()
        ver_patch = {"stack": pkg.get("version")}
        meta_path = os.path.join(root, "META.json")
        if os.path.exists(meta_path):
            try:
                meta = _load_json(meta_path, {})
                if meta.get("klipper_core"):
                    ver_patch["klipper_core"] = meta["klipper_core"]
                if meta.get("klipper_custom"):
                    ver_patch["klipper_custom"] = meta["klipper_custom"]
                if meta.get("mcu"):
                    ver_patch["mcu"] = meta["mcu"]
            except Exception:
                pass
        save_versions(ver_patch)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    if do_restart:
        _set_state(progress=0.9, message="正在重启…")
        restart = pkg.get("restart") or "klipper"
        if restart == "moonraker":
            _restart_service("moonraker")
        else:
            _firmware_restart()


def _parse_apt_list(text):
    pkgs = []
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        pkgs.append(line)
    return pkgs


def _sudo_bash(cmd, timeout=1800):
    try:
        subprocess.check_call(["sudo", "-n", "bash", "-lc", cmd], timeout=timeout)
    except Exception:
        subprocess.check_call(
            ["bash", "-lc", "echo 1 | sudo -S bash -lc %s" % json.dumps(cmd)],
            timeout=timeout,
        )


def _install_system(pkg, archive_path):
    """Install system kind: .list of apt pins, or tar/zip with packages.list + optional debs/."""
    _set_state(phase="install", message="安装系统包…", progress=0.55)
    path = archive_path
    lower = path.lower()
    pkgs = []
    deb_dir = None
    tmp = None
    try:
        if lower.endswith(".list") or lower.endswith(".txt"):
            with open(path, "r", encoding="utf-8") as f:
                pkgs = _parse_apt_list(f.read())
        else:
            tmp = tempfile.mkdtemp(prefix="ncpsky_sys_")
            if lower.endswith(".zip"):
                with zipfile.ZipFile(path, "r") as zf:
                    zf.extractall(tmp)
            else:
                # tar / tar.gz / tgz / system bundle
                with tarfile.open(path, "r:*") as tf:
                    tf.extractall(tmp)
            root = tmp
            for cand in ("system", "ncpsky-system"):
                if os.path.isdir(os.path.join(tmp, cand)):
                    root = os.path.join(tmp, cand)
                    break
            list_path = None
            for name in ("packages.list", "system.list", "apt.list"):
                p = os.path.join(root, name)
                if os.path.isfile(p):
                    list_path = p
                    break
            if list_path:
                with open(list_path, "r", encoding="utf-8") as f:
                    pkgs = _parse_apt_list(f.read())
            deb_cand = os.path.join(root, "debs")
            if os.path.isdir(deb_cand):
                deb_dir = deb_cand
            if not pkgs and not deb_dir:
                raise RuntimeError("system 包缺少 packages.list 或 debs/")

        if deb_dir:
            debs = sorted(
                os.path.join(deb_dir, f)
                for f in os.listdir(deb_dir)
                if f.endswith(".deb")
            )
            if debs:
                _set_state(message="安装离线 deb…", progress=0.6)
                quoted = " ".join("'%s'" % d.replace("'", "'\\''") for d in debs)
                _sudo_bash(
                    "DEBIAN_FRONTEND=noninteractive dpkg -i %s || "
                    "DEBIAN_FRONTEND=noninteractive apt-get install -f -y" % quoted,
                    timeout=1800,
                )

        if pkgs:
            _set_state(message="apt 安装系统依赖…", progress=0.7)
            _sudo_bash(
                "DEBIAN_FRONTEND=noninteractive apt-get update -y || true; "
                "DEBIAN_FRONTEND=noninteractive apt-get install -y --allow-downgrades %s"
                % " ".join(pkgs),
                timeout=1800,
            )

        if not pkgs and not deb_dir:
            raise RuntimeError("empty system package list")
        save_versions({"system": pkg.get("version")})
        _set_state(progress=0.9, message="系统包已安装")
    finally:
        if tmp:
            shutil.rmtree(tmp, ignore_errors=True)


def _install_platform(pkg, archive_path):
    """Install platform kind: Qt/tslib/fonts/boot hooks under mapped roots."""
    local_ver = load_versions().get("platform", "unknown")
    _backup_kind("platform", local_ver)
    _set_state(phase="install", message="安装平台运行时…", progress=0.58)
    tmp = tempfile.mkdtemp(prefix="ncpsky_plat_")
    try:
        lower = archive_path.lower()
        if lower.endswith(".zip"):
            with zipfile.ZipFile(archive_path, "r") as zf:
                zf.extractall(tmp)
        else:
            with tarfile.open(archive_path, "r:*") as tf:
                tf.extractall(tmp)
        root = tmp
        for cand in ("platform", "ncpsky-platform"):
            if os.path.isdir(os.path.join(tmp, cand)):
                root = os.path.join(tmp, cand)
                break
        meta = _load_json(os.path.join(root, "META.json"), {})
        # Default roots: files/ maps relative paths onto filesystem absolute prefixes
        mappings = meta.get("install_map") or {
            "qt": "/home/pi/qt",
            "tslib": "/usr/local/tslib",
            "fonts": "/usr/local/share/fonts/ncpsky",
            "hooks": "/home/pi/ncpsky-panel/ota/hooks",
            "sing-box": "/usr/local/bin",
            "etc": "/etc",
        }
        files_root = os.path.join(root, "files")
        if not os.path.isdir(files_root):
            files_root = root
        for key, dest_root in mappings.items():
            src = os.path.join(files_root, key)
            if not os.path.isdir(src):
                continue
            os.makedirs(dest_root, exist_ok=True)
            for dirpath, _dirnames, filenames in os.walk(src):
                rel = os.path.relpath(dirpath, src)
                out_dir = dest_root if rel == "." else os.path.join(dest_root, rel)
                os.makedirs(out_dir, exist_ok=True)
                for fn in filenames:
                    s = os.path.join(dirpath, fn)
                    d = os.path.join(out_dir, fn)
                    shutil.copy2(s, d)
                    # executables under hooks / bin keep +x
                    if key in ("hooks", "sing-box") or fn.endswith((".sh", ".py")):
                        try:
                            mode = os.stat(d).st_mode
                            os.chmod(d, mode | 0o111)
                        except Exception:
                            pass
        # Optional startboot rewrite if package ships flag
        if meta.get("rewrite_startboot", True):
            _write_startboot_wrapper()
        save_versions({"platform": pkg.get("version") or meta.get("version")})
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _install_factory(pkg, archive_path):
    """Factory channel only: apply image marker / wipe instructions (not daily OTA)."""
    cfg = load_config()
    if (cfg.get("channel") or "") != "factory":
        raise RuntimeError("factory 包仅在 factory 通道安装")
    _set_state(phase="install", message="执行出厂整包…", progress=0.5)
    tmp = tempfile.mkdtemp(prefix="ncpsky_factory_")
    try:
        lower = archive_path.lower()
        if lower.endswith(".zip"):
            with zipfile.ZipFile(archive_path, "r") as zf:
                zf.extractall(tmp)
        else:
            with tarfile.open(archive_path, "r:*") as tf:
                tf.extractall(tmp)
        root = tmp
        for cand in ("factory", "ncpsky-factory"):
            if os.path.isdir(os.path.join(tmp, cand)):
                root = os.path.join(tmp, cand)
                break
        meta = _load_json(os.path.join(root, "META.json"), {})
        wipe_save = bool(meta.get("wipe_save_config", False))
        # Prefer nested kinds if present (system/platform/stack/panel/mcu archives)
        nested = meta.get("apply_order") or [
            "system", "platform", "stack", "panel", "mcu"
        ]
        for kind in nested:
            nested_path = None
            for fn in os.listdir(root):
                if fn.startswith(kind + "-") or fn.startswith(kind + "."):
                    nested_path = os.path.join(root, fn)
                    break
            pkg_dir = os.path.join(root, kind)
            if nested_path is None and os.path.isdir(pkg_dir):
                # zip the dir on the fly? skip — expect archives
                continue
            if nested_path is None:
                continue
            sub = {"id": "%s-factory" % kind, "kind": kind, "version": pkg.get("version")}
            if kind == "system":
                _install_system(sub, nested_path)
            elif kind == "platform":
                _install_platform(sub, nested_path)
            elif kind == "stack":
                _install_stack(sub, nested_path, do_restart=False)
            elif kind == "panel":
                _install_panel(sub, nested_path, do_restart=False)
            elif kind == "mcu":
                _install_mcu(sub, nested_path, confirmed=True)
        if wipe_save and os.path.isfile(PRINTER_CFG_LIVE):
            # Strip SAVE_CONFIG only when factory meta asks
            scripts_dir = os.path.dirname(os.path.abspath(__file__))
            if scripts_dir not in sys.path:
                sys.path.insert(0, scripts_dir)
            from printer_cfg_merge import strip_save_config
            with open(PRINTER_CFG_LIVE, "r", encoding="utf-8", errors="replace") as f:
                body = strip_save_config(f.read())
            with open(PRINTER_CFG_LIVE, "w", encoding="utf-8", newline="\n") as f:
                f.write(body)
            LOG.warning("factory wiped SAVE_CONFIG from printer.cfg")
        # Optional full disk image path recorded for external flasher
        image = meta.get("disk_image") or ""
        image_path = os.path.join(root, image) if image else ""
        if image_path and os.path.isfile(image_path):
            dest = os.path.join(STAGING, os.path.basename(image_path))
            shutil.copy2(image_path, dest)
            LOG.info("factory disk image staged at %s (manual flash / next boot)", dest)
        save_versions({"factory": pkg.get("version") or meta.get("version")})
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _install_mcu(pkg, bin_path, confirmed=False):
    if not confirmed and not pkg.get("auto", False):
        _set_state(
            phase="await_mcu_confirm",
            message="等待确认刷写 MCU",
            progress=0.5,
            confirm_mcu=pkg,
        )
        return {"await_confirm": True}
    local_ver = load_versions().get("mcu", "unknown")
    _backup_kind("mcu", local_ver)
    _set_state(phase="install", message="刷写 MCU…", progress=0.6, confirm_mcu=None)
    os.makedirs("/home/pi/klipper/out", exist_ok=True)
    dest = "/home/pi/klipper/out/klipper.bin"
    shutil.copy2(bin_path, dest)
    # Prefer make flash if serial known
    serial = "/dev/serial/by-id/usb-1a86_USB_Serial-if00-port0"
    flash_ok = False
    err = ""
    try:
        # sdflash / make flash FLASH_DEVICE=
        r = subprocess.run(
            ["bash", "-lc",
             "cd /home/pi/klipper && make flash FLASH_DEVICE=%s" % serial],
            capture_output=True, text=True, timeout=300,
        )
        flash_ok = r.returncode == 0
        if not flash_ok:
            err = (r.stderr or r.stdout or "flash failed")[-500:]
    except Exception as ex:
        err = str(ex)
    if not flash_ok:
        # keep bin in place for manual retry
        raise RuntimeError("MCU 刷写失败: %s（bin 已保存至 %s）" % (err, dest))
    save_versions({"mcu": pkg.get("version")})
    _firmware_restart()
    return {"await_confirm": False}


def _restart_panel():
    # Prefer bash …/run_panel.sh so a 0644 script still starts after zip install.
    subprocess.Popen(
        ["bash", "-lc",
         "sleep 1; echo 1 | sudo -S killall -9 ncpsky-panel qmlscene 2>/dev/null; "
         "echo 1 | sudo -S rm -f /tmp/ncpsky-panel.lock; "
         "echo 1 | sudo -S bash -c "
         "'nohup bash /home/pi/ncpsky-panel/scripts/run_panel.sh "
         ">/tmp/ncpsky-panel.out 2>&1 &'"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )


def _restart_service(name):
    subprocess.call(
        ["bash", "-lc", "echo 1 | sudo -S systemctl restart %s" % name],
        timeout=60,
    )


def _firmware_restart():
    try:
        data = json.dumps({}).encode()
        req = Request(
            MOONRAKER + "/printer/firmware_restart",
            data=data,
            method="POST",
            headers={"Content-Type": "application/json"},
        )
        urlopen(req, timeout=30).read()
    except Exception:
        _restart_service("klipper")


def _reboot_device():
    """Full reboot after OTA so panel + Klipper come up cleanly."""
    subprocess.Popen(
        ["bash", "-lc", "sleep 2; echo 1 | sudo -S reboot"],
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
    )


def cleanup_after_update(marker=None):
    """Clear staging / old backups / qmlc / update history after successful OTA reboot."""
    marker = marker or PENDING_CLEANUP
    info = _load_json(marker, {}) if os.path.isfile(marker) else {}
    # staging downloads
    if os.path.isdir(STAGING):
        for fn in os.listdir(STAGING):
            try:
                os.remove(os.path.join(STAGING, fn))
            except Exception:
                pass
    # OTA backups created during this update (keep none — user asked to clear)
    if os.path.isdir(BACKUP):
        for fn in list(os.listdir(BACKUP)):
            try:
                os.remove(os.path.join(BACKUP, fn))
            except Exception:
                pass
    # update engine history (not print history)
    try:
        _save_json(HISTORY_PATH, [])
    except Exception:
        pass
    # compiled qml / pycache under panel
    for root, dirs, files in os.walk(PANEL_ROOT):
        rel = os.path.relpath(root, PANEL_ROOT).replace("\\", "/")
        if rel.startswith("ota/backup") or rel.startswith("ota/staging"):
            continue
        if os.path.basename(root) == "__pycache__":
            shutil.rmtree(root, ignore_errors=True)
            dirs[:] = []
            continue
        for fn in files:
            if fn.endswith((".qmlc", ".jsc", ".pyc")):
                try:
                    os.remove(os.path.join(root, fn))
                except Exception:
                    pass
    try:
        if os.path.isfile(marker):
            os.remove(marker)
    except Exception:
        pass
    LOG.info("OTA cleanup done marker=%s", info)
    return {"ok": True, "cleaned": True}


def maybe_run_pending_cleanup():
    if os.path.isfile(PENDING_CLEANUP):
        try:
            return cleanup_after_update(PENDING_CLEANUP)
        except Exception as ex:
            LOG.exception("pending cleanup failed: %s", ex)
            return {"ok": False, "error": str(ex)}
    return {"ok": True, "cleaned": False}


def _mark_pending_cleanup(pkgs):
    _save_json(PENDING_CLEANUP, {
        "ts": _utc_now(),
        "packages": [p.get("id") for p in pkgs],
        "versions": load_versions(),
    })


def _kind_order(kind):
    # system → platform → stack(cfg merge) → panel → mcu; factory last if present
    order = {
        "system": 0,
        "platform": 1,
        "stack": 2,
        "panel": 3,
        "mcu": 4,
        "factory": 5,
    }
    return order.get(kind, 9)


def _run_upgrade_job(package_ids, confirm_mcu=False):
    cfg = load_config()
    st = get_runtime_state()
    available = {p.get("id"): p for p in (st.get("available") or [])}
    if not available:
        chk = check_updates(cfg)
        if not chk.get("ok"):
            _set_state(busy=False, phase="idle", error=chk.get("error") or "检查更新失败",
                       update_available=False)
            return
        available = {p.get("id"): p for p in (chk.get("available") or [])}

    # Empty / ["all"] → update every available package together
    if not package_ids or package_ids == ["all"] or package_ids == "all":
        pkgs = list(available.values())
    else:
        pkgs = []
        for pid in package_ids:
            if isinstance(pid, dict):
                pkgs.append(pid)
            elif pid in available:
                pkgs.append(available[pid])

    pkgs = sorted(pkgs, key=lambda p: _kind_order(p.get("kind")))
    if not pkgs:
        _set_state(busy=False, phase="idle", error="当前已是最新版本", update_available=False)
        return

    if moonraker_print_busy():
        _set_state(busy=False, phase="idle", error="打印中不可更新")
        return

    release_assets = st.get("release_assets")
    _set_state(busy=True, error="", progress=0.05, message="正在准备更新…", phase="download")
    try:
        # 1) Download all first
        downloaded = []
        n = max(1, len(pkgs))
        for i, pkg in enumerate(pkgs):
            if pkg.get("requires_idle", True) and moonraker_print_busy():
                raise RuntimeError("打印中不可更新")
            prog = 0.08 + 0.42 * (i / float(n))
            path, digest = _download_package(
                pkg, cfg, release_assets=release_assets, progress=prog
            )
            downloaded.append((pkg, path, digest))
            _set_state(progress=0.08 + 0.42 * ((i + 1) / float(n)),
                       message="正在下载更新…")

        # 2) Install all without mid-flight UI restart (avoids frozen/blank panel)
        for i, (pkg, path, digest) in enumerate(downloaded):
            kind = pkg.get("kind")
            prog = 0.55 + 0.35 * (i / float(n))
            _set_state(progress=prog, phase="install", message="正在安装更新…")
            if kind == "panel":
                _install_panel(pkg, path, do_restart=False)
            elif kind == "stack":
                _install_stack(pkg, path, do_restart=False)
            elif kind == "system":
                _install_system(pkg, path)
            elif kind == "platform":
                _install_platform(pkg, path)
            elif kind == "factory":
                _install_factory(pkg, path)
            elif kind == "mcu":
                # Full-bundle update: user already confirmed dialog → flash without second prompt
                res = _install_mcu(pkg, path, confirmed=True)
                if res and res.get("await_confirm"):
                    # Should not happen with confirmed=True
                    pass
            else:
                raise RuntimeError("不支持的更新类型: %s" % kind)
            _append_history({
                "ts": _utc_now(),
                "action": "upgrade",
                "package": pkg.get("id"),
                "kind": kind,
                "version": pkg.get("version"),
                "sha256": digest,
                "ok": True,
            })

        _mark_pending_cleanup([p for p, _, _ in downloaded])
        _set_state(
            busy=True,
            phase="rebooting",
            progress=1.0,
            message="更新完成，正在重启…",
            current_package=None,
            update_available=False,
            available=[],
        )
        _reboot_device()
    except Exception as ex:
        LOG.exception("upgrade failed")
        _append_history({
            "ts": _utc_now(),
            "action": "upgrade",
            "ok": False,
            "error": str(ex),
        })
        _set_state(busy=False, phase="error", error=str(ex), progress=0, message="")


def start_upgrade(packages=None, confirm_mcu=False):
    st = get_runtime_state()
    if st.get("busy"):
        return {"ok": False, "error": "正在更新，请稍候"}
    if moonraker_print_busy():
        return {"ok": False, "error": "打印中不可更新"}
    ids = packages if packages is not None else ["all"]
    if ids == []:
        ids = ["all"]
    t = threading.Thread(target=_run_upgrade_job, args=(ids, confirm_mcu), daemon=True)
    t.start()
    return {"ok": True, "started": True}


def start_upgrade_all():
    """Consumer path: update every available package, then reboot."""
    return start_upgrade(["all"], confirm_mcu=True)


def confirm_mcu_flash():
    st = get_runtime_state()
    pkg = st.get("confirm_mcu")
    if not pkg:
        return {"ok": False, "error": "没有待确认的更新"}
    return start_upgrade([pkg], confirm_mcu=True)


# init on import
try:
    _ensure_dirs()
    maybe_run_pending_cleanup()
except Exception:
    pass
