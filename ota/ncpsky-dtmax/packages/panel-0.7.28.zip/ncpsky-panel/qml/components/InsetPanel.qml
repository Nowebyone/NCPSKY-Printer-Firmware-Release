import QtQuick 2.15
import ".."

// Recessed surface: dark well + top hairline highlight
Item {
    id: root
    default property alias contentData: host.data

    Rectangle {
        anchors.fill: parent
        radius: Theme.radiusLg
        color: "#0B0C0E"
    }
    Rectangle {
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.margins: 1
        height: 1
        color: "#22262C"
        opacity: 0.95
    }
    Rectangle {
        anchors.fill: parent
        anchors.margins: 1
        anchors.topMargin: 2
        radius: Theme.radiusLg - 1
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#121418" }
            GradientStop { position: 1.0; color: "#0E1013" }
        }
    }
    Item {
        id: host
        anchors.fill: parent
        // Keep child tiles/buttons from painting outside rounded well (linuxfb speckles)
        clip: true
    }
}
