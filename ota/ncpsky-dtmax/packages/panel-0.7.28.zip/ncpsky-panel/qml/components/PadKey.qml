import QtQuick 2.15
import ".."

Item {
    id: key
    property string text: ""
    property bool primary: false
    signal clicked()

    width: 44
    height: 40

    Rectangle {
        anchors.fill: parent
        radius: Theme.radius
        color: touch.pressed ? Theme.bgTilePressed : (key.primary ? Theme.accentSoft : Theme.bgTile)
    }
    Text {
        anchors.centerIn: parent
        text: key.text
        color: key.primary ? Theme.accent : Theme.textPrimary
        font.pixelSize: 13
        font.family: Theme.fontFamily
        font.weight: Theme.fontWeight
    }
    TouchArea {
        id: touch
        // Expand hit box beyond visual bounds (password / dense pads)
        anchors.fill: parent
        anchors.margins: -5
        onClicked: key.clicked()
    }
}
