import QtQuick 2.15
import ".."

// Bottom-sheet keyboard for 480×272 content (~248px under TopBar).
// Keys size from remaining height so nothing is clipped; hit boxes stay large.
Item {
    id: kb
    anchors.fill: parent
    visible: open
    z: 200

    property bool open: false
    property string title: ""
    property string text: ""
    property bool password: false
    property bool numeric: false
    property bool shift: false

    property var _rowsLower: [
        ["1","2","3","4","5","6","7","8","9","0"],
        ["q","w","e","r","t","y","u","i","o","p"],
        ["a","s","d","f","g","h","j","k","l"],
        ["z","x","c","v","b","n","m",".","/",":"]
    ]
    property var _rowsUpper: [
        ["!","@","#","$","%","^","&","*","(",")"],
        ["Q","W","E","R","T","Y","U","I","O","P"],
        ["A","S","D","F","G","H","J","K","L"],
        ["Z","X","C","V","B","N","M","-","_","="]
    ]
    property var _rowsNum: [
        ["1","2","3"],
        ["4","5","6"],
        ["7","8","9"],
        [".","0","⌫"]
    ]

    // Dynamic key height from leftover space (header 28 + field 32 + gaps)
    readonly property int _headerH: 28
    readonly property int _fieldH: 32
    readonly property int _chrome: 6 + 6 + _headerH + 4 + _fieldH + 4  // margins + gaps
    readonly property int _keyRows: numeric ? 4 : 5
    readonly property int _rowGap: numeric ? 5 : 3
    readonly property int keyH: {
        var avail = Math.max(80, height - _chrome)
        var gaps = (_keyRows - 1) * _rowGap
        return Math.max(28, Math.min(44, Math.floor((avail - gaps) / _keyRows)))
    }

    signal accepted(string value)
    signal cancelled()

    function show(opts) {
        opts = opts || {}
        title = opts.title || ""
        text = opts.text || ""
        password = !!opts.password
        numeric = !!opts.numeric
        shift = false
        open = true
        AppState.pageLocked = true
    }

    function hide(commit) {
        open = false
        AppState.pageLocked = AppState.otaBusy || !!AppState.otaConfirmMcu
        if (commit)
            accepted(text)
        else
            cancelled()
    }

    function _append(ch) {
        if (ch === "⌫") {
            if (text.length)
                text = text.substring(0, text.length - 1)
            return
        }
        text = text + ch
    }

    Rectangle {
        anchors.fill: parent
        color: "#E0080A0B"
        MouseArea {
            anchors.fill: parent
            onClicked: { /* swallow */ }
        }
    }

    Rectangle {
        id: card
        anchors.fill: parent
        color: Theme.bgElevated
        border.width: 1
        border.color: Theme.line

        Column {
            anchors.fill: parent
            anchors.leftMargin: 6
            anchors.rightMargin: 6
            anchors.topMargin: 6
            anchors.bottomMargin: 6
            spacing: 4

            Row {
                width: parent.width
                height: kb._headerH
                spacing: 6
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: kb.title
                    color: Theme.textPrimary
                    font.pixelSize: Theme.fontBody
                    font.family: Theme.fontFamily
                    font.weight: Theme.fontWeight
                    width: parent.width - 128
                    elide: Text.ElideRight
                }
                PrimaryButton {
                    anchors.verticalCenter: parent.verticalCenter
                    text: AppState.tr("kb.cancel")
                    primary: false
                    height: kb._headerH
                    width: 58
                    onClicked: kb.hide(false)
                }
                PrimaryButton {
                    anchors.verticalCenter: parent.verticalCenter
                    text: AppState.tr("kb.ok")
                    height: kb._headerH
                    width: 58
                    onClicked: kb.hide(true)
                }
            }

            Rectangle {
                width: parent.width
                height: kb._fieldH
                radius: Theme.radius
                color: Theme.bg
                border.width: 1
                border.color: Theme.line
                Text {
                    anchors.fill: parent
                    anchors.margins: 8
                    text: kb.password
                          ? (kb.text.length ? Array(Math.min(kb.text.length, 32) + 1).join("•") : AppState.tr("kb.placeholder"))
                          : (kb.text.length ? kb.text : AppState.tr("kb.placeholder"))
                    color: kb.text.length ? Theme.textPrimary : Theme.textMute
                    font.pixelSize: Theme.fontBody
                    elide: Text.ElideLeft
                    verticalAlignment: Text.AlignVCenter
                }
            }

            // —— Numeric pad ——
            Column {
                width: parent.width
                spacing: kb._rowGap
                visible: kb.numeric
                Repeater {
                    model: kb._rowsNum
                    Row {
                        property var rowKeys: modelData
                        spacing: 6
                        anchors.horizontalCenter: parent.horizontalCenter
                        Repeater {
                            model: rowKeys
                            PadKey {
                                text: modelData
                                width: Math.floor((card.width - 28) / 3)
                                height: kb.keyH
                                primary: modelData === "⌫"
                                onClicked: kb._append(modelData)
                            }
                        }
                    }
                }
            }

            // —— QWERTY ——
            Column {
                width: parent.width
                spacing: kb._rowGap
                visible: !kb.numeric
                Repeater {
                    model: kb.shift ? kb._rowsUpper : kb._rowsLower
                    Row {
                        property var rowKeys: modelData
                        spacing: 3
                        anchors.horizontalCenter: parent.horizontalCenter
                        Repeater {
                            model: rowKeys
                            PadKey {
                                text: modelData
                                width: Math.max(28, Math.floor((card.width - 18 - (rowKeys.length - 1) * 3) / rowKeys.length))
                                height: kb.keyH
                                onClicked: kb._append(modelData)
                            }
                        }
                    }
                }
                Row {
                    spacing: 4
                    anchors.horizontalCenter: parent.horizontalCenter
                    PadKey {
                        text: kb.shift ? "abc" : "ABC"
                        width: 52
                        height: kb.keyH
                        primary: true
                        onClicked: kb.shift = !kb.shift
                    }
                    PadKey {
                        text: "空格"
                        width: Math.min(160, card.width - 148)
                        height: kb.keyH
                        onClicked: kb._append(" ")
                    }
                    PadKey {
                        text: "删"
                        width: 44
                        height: kb.keyH
                        primary: true
                        onClicked: {
                            if (kb.text.length)
                                kb.text = kb.text.substring(0, kb.text.length - 1)
                        }
                    }
                    PadKey {
                        text: "清"
                        width: 40
                        height: kb.keyH
                        onClicked: kb.text = ""
                    }
                }
            }
        }
    }
}
