import QtQuick 2.15
import ".."

Item {
    id: btn
    property string text: ""
    property bool active: false
    property bool danger: false
    property bool enabled: true
    signal clicked()

    width: Math.max(40, label.implicitWidth + 20)
    height: 34
    opacity: enabled ? 1 : 0.35

    Rectangle {
        anchors.fill: parent
        radius: Theme.radius
        color: {
            if (touch.pressed) return Theme.bgTilePressed
            if (danger && active) return Theme.danger
            if (active) return Theme.accentSoft
            return "transparent"
        }
        border.width: active ? 0 : 1
        border.color: Theme.line
    }
    Text {
        id: label
        anchors.centerIn: parent
        text: btn.text
        color: {
            if (danger && active) return "#fff"
            if (active) return Theme.accent
            return Theme.textSecondary
        }
        font.family: Theme.fontFamily
        font.pixelSize: Theme.fontBody
        font.weight: Theme.fontWeight
    }
    TouchArea {
        id: touch
        anchors.fill: parent
        enabled: btn.enabled
        onClicked: btn.clicked()
    }
}
