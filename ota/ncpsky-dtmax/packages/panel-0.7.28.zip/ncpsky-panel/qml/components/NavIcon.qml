import QtQuick 2.15
import ".."

Item {
    id: root
    property string name: "home"
    property color ink: Theme.textSecondary
    width: 22
    height: 22

    Canvas {
        id: c
        anchors.fill: parent
        onPaint: {
            var ctx = getContext("2d")
            ctx.reset()
            ctx.strokeStyle = root.ink
            ctx.fillStyle = root.ink
            ctx.lineWidth = 1.6
            ctx.lineCap = "round"
            ctx.lineJoin = "round"
            var w = width, h = height
            if (w < 4 || h < 4)
                return
            if (root.name === "home") {
                ctx.beginPath()
                ctx.moveTo(w * 0.5, h * 0.18)
                ctx.lineTo(w * 0.86, h * 0.48)
                ctx.lineTo(w * 0.86, h * 0.86)
                ctx.lineTo(w * 0.14, h * 0.86)
                ctx.lineTo(w * 0.14, h * 0.48)
                ctx.closePath()
                ctx.stroke()
                ctx.beginPath()
                ctx.rect(w * 0.38, h * 0.56, w * 0.24, h * 0.30)
                ctx.stroke()
            } else if (root.name === "device" || root.name === "controls") {
                // compact printer silhouette
                ctx.beginPath()
                ctx.rect(w * 0.22, h * 0.18, w * 0.56, h * 0.18)
                ctx.stroke()
                ctx.beginPath()
                ctx.moveTo(w * 0.30, h * 0.36)
                ctx.lineTo(w * 0.30, h * 0.78)
                ctx.lineTo(w * 0.70, h * 0.78)
                ctx.lineTo(w * 0.70, h * 0.36)
                ctx.stroke()
                ctx.beginPath()
                ctx.moveTo(w * 0.42, h * 0.48)
                ctx.lineTo(w * 0.58, h * 0.48)
                ctx.lineTo(w * 0.50, h * 0.66)
                ctx.closePath()
                ctx.stroke()
            } else if (root.name === "filament") {
                ctx.beginPath()
                ctx.arc(w * 0.5, h * 0.5, w * 0.34, 0, Math.PI * 2)
                ctx.stroke()
                ctx.beginPath()
                ctx.arc(w * 0.5, h * 0.5, w * 0.14, 0, Math.PI * 2)
                ctx.stroke()
            } else if (root.name === "calibrate") {
                // level: flat bar + center bubble (no crossed box)
                ctx.beginPath()
                ctx.moveTo(w * 0.16, h * 0.50)
                ctx.lineTo(w * 0.84, h * 0.50)
                ctx.stroke()
                ctx.beginPath()
                ctx.arc(w * 0.50, h * 0.50, w * 0.18, 0, Math.PI * 2)
                ctx.stroke()
                ctx.beginPath()
                ctx.arc(w * 0.50, h * 0.50, w * 0.06, 0, Math.PI * 2)
                ctx.fill()
            } else if (root.name === "settings") {
                ctx.beginPath()
                ctx.arc(w * 0.5, h * 0.5, w * 0.14, 0, Math.PI * 2)
                ctx.stroke()
                for (var i = 0; i < 6; i++) {
                    var a = i * Math.PI / 3
                    var x1 = w * 0.5 + Math.cos(a) * w * 0.24
                    var y1 = h * 0.5 + Math.sin(a) * h * 0.24
                    var x2 = w * 0.5 + Math.cos(a) * w * 0.40
                    var y2 = h * 0.5 + Math.sin(a) * h * 0.40
                    ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke()
                }
            } else if (root.name === "alerts" || root.name === "hms") {
                ctx.beginPath()
                ctx.moveTo(w * 0.5, h * 0.14)
                ctx.lineTo(w * 0.82, h * 0.78)
                ctx.lineTo(w * 0.18, h * 0.78)
                ctx.closePath()
                ctx.stroke()
                ctx.beginPath()
                ctx.moveTo(w * 0.5, h * 0.36); ctx.lineTo(w * 0.5, h * 0.56)
                ctx.stroke()
                ctx.beginPath()
                ctx.arc(w * 0.5, h * 0.68, 1.2, 0, Math.PI * 2)
                ctx.fill()
            }
        }
        onWidthChanged: requestPaint()
        onHeightChanged: requestPaint()
    }
    onInkChanged: c.requestPaint()
    onNameChanged: c.requestPaint()
    Component.onCompleted: c.requestPaint()
}
