import QtQuick 2.15
import "."
import "components"

Item {
    id: splash
    anchors.fill: parent
    // Keep visible through crossfade; finish() hides after opacity hits 0
    visible: true
    z: 1000
    opacity: 1
    scale: 1
    transformOrigin: Item.Center

    Rectangle {
        anchors.fill: parent
        color: "#040606"
    }

    // Same still as zzcat hold — fades to black before radar Splash starts
    Image {
        id: holdCover
        anchors.fill: parent
        source: Qt.resolvedUrl("../assets/boot_hold.png")
        fillMode: Image.PreserveAspectCrop
        opacity: 1
        z: 50
        asynchronous: false
        cache: true
    }

    Rectangle {
        id: wash
        width: 340
        height: 340
        radius: 170
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.verticalCenter: parent.verticalCenter
        anchors.verticalCenterOffset: -20
        color: Theme.accent
        opacity: 0
        scale: 0.35
    }

    Rectangle {
        id: cornerGlow
        width: 200
        height: 200
        radius: 100
        x: parent.width - 110
        y: -70
        color: Theme.accent
        opacity: 0
    }

    Canvas {
        id: field
        anchors.fill: parent
        opacity: 0
        onPaint: {
            var ctx = getContext("2d")
            ctx.reset()
            var w = width, h = height
            ctx.strokeStyle = "#A78BFA"
            ctx.lineWidth = 1
            ctx.globalAlpha = 0.10
            var i
            for (i = 0; i < 8; i++) {
                var y = 36 + (i / 7) * (h - 48)
                ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke()
            }
            for (i = 0; i < 11; i++) {
                var u = i / 10
                ctx.beginPath()
                ctx.moveTo(w * 0.5 + (u - 0.5) * w * 0.12, 32)
                ctx.lineTo(w * u, h)
                ctx.stroke()
            }
            ctx.globalAlpha = 0.20
            ctx.lineWidth = 1.4
            var cx = w * 0.5, cy = h * 0.38
            var pts = [[cx, cy - 58], [cx - 66, cy + 44], [cx + 66, cy + 44]]
            for (i = 0; i < 3; i++) {
                ctx.beginPath(); ctx.moveTo(pts[i][0], pts[i][1]); ctx.lineTo(cx, cy); ctx.stroke()
                ctx.beginPath(); ctx.arc(pts[i][0], pts[i][1], 3.2, 0, Math.PI * 2); ctx.stroke()
            }
            ctx.beginPath(); ctx.arc(cx, cy, 6.5, 0, Math.PI * 2); ctx.stroke()
        }
        Component.onCompleted: requestPaint()
        onWidthChanged: requestPaint()
        onHeightChanged: requestPaint()
    }

    Item {
        id: orbit
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.verticalCenter: parent.verticalCenter
        anchors.verticalCenterOffset: -36
        width: 128
        height: 128
        opacity: 0
        rotation: 0
        Rectangle {
            anchors.fill: parent
            radius: width / 2
            color: "transparent"
            border.width: 1
            border.color: "#2A6B45"
        }
        Rectangle {
            width: 6; height: 6; radius: 3
            color: Theme.accent
            anchors.horizontalCenter: parent.horizontalCenter
            anchors.top: parent.top
            anchors.topMargin: -2
        }
        Rectangle {
            width: 4; height: 4; radius: 2
            color: "#7CFFB0"
            anchors.verticalCenter: parent.verticalCenter
            anchors.right: parent.right
            anchors.rightMargin: -1
            opacity: 0.85
        }
    }

    Rectangle {
        id: ring0
        width: 58; height: 58; radius: 29
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.verticalCenter: parent.verticalCenter
        anchors.verticalCenterOffset: -36
        color: "transparent"
        border.width: 1
        border.color: Theme.accent
        opacity: 0
        scale: 0.55
    }
    Rectangle {
        id: ring1
        width: 86; height: 86; radius: 43
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.verticalCenter: parent.verticalCenter
        anchors.verticalCenterOffset: -36
        color: "transparent"
        border.width: 1
        border.color: Theme.accent
        opacity: 0
        scale: 0.55
    }
    Rectangle {
        id: ring2
        width: 118; height: 118; radius: 59
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.verticalCenter: parent.verticalCenter
        anchors.verticalCenterOffset: -36
        color: "transparent"
        border.width: 1
        border.color: Theme.accent
        opacity: 0
        scale: 0.55
    }

    Canvas {
        id: mark
        width: 54
        height: 48
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.verticalCenter: parent.verticalCenter
        anchors.verticalCenterOffset: -36
        opacity: 0
        scale: 0.2
        transformOrigin: Item.Center
        onPaint: {
            var ctx = getContext("2d")
            ctx.reset()
            var w = width, h = height
            ctx.fillStyle = "#A78BFA"
            ctx.beginPath()
            ctx.moveTo(w * 0.5, h * 0.08)
            ctx.lineTo(w * 0.92, h * 0.88)
            ctx.lineTo(w * 0.08, h * 0.88)
            ctx.closePath()
            ctx.fill()
            ctx.fillStyle = "#040606"
            ctx.beginPath()
            ctx.moveTo(w * 0.5, h * 0.32)
            ctx.lineTo(w * 0.72, h * 0.74)
            ctx.lineTo(w * 0.28, h * 0.74)
            ctx.closePath()
            ctx.fill()
        }
        Component.onCompleted: requestPaint()
    }

    Rectangle {
        id: sweep
        width: parent.width
        height: 3
        y: -6
        opacity: 0
        gradient: Gradient {
            orientation: Gradient.Horizontal
            GradientStop { position: 0.0; color: "transparent" }
            GradientStop { position: 0.35; color: Theme.accent }
            GradientStop { position: 0.5; color: "#E8FFE0" }
            GradientStop { position: 0.65; color: Theme.accent }
            GradientStop { position: 1.0; color: "transparent" }
        }
    }

    Column {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: parent.top
        anchors.topMargin: 168
        spacing: 5

        Text {
            id: brand
            anchors.horizontalCenter: parent.horizontalCenter
            text: "NCPSKY"
            color: Theme.textPrimary
            font.pixelSize: 30
            font.letterSpacing: 7
            font.family: Theme.fontFamily
            font.weight: Theme.fontWeight
            opacity: 0
        }

        Item {
            anchors.horizontalCenter: parent.horizontalCenter
            width: 120
            height: 8
            Rectangle {
                id: ruleGlow
                anchors.centerIn: parent
                width: rule.width + 18
                height: 8
                radius: 4
                color: Theme.accent
                opacity: 0
            }
            Rectangle {
                id: rule
                anchors.centerIn: parent
                width: 0
                height: 2
                radius: 1
                color: Theme.accent
            }
        }

        Text {
            id: model
            anchors.horizontalCenter: parent.horizontalCenter
            text: "DTMax"
            color: Theme.textSecondary
            font.pixelSize: 15
            font.letterSpacing: 4
            font.family: Theme.fontFamily
            font.weight: Theme.fontWeight
            opacity: 0
        }

        Text {
            id: tag
            anchors.horizontalCenter: parent.horizontalCenter
            text: "DELTA SERIES"
            color: Theme.textMute
            font.pixelSize: 9
            font.letterSpacing: 3.2
            font.family: Theme.fontFamily
            font.weight: Theme.fontWeight
            opacity: 0
        }
    }

    Item {
        id: rail
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.leftMargin: 28
        anchors.rightMargin: 28
        anchors.bottomMargin: 18
        height: 3
        opacity: 0
        Rectangle { anchors.fill: parent; radius: 1; color: "#1A2220" }
        Rectangle {
            id: railFill
            height: parent.height
            width: 0
            radius: 1
            color: Theme.accent
        }
        Rectangle {
            anchors.verticalCenter: parent.verticalCenter
            anchors.left: railFill.right
            anchors.leftMargin: -3
            width: 7
            height: 7
            radius: 3.5
            color: "#B6FFD0"
            opacity: railFill.width > 4 ? 0.95 : 0
        }
    }

    Text {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 5
        text: "TAP TO SKIP"
        color: Theme.textMute
        font.pixelSize: 9
        font.letterSpacing: 1.5
        font.family: Theme.fontFamily
        font.weight: Theme.fontWeight
        opacity: tag.opacity * 0.55
    }

    NumberAnimation {
        id: orbitSpin
        target: orbit
        property: "rotation"
        from: 0
        to: 360
        duration: 4200
        loops: Animation.Infinite
        running: splash.visible && !AppState.splashDone && holdCover.opacity < 0.05
    }

    // still → black → full radar Splash (original intro, unchanged after bridge)
    SequentialAnimation {
        id: intro
        running: true

        PauseAnimation { duration: 280 }
        NumberAnimation {
            target: holdCover
            property: "opacity"
            to: 0
            duration: 480
            easing.type: Easing.InOutCubic
        }
        PauseAnimation { duration: 180 }

        ParallelAnimation {
            NumberAnimation { target: wash; property: "opacity"; to: 0.13; duration: 480 }
            NumberAnimation { target: wash; property: "scale"; to: 1.08; duration: 780; easing.type: Easing.OutCubic }
            NumberAnimation { target: field; property: "opacity"; to: 1; duration: 520 }
            NumberAnimation { target: cornerGlow; property: "opacity"; to: 0.07; duration: 600 }
            NumberAnimation { target: orbit; property: "opacity"; to: 0.9; duration: 420 }
            NumberAnimation { target: rail; property: "opacity"; to: 1; duration: 300 }
        }

        ParallelAnimation {
            NumberAnimation { target: mark; property: "opacity"; to: 1; duration: 220 }
            NumberAnimation { target: mark; property: "scale"; to: 1.16; duration: 380; easing.type: Easing.OutBack }
            ScriptAction {
                script: {
                    ring0.opacity = 0.48; ring0.scale = 0.72
                    ring1.opacity = 0.34; ring1.scale = 0.72
                    ring2.opacity = 0.22; ring2.scale = 0.72
                    pulseGroup.start()
                }
            }
        }
        NumberAnimation { target: mark; property: "scale"; to: 1.0; duration: 140 }
        PauseAnimation { duration: 420 }

        ParallelAnimation {
            NumberAnimation { target: brand; property: "opacity"; to: 1; duration: 360 }
            NumberAnimation { target: sweep; property: "opacity"; to: 1; duration: 80 }
            NumberAnimation {
                target: sweep; property: "y"
                from: 24; to: 248
                duration: 560; easing.type: Easing.InOutQuad
            }
            NumberAnimation {
                target: railFill; property: "width"
                to: 424
                duration: 1100; easing.type: Easing.InOutCubic
            }
        }
        NumberAnimation { target: sweep; property: "opacity"; to: 0; duration: 160 }

        ParallelAnimation {
            NumberAnimation { target: rule; property: "width"; to: 88; duration: 320; easing.type: Easing.OutCubic }
            NumberAnimation { target: ruleGlow; property: "opacity"; to: 0.22; duration: 280 }
            NumberAnimation { target: model; property: "opacity"; to: 1; duration: 300 }
            NumberAnimation { target: tag; property: "opacity"; to: 1; duration: 360 }
        }
        NumberAnimation { target: ruleGlow; property: "opacity"; to: 0; duration: 280 }

        SequentialAnimation {
            NumberAnimation { target: mark; property: "opacity"; to: 0.78; duration: 180 }
            NumberAnimation { target: mark; property: "opacity"; to: 1.0; duration: 180 }
        }
        PauseAnimation { duration: 260 }

        ScriptAction { script: AppState.splashDone = true }

        ParallelAnimation {
            NumberAnimation { target: splash; property: "opacity"; to: 0; duration: 420; easing.type: Easing.InOutCubic }
            NumberAnimation { target: wash; property: "opacity"; to: 0; duration: 320 }
        }
        ScriptAction { script: splash.finish() }
    }

    ParallelAnimation {
        id: pulseGroup
        SequentialAnimation {
            ParallelAnimation {
                NumberAnimation { target: ring0; property: "scale"; to: 1.55; duration: 520; easing.type: Easing.OutCubic }
                NumberAnimation { target: ring0; property: "opacity"; to: 0; duration: 520 }
            }
        }
        SequentialAnimation {
            PauseAnimation { duration: 90 }
            ParallelAnimation {
                NumberAnimation { target: ring1; property: "scale"; to: 1.7; duration: 560; easing.type: Easing.OutCubic }
                NumberAnimation { target: ring1; property: "opacity"; to: 0; duration: 560 }
            }
        }
        SequentialAnimation {
            PauseAnimation { duration: 170 }
            ParallelAnimation {
                NumberAnimation { target: ring2; property: "scale"; to: 1.85; duration: 600; easing.type: Easing.OutCubic }
                NumberAnimation { target: ring2; property: "opacity"; to: 0; duration: 600 }
            }
        }
    }

    function finish() {
        intro.stop()
        orbitSpin.stop()
        pulseGroup.stop()
        holdCover.opacity = 0
        AppState.splashDone = true
        splash.visible = false
        splash.opacity = 1
        splash.scale = 1
        AppState.otaBootAutoCheck()
    }

    TouchArea {
        anchors.fill: parent
        onClicked: splash.finish()
    }
}
