import QtQuick 2.15
import "../components"
import ".."

Item {
    id: page

    Column {
        id: header
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: parent.top
        anchors.leftMargin: 12
        anchors.rightMargin: 12
        anchors.topMargin: 4
        spacing: 6

        Row {
            width: parent.width
            height: Theme.touchMin - 4
            PageHeader {
                title: "选择文件"
                subtitle: "点按即可开始打印"
                width: parent.width - 100
                anchors.verticalCenter: parent.verticalCenter
            }
            SegButton {
                anchors.verticalCenter: parent.verticalCenter
                text: "返回"
                height: 36
                onClicked: AppState.go("home")
            }
        }

        Row {
            width: parent.width
            height: 40
            spacing: 8

            Rectangle {
                width: (parent.width - 8) / 2
                height: parent.height
                radius: Theme.radius
                color: localTouch.pressed
                       ? Theme.bgTilePressed
                       : (AppState.fileSource === "local" ? Theme.accentSoft : "transparent")
                border.width: AppState.fileSource === "local" ? 0 : 1
                border.color: Theme.line
                Text {
                    anchors.centerIn: parent
                    text: "内置存储"
                    color: AppState.fileSource === "local" ? Theme.accent : Theme.textSecondary
                    font.family: Theme.fontFamily
                    font.pixelSize: Theme.fontBody
                    font.weight: Theme.fontWeight
                }
                TouchArea {
                    id: localTouch
                    anchors.fill: parent
                    onClicked: AppState.fileSource = "local"
                }
            }
            Rectangle {
                width: (parent.width - 8) / 2
                height: parent.height
                radius: Theme.radius
                color: usbTouch.pressed
                       ? Theme.bgTilePressed
                       : (AppState.fileSource === "usb" ? Theme.accentSoft : "transparent")
                border.width: AppState.fileSource === "usb" ? 0 : 1
                border.color: Theme.line
                Text {
                    anchors.centerIn: parent
                    text: "U盘"
                    color: AppState.fileSource === "usb" ? Theme.accent : Theme.textSecondary
                    font.family: Theme.fontFamily
                    font.pixelSize: Theme.fontBody
                    font.weight: Theme.fontWeight
                }
                TouchArea {
                    id: usbTouch
                    anchors.fill: parent
                    onClicked: {
                        AppState.fileSource = "usb"
                        AppState.refreshUsbFiles()
                    }
                }
            }
        }
    }

    ListView {
        id: list
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.top: header.bottom
        anchors.bottom: parent.bottom
        anchors.leftMargin: 12
        anchors.rightMargin: 12
        anchors.topMargin: 6
        clip: true
        interactive: true
        boundsBehavior: Flickable.StopAtBounds
        flickableDirection: Flickable.VerticalFlick
        model: AppState.fileSource === "usb" ? AppState.usbFiles : AppState.gcodeFiles
        spacing: 0

        delegate: Item {
            width: list.width
            height: Theme.touchMin
            readonly property string filePath: (typeof modelData === "string")
                                              ? modelData
                                              : (modelData.path || "")
            readonly property string fileName: (typeof modelData === "string")
                                              ? modelData
                                              : (modelData.name || modelData.path || "")
            readonly property string thumbUrl: (typeof modelData === "object" && modelData && modelData.thumb)
                                              ? modelData.thumb : ""

            Rectangle {
                anchors.fill: parent
                color: touch.pressed ? Theme.bgTilePressed : "transparent"
            }
            Rectangle {
                anchors.bottom: parent.bottom
                width: parent.width
                height: 1
                color: Theme.lineSoft
            }

            Rectangle {
                id: thumbBox
                anchors.left: parent.left
                anchors.leftMargin: 2
                anchors.verticalCenter: parent.verticalCenter
                width: 40
                height: 40
                radius: 4
                color: Theme.bgTile
                clip: true
                Image {
                    id: thumbImage
                    anchors.fill: parent
                    anchors.margins: 2
                    source: thumbUrl
                    fillMode: Image.PreserveAspectCrop
                    asynchronous: true
                    cache: true
                    visible: status === Image.Ready
                }
                Text {
                    anchors.centerIn: parent
                    visible: thumbImage.status !== Image.Ready
                    text: "#"
                    color: Theme.textMute
                    font.family: Theme.fontFamily
                    font.pixelSize: 14
                    font.weight: Theme.fontWeight
                }
            }

            Text {
                anchors.left: thumbBox.right
                anchors.leftMargin: 10
                anchors.verticalCenter: parent.verticalCenter
                width: parent.width - 56 - 52
                text: fileName
                color: Theme.textPrimary
                font.pixelSize: Theme.fontBody
                elide: Text.ElideMiddle
            }
            Text {
                anchors.right: parent.right
                anchors.verticalCenter: parent.verticalCenter
                text: "打印"
                color: Theme.accent
                font.pixelSize: Theme.fontSmall
                font.family: Theme.fontFamily
                font.weight: Theme.fontWeight
            }
            TouchArea {
                id: touch
                anchors.fill: parent
                // Let the list take a vertical drag; a tap still starts the print
                preventStealing: false
                onClicked: AppState.startPrint(filePath)
            }
        }

        Text {
            anchors.centerIn: parent
            visible: list.count === 0
            width: parent.width - 24
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.WordWrap
            text: {
                if (!AppState.connected)
                    return "设备未连接"
                if (AppState.fileSource === "usb")
                    return AppState.usbMessage.length ? AppState.usbMessage : "未检测到 U 盘"
                return "还没有可打印文件"
            }
            color: Theme.textMute
            font.pixelSize: Theme.fontBody
        }
    }

    onVisibleChanged: {
        if (visible)
            AppState.refreshFiles()
    }
    Component.onCompleted: AppState.refreshFiles()
}
