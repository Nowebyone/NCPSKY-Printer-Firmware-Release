import QtQuick 2.15
import "../components"
import ".."

Item {
    id: page

    Column {
        anchors.fill: parent
        anchors.margins: 14
        spacing: 12

        Text {
            width: parent.width
            text: AppState.printFilename.length ? AppState.printFilename : "当前没有打印任务"
            color: Theme.textPrimary
            font.pixelSize: Theme.fontTitle
            font.family: Theme.fontFamily
            font.weight: Theme.fontWeight
            elide: Text.ElideMiddle
        }

        ProgressHero {
            width: parent.width
            progress: AppState.printProgress
            etaText: AppState.printEtaText
        }

        Text {
            text: "第 " + AppState.printLayer + " 层" + (AppState.printLayerTotal ? (" / 共 " + AppState.printLayerTotal + " 层") : "")
            color: Theme.textSecondary
            font.pixelSize: Theme.fontSmall
        }

        Row {
            spacing: 10
            PrimaryButton {
                text: AppState.printPaused ? "继续打印" : "暂停"
                height: Theme.touchMin - 4
                enabled: AppState.printing || AppState.printPaused
                onClicked: AppState.printPaused ? AppState.resumePrint() : AppState.pausePrint()
            }
            PrimaryButton {
                text: "取消"
                danger: true
                height: Theme.touchMin - 4
                enabled: AppState.printing || AppState.printPaused
                onClicked: AppState.cancelPrint()
            }
            PrimaryButton {
                text: "返回首页"
                primary: false
                height: Theme.touchMin - 4
                onClicked: AppState.go("home")
            }
        }
    }
}
