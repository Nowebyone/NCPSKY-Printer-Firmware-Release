# NCPSKY Mainsail 主题

部署到打印机 `printer_data/config/.theme/`：

```powershell
python H:\printer\scripts\deploy_mainsail_theme.py
```

包含：
- `sidebar-logo.svg` / `sidebar-background.svg` / `main-background.svg`
- `favicon-16x16.png` / `favicon-32x32.png`
- `custom.css`（NCPSKY 深紫黑 + `#A78BFA`）
- `default.json`（重置界面时的默认主色/机名）
