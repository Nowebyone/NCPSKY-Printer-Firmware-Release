#!/usr/bin/env python3
"""WiFi (wpa_cli) + OTA proxy / sing-box helpers for the panel helper (:7126).

Runs as root with the panel. Never returns WiFi PSK or full VLESS URLs.
"""
from __future__ import annotations

import base64
import json
import os
import re
import subprocess
import time
import urllib.parse
import urllib.request
import ssl

IFACE = "wlan0"
WPA_CONF = "/etc/wpa_supplicant.conf"
SINGBOX_BIN = "/usr/local/bin/sing-box"
SINGBOX_CFG = "/etc/sing-box/config.json"
SINGBOX_UNIT = "sing-box"
VLESS_PATH = "/home/pi/ncpsky-panel/ota/proxy.vless"  # legacy share dump
PROXY_CONF_PATH = "/home/pi/ncpsky-panel/ota/proxy.json"
PROXY_LOCAL_PORT = 7890


def _run(cmd, timeout=30, input_text=None):
    try:
        p = subprocess.run(
            cmd,
            input=input_text,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            universal_newlines=True,
        )
        return p.returncode, (p.stdout or ""), (p.stderr or "")
    except Exception as ex:
        return 1, "", str(ex)


def _wpa(*args, timeout=20):
    cmd = ["wpa_cli", "-i", IFACE] + list(args)
    code, out, err = _run(cmd, timeout=timeout)
    text = (out or "").strip()
    if code != 0 and not text:
        text = (err or "").strip()
    return code, text


def _decode_wpa_ssid(raw):
    """Decode wpa_cli \\xHH sequences to unicode."""
    if raw is None:
        return ""
    s = str(raw)
    out = bytearray()
    i = 0
    while i < len(s):
        if s[i : i + 2] == "\\x" and i + 4 <= len(s):
            try:
                out.append(int(s[i + 2 : i + 4], 16))
                i += 4
                continue
            except ValueError:
                pass
        out.append(ord(s[i]))
        i += 1
    return out.decode("utf-8", errors="replace")


def _ssid_hex(ssid):
    return "".join("%02x" % b for b in ssid.encode("utf-8"))


def _iface_addrs():
    code, out, _ = _run(["ip", "-br", "addr", "show", IFACE], timeout=8)
    if code != 0:
        return []
    # wlan0 UP 192.168.2.228/24 fe80::.../64
    parts = out.split()
    ips = []
    for p in parts[2:]:
        if "/" in p and ":" not in p.split("/")[0]:
            ips.append(p.split("/")[0])
        elif "/" in p and p.count(":") >= 2:
            continue
    return ips


def wifi_status():
    code, text = _wpa("status", timeout=8)
    info = {
        "ok": True,
        "iface": IFACE,
        "ssid": "",
        "bssid": "",
        "ip": "",
        "ips": [],
        "state": "unknown",
        "signal": None,
        "freq": None,
        "key_mgmt": "",
    }
    if code != 0:
        info["ok"] = False
        info["error"] = text or "wpa_cli failed"
        ips = _iface_addrs()
        info["ips"] = ips
        info["ip"] = ips[0] if ips else ""
        return info

    kv = {}
    for line in text.splitlines():
        if "=" in line:
            k, v = line.split("=", 1)
            kv[k.strip()] = v.strip()

    info["ssid"] = _decode_wpa_ssid(kv.get("ssid", ""))
    info["bssid"] = kv.get("bssid", "")
    info["state"] = kv.get("wpa_state", "") or "unknown"
    info["key_mgmt"] = kv.get("key_mgmt", "")
    info["ip"] = kv.get("ip_address", "")
    if kv.get("freq"):
        try:
            info["freq"] = int(kv["freq"])
        except ValueError:
            pass

    # signal from scan_results for current bssid if possible
    signal = None
    if info["bssid"]:
        _, scan = _wpa("scan_results", timeout=8)
        for line in (scan or "").splitlines()[1:]:
            cols = line.split("\t")
            if len(cols) >= 5 and cols[0].lower() == info["bssid"].lower():
                try:
                    signal = int(cols[2])
                except ValueError:
                    signal = None
                break
    info["signal"] = signal

    ips = _iface_addrs()
    if not info["ip"] and ips:
        info["ip"] = ips[0]
    info["ips"] = ips or ([info["ip"]] if info["ip"] else [])
    return info


def wifi_scan(wait_sec=4.0):
    _wpa("scan", timeout=10)
    time.sleep(max(1.0, min(10.0, float(wait_sec))))
    # some drivers need a second kick before scan_results fills
    _wpa("scan", timeout=8)
    time.sleep(1.0)
    code, text = _wpa("scan_results", timeout=10)
    if code != 0:
        return {"ok": False, "error": text or "scan failed", "networks": []}

    cur = wifi_status()
    cur_ssid = cur.get("ssid") or ""
    cur_bssid = (cur.get("bssid") or "").lower()

    seen = {}
    for line in text.splitlines()[1:]:
        cols = line.split("\t")
        if len(cols) < 5:
            continue
        bssid, freq, level, flags, raw_ssid = cols[0], cols[1], cols[2], cols[3], cols[4]
        ssid = _decode_wpa_ssid(raw_ssid)
        if not ssid:
            continue
        try:
            signal = int(level)
        except ValueError:
            signal = -100
        try:
            freq_i = int(freq)
        except ValueError:
            freq_i = 0
        sec = "open"
        fl = flags.upper()
        if "WPA3" in fl or "SAE" in fl:
            sec = "wpa3"
        elif "WPA2" in fl or "WPA" in fl:
            sec = "wpa2"
        elif "WEP" in fl:
            sec = "wep"
        connected = (ssid == cur_ssid) or (bssid.lower() == cur_bssid)
        prev = seen.get(ssid)
        if prev is None or signal > prev["signal"]:
            seen[ssid] = {
                "ssid": ssid,
                "signal": signal,
                "freq": freq_i,
                "security": sec,
                "flags": flags,
                "connected": connected,
            }
        elif connected:
            seen[ssid]["connected"] = True

    nets = sorted(seen.values(), key=lambda n: (not n["connected"], -n["signal"], n["ssid"]))
    return {"ok": True, "networks": nets, "status": cur}


def _quote_psk(password):
    # wpa_cli set_network N psk '"secret"'
    return '"%s"' % str(password).replace("\\", "\\\\").replace('"', '\\"')


def wifi_connect(ssid, password="", open_network=False, timeout_sec=25):
    ssid = (ssid or "").strip()
    if not ssid:
        return {"ok": False, "error": "missing ssid"}
    password = password or ""
    open_network = bool(open_network) or (not password)

    code, nid = _wpa("add_network", timeout=8)
    if code != 0 or not re.match(r"^\d+$", (nid or "").strip()):
        return {"ok": False, "error": "add_network failed: %s" % nid}
    nid = nid.strip()

    code, out = _wpa("set_network", nid, "ssid", _ssid_hex(ssid), timeout=8)
    if code != 0 or out.strip() != "OK":
        _wpa("remove_network", nid, timeout=5)
        return {"ok": False, "error": "set ssid failed: %s" % out}

    if open_network:
        for args in (
            ("set_network", nid, "key_mgmt", "NONE"),
            ("set_network", nid, "psk", '""'),
        ):
            # open: key_mgmt NONE only
            pass
        code, out = _wpa("set_network", nid, "key_mgmt", "NONE", timeout=8)
        if code != 0 or out.strip() != "OK":
            _wpa("remove_network", nid, timeout=5)
            return {"ok": False, "error": "set open failed: %s" % out}
    else:
        code, out = _wpa("set_network", nid, "psk", _quote_psk(password), timeout=8)
        if code != 0 or out.strip() != "OK":
            _wpa("remove_network", nid, timeout=5)
            return {"ok": False, "error": "set psk failed (check password)"}

    _wpa("enable_network", nid, timeout=8)
    code, out = _wpa("select_network", nid, timeout=8)
    if code != 0 or out.strip() != "OK":
        return {"ok": False, "error": "select_network failed: %s" % out}
    _wpa("save_config", timeout=8)

    # DHCP renew (best-effort)
    _run(["dhclient", "-r", IFACE], timeout=12)
    _run(["dhclient", IFACE], timeout=20)

    deadline = time.time() + max(5, min(60, float(timeout_sec)))
    last = wifi_status()
    while time.time() < deadline:
        last = wifi_status()
        if last.get("state") == "COMPLETED" and last.get("ssid") == ssid:
            break
        time.sleep(1.0)

    ok = last.get("state") == "COMPLETED" and last.get("ssid") == ssid
    return {
        "ok": ok,
        "error": "" if ok else ("connect timeout, state=%s" % last.get("state")),
        "status": last,
        "network_id": int(nid),
    }


def wifi_disconnect():
    code, out = _wpa("disconnect", timeout=8)
    st = wifi_status()
    return {"ok": code == 0 or out.strip() == "OK", "detail": out, "status": st}


def wifi_reassociate():
    _wpa("reassociate", timeout=8)
    time.sleep(2)
    return {"ok": True, "status": wifi_status()}


def _wifi_ready(st=None):
    st = st or wifi_status()
    state = (st.get("state") or "").upper()
    has_link = bool(st.get("ssid")) and state in ("COMPLETED", "ASSOCIATED")
    has_ip = bool(st.get("ip") or (st.get("ips") or []))
    return bool(has_link and has_ip), st


def wifi_ensure_connected(timeout_sec=60, poll=2.5):
    """After cold boot, nudge wpa_supplicant until associated + has IP."""
    ok, st = _wifi_ready()
    if ok:
        return {"ok": True, "status": st, "action": "already"}
    deadline = time.time() + max(5.0, float(timeout_sec))
    actions = []
    while time.time() < deadline:
        _wpa("reconnect", timeout=8)
        _wpa("reassociate", timeout=8)
        actions.append("reassociate")
        time.sleep(max(1.0, float(poll)))
        ok, st = _wifi_ready()
        if ok:
            return {"ok": True, "status": st, "action": ",".join(actions)}
    ok, st = _wifi_ready()
    return {
        "ok": ok,
        "status": st,
        "action": ",".join(actions) or "timeout",
        "error": "" if ok else "wifi not ready after boot",
    }


def ensure_network_on_boot(wifi_timeout_sec=75):
    """Cold-boot / panel restart: bring Wi‑Fi up, then restart sing-box if user enabled proxy.

    Sequence matters — sing-box often starts before wlan has an IP and never recovers
    until manually restarted.
    """
    out = {
        "ok": True,
        "wifi": None,
        "proxy": None,
        "ota_proxy_enabled": False,
        "actions": [],
    }
    wifi_res = wifi_ensure_connected(timeout_sec=wifi_timeout_sec)
    out["wifi"] = wifi_res.get("status")
    out["actions"].append("wifi:" + str(wifi_res.get("action") or ""))
    if not wifi_res.get("ok"):
        out["ok"] = False
        out["error"] = wifi_res.get("error") or "wifi"

    ota_proxy_on = False
    try:
        # Prefer OTA config flag the user toggles in 设置 → 代理 / 更新走代理
        import ncpsky_ota as _ota  # local import: same scripts dir on device

        cfg = _ota.load_config() if hasattr(_ota, "load_config") else {}
        ota_proxy_on = bool((cfg.get("proxy") or {}).get("enabled"))
    except Exception:
        ota_proxy_on = False
    out["ota_proxy_enabled"] = ota_proxy_on

    conf = _load_proxy_conf()
    configured = bool(conf.get("mode")) or (
        os.path.isfile(VLESS_PATH) and os.path.getsize(VLESS_PATH) > 8
    )
    # Also treat a live sing-box config with a proxy outbound as configured
    if not configured and _host_from_singbox_cfg():
        configured = True

    if configured and ota_proxy_on:
        # Enable unit so future boots start it; restart now that Wi‑Fi should be up
        _run(["systemctl", "enable", SINGBOX_UNIT], timeout=15)
        restarted = _restart_singbox()
        out["actions"].append("singbox_restart" if restarted else "singbox_restart_failed")
        # Brief wait + one retry if port not listening yet
        time.sleep(1.5)
        if not _proxy_listening(int(conf.get("local_port") or PROXY_LOCAL_PORT)):
            _restart_singbox()
            out["actions"].append("singbox_retry")
            time.sleep(1.0)
    elif configured and not ota_proxy_on:
        out["actions"].append("proxy_configured_but_disabled")

    out["proxy"] = proxy_status()
    if ota_proxy_on and configured and not (
        out["proxy"].get("singbox_active") or out["proxy"].get("local_listening")
    ):
        out["ok"] = False
        out["error"] = (out.get("error") or "") + " proxy_not_listening"
    return out


# ---- flexible proxy (share / subscribe / http / manual → sing-box) --------

def _b64decode_padded(s):
    s = (s or "").strip().replace("-", "+").replace("_", "/")
    pad = (-len(s)) % 4
    if pad:
        s += "=" * pad
    return base64.b64decode(s)


def _load_proxy_conf():
    data = {
        "mode": "",
        "label": "",
        "node": "",
        "type": "",
        "local_port": PROXY_LOCAL_PORT,
        "ota_proxy_url": "http://127.0.0.1:%d" % PROXY_LOCAL_PORT,
        "manual": {},
    }
    try:
        with open(PROXY_CONF_PATH, "r", encoding="utf-8") as f:
            raw = json.load(f)
        if isinstance(raw, dict):
            data.update(raw)
    except Exception:
        pass
    return data


def _save_proxy_conf(patch):
    data = _load_proxy_conf()
    data.update(patch or {})
    os.makedirs(os.path.dirname(PROXY_CONF_PATH), exist_ok=True)
    tmp = PROXY_CONF_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")
    os.replace(tmp, PROXY_CONF_PATH)
    try:
        os.chmod(PROXY_CONF_PATH, 0o600)
    except Exception:
        pass
    return data


def parse_vless(url):
    if not (url or "").strip().startswith("vless://"):
        raise ValueError("需要 vless:// 分享链接")
    u = urllib.parse.urlparse(url.strip())
    q = urllib.parse.parse_qs(u.query)

    def one(key, default=""):
        return (q.get(key) or [default])[0]

    if not u.hostname or not u.username:
        raise ValueError("VLESS 链接缺少服务器或 UUID")
    security = one("security", "reality")
    return {
        "type": "vless",
        "uuid": u.username,
        "server": u.hostname,
        "server_port": int(u.port or 443),
        "flow": one("flow"),
        "packet_encoding": one("packetEncoding", "xudp"),
        "server_name": one("sni") or one("servername") or u.hostname,
        "fingerprint": one("fp", "chrome"),
        "public_key": one("pbk"),
        "short_id": one("sid"),
        "security": security,
        "network": one("type", "tcp"),
        "path": one("path"),
        "host": one("host"),
        "label": urllib.parse.unquote(u.fragment or "") or ("%s:%s" % (u.hostname, u.port or 443)),
    }


def parse_vmess(url):
    if not (url or "").strip().startswith("vmess://"):
        raise ValueError("需要 vmess:// 分享链接")
    raw = url.strip()[8:]
    try:
        obj = json.loads(_b64decode_padded(raw).decode("utf-8", errors="replace"))
    except Exception as ex:
        raise ValueError("vmess 解码失败: %s" % ex)
    return {
        "type": "vmess",
        "uuid": obj.get("id") or "",
        "server": obj.get("add") or obj.get("host") or "",
        "server_port": int(obj.get("port") or 443),
        "security": obj.get("tls") or "",
        "server_name": obj.get("sni") or obj.get("host") or obj.get("add") or "",
        "network": obj.get("net") or "tcp",
        "path": obj.get("path") or "",
        "host": obj.get("host") or "",
        "alter_id": int(obj.get("aid") or 0),
        "cipher": obj.get("scy") or "auto",
        "fingerprint": obj.get("fp") or "chrome",
        "label": obj.get("ps") or ("%s:%s" % (obj.get("add"), obj.get("port"))),
    }


def parse_trojan(url):
    if not (url or "").strip().startswith("trojan://"):
        raise ValueError("需要 trojan:// 分享链接")
    u = urllib.parse.urlparse(url.strip())
    q = urllib.parse.parse_qs(u.query)

    def one(key, default=""):
        return (q.get(key) or [default])[0]

    if not u.hostname or not u.username:
        raise ValueError("trojan 链接缺少服务器或密码")
    return {
        "type": "trojan",
        "password": urllib.parse.unquote(u.username),
        "server": u.hostname,
        "server_port": int(u.port or 443),
        "server_name": one("sni") or u.hostname,
        "fingerprint": one("fp", "chrome"),
        "network": one("type", "tcp"),
        "path": one("path"),
        "host": one("host"),
        "label": urllib.parse.unquote(u.fragment or "") or ("%s:%s" % (u.hostname, u.port or 443)),
    }


def parse_ss(url):
    # ss://BASE64  or ss://method:pass@host:port
    if not (url or "").strip().startswith("ss://"):
        raise ValueError("需要 ss:// 分享链接")
    raw = url.strip()[5:]
    label = ""
    if "#" in raw:
        raw, frag = raw.split("#", 1)
        label = urllib.parse.unquote(frag)
    try:
        if "@" not in raw:
            decoded = _b64decode_padded(raw).decode("utf-8", errors="replace")
        else:
            userinfo, hostport = raw.split("@", 1)
            try:
                userinfo = _b64decode_padded(userinfo).decode("utf-8", errors="replace")
            except Exception:
                userinfo = urllib.parse.unquote(userinfo)
            decoded = userinfo + "@" + hostport
        method_pass, hostport = decoded.rsplit("@", 1)
        method, password = method_pass.split(":", 1)
        if ":" in hostport:
            host, port = hostport.rsplit(":", 1)
        else:
            host, port = hostport, "8388"
        return {
            "type": "shadowsocks",
            "method": method,
            "password": password,
            "server": host,
            "server_port": int(port),
            "label": label or ("%s:%s" % (host, port)),
        }
    except Exception as ex:
        raise ValueError("ss 解析失败: %s" % ex)


def parse_http_proxy(url):
    u = urllib.parse.urlparse((url or "").strip())
    if u.scheme not in ("http", "https", "socks5", "socks5h"):
        raise ValueError("HTTP/SOCKS 代理需形如 http://host:port 或 socks5://host:port")
    if not u.hostname:
        raise ValueError("缺少代理主机")
    port = int(u.port or (443 if u.scheme == "https" else 1080 if u.scheme.startswith("socks") else 8080))
    return {
        "type": "http" if u.scheme in ("http", "https") else "socks",
        "server": u.hostname,
        "server_port": port,
        "scheme": u.scheme,
        "username": u.username or "",
        "password": u.password or "",
        "label": "%s://%s:%s" % (u.scheme, u.hostname, port),
        "ota_url": "%s://%s:%s" % (
            "http" if u.scheme in ("http", "https") else "socks5",
            u.hostname,
            port,
        ),
    }


def parse_share_link(url):
    s = (url or "").strip()
    low = s.lower()
    if low.startswith("vless://"):
        return parse_vless(s)
    if low.startswith("vmess://"):
        return parse_vmess(s)
    if low.startswith("trojan://"):
        return parse_trojan(s)
    if low.startswith("ss://"):
        return parse_ss(s)
    raise ValueError("不支持的分享链接（支持 vless / vmess / trojan / ss）")


def parse_manual(manual):
    m = dict(manual or {})
    t = (m.get("type") or "vless").lower()
    server = (m.get("server") or "").strip()
    if not server:
        raise ValueError("手动配置缺少 server")
    port = int(m.get("server_port") or m.get("port") or 443)
    node = {
        "type": t,
        "server": server,
        "server_port": port,
        "uuid": (m.get("uuid") or "").strip(),
        "password": (m.get("password") or "").strip(),
        "flow": (m.get("flow") or "").strip(),
        "packet_encoding": m.get("packet_encoding") or "xudp",
        "server_name": (m.get("server_name") or m.get("sni") or server).strip(),
        "fingerprint": (m.get("fingerprint") or m.get("fp") or "chrome").strip(),
        "public_key": (m.get("public_key") or m.get("pbk") or "").strip(),
        "short_id": (m.get("short_id") or m.get("sid") or "").strip(),
        "security": (m.get("security") or "reality").strip(),
        "network": (m.get("network") or "tcp").strip(),
        "path": (m.get("path") or "").strip(),
        "host": (m.get("host") or "").strip(),
        "method": (m.get("method") or "aes-128-gcm").strip(),
        "alter_id": int(m.get("alter_id") or 0),
        "cipher": (m.get("cipher") or "auto").strip(),
        "label": (m.get("label") or ("%s:%s" % (server, port))),
    }
    if t == "vless" and not node["uuid"]:
        raise ValueError("VLESS 需要 uuid")
    if t == "vmess" and not node["uuid"]:
        raise ValueError("VMess 需要 uuid")
    if t == "trojan" and not node["password"]:
        raise ValueError("Trojan 需要 password")
    if t == "shadowsocks" and not node["password"]:
        raise ValueError("Shadowsocks 需要 password")
    return node


def _fetch_url(url, timeout=25):
    ctx = ssl._create_unverified_context()
    req = urllib.request.Request(url, headers={"User-Agent": "ncpsky-panel/1.0"})
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
        return r.read()


def fetch_subscription(url):
    url = (url or "").strip()
    if not url.startswith("http://") and not url.startswith("https://"):
        raise ValueError("订阅地址需以 http:// 或 https:// 开头")
    raw = _fetch_url(url)
    text = raw.decode("utf-8", errors="replace").strip()
    # often base64 of newline-separated share links
    links = []
    try:
        decoded = _b64decode_padded(text).decode("utf-8", errors="replace")
        body = decoded
    except Exception:
        body = text
    for line in re.split(r"[\r\n]+", body):
        line = line.strip()
        if not line:
            continue
        low = line.lower()
        if low.startswith(("vless://", "vmess://", "trojan://", "ss://")):
            links.append(line)
    if not links:
        # maybe plain single link
        if body.lower().startswith(("vless://", "vmess://", "trojan://", "ss://")):
            links = [body.strip()]
    if not links:
        raise ValueError("订阅内容中未找到可用节点")
    # prefer vless, then trojan, vmess, ss
    order = {"vless": 0, "trojan": 1, "vmess": 2, "ss": 3}
    links.sort(key=lambda x: order.get(x.split("://", 1)[0].lower(), 9))
    node = parse_share_link(links[0])
    node["_share"] = links[0]
    node["_subscribe_count"] = len(links)
    return node


def detect_mode(value, mode=None):
    mode = (mode or "auto").lower()
    s = (value or "").strip()
    if mode in ("share", "subscribe", "http", "manual"):
        return mode
    low = s.lower()
    if low.startswith(("vless://", "vmess://", "trojan://", "ss://")):
        return "share"
    if low.startswith("socks5://") or low.startswith("socks5h://"):
        return "http"
    if low.startswith("http://") or low.startswith("https://"):
        # subscription vs plain http proxy
        path = urllib.parse.urlparse(s).path or ""
        if any(k in s.lower() for k in ("sub", "subscribe", "token=", "api/v1", "clash", "v2ray")):
            return "subscribe"
        if path in ("", "/") and urllib.parse.urlparse(s).port:
            return "http"
        return "subscribe"
    if ":" in s and "://" not in s:
        # host:port → treat as http proxy
        return "http"
    return "share"


def build_outbound(node):
    t = (node.get("type") or "").lower()
    if t == "vless":
        ob = {
            "type": "vless",
            "tag": "proxy",
            "server": node["server"],
            "server_port": int(node["server_port"]),
            "uuid": node["uuid"],
            "flow": node.get("flow") or "",
            "packet_encoding": node.get("packet_encoding") or "xudp",
        }
        sec = (node.get("security") or "reality").lower()
        if sec in ("reality", "tls"):
            tls = {
                "enabled": True,
                "server_name": node.get("server_name") or node["server"],
                "utls": {"enabled": True, "fingerprint": node.get("fingerprint") or "chrome"},
            }
            if sec == "reality" or node.get("public_key"):
                tls["reality"] = {
                    "enabled": True,
                    "public_key": node.get("public_key") or "",
                    "short_id": node.get("short_id") or "",
                }
            ob["tls"] = tls
        return ob
    if t == "vmess":
        ob = {
            "type": "vmess",
            "tag": "proxy",
            "server": node["server"],
            "server_port": int(node["server_port"]),
            "uuid": node["uuid"],
            "security": node.get("cipher") or "auto",
            "alter_id": int(node.get("alter_id") or 0),
        }
        if (node.get("security") or "").lower() in ("tls", "reality") or node.get("server_name"):
            ob["tls"] = {
                "enabled": True,
                "server_name": node.get("server_name") or node["server"],
                "utls": {"enabled": True, "fingerprint": node.get("fingerprint") or "chrome"},
            }
        return ob
    if t == "trojan":
        return {
            "type": "trojan",
            "tag": "proxy",
            "server": node["server"],
            "server_port": int(node["server_port"]),
            "password": node.get("password") or "",
            "tls": {
                "enabled": True,
                "server_name": node.get("server_name") or node["server"],
                "utls": {"enabled": True, "fingerprint": node.get("fingerprint") or "chrome"},
            },
        }
    if t == "shadowsocks":
        return {
            "type": "shadowsocks",
            "tag": "proxy",
            "server": node["server"],
            "server_port": int(node["server_port"]),
            "method": node.get("method") or "aes-128-gcm",
            "password": node.get("password") or "",
        }
    if t in ("http", "socks"):
        ob = {
            "type": "http" if t == "http" else "socks",
            "tag": "proxy",
            "server": node["server"],
            "server_port": int(node["server_port"]),
        }
        if node.get("username"):
            ob["username"] = node["username"]
            ob["password"] = node.get("password") or ""
        return ob
    raise ValueError("未知节点类型: %s" % t)


def build_singbox_config(node, local_port=PROXY_LOCAL_PORT):
    return {
        "log": {"level": "info", "timestamp": True},
        "inbounds": [
            {
                "type": "mixed",
                "tag": "mixed-in",
                "listen": "127.0.0.1",
                "listen_port": int(local_port),
            }
        ],
        "outbounds": [
            build_outbound(node),
            {"type": "direct", "tag": "direct"},
        ],
        "route": {
            "rules": [{"ip_is_private": True, "outbound": "direct"}],
            "final": "proxy",
            "auto_detect_interface": True,
        },
    }


def _write_singbox(cfg):
    os.makedirs(os.path.dirname(SINGBOX_CFG), exist_ok=True)
    tmpc = SINGBOX_CFG + ".tmp"
    with open(tmpc, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
        f.write("\n")
    os.replace(tmpc, SINGBOX_CFG)


def _restart_singbox():
    if not os.path.isfile(SINGBOX_BIN):
        return False
    _run(["systemctl", "restart", SINGBOX_UNIT], timeout=20)
    time.sleep(1.2)
    return True


def _singbox_active():
    code, out, _ = _run(["systemctl", "is-active", SINGBOX_UNIT], timeout=5)
    return (out or "").strip() == "active"


def _proxy_listening(port=None):
    port = int(port or PROXY_LOCAL_PORT)
    code, out, _ = _run(["ss", "-lntp"], timeout=5)
    return (":%d" % port) in (out or "") and "127.0.0.1" in (out or "")


def _host_from_singbox_cfg():
    try:
        with open(SINGBOX_CFG, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        for ob in cfg.get("outbounds") or []:
            if ob.get("tag") == "proxy" and ob.get("server"):
                return "%s:%s" % (ob.get("server"), ob.get("server_port") or "")
            if ob.get("type") in ("vless", "vmess", "trojan", "shadowsocks", "http", "socks") and ob.get("server"):
                return "%s:%s" % (ob.get("server"), ob.get("server_port") or "")
    except Exception:
        pass
    return ""


def proxy_status():
    conf = _load_proxy_conf()
    host = conf.get("node") or ""
    configured = bool(conf.get("mode")) or (os.path.isfile(VLESS_PATH) and os.path.getsize(VLESS_PATH) > 8)
    if not host:
        host = _host_from_singbox_cfg()
        if host:
            configured = True
    local_port = int(conf.get("local_port") or PROXY_LOCAL_PORT)
    return {
        "ok": True,
        "configured": configured,
        "vless_configured": configured,  # compat
        "mode": conf.get("mode") or "",
        "type": conf.get("type") or "",
        "label": conf.get("label") or "",
        "node": host,
        "vless_host": host,  # compat
        "manual": conf.get("manual") or {},
        "singbox_installed": os.path.isfile(SINGBOX_BIN),
        "singbox_active": _singbox_active(),
        "local_port": local_port,
        "local_listening": _proxy_listening(local_port),
        "local_url": "http://127.0.0.1:%d" % local_port,
        "ota_proxy_url": conf.get("ota_proxy_url") or ("http://127.0.0.1:%d" % local_port),
    }


def apply_proxy_config(value="", mode="auto", manual=None, local_port=None, restart=True):
    """Apply share link / subscription / http proxy / manual node."""
    value = (value or "").strip()
    manual = manual or {}
    port = int(local_port or _load_proxy_conf().get("local_port") or PROXY_LOCAL_PORT)
    mode = detect_mode(value, mode)

    node = None
    share_dump = ""
    ota_url = "http://127.0.0.1:%d" % port

    if mode == "manual":
        node = parse_manual(manual)
    elif mode == "subscribe":
        node = fetch_subscription(value)
        share_dump = node.pop("_share", "") or value
    elif mode == "http":
        raw = value
        if "://" not in raw:
            raw = "http://" + raw
        node = parse_http_proxy(raw)
        ota_url = node.get("ota_url") or ota_url
    else:
        node = parse_share_link(value)
        share_dump = value

    label = node.get("label") or ("%s:%s" % (node.get("server"), node.get("server_port")))
    node_host = "%s:%s" % (node.get("server"), node.get("server_port"))

    cfg = build_singbox_config(node, port)
    _write_singbox(cfg)

    # persist
    if share_dump:
        os.makedirs(os.path.dirname(VLESS_PATH), exist_ok=True)
        tmp = VLESS_PATH + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(share_dump + "\n")
        os.replace(tmp, VLESS_PATH)
        try:
            os.chmod(VLESS_PATH, 0o600)
        except Exception:
            pass

    _save_proxy_conf({
        "mode": mode,
        "type": node.get("type") or "",
        "label": label,
        "node": node_host,
        "local_port": port,
        "ota_proxy_url": ota_url,
        "manual": manual if mode == "manual" else {
            "type": node.get("type"),
            "server": node.get("server"),
            "server_port": node.get("server_port"),
            "uuid": node.get("uuid") or "",
            "password": "",  # never persist password/uuid secrets in clear UI dump beyond need
            "sni": node.get("server_name") or "",
            "fp": node.get("fingerprint") or "",
        },
        "updated_at": int(time.time()),
    })

    restarted = False
    if restart:
        restarted = _restart_singbox()

    st = proxy_status()
    st["ok"] = True
    st["restarted"] = restarted
    st["applied_mode"] = mode
    st["subscribe_count"] = node.get("_subscribe_count")
    return st


def set_vless(url, restart=True):
    # backward-compatible entry
    return apply_proxy_config(value=url, mode="auto", restart=restart)


def set_proxy_input(value, mode="auto", manual=None, local_port=None, restart=True):
    return apply_proxy_config(
        value=value, mode=mode, manual=manual, local_port=local_port, restart=restart
    )


def clear_vless(stop=False):
    return clear_proxy(stop=stop)


def clear_proxy(stop=False):
    for path in (VLESS_PATH, PROXY_CONF_PATH):
        try:
            if os.path.isfile(path):
                os.remove(path)
        except Exception as ex:
            return {"ok": False, "error": str(ex)}
    if stop:
        _run(["systemctl", "stop", SINGBOX_UNIT], timeout=15)
    return proxy_status()


def network_overview():
    wifi = wifi_status()
    proxy = proxy_status()
    return {
        "ok": True,
        "wifi": wifi,
        "proxy": proxy,
        "hint": _hint(wifi, proxy),
    }


def _hint(wifi, proxy):
    parts = []
    if wifi.get("ssid"):
        parts.append(wifi["ssid"])
    if wifi.get("ip"):
        parts.append(wifi["ip"])
    elif wifi.get("ips"):
        parts.append(wifi["ips"][0])
    if wifi.get("signal") is not None:
        parts.append("%sdBm" % wifi["signal"])
    if proxy.get("singbox_active") or proxy.get("configured"):
        parts.append("proxy:on")
    return " · ".join(parts) if parts else ""
