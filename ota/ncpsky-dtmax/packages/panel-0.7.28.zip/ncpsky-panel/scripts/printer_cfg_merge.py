#!/usr/bin/env python3
"""Merge OTA-managed printer.cfg body with live SAVE_CONFIG + identity keys."""
from __future__ import annotations

import argparse
import os
import re
import shutil
from typing import Dict, List, Optional, Tuple

DEFAULT_IDENTITY_KEYS = ("serial", "canbus_uuid", "uuid")


def split_save_config(text: str) -> Tuple[str, str]:
    """Return (body_before, save_block_including_marker). save_block may be empty."""
    lines = text.splitlines(keepends=True)
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("#*#") and "SAVE_CONFIG" in stripped.upper():
            return "".join(lines[:i]).rstrip() + "\n", "".join(lines[i:])
    return text.rstrip() + "\n", ""


def strip_save_config(text: str) -> str:
    body, _ = split_save_config(text)
    return body


def _iter_sections(text: str):
    """Yield (section_name_or_None, header_or_None, body_lines without headers)."""
    name = None
    header = None
    body: List[str] = []
    for line in text.splitlines():
        m = re.match(r"^\[([^\]]+)\]\s*$", line.strip())
        if m:
            yield name, header, body
            name = m.group(1).strip()
            header = line.rstrip("\n")
            body = []
        else:
            body.append(line.rstrip("\n"))
    yield name, header, body


def _key_values(body_lines: List[str]) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for line in body_lines:
        s = line.strip()
        if not s or s.startswith("#") or ":" not in line:
            continue
        key, _, val = line.partition(":")
        out[key.strip().lower()] = val.strip()
    return out


def _restore_identity_in_body(
    incoming_body: str, live_body: str, identity_keys: List[str]
) -> str:
    live_maps = {}
    for name, _hdr, body in _iter_sections(live_body):
        if name:
            live_maps[name.lower()] = _key_values(body)

    keys = [k.lower() for k in identity_keys]
    out: List[str] = []
    for name, header, body in _iter_sections(incoming_body):
        if name is None and header is None:
            out.extend(body)
            continue
        out.append(header if header is not None else "")
        live_map = live_maps.get((name or "").lower(), {})
        seen = set()
        for line in body:
            s = line.strip()
            if s and not s.startswith("#") and ":" in line:
                key = line.partition(":")[0].strip().lower()
                if key in keys and key in live_map:
                    left = line.partition(":")[0].rstrip()
                    out.append("%s: %s" % (left, live_map[key]))
                    seen.add(key)
                    continue
            out.append(line)
        for key in keys:
            if key in live_map and key not in seen:
                out.append("%s: %s" % (key, live_map[key]))
    text = "\n".join(out).rstrip() + "\n"
    return text


def replace_printer_cfg_text(
    live_text: str,
    incoming_text: str,
    identity_keys: Optional[List[str]] = None,
) -> str:
    """Install the firmware printer.cfg. Drop SAVE_CONFIG (mesh, measured
    endstops, shaper, delta height table). Keep serial / canbus_uuid / uuid.
    """
    identity_keys = list(identity_keys or DEFAULT_IDENTITY_KEYS)
    live_body, _live_save = split_save_config(live_text)
    incoming_body = strip_save_config(incoming_text)
    if not incoming_body.strip():
        raise ValueError("incoming printer.cfg body is empty")
    return _restore_identity_in_body(incoming_body, live_body, identity_keys)


def merge_printer_cfg_text(
    live_text: str,
    incoming_text: str,
    identity_keys: Optional[List[str]] = None,
) -> str:
    identity_keys = list(identity_keys or DEFAULT_IDENTITY_KEYS)
    live_body, live_save = split_save_config(live_text)
    incoming_body = strip_save_config(incoming_text)
    if not incoming_body.strip():
        raise ValueError("incoming printer.cfg body is empty")
    merged_body = _restore_identity_in_body(incoming_body, live_body, identity_keys)
    if live_save.strip():
        if "SAVE_CONFIG" not in live_save.upper():
            raise ValueError("live SAVE_CONFIG block missing marker")
        return merged_body.rstrip() + "\n\n" + live_save.lstrip("\n")
    return merged_body


def replace_printer_cfg_files(
    live_path: str,
    incoming_path: str,
    dest_path: Optional[str] = None,
    backup_path: Optional[str] = None,
    identity_keys: Optional[List[str]] = None,
) -> str:
    dest_path = dest_path or live_path
    with open(live_path, "r", encoding="utf-8", errors="replace") as f:
        live_text = f.read()
    with open(incoming_path, "r", encoding="utf-8", errors="replace") as f:
        incoming_text = f.read()

    if backup_path:
        os.makedirs(os.path.dirname(backup_path) or ".", exist_ok=True)
        shutil.copy2(live_path, backup_path)

    replaced = replace_printer_cfg_text(
        live_text, incoming_text, identity_keys=identity_keys
    )
    if "#*#" in replaced:
        raise ValueError("replaced printer.cfg still contains a SAVE_CONFIG block")
    tmp = dest_path + ".ota_replace_tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write(replaced)
    os.replace(tmp, dest_path)
    return dest_path


def merge_printer_cfg_files(
    live_path: str,
    incoming_path: str,
    dest_path: Optional[str] = None,
    backup_path: Optional[str] = None,
    identity_keys: Optional[List[str]] = None,
) -> str:
    dest_path = dest_path or live_path
    with open(live_path, "r", encoding="utf-8", errors="replace") as f:
        live_text = f.read()
    with open(incoming_path, "r", encoding="utf-8", errors="replace") as f:
        incoming_text = f.read()

    if backup_path:
        os.makedirs(os.path.dirname(backup_path) or ".", exist_ok=True)
        shutil.copy2(live_path, backup_path)

    try:
        merged = merge_printer_cfg_text(live_text, incoming_text, identity_keys=identity_keys)
        if "SAVE_CONFIG" in live_text.upper() and "SAVE_CONFIG" not in merged.upper():
            raise ValueError("merged result lost SAVE_CONFIG")
        tmp = dest_path + ".ota_merge_tmp"
        with open(tmp, "w", encoding="utf-8", newline="\n") as f:
            f.write(merged)
        os.replace(tmp, dest_path)
        return dest_path
    except Exception:
        if backup_path and os.path.isfile(backup_path) and dest_path == live_path:
            try:
                shutil.copy2(backup_path, live_path)
            except Exception:
                pass
        raise


def main():
    ap = argparse.ArgumentParser(description="Merge OTA printer.cfg with live SAVE_CONFIG")
    ap.add_argument("--live", required=True)
    ap.add_argument("--incoming", required=True)
    ap.add_argument("--out", help="output path (default: --live)")
    ap.add_argument("--backup")
    args = ap.parse_args()
    path = merge_printer_cfg_files(
        args.live, args.incoming, dest_path=args.out, backup_path=args.backup
    )
    print("wrote", path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
