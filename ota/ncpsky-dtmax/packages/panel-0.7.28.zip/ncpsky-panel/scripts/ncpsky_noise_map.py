#!/usr/bin/env python3
"""ADXL offline noise-vs-speed map for NCPSKY T1 Max / DTMax.

Builds forbidden velocity bands from cruise-move accelerometer RMS, writes
noise_map.json, and syncs [gcode_macro NCPSKY_NOISE_MAP] variables so
APPLY_NOISE_MAP / quiet macros can apply limits without mid-print TMC writes.
"""
from __future__ import annotations

import csv
import glob
import json
import math
import os
import threading
import time
import urllib.error
import urllib.request
from typing import Any, Callable, Dict, List, Optional, Tuple


def _cruise_ratio(accel, accel_to_decel):
    accel = float(accel) or 1.0
    return max(0.0, min(0.99, 1.0 - (float(accel_to_decel) / accel)))

MOONRAKER = os.environ.get("NCPSKY_MOONRAKER", "http://127.0.0.1:7125")
CONFIG_DIR = os.environ.get(
    "NCPSKY_CONFIG_DIR", "/home/pi/printer_data/config"
)
TMP = os.environ.get("NCPSKY_TMP", "/tmp")
MAP_PATH = os.path.join(CONFIG_DIR, "noise_map.json")
DEFAULT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "config",
    "noise_map.default.json",
)
# Panel deploy may keep default next to scripts too
DEFAULT_FALLBACKS = [
    DEFAULT_PATH,
    os.path.join(CONFIG_DIR, "noise_map.default.json"),
    "/home/pi/ncpsky-panel/config/noise_map.default.json",
]

# Host ADXL while the towers use ordinary StealthChop steps.
# The grid covers the print envelope and does not lower max_velocity.
DEFAULT_VELOCITIES = [
    10, 20, 30, 40, 50, 60, 70, 80,
    100, 120, 150, 200, 250, 300,
    400, 500, 600, 800,
]
DEFAULT_ACCELS = [1000]
# Delta tower compass angles (deg, +X=0 CCW) — FLSun T1 Max A/B/C columns
TOWER_ANGLES_DEG = (210.0, 330.0, 90.0)

_lock = threading.Lock()
_job: Dict[str, Any] = {
    "busy": 0,
    "phase": "idle",
    "progress": 0.0,
    "error": "",
    "message": "",
    "map_path": MAP_PATH,
}


def job_status() -> Dict[str, Any]:
    with _lock:
        return dict(_job)


def _set_job(**kwargs: Any) -> None:
    with _lock:
        _job.update(kwargs)


def _http_json(url: str, data: Any = None, timeout: float = 120) -> Dict[str, Any]:
    if data is None:
        req = urllib.request.Request(url)
    else:
        body = json.dumps(data).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def gcode(script: str, timeout: float = 300) -> None:
    _http_json(
        MOONRAKER.rstrip("/") + "/printer/gcode/script",
        {"script": script},
        timeout=timeout,
    )


def wait_ready(timeout: float = 120) -> None:
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            raw = _http_json(
                MOONRAKER.rstrip("/")
                + "/printer/objects/query?print_stats&idle_timeout&toolhead",
                timeout=10,
            )
            st = ((raw.get("result") or {}).get("status")) or {}
            ps = st.get("print_stats") or {}
            idle = st.get("idle_timeout") or {}
            state = (ps.get("state") or "").lower()
            istate = (idle.get("state") or "").lower()
            if state in ("printing", "paused"):
                time.sleep(0.3)
                continue
            if istate in ("idle", "ready") or state in ("standby", "complete", "cancelled", "error", ""):
                # Also ensure not homing-busy: max_velocity present is enough
                return
        except Exception:
            pass
        time.sleep(0.35)
    raise TimeoutError("printer not idle within %.0fs" % timeout)


def load_default_map() -> Dict[str, Any]:
    for path in DEFAULT_FALLBACKS:
        if path and os.path.isfile(path):
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    return {
        "version": 1,
        "source": "builtin",
        "forbidden_velocity_bands": [
            {"lo": 7.0, "hi": 13.0, "reason": "tower cogging ~33Hz"},
            {"lo": 22.0, "hi": 28.0, "reason": "probe travel couple"},
        ],
        "preferred_accel": 1000.0,
        "limits": {
            "max_velocity": 300.0,
            "max_accel": 3000.0,
            "max_accel_to_decel": 1500.0,
            "pace_speed": 80.0,
            "quiet_travel_mm_s": 50.0,
            "quiet_home_first_mm_s": 80.0,
            "quiet_home_second_mm_s": 5.0,
            "quiet_probe_accel": 1000.0,
        },
    }


def load_map(path: str = MAP_PATH) -> Dict[str, Any]:
    if os.path.isfile(path):
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict) and data.get("forbidden_velocity_bands") is not None:
            return data
    return load_default_map()


def save_map(data: Dict[str, Any], path: str = MAP_PATH) -> str:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")
    os.replace(tmp, path)
    return path


def parse_adxl_csv(path: str) -> Tuple[float, float, int]:
    """Return (rms_xyz, peak_abs, n_samples) from Klipper ADXL CSV."""
    xs: List[float] = []
    ys: List[float] = []
    zs: List[float] = []
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        reader = csv.reader(f)
        header = next(reader, None)
        # Formats: time,x,y,z  or  #time,x,y,z
        for row in reader:
            if not row or row[0].startswith("#"):
                continue
            if len(row) < 4:
                continue
            try:
                xs.append(float(row[1]))
                ys.append(float(row[2]))
                zs.append(float(row[3]))
            except ValueError:
                continue
    n = len(xs)
    if n < 8:
        return 0.0, 0.0, n
    # Drop first/last 15% (accel / decel edges)
    a = max(1, int(n * 0.15))
    b = max(a + 1, n - a)
    xs, ys, zs = xs[a:b], ys[a:b], zs[a:b]
    n = len(xs)
    acc2 = 0.0
    peak = 0.0
    for i in range(n):
        m2 = xs[i] * xs[i] + ys[i] * ys[i] + zs[i] * zs[i]
        acc2 += m2
        peak = max(peak, math.sqrt(m2))
    rms = math.sqrt(acc2 / n) if n else 0.0
    return rms, peak, n


def latest_adxl_csv(name: str) -> Optional[str]:
    patterns = [
        os.path.join(TMP, "adxl345-*%s*.csv" % name),
        os.path.join(TMP, "adxl345*%s*.csv" % name),
        os.path.join(TMP, "*%s*.csv" % name),
    ]
    files: List[str] = []
    for p in patterns:
        files.extend(glob.glob(p))
    if not files:
        return None
    files.sort(key=os.path.getmtime, reverse=True)
    return files[0]


def merge_bands(
    bands: List[Dict[str, Any]], gap: float = 2.0
) -> List[Dict[str, Any]]:
    if not bands:
        return []
    items = sorted(
        (
            {
                "lo": float(b["lo"]),
                "hi": float(b["hi"]),
                "reason": b.get("reason") or "",
            }
            for b in bands
            if float(b.get("hi", 0)) > float(b.get("lo", 0))
        ),
        key=lambda x: x["lo"],
    )
    out = [items[0]]
    for b in items[1:]:
        cur = out[-1]
        if b["lo"] <= cur["hi"] + gap:
            cur["hi"] = max(cur["hi"], b["hi"])
            if b["reason"] and b["reason"] not in cur["reason"]:
                cur["reason"] = (cur["reason"] + "; " + b["reason"]).strip("; ")
        else:
            out.append(dict(b))
    return out


def detect_bands_from_samples(
    samples: List[Dict[str, Any]],
    ratio: float = 1.45,
    min_width: float = 2.0,
) -> List[Dict[str, Any]]:
    """Peak RMS vs median → velocity bands (per accel, then union)."""
    by_accel: Dict[float, List[Dict[str, Any]]] = {}
    for s in samples:
        a = float(s.get("accel") or 0)
        by_accel.setdefault(a, []).append(s)

    bands: List[Dict[str, Any]] = []
    for accel, rows in by_accel.items():
        rows = sorted(rows, key=lambda r: float(r["velocity"]))
        rms_list = [float(r["rms"]) for r in rows if float(r.get("rms") or 0) > 0]
        if len(rms_list) < 3:
            continue
        med = sorted(rms_list)[len(rms_list) // 2]
        if med <= 1e-6:
            continue
        hot = [
            float(r["velocity"])
            for r in rows
            if float(r.get("rms") or 0) >= med * ratio
        ]
        if not hot:
            continue
        hot.sort()
        lo = hi = hot[0]
        for v in hot[1:]:
            if v <= hi + min_width + 1.0:
                hi = v
            else:
                bands.append(
                    {
                        "lo": max(0.0, lo - 1.0),
                        "hi": hi + 1.0,
                        "reason": "ADXL RMS peak @ accel=%g" % accel,
                    }
                )
                lo = hi = v
        bands.append(
            {
                "lo": max(0.0, lo - 1.0),
                "hi": hi + 1.0,
                "reason": "ADXL RMS peak @ accel=%g" % accel,
            }
        )
    return merge_bands(bands)


def pick_quiet_travel(
    bands: List[Dict[str, Any]], candidates: Optional[List[float]] = None
) -> float:
    # Prefer 50 mm/s (legacy quiet travel) then other gaps outside ban bands
    cands = candidates or [50.0, 40.0, 60.0, 80.0, 18.0, 15.0]
    for v in cands:
        ok = True
        for b in bands:
            if float(b["lo"]) <= v <= float(b["hi"]):
                ok = False
                break
        if ok:
            return float(v)
    return 50.0


def derive_limits(
    base: Dict[str, Any], bands: List[Dict[str, Any]]
) -> Dict[str, float]:
    lim = dict(base.get("limits") or {})
    lim.setdefault("max_velocity", 300.0)
    lim.setdefault("max_accel", 3000.0)
    lim.setdefault("max_accel_to_decel", 1500.0)
    lim.setdefault("pace_speed", 80.0)
    lim.setdefault("quiet_home_first_mm_s", 80.0)
    lim.setdefault("quiet_home_second_mm_s", 5.0)
    lim.setdefault("quiet_probe_accel", 1000.0)
    travel = pick_quiet_travel(bands)
    lim["quiet_travel_mm_s"] = travel
    # Keep pace_speed out of any ban band
    pace = float(lim["pace_speed"])
    for b in bands:
        if float(b["lo"]) <= pace <= float(b["hi"]):
            pace = pick_quiet_travel(bands, [60, 70, 80, 90, 100, 120])
            break
    lim["pace_speed"] = pace
    # Record bands for the chart. Do not lower the printer speed envelope.
    return {k: float(v) for k, v in lim.items()}


def build_map_from_samples(
    samples: List[Dict[str, Any]],
    seed: Optional[Dict[str, Any]] = None,
    merge_seed: bool = True,
) -> Dict[str, Any]:
    seed = seed or load_default_map()
    measured = detect_bands_from_samples(samples)
    seed_bands = list(seed.get("forbidden_velocity_bands") or [])
    if merge_seed:
        bands = merge_bands(seed_bands + measured)
    else:
        bands = merge_bands(measured) or merge_bands(seed_bands)
    limits = derive_limits(seed, bands)
    return {
        "version": 1,
        "source": "measured" if samples else seed.get("source", "default_seed"),
        "product_id": seed.get("product_id", "ncpsky-dtmax"),
        "shaper_hz_hint": float(seed.get("shaper_hz_hint") or 33.0),
        "samples": samples,
        "forbidden_velocity_bands": bands,
        "preferred_accel": float(
            seed.get("preferred_accel") or limits.get("quiet_probe_accel") or 1000
        ),
        "limits": limits,
        "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "notes": seed.get("notes") or "",
    }


def _save_variable_cmds(lim: Dict[str, Any], source: str, note: str) -> List[str]:
    """SAVE_VARIABLE literals so a restart can restore the measured envelope."""
    def literal(text: str) -> str:
        esc = (
            str(text)
            .replace("\\", "")
            .replace('"', "")
            .replace("'", "")
            .replace("\n", " ")[:80]
        )
        return "'\"%s\"'" % esc

    return [
        "SAVE_VARIABLE VARIABLE=noise_max_velocity VALUE=%g"
        % float(lim.get("max_velocity", 300)),
        "SAVE_VARIABLE VARIABLE=noise_max_accel VALUE=%g"
        % float(lim.get("max_accel", 3000)),
        "SAVE_VARIABLE VARIABLE=noise_max_accel_to_decel VALUE=%g"
        % float(lim.get("max_accel_to_decel", 1500)),
        "SAVE_VARIABLE VARIABLE=noise_pace_speed VALUE=%g"
        % float(lim.get("pace_speed", 80)),
        "SAVE_VARIABLE VARIABLE=noise_quiet_travel VALUE=%g"
        % float(lim.get("quiet_travel_mm_s", 50)),
        "SAVE_VARIABLE VARIABLE=noise_quiet_accel VALUE=%g"
        % float(lim.get("quiet_probe_accel", 1000)),
        "SAVE_VARIABLE VARIABLE=noise_source VALUE=%s" % literal(source or "unknown"),
        "SAVE_VARIABLE VARIABLE=noise_ban_note VALUE=%s" % literal(note or "none"),
    ]


def _gcode_str_literal(s: str) -> str:
    """Klipper SET_GCODE_VARIABLE VALUE must be a Python literal, e.g. '\"text\"'."""
    esc = (
        str(s)
        .replace("\\", "\\\\")
        .replace('"', "")
        .replace("'", "")
        .replace("\n", " ")[:180]
    )
    return "'\"%s\"'" % esc


def sync_macro_variables(data: Dict[str, Any]) -> None:
    """Push limits into NCPSKY_NOISE_MAP gcode variables (best-effort)."""
    lim = data.get("limits") or {}
    bands = data.get("forbidden_velocity_bands") or []
    note = "; ".join(
        "%g-%g %s" % (float(b["lo"]), float(b["hi"]), b.get("reason") or "")
        for b in bands[:4]
    )[:180]
    cmds = [
        "SET_GCODE_VARIABLE MACRO=NCPSKY_NOISE_MAP VARIABLE=enabled VALUE=1",
        "SET_GCODE_VARIABLE MACRO=NCPSKY_NOISE_MAP VARIABLE=max_velocity VALUE=%g"
        % float(lim.get("max_velocity", 300)),
        "SET_GCODE_VARIABLE MACRO=NCPSKY_NOISE_MAP VARIABLE=max_accel VALUE=%g"
        % float(lim.get("max_accel", 3000)),
        "SET_GCODE_VARIABLE MACRO=NCPSKY_NOISE_MAP VARIABLE=max_accel_to_decel VALUE=%g"
        % float(lim.get("max_accel_to_decel", 1500)),
        "SET_GCODE_VARIABLE MACRO=NCPSKY_NOISE_MAP VARIABLE=pace_speed VALUE=%g"
        % float(lim.get("pace_speed", 80)),
        "SET_GCODE_VARIABLE MACRO=NCPSKY_NOISE_MAP VARIABLE=quiet_travel VALUE=%g"
        % float(lim.get("quiet_travel_mm_s", 50)),
        "SET_GCODE_VARIABLE MACRO=NCPSKY_NOISE_MAP VARIABLE=quiet_accel VALUE=%g"
        % float(lim.get("quiet_probe_accel", 1000)),
        "SET_GCODE_VARIABLE MACRO=NCPSKY_NOISE_MAP VARIABLE=source VALUE=%s"
        % _gcode_str_literal(str(data.get("source") or "")),
        "SET_GCODE_VARIABLE MACRO=NCPSKY_NOISE_MAP VARIABLE=ban_note VALUE=%s"
        % _gcode_str_literal(note or "none"),
    ]
    cmds.extend(_save_variable_cmds(lim, data.get("source") or "", note or "none"))
    try:
        gcode("\n".join(cmds), timeout=60)
    except Exception as ex:
        # Macro may not be loaded yet
        _set_job(message="macro sync skipped: %s" % ex)


def apply_noise_map(data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    data = data or load_map()
    lim = data.get("limits") or derive_limits(data, data.get("forbidden_velocity_bands") or [])
    sync_macro_variables(data)
    script = (
        "APPLY_NOISE_MAP"
        if True
        else "SET_VELOCITY_LIMIT VELOCITY=%g ACCEL=%g MINIMUM_CRUISE_RATIO=%g"
        % (
            float(lim["max_velocity"]),
            float(lim["max_accel"]),
            _cruise_ratio(lim["max_accel"], lim["max_accel_to_decel"]),
        )
    )
    try:
        gcode(script, timeout=60)
    except Exception:
        gcode(
            "SET_VELOCITY_LIMIT VELOCITY=%g ACCEL=%g MINIMUM_CRUISE_RATIO=%g"
            % (
                float(lim["max_velocity"]),
                float(lim["max_accel"]),
                _cruise_ratio(lim["max_accel"], lim["max_accel_to_decel"]),
            ),
            timeout=60,
        )
    return data


def ensure_homed() -> None:
    raw = _http_json(
        MOONRAKER.rstrip("/") + "/printer/objects/query?toolhead", timeout=15
    )
    st = ((raw.get("result") or {}).get("status")) or {}
    axes = ((st.get("toolhead") or {}).get("homed_axes")) or ""
    if "xyz" not in axes:
        gcode("G28", timeout=300)
        wait_ready(180)


def measure_tower_noise(
    velocity: float,
    accel: float,
    z_height: float,
    travel: float,
) -> Tuple[float, float, int, str]:
    """Host ADXL while the towers run ordinary step pulses. Does not change
    the printer's saved speed limit beyond this one measurement."""
    name = "nq%d" % int(round(velocity))
    csv_path = os.path.join(TMP, "adxl345-%s.csv" % name)
    try:
        os.remove(csv_path)
    except OSError:
        pass
    gcode(
        "SET_VELOCITY_LIMIT VELOCITY=%g ACCEL=%g MINIMUM_CRUISE_RATIO=0.5"
        % (max(velocity + 20.0, 50.0), accel)
    )
    gcode("G90\nG1 X0 Y0 Z%g F3000" % z_height, timeout=120)
    gcode("ACCELEROMETER_MEASURE CHIP=adxl345 NAME=%s" % name, timeout=30)
    feed = max(300, int(round(velocity * 60.0)))
    lines = []
    for ang in TOWER_ANGLES_DEG:
        rad = math.radians(ang)
        x = travel * math.cos(rad)
        y = travel * math.sin(rad)
        lines.append("G1 X%.3f Y%.3f Z%.3f F%d" % (x, y, z_height, feed))
        lines.append("G1 X0 Y0 Z%.3f F%d" % (z_height, feed))
    gcode("\n".join(lines), timeout=600)
    gcode("ACCELEROMETER_MEASURE NAME=%s" % name, timeout=60)
    wait_ready(60)
    if not os.path.isfile(csv_path):
        raise RuntimeError("ADXL csv missing: %s" % csv_path)
    rms, peak, n = parse_adxl_csv(csv_path)
    if n < 200:
        raise RuntimeError("ADXL sample too small n=%d" % n)
    return rms, peak, n, "adxl_host"


def run_sweep(
    velocities: Optional[List[float]] = None,
    accels: Optional[List[float]] = None,
    z_height: float = 30.0,
    travel: float = 90.0,
    merge_seed: bool = True,
    progress_cb: Optional[Callable[[float, str], None]] = None,
) -> Dict[str, Any]:
    velocities = [float(v) for v in (velocities or DEFAULT_VELOCITIES)]
    accels = [float(a) for a in (accels or DEFAULT_ACCELS)]
    total = max(1, len(velocities) * len(accels))
    done = 0
    samples: List[Dict[str, Any]] = []

    def prog(msg: str) -> None:
        p = done / float(total)
        if progress_cb:
            progress_cb(p, msg)
        _set_job(progress=p, phase="sweep", message=msg)

    prog("归零…")
    ensure_homed()
    # Ordinary StealthChop stepping. Host ADXL is safe once coil SPI is gone.
    prog("确认静音斩波…")
    gcode("NCPSKY_QUIET_APPLY", timeout=60)
    wait_ready(60)

    for accel in accels:
        for vel in velocities:
            prog("%.0f mm/s · ADXL采样三塔" % vel)
            rms, peak, n, drive = measure_tower_noise(
                vel, accel, z_height, travel
            )
            samples.append(
                {
                    "velocity": vel,
                    "accel": accel,
                    "rms": round(rms, 5),
                    "peak": round(peak, 5),
                    "n": n,
                    "csv": "",
                    "dirs": "towers_abc",
                    "drive": drive or "adxl_host",
                }
            )
            done += 1
            prog("%.0f mm/s · %s" % (vel, samples[-1]["drive"]))

    gcode("NCPSKY_QUIET_APPLY", timeout=60)

    data = build_map_from_samples(samples, load_default_map(), merge_seed=merge_seed)
    drives = sorted({str(s.get("drive") or "") for s in samples if s.get("drive")})
    data["drive"] = ",".join(drives) if drives else "adxl_host"
    save_map(data)
    sync_macro_variables(data)
    return data


def start_sweep_async(**kwargs: Any) -> Dict[str, Any]:
    with _lock:
        if _job.get("busy"):
            return {"ok": False, "error": "noise map already running", **job_status()}
        _job.update(
            {
                "busy": 1,
                "phase": "starting",
                "progress": 0.0,
                "error": "",
                "message": "准备中",
            }
        )

    def worker() -> None:
        try:
            data = run_sweep(**kwargs)
            _set_job(
                busy=0,
                phase="done",
                progress=1.0,
                message="完成",
                error="",
                result_bands=data.get("forbidden_velocity_bands"),
                limits=data.get("limits"),
            )
            try:
                gcode(
                    "SET_GCODE_VARIABLE MACRO=NCPSKY_NOISE_MAP_STATUS "
                    "VARIABLE=phase VALUE='\"done\"'\n"
                    "SET_GCODE_VARIABLE MACRO=NCPSKY_NOISE_MAP_STATUS "
                    "VARIABLE=busy VALUE=0\n"
                    "APPLY_NOISE_MAP",
                    timeout=60,
                )
            except Exception:
                pass
        except Exception as ex:
            _set_job(
                busy=0,
                phase="error",
                progress=0.0,
                error=str(ex),
                message="failed",
            )
            try:
                err = str(ex).replace('"', "").replace("'", "")[:120]
                gcode(
                    "SET_GCODE_VARIABLE MACRO=NCPSKY_NOISE_MAP_STATUS "
                    "VARIABLE=phase VALUE='\"error\"'\n"
                    "SET_GCODE_VARIABLE MACRO=NCPSKY_NOISE_MAP_STATUS "
                    "VARIABLE=err VALUE=\"%s\"\n"
                    "SET_GCODE_VARIABLE MACRO=NCPSKY_NOISE_MAP_STATUS "
                    "VARIABLE=busy VALUE=0" % err,
                    timeout=30,
                )
            except Exception:
                pass

    threading.Thread(target=worker, daemon=True).start()
    return {"ok": True, **job_status()}


def ensure_default_installed() -> str:
    """Copy default seed to config if noise_map.json missing."""
    if os.path.isfile(MAP_PATH):
        return MAP_PATH
    data = load_default_map()
    data["source"] = data.get("source") or "default_seed"
    return save_map(data)


def noise_curve(samples: Optional[List[Dict[str, Any]]] = None) -> List[Dict[str, float]]:
    """Aggregate max RMS per velocity for panel noise-speed chart."""
    by_v: Dict[float, float] = {}
    for s in samples or []:
        try:
            v = float(s.get("v") or s.get("velocity") or 0)
            rms = float(s.get("rms") or 0)
        except (TypeError, ValueError):
            continue
        if v <= 0 or rms < 0:
            continue
        prev = by_v.get(v)
        if prev is None or rms > prev:
            by_v[v] = rms
    return [{"v": v, "rms": by_v[v]} for v in sorted(by_v.keys())]


def map_summary(data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    data = data or load_map()
    samples = data.get("samples") or []
    return {
        "ok": True,
        "path": MAP_PATH if os.path.isfile(MAP_PATH) else None,
        "source": data.get("source"),
        "bands": data.get("forbidden_velocity_bands") or [],
        "limits": data.get("limits") or {},
        "preferred_accel": data.get("preferred_accel"),
        "sample_count": len(samples),
        "curve": noise_curve(samples),
        "updated_at": data.get("updated_at"),
        "job": job_status(),
    }


def main() -> None:
    import argparse

    global MOONRAKER, CONFIG_DIR, MAP_PATH

    ap = argparse.ArgumentParser(description="NCPSKY ADXL noise speed map")
    ap.add_argument("--moonraker", default=None)
    ap.add_argument("--config-dir", default=None)
    ap.add_argument("--install-default", action="store_true")
    ap.add_argument("--apply", action="store_true")
    ap.add_argument("--sweep", action="store_true")
    ap.add_argument("--no-merge-seed", action="store_true")
    ap.add_argument("--velocities", default="")
    ap.add_argument("--accels", default="")
    args = ap.parse_args()

    if args.moonraker:
        MOONRAKER = args.moonraker
    if args.config_dir:
        CONFIG_DIR = args.config_dir
        MAP_PATH = os.path.join(CONFIG_DIR, "noise_map.json")

    if args.install_default:
        path = ensure_default_installed()
        print("installed", path)
        sync_macro_variables(load_map())
        return
    if args.apply:
        data = apply_noise_map()
        print(json.dumps(map_summary(data), indent=2))
        return
    if args.sweep:
        vels = (
            [float(x) for x in args.velocities.split(",") if x.strip()]
            if args.velocities
            else None
        )
        accs = (
            [float(x) for x in args.accels.split(",") if x.strip()]
            if args.accels
            else None
        )
        data = run_sweep(
            velocities=vels,
            accels=accs,
            merge_seed=not args.no_merge_seed,
            progress_cb=lambda p, m: print("%.0f%% %s" % (p * 100, m), flush=True),
        )
        print(json.dumps(map_summary(data), indent=2))
        return
    print(json.dumps(map_summary(), indent=2))


if __name__ == "__main__":
    main()
