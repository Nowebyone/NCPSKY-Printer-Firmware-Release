#!/bin/bash
set +e
export HOME=/home/pi
PANEL_ROOT=/home/pi/ncpsky-panel
QT_ROOT=/home/pi/qt/arm_qt_environment
OUT=/home/pi/qt/out_linux
TSLIB_ROOT=/home/pi/qt/arm_tslib

export LD_LIBRARY_PATH="${OUT}/lib/log4cpp:${OUT}/lib:${QT_ROOT}/lib:${QT_ROOT}/plugins/platforms:/usr/local/lib:/usr/lib/arm-linux-gnueabihf/rkmedia:${TSLIB_ROOT}/lib"
export QT_QPA_PLATFORM_PLUGIN_PATH="${QT_ROOT}/plugins"
export QT_PLUGIN_PATH="${QT_ROOT}/plugins"
export QT_QPA_FONTDIR=/home/pi/qt/fonts
export QT_QPA_PLATFORM="linuxfb:fb=/dev/fb0:tty=/dev/tty0"
export QT_QPA_FB_HIDECURSOR=1
export QT_QPA_EGLFS_HIDECURSOR=1
export QT_QPA_FB_TSLIB=1
export QT_QPA_GENERIC_PLUGINS=
# Starve evdev mouse discovery — touchscreen must not also become a pointer cursor source
unset QT_QPA_EVDEV_MOUSE_PARAMETERS
unset QT_QPA_FB_DISABLE_INPUT
unset QT_QPA_EVDEV_TOUCHSCREEN_PARAMETERS
unset DISPLAY

export TSLIB_ROOT="${TSLIB_ROOT}"
export TSLIB_TSDEVICE=/dev/input/event1
export TSLIB_FBDEVICE=/dev/fb0
export TSLIB_PLUGINDIR="${TSLIB_ROOT}/lib/ts"
export TSLIB_CONSOLEDEVICE=none
export TSLIB_CONFFILE="${TSLIB_ROOT}/etc/ts.conf"
export TSLIB_CALIBFILE=/etc/pointercal
export XDG_RUNTIME_DIR=/tmp/runtime-ncpsky
mkdir -p "$XDG_RUNTIME_DIR"
chmod 700 "$XDG_RUNTIME_DIR" 2>/dev/null || true
export QML2_IMPORT_PATH="${PANEL_ROOT}/qml:${QT_ROOT}/qml"
export NCPSKY_QML_ROOT="${PANEL_ROOT}/qml"
export LD_PRELOAD="${TSLIB_ROOT}/lib/libts.so"

(setterm -cursor off >/dev/tty0 2>/dev/null) || true
(printf '\033[?25l' >/dev/tty0 2>/dev/null) || true

LOCK=/tmp/ncpsky-panel.lock
exec 9>"$LOCK"
if ! flock -n 9; then
  echo "ncpsky-panel already running" >&2
  exit 0
fi

# Engines older than 0.7.27 ignore stack/mainsail. The panel zip carries the
# same web root; copy it once the bundle stamp changes, then start the UI.
_install_web_payload() {
  local payload="${PANEL_ROOT}/payload/mainsail"
  local stamp_src="${payload}/.ncpsky-bundle"
  local dest="/home/pi/mainsail"
  local stamp_dst="${dest}/.ncpsky-bundle"
  local theme="${PANEL_ROOT}/payload/mainsail-theme"
  [ -f "${payload}/index.html" ] || return 0
  [ -f "${stamp_src}" ] || return 0
  if [ -f "${stamp_dst}" ] && cmp -s "${stamp_src}" "${stamp_dst}"; then
    return 0
  fi
  mkdir -p "${dest}" 2>/dev/null || true
  if ! cp -a "${payload}/." "${dest}/" 2>/dev/null; then
    echo 1 | sudo -S bash -c "rm -rf '${dest}' && mkdir -p '${dest}' && cp -a '${payload}/.' '${dest}/' && chown -R pi:pi '${dest}'" || return 0
  fi
  chown -R pi:pi "${dest}" 2>/dev/null || true
  if [ -d "${theme}" ]; then
    mkdir -p /home/pi/printer_data/config/.theme 2>/dev/null || true
    cp -a "${theme}/." /home/pi/printer_data/config/.theme/ 2>/dev/null || \
      echo 1 | sudo -S bash -c "mkdir -p /home/pi/printer_data/config/.theme && cp -a '${theme}/.' /home/pi/printer_data/config/.theme/ && chown -R pi:pi /home/pi/printer_data/config/.theme" || true
  fi
}
_install_web_payload

# Local CSV bridge for real shaper spectrum (panel has no WebSocket /tmp access)
# Prefer freeing the port — avoid `pkill -f` matching this launcher script.
(fuser -k 7126/tcp >/dev/null 2>&1) || true
python3 "${PANEL_ROOT}/scripts/local_fileserver.py" >/tmp/ncpsky_fileserver.log 2>&1 &

cd "${PANEL_ROOT}/qml"
if [ -x "${PANEL_ROOT}/bin/ncpsky-panel" ]; then
  exec "${PANEL_ROOT}/bin/ncpsky-panel"
fi
exec "${QT_ROOT}/bin/qmlscene" main.qml
