#!/usr/bin/env python3
"""Generate early-boot static brand frames + hold PNG for Splash bridge.

Flow:
  zzcat: black → static brand still → hold
  Splash: show same still → fade to black → full radar Splash intro
"""
from __future__ import annotations

import math
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "assets" / "boot_zzcat"
HOLD_PNG = ROOT / "assets" / "boot_hold.png"
W, H = 480, 272
FRAME_BYTES = 524288
FB_BYTES = W * H * 4


def font(size: int) -> ImageFont.ImageFont:
    for p in (
        Path(r"C:\Windows\Fonts\SourceHanSansCN-Bold.otf"),
        Path(r"C:\Windows\Fonts\msyhbd.ttc"),
        Path(r"C:\Windows\Fonts\segoeuib.ttf"),
        Path(r"C:\Windows\Fonts\arialbd.ttf"),
    ):
        if p.exists():
            try:
                return ImageFont.truetype(str(p), size)
            except Exception:
                pass
    return ImageFont.load_default()


def ease_out_cubic(t: float) -> float:
    t = max(0.0, min(1.0, t))
    return 1 - (1 - t) ** 3


def ease_in_out(t: float) -> float:
    t = max(0.0, min(1.0, t))
    return 3 * t * t - 2 * t * t * t


def draw_static_brand(t: float) -> Image.Image:
    """t=0 black … t=1 polished static brand (triangle + NCPSKY). No progress bar."""
    t = max(0.0, min(1.0, t))
    e = ease_out_cubic(t)
    img = Image.new("RGB", (W, H), (4, 6, 6))
    if e < 0.002:
        return img

    draw = ImageDraw.Draw(img, "RGBA")
    cx, cy = W // 2, H // 2 - 28

    # soft wash
    wash = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    wd = ImageDraw.Draw(wash)
    a = int(36 * e)
    r = int(70 + 50 * e)
    wd.ellipse((cx - r, cy - r, cx + r, cy + r), fill=(167, 139, 250, a))
    wash = wash.filter(ImageFilter.GaussianBlur(26))
    img = Image.alpha_composite(img.convert("RGBA"), wash).convert("RGB")
    draw = ImageDraw.Draw(img, "RGBA")

    # quiet concentric rings (static)
    ring_t = ease_in_out(min(1.0, t / 0.55))
    for i in range(5):
        appear = ease_out_cubic(max(0.0, min(1.0, ring_t * 1.2 - i * 0.12)))
        if appear <= 0:
            continue
        rad = 22 + i * 14
        alpha = int((28 - i * 3) * appear)
        draw.ellipse((cx - rad, cy - rad, cx + rad, cy + rad), outline=(167, 139, 250, alpha), width=1)

    # triangle mark
    mark_t = ease_out_cubic(max(0.0, min(1.0, (t - 0.18) / 0.40)))
    if mark_t > 0:
        scale = 0.4 + 0.6 * mark_t
        th = int(78 * scale)
        tw = int(90 * scale)
        ma = int(255 * mark_t)
        tri = [(cx, cy - th // 2), (cx + tw // 2, cy + th // 2), (cx - tw // 2, cy + th // 2)]
        draw.polygon(tri, fill=(167, 139, 250, ma))
        ith, itw = int(th * 0.42), int(tw * 0.5)
        inner = [
            (cx, cy - ith // 2 + 5),
            (cx + itw // 2, cy + ith // 2 + 3),
            (cx - itw // 2, cy + ith // 2 + 3),
        ]
        draw.polygon(inner, fill=(4, 6, 6, ma))

    # brand block
    text_t = ease_out_cubic(max(0.0, min(1.0, (t - 0.42) / 0.40)))
    if text_t > 0.01:
        f1 = font(30)
        f2 = font(14)
        f3 = font(9)
        ba = int(255 * text_t)
        brand = "NCPSKY"
        bbox = draw.textbbox((0, 0), brand, font=f1)
        bw, bh = bbox[2] - bbox[0], bbox[3] - bbox[1]
        bx = (W - bw) // 2
        by = cy + 52
        draw.text((bx, by + 1), brand, font=f1, fill=(0, 0, 0, int(110 * text_t)))
        draw.text((bx, by), brand, font=f1, fill=(240, 242, 244, ba))
        rw = int(88 * text_t)
        ry = by + bh + 8
        draw.rectangle(((W - rw) // 2, ry, (W + rw) // 2, ry + 2), fill=(167, 139, 250, ba))

        sub_t = ease_out_cubic(max(0.0, min(1.0, (t - 0.58) / 0.32)))
        sa = int(255 * sub_t)
        if sa > 4:
            m = "DTMax"
            mb = draw.textbbox((0, 0), m, font=f2)
            draw.text(((W - (mb[2] - mb[0])) // 2, ry + 10), m, font=f2, fill=(160, 168, 174, sa))
            tag = "DELTA SERIES"
            tb = draw.textbbox((0, 0), tag, font=f3)
            draw.text(((W - (tb[2] - tb[0])) // 2, ry + 30), tag, font=f3, fill=(110, 118, 124, sa))

    return img.convert("RGB")


def to_bgra(img: Image.Image) -> bytes:
    img = img.convert("RGB")
    buf = bytearray(FB_BYTES)
    i = 0
    px = img.load()
    for y in range(H):
        for x in range(W):
            r, g, b = px[x, y]
            buf[i : i + 4] = bytes((b, g, r, 255))
            i += 4
    raw = bytes(buf)
    if len(raw) < FRAME_BYTES:
        raw = raw + b"\x00" * (FRAME_BYTES - len(raw))
    return raw[:FRAME_BYTES]


def main() -> None:
    intro_dir = OUT / "intro"
    loop_dir = OUT / "loop"
    preview = OUT / "preview"
    for d in (intro_dir, loop_dir, preview):
        d.mkdir(parents=True, exist_ok=True)

    intro_ids = list(range(1, 88, 2))
    hold_img = None
    hold_raw = None
    for idx, n in enumerate(intro_ids):
        u = idx / max(1, len(intro_ids) - 1)
        img = draw_static_brand(u)
        raw = to_bgra(img)
        (intro_dir / f"{n}.raw").write_bytes(raw)
        if idx % 5 == 0 or n in (1, 43, 87):
            img.save(preview / f"fade_{n:02d}.png")
        if n == 87:
            hold_img = img
            hold_raw = raw

    assert hold_img is not None and hold_raw is not None
    hold_img.save(preview / "hold_static.png")
    hold_img.save(HOLD_PNG)
    print("hold png", HOLD_PNG)

    for n in range(1, 54, 2):
        (loop_dir / f"{n}.raw").write_bytes(hold_raw)
    for name in ("poweroff.raw", "u0.raw", "u25.raw", "u50.raw", "u75.raw", "u100.raw"):
        (OUT / name).write_bytes(hold_raw)

    print("static brand fade", len(intro_ids), "→ hold; Splash will black-bridge into radar")


if __name__ == "__main__":
    main()
