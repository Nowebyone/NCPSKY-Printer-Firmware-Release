#!/usr/bin/env python3
"""Offline checks for the calibrate-to-print flow. No printer required."""
from __future__ import annotations

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PANEL = os.path.abspath(os.path.join(HERE, "..", ".."))
OVERLAY = os.path.join(PANEL, "klipper_overlays")
sys.path.insert(0, OVERLAY)

from ncpsky_print_limits import combine_print_accel, shaper_freq_accepted  # noqa: E402


def read(path):
    with open(path, encoding="utf-8") as handle:
        return handle.read()


def macro_body(text, name):
    marker = "[gcode_macro %s]" % name
    start = text.find(marker)
    if start < 0:
        raise AssertionError("missing macro %s" % name)
    rest = text[start + len(marker):]
    nxt = rest.find("\n[")
    body = rest if nxt < 0 else rest[:nxt]
    gcode_at = body.find("\ngcode:")
    return body[gcode_at:] if gcode_at >= 0 else body


def main():
    calib_a = read(os.path.join(PANEL, "config", "ncpsky_calib.cfg"))
    calib_b = read(os.path.join(PANEL, "ota", "stack_templates", "macros", "ncpsky_calib.cfg"))
    if calib_a != calib_b:
        raise AssertionError("ncpsky_calib.cfg copies differ")
    if "NCPSKY_PID_CALIBRATE" not in calib_a:
        raise AssertionError("PID calibrate macro missing")
    mesh = macro_body(calib_a, "NCPSKY_CALIBRATE_MESH")
    if 'if "xyz" not in printer.toolhead.homed_axes' not in mesh:
        raise AssertionError("mesh macro must home only when needed")
    if "\n  G28\n  _NCPSKY_ENSURE_PROBE_HEAT" in mesh:
        raise AssertionError("mesh macro still forces G28 before heat")

    noise_a = read(os.path.join(PANEL, "config", "ncpsky_noise_map.cfg"))
    noise_b = read(os.path.join(PANEL, "ota", "stack_templates", "macros", "ncpsky_noise_map.cfg"))
    if noise_a != noise_b:
        raise AssertionError("ncpsky_noise_map.cfg copies differ")
    fallback = macro_body(noise_a, "_NCPSKY_NOISE_MAP_FALLBACK") if False else noise_a
    # delayed_gcode, not gcode_macro
    if 'phase VALUE=\'"seed_applied"\'' in noise_a or "seed_applied" in noise_a:
        raise AssertionError("noise fallback must not report seed_applied")
    if 'phase VALUE=\'"error"\'' not in noise_a:
        raise AssertionError("noise fallback must set phase=error")
    if "_NCPSKY_LOAD_NOISE_LIMITS" not in noise_a:
        raise AssertionError("noise limits must reload from save_variables")

    printer_a = read(os.path.join(PANEL, "ota", "stack_templates", "config", "printer.cfg"))
    printer_b = read(os.path.join(PANEL, "ota", "printer_cfg_baseline.cfg"))
    if printer_a != printer_b:
        raise AssertionError("printer.cfg copies differ")
    if "F100" in printer_a or "F108" in printer_a:
        raise AssertionError("unimplemented F100/F108 still called")
    if "LOAD_FUNCTION_SWITCH" in printer_a:
        raise AssertionError("missing LOAD_FUNCTION_SWITCH still called")
    if "bed_level_2" in macro_body(printer_a, "LOAD_GCODE_OFFSETS") if False else "bed_level_2" in printer_a[printer_a.find("[delayed_gcode LOAD_GCODE_OFFSETS]"):printer_a.find("[idle_timeout]")]:
        raise AssertionError("boot still auto-runs bed_level_2")
    start = macro_body(printer_a, "START_PRINT")
    if "CURRENT=0.8" in start:
        raise AssertionError("START_PRINT still drops extruder current to 0.8 A")
    if start.find("G28") < 0 or start.find("APPLY_NOISE_MAP") < start.find("G28"):
        raise AssertionError("APPLY_NOISE_MAP must follow G28")
    if "CURRENT=1.1" not in macro_body(printer_a, "RESTORE_E_CURRENT"):
        raise AssertionError("RESTORE_E_CURRENT must match extruder run_current 1.1")
    if "-0.50001" not in printer_a:
        raise AssertionError("Z offset clamp should be +/- 0.5 mm")
    measure = macro_body(printer_a, "MEASURING_RESONANCES")
    if "SAVE_CONFIG" in measure or "SHAPER_CALIBRATE AXIS" in measure:
        raise AssertionError("MEASURING_RESONANCES must only schedule the panel job")
    if "NCPSKY_SHAPER_CALIBRATE" not in measure:
        raise AssertionError("MEASURING_RESONANCES must call NCPSKY_SHAPER_CALIBRATE")

    page = read(os.path.join(PANEL, "qml", "pages", "CalibratePage.qml"))
    order = [page.find('id: "pid"'), page.find('id: "motor_noise"'),
             page.find('id: "shaper"'), page.find('id: "bed"')]
    if any(i < 0 for i in order) or order != sorted(order):
        raise AssertionError("calibrate steps must be pid, motor_noise, shaper, bed")
    if 'q.push({ id: "home"' in page:
        raise AssertionError("queue must not force a leading G28")
    if 'step.id === "save"' in page and "ok = true" in page:
        raise AssertionError("SAVE_CONFIG failure must not be treated as success")
    if "不能当作本次降噪结果" not in page:
        raise AssertionError("seed_applied must fail the noise step")
    if "emergencyStopCalib" not in page:
        raise AssertionError("calibration page needs an emergency stop")
    if 'text.indexOf("NCPSKY phase:") >= 0' in page:
        raise AssertionError("tmc done-detect must not match any NCPSKY phase: line")
    if "NCPSKY quiet: 校准完成" not in page:
        raise AssertionError("tmc done-detect must require quiet 校准完成")
    if "震动补偿不合格" not in page:
        raise AssertionError("rejected shaper must fail the calibrate queue")
    if "NCPSKY_PID_JOB_RUN" not in calib_a:
        raise AssertionError("PID delayed job must call NCPSKY_PID_JOB_RUN")
    if "[ncpsky_pid]" not in calib_a:
        raise AssertionError("ncpsky_pid section missing from calib cfg")
    pid_py = os.path.join(OVERLAY, "ncpsky_pid.py")
    if not os.path.isfile(pid_py):
        raise AssertionError("ncpsky_pid.py overlay missing")

    app = read(os.path.join(PANEL, "qml", "AppState.qml"))
    if "CALIBRATE_MOTOR_NOISE" in app:
        raise AssertionError("print start must not run CALIBRATE_MOTOR_NOISE")
    if "没有已保存的床网" not in app:
        raise AssertionError("startPrint must block when default bed mesh is missing")
    cancel_at = app.find("function cancelPrint")
    cancel_body = app[cancel_at:cancel_at + 450]
    if "printPreparing && !printing" in cancel_body:
        raise AssertionError("cancelPrint must not skip Moonraker cancel during prep")
    if 'httpPost("/printer/print/cancel"' not in cancel_body:
        raise AssertionError("cancelPrint must always post print/cancel")

    if not shaper_freq_accepted(51.4, 5, 133.33):
        raise AssertionError("51.4 Hz should be accepted")
    if shaper_freq_accepted(149.8, 5, 133.33):
        raise AssertionError("149.8 Hz is outside the sweep and must be rejected")
    if shaper_freq_accepted(4.9, 5, 133.33):
        raise AssertionError("below min_freq must be rejected")
    if shaper_freq_accepted(133.33, 5, 133.33):
        raise AssertionError("a peak on max_freq must be rejected")

    if combine_print_accel(2500, 3000, 40000) != 2500:
        raise AssertionError("shaper suggestion should win when it is the smallest")
    if combine_print_accel(8000, 3000, 40000) != 3000:
        raise AssertionError("noise-map accel should cap a high shaper suggestion")
    if combine_print_accel(None, 3000, 40000) != 3000:
        raise AssertionError("no shaper must not leave print accel at 40000")
    if combine_print_accel(None, 0, 40000) != 3000:
        raise AssertionError("missing noise map uses 3000, not printer travel accel")
    if combine_print_accel(3450, 3000, 40000) != 3000:
        raise AssertionError("rounded shaper accel is still limited by the noise map")

    quiet = read(os.path.join(OVERLAY, "ncpsky_quiet.py"))
    if "NCPSKY_QUIET_CALIBRATE" not in quiet:
        raise AssertionError("quiet calibrate command missing")
    if "direct_mode" in quiet:
        raise AssertionError("quiet policy must not enter direct mode")
    noise_py = read(os.path.join(PANEL, "scripts", "ncpsky_noise_map.py"))
    if "NCPSKY_PHASE_APPLY" in noise_py or "xdirect" in noise_py:
        raise AssertionError("noise sweep must not use XDIRECT")
    if "ACCELEROMETER_MEASURE" not in noise_py:
        raise AssertionError("noise sweep must use the host ADXL")
    limits_py = read(os.path.join(OVERLAY, "ncpsky_print_limits.py"))
    note_at = limits_py.find("def note_shaper_accel")
    if note_at < 0:
        raise AssertionError("shaper must note print accel cap")
    if "combine_print_accel" not in limits_py[note_at:note_at + 250]:
        raise AssertionError("note_shaper_accel must combine with noise-map accel")

    # silence unused if the delayed_gcode branch above is the real check
    del fallback
    print("calib flow checks ok")


if __name__ == "__main__":
    main()
