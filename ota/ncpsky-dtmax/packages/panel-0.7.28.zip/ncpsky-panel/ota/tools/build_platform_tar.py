#!/usr/bin/env python3
"""Build platform OTA package (Qt / tslib / fonts / hooks / sing-box bits).

Layout inside archive:
  platform/META.json
  platform/files/<bucket>/...
Buckets map via META install_map to absolute roots on device.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import tarfile
from datetime import datetime, timezone

DEFAULT_MAP = {
    "qt": "/home/pi/qt",
    "tslib": "/usr/local/tslib",
    "fonts": "/usr/local/share/fonts/ncpsky",
    "hooks": "/home/pi/ncpsky-panel/ota/hooks",
    "sing-box": "/usr/local/bin",
    "etc": "/etc",
}


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def add_tree(tf, src_root, arc_prefix):
    if not src_root or not os.path.isdir(src_root):
        return 0
    n = 0
    for dirpath, _dirnames, filenames in os.walk(src_root):
        for fn in filenames:
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, src_root).replace("\\", "/")
            tf.add(full, arcname="%s/%s" % (arc_prefix, rel))
            n += 1
    return n


def main():
    ap = argparse.ArgumentParser(description="Build NCPSKY platform OTA tar.gz")
    ap.add_argument("--version", required=True, help="e.g. plat-2026.11.24.1")
    ap.add_argument("--out")
    ap.add_argument("--qt-dir", help="files to install under /home/pi/qt")
    ap.add_argument("--tslib-dir")
    ap.add_argument("--fonts-dir")
    ap.add_argument("--hooks-dir")
    ap.add_argument("--singbox-dir", help="sing-box binary dir → /usr/local/bin")
    ap.add_argument("--etc-dir", help="etc overlays")
    ap.add_argument("--files-root", help="pre-arranged platform/files tree")
    ap.add_argument("--notes", default="")
    ap.add_argument("--no-startboot", action="store_true")
    args = ap.parse_args()

    here = os.path.dirname(os.path.abspath(__file__))
    panel_root = os.path.abspath(os.path.join(here, "..", ".."))
    out_dir = os.path.join(panel_root, "ota", "dist")
    os.makedirs(out_dir, exist_ok=True)
    out = args.out or os.path.join(out_dir, "platform-%s.tar.gz" % args.version)

    meta = {
        "product": "NCPSKY ▲ DTMax",
        "firmware_target": "FLSun T1 Max",
        "kind": "platform",
        "version": args.version,
        "install_map": dict(DEFAULT_MAP),
        "rewrite_startboot": not args.no_startboot,
        "notes": args.notes,
        "built_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }

    with tarfile.open(out, "w:gz") as tf:
        data = (json.dumps(meta, indent=2, ensure_ascii=False) + "\n").encode()
        info = tarfile.TarInfo(name="platform/META.json")
        info.size = len(data)
        tf.addfile(info, io.BytesIO(data))

        if args.files_root and os.path.isdir(args.files_root):
            add_tree(tf, args.files_root, "platform/files")
        else:
            buckets = {
                "qt": args.qt_dir,
                "tslib": args.tslib_dir,
                "fonts": args.fonts_dir,
                "hooks": args.hooks_dir,
                "sing-box": args.singbox_dir,
                "etc": args.etc_dir,
            }
            for key, src in buckets.items():
                if src:
                    add_tree(tf, src, "platform/files/%s" % key)

        # Always ship a tiny README so empty platform packages are still valid
        readme = (
            "# NCPSKY platform package\n"
            "Buckets under files/ map via META.json install_map.\n"
        ).encode()
        rinfo = tarfile.TarInfo(name="platform/README.md")
        rinfo.size = len(readme)
        tf.addfile(rinfo, io.BytesIO(readme))

    digest = sha256_file(out)
    with open(out + ".sha256", "w", encoding="utf-8") as f:
        f.write("%s  %s\n" % (digest, os.path.basename(out)))
    print(json.dumps({
        "id": "platform-%s" % args.version
        if not str(args.version).startswith("platform-") else args.version,
        "kind": "platform",
        "version": args.version,
        "file": os.path.basename(out),
        "sha256": digest,
        "size": os.path.getsize(out),
    }, indent=2, ensure_ascii=False))
    print("Wrote", out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
