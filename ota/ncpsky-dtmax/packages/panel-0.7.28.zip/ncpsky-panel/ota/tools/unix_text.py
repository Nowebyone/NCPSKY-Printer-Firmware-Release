"""Force Unix newlines when a Windows tree is packed into an OTA archive.

core.autocrlf leaves CR in the working copy. bash then rejects run_panel.sh
and the panel never starts after an update.
"""
from __future__ import annotations

import os

TEXT_EXTS = {
    ".sh", ".py", ".qml", ".js", ".json", ".md", ".txt", ".cfg", ".conf",
    ".ini", ".service", ".desktop", ".xml", ".yml", ".yaml", ".cmake",
    ".pro", ".pri", ".list", ".css", ".html", ".svg",
}
TEXT_NAMES = {
    "VERSION", "FIRMWARE_VERSION", "Makefile", "Kconfig", "Dockerfile",
}


def is_text_name(name):
    base = os.path.basename(str(name).replace("\\", "/"))
    ext = os.path.splitext(base)[1].lower()
    return ext in TEXT_EXTS or base in TEXT_NAMES


def unix_bytes(data):
    if b"\r" not in data:
        return data
    return data.replace(b"\r\n", b"\n").replace(b"\r", b"\n")


def read_payload(path, rel):
    with open(path, "rb") as fh:
        data = fh.read()
    if is_text_name(rel):
        data = unix_bytes(data)
    return data
