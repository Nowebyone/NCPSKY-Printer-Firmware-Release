#!/usr/bin/env python3
"""Build stack OTA zip: macros/templates + optional klipper/moonraker + printer.cfg baseline.

Default: pack local macros from printer_data/config (ncpsky_*.cfg) and
optional --klipper / --moonraker source trees (code only, no .git/venv).

printer.cfg: ships a SAVE_CONFIG-stripped baseline under stack/config/printer.cfg.
Live install replaces the managed body and keeps the machine SAVE_CONFIG block.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import tarfile
import tempfile
import zipfile
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPTS = os.path.abspath(os.path.join(HERE, "..", "..", "scripts"))
if SCRIPTS not in sys.path:
    sys.path.insert(0, SCRIPTS)

from printer_cfg_merge import strip_save_config  # noqa: E402


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def add_tree(zf, src_root, arc_prefix, skip_names=None):
    skip_names = skip_names or {
        ".git", "klippy-env", "moonraker-env", ".venv", "__pycache__",
        "out", "database", ".database",
    }
    if not src_root or not os.path.isdir(src_root):
        return 0
    n = 0
    for dirpath, dirnames, filenames in os.walk(src_root):
        dirnames[:] = [d for d in dirnames if d not in skip_names]
        for fn in filenames:
            if fn.endswith((".pyc", ".o", ".a")):
                continue
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, src_root).replace("\\", "/")
            zf.write(full, "%s/%s" % (arc_prefix, rel))
            n += 1
    return n


def mainsail_version_from(path):
    base = os.path.basename(path.rstrip("/\\"))
    for suffix in (".tar.gz", ".tgz", ".tar", ".zip"):
        if base.endswith(suffix):
            base = base[: -len(suffix)]
            break
    if base.startswith("mainsail-"):
        return base[len("mainsail-"):]
    return ""


def materialize_mainsail(path):
    """Return (root_dir, cleanup_or_None, version) with index.html at the root."""
    if not path:
        return None, None, ""
    version = mainsail_version_from(path)
    if os.path.isdir(path):
        root = path
        if os.path.isfile(os.path.join(path, "mainsail", "index.html")):
            root = os.path.join(path, "mainsail")
        if not os.path.isfile(os.path.join(root, "index.html")):
            raise SystemExit("mainsail dir has no index.html: %s" % path)
        return root, None, version
    if not os.path.isfile(path):
        raise SystemExit("mainsail path missing: %s" % path)
    tmp = tempfile.mkdtemp(prefix="ncpsky-mainsail-")
    with tarfile.open(path, "r:gz") as tf:
        tf.extractall(tmp)
    root = tmp
    if os.path.isfile(os.path.join(tmp, "mainsail", "index.html")):
        root = os.path.join(tmp, "mainsail")
    elif not os.path.isfile(os.path.join(tmp, "index.html")):
        for dirpath, _dirs, files in os.walk(tmp):
            if "index.html" in files:
                root = dirpath
                break
    if not os.path.isfile(os.path.join(root, "index.html")):
        shutil.rmtree(tmp, ignore_errors=True)
        raise SystemExit("mainsail archive has no index.html: %s" % path)
    return root, tmp, version


def stamp_mainsail(root, version):
    stamp = os.path.join(root, ".ncpsky-bundle")
    with open(stamp, "w", encoding="utf-8", newline="\n") as f:
        f.write("mainsail-%s\n" % (version or "unknown"))


def load_baseline_printer_cfg(path):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        text = f.read()
    body = strip_save_config(text)
    # Reject residual Klipper SAVE_CONFIG markers (comments mentioning the name are OK)
    for line in body.splitlines():
        s = line.strip()
        if s.startswith("#*#") and "SAVE_CONFIG" in s.upper():
            raise SystemExit("baseline printer.cfg still contains SAVE_CONFIG marker after strip")
    if not body.strip():
        raise SystemExit("baseline printer.cfg body empty")
    return body


def main():
    ap = argparse.ArgumentParser(description="Build NCPSKY stack OTA zip")
    ap.add_argument("--version", required=True, help="e.: 2026.11.23.1")
    ap.add_argument("--out", help="output zip")
    ap.add_argument("--macros-dir", help="dir of .cfg macros to ship")
    ap.add_argument("--klipper", help="optional klipper source root")
    ap.add_argument("--moonraker", help="optional moonraker source root")
    ap.add_argument("--mainsail", help="Mainsail web root or mainsail-*.tar.gz")
    ap.add_argument("--mainsail-theme", help="files copied to printer_data/config/.theme")
    ap.add_argument("--nginx", help="optional nginx site dir (mainsail, common_vars.conf, upstreams.conf)")
    ap.add_argument(
        "--printer-cfg",
        help="OTA-managed printer.cfg baseline (SAVE_CONFIG stripped on pack)",
    )
    ap.add_argument(
        "--no-printer-cfg",
        action="store_true",
        help="omit printer.cfg from stack (legacy)",
    )
    ap.add_argument(
        "--panel-root",
        default=None,
        help="ncpsky-panel root (for dist/)",
    )
    args = ap.parse_args()

    panel_root = args.panel_root or os.path.abspath(os.path.join(HERE, "..", ".."))
    out_dir = os.path.join(panel_root, "ota", "dist")
    os.makedirs(out_dir, exist_ok=True)
    out = args.out or os.path.join(out_dir, "stack-%s.zip" % args.version)

    macros = args.macros_dir
    if not macros:
        cand = os.path.join(panel_root, "ota", "stack_templates", "macros")
        if os.path.isdir(cand):
            macros = cand
        else:
            macros = "/home/pi/printer_data/config"

    printer_cfg = args.printer_cfg
    if not printer_cfg and not args.no_printer_cfg:
        for cand in (
            os.path.join(panel_root, "ota", "stack_templates", "config", "printer.cfg"),
            os.path.join(panel_root, "ota", "stack_templates", "config", "printer.cfg.ota"),
        ):
            if os.path.isfile(cand):
                printer_cfg = cand
                break

    if args.klipper:
        so = os.path.join(args.klipper, "klippy", "chelper", "c_helper.so")
        if not os.path.isfile(so):
            raise SystemExit("klipper tree is missing klippy/chelper/c_helper.so: %s" % so)

    web_root, web_tmp, web_ver = materialize_mainsail(args.mainsail)
    try:
        if web_root:
            stamp_mainsail(web_root, web_ver)
        _write_stack_zip(
            args, out, panel_root, printer_cfg, macros, web_root, web_ver
        )
    finally:
        if web_tmp:
            shutil.rmtree(web_tmp, ignore_errors=True)

    digest = sha256_file(out)
    with open(out + ".sha256", "w", encoding="utf-8") as f:
        f.write("%s  %s\n" % (digest, os.path.basename(out)))
    meta = {
        "id": "stack-%s" % args.version,
        "kind": "stack",
        "version": args.version,
        "file": os.path.basename(out),
        "sha256": digest,
        "size": os.path.getsize(out),
        "printer_cfg": bool(printer_cfg and not args.no_printer_cfg),
        "mainsail": web_ver,
        "built_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    print(json.dumps(meta, indent=2, ensure_ascii=False))
    print("Wrote", out)
    return 0


def _write_stack_zip(args, out, panel_root, printer_cfg, macros, web_root, web_ver):
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        info = (
            "product=NCPSKY DTMax\n"
            "firmware_target=FLSun T1 Max\n"
            "stack=%s\n"
            "klipper_core=0.14.0\n"
            % args.version
        ).encode()
        zf.writestr("stack/VERSION", info)
        zf.writestr(
            "stack/META.json",
            json.dumps({
                "product": "NCPSKY ▲ DTMax",
                "firmware_target": "FLSun T1 Max",
                "stack": args.version,
                "klipper_core": "0.14.0",
                "printer_cfg_replace": False,
                "printer_cfg_merge": True,
                "klipper": bool(args.klipper),
                "moonraker": bool(args.moonraker),
                "mainsail": web_ver or "",
            }, indent=2) + "\n",
        )

        if macros and os.path.isdir(macros):
            for fn in os.listdir(macros):
                # cfg + noise_map.default.json (and similar) land in printer_data/config
                if not (fn.endswith(".cfg") or fn.endswith(".conf") or fn.endswith(".json")):
                    continue
                if fn == "printer.cfg" or fn.startswith("printer-"):
                    continue
                if fn in ("moonraker.conf", "moonraker.asvc", "secrets.json"):
                    continue
                full = os.path.join(macros, fn)
                zf.write(full, "stack/macros/%s" % fn)

        add_tree(zf, args.klipper, "stack/klipper")
        add_tree(zf, args.moonraker, "stack/moonraker")
        if web_root:
            add_tree(zf, web_root, "stack/mainsail")
        if args.mainsail_theme:
            add_tree(zf, args.mainsail_theme, "stack/mainsail-theme")
        if args.nginx:
            add_tree(zf, args.nginx, "stack/nginx")
        for overlay_name in (
            "ncpsky_adaptive_mesh.py",
            "ncpsky_print_limits.py",
            "ncpsky_quiet.py",
            "ncpsky_pid.py",
            "ncpsky_shaper_mcu.py",
        ):
            overlay = os.path.join(panel_root, "klipper_overlays", overlay_name)
            if os.path.isfile(overlay):
                zf.write(overlay, "stack/klipper_extras/%s" % overlay_name)
        # TMC2160 electrical quieting lives in this patched Autotune module.
        autotune_dir = os.path.abspath(os.path.join(panel_root, "..", "t1max-tmc-autotune"))
        for name in ("autotune_tmc.py", "motor_constants.py"):
            src = os.path.join(autotune_dir, name)
            if os.path.isfile(src):
                zf.write(src, "stack/klipper_extras/%s" % name)

        include_snip = (
            "# NCPSKY stack includes — managed by OTA; do not put SAVE_CONFIG here\n"
            "[include ncpsky_calib.cfg]\n"
            "# ncpsky_calib.cfg pulls in ncpsky_noise_map.cfg (ADXL speed bans)\n"
        )
        zf.writestr("stack/config_templates/ncpsky_includes.cfg", include_snip)

        if printer_cfg and not args.no_printer_cfg:
            body = load_baseline_printer_cfg(printer_cfg)
            zf.writestr("stack/config/printer.cfg", body)
            # Keep .ota name as alias for tooling clarity
            zf.writestr("stack/config/printer.cfg.ota", body)


if __name__ == "__main__":
    sys.exit(main())
