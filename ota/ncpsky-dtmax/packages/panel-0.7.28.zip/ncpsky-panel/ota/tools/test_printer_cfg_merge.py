#!/usr/bin/env python3
"""Unit checks for printer.cfg OTA merge."""
from __future__ import annotations

import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPTS = os.path.abspath(os.path.join(HERE, "..", "..", "scripts"))
sys.path.insert(0, SCRIPTS)

from printer_cfg_merge import (  # noqa: E402
    merge_printer_cfg_text,
    replace_printer_cfg_text,
    split_save_config,
)


LIVE = """# live preamble
[include ncpsky_includes.cfg]

[mcu]
serial: /dev/serial/by-id/usb-LIVE-BOARD

[printer]
kinematics: delta
max_velocity: 200

#*# <---------------------- SAVE_CONFIG ---------------------->
#*# [probe]
#*# z_offset = 1.23
#*# [bed_mesh default]
#*# points =
#*#   0.1, 0.2
"""

INCOMING = """# OTA managed
[include ncpsky_includes.cfg]

[mcu]
serial: /dev/serial/by-id/usb-PLACEHOLDER

[printer]
kinematics: delta
max_velocity: 300
max_accel: 4000

[output_pin accessory_fan]
pin: PA8
"""


def test_split():
    body, save = split_save_config(LIVE)
    assert "SAVE_CONFIG" not in body
    assert "SAVE_CONFIG" in save
    assert "z_offset = 1.23" in save


def test_merge_keeps_save_and_serial():
    out = merge_printer_cfg_text(LIVE, INCOMING)
    assert "max_accel: 4000" in out
    assert "accessory_fan" in out
    assert "usb-LIVE-BOARD" in out
    assert "usb-PLACEHOLDER" not in out
    assert "#*# <---------------------- SAVE_CONFIG ---------------------->" in out
    assert "z_offset = 1.23" in out
    # SAVE_CONFIG after managed body
    assert out.index("accessory_fan") < out.index("SAVE_CONFIG")


def test_replace_drops_calibration_keeps_serial():
    out = replace_printer_cfg_text(LIVE, INCOMING)
    assert "max_accel: 4000" in out
    assert "usb-LIVE-BOARD" in out
    assert "usb-PLACEHOLDER" not in out
    assert "z_offset = 1.23" not in out
    assert "points =" not in out
    assert "#*#" not in out


def test_merge_drops_manual_current_keeps_mesh():
    live = """[tmc5160 stepper_a]
run_current: 2.5

[mcu]
serial: /dev/serial/by-id/usb-LIVE-BOARD

#*# <---------------------- SAVE_CONFIG ---------------------->
#*# [bed_mesh default]
#*# points =
#*#   0.1, 0.2
"""
    incoming = """[tmc5160 stepper_a]
run_current: 1.2

[mcu]
serial: /dev/serial/by-id/usb-PLACEHOLDER
"""
    out = merge_printer_cfg_text(live, incoming)
    assert "run_current: 1.2" in out
    assert "run_current: 2.5" not in out
    assert "0.1, 0.2" in out
    assert "usb-LIVE-BOARD" in out


def test_merge_without_live_save():
    live = "[mcu]\nserial: /dev/ttyACM0\n"
    incoming = "[mcu]\nserial: /dev/null\n[printer]\nkinematics: delta\n"
    out = merge_printer_cfg_text(live, incoming)
    assert "ttyACM0" in out
    assert "SAVE_CONFIG" not in out


def main():
    test_split()
    test_merge_keeps_save_and_serial()
    test_replace_drops_calibration_keeps_serial()
    test_merge_drops_manual_current_keeps_mesh()
    test_merge_without_live_save()
    # file roundtrip
    with tempfile.TemporaryDirectory() as td:
        live_p = os.path.join(td, "live.cfg")
        inc_p = os.path.join(td, "inc.cfg")
        bak = os.path.join(td, "bak.cfg")
        open(live_p, "w", encoding="utf-8").write(LIVE)
        open(inc_p, "w", encoding="utf-8").write(INCOMING)
        from printer_cfg_merge import merge_printer_cfg_files

        merge_printer_cfg_files(live_p, inc_p, backup_path=bak)
        text = open(live_p, encoding="utf-8").read()
        assert "z_offset = 1.23" in text
        assert os.path.isfile(bak)
    print("ok")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
