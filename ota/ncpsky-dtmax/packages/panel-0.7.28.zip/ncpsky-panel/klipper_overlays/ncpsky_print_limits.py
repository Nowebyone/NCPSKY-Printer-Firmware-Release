# Print-time accel ceiling from input-shaper calibration.
# Travel and homing keep the printer max_accel. A cap of 0 means
# shaper calibration has not produced a number yet.
#
# Also bridges stock SHAPER_CALIBRATE → note_shaper_accel + panel
# NCPSKY_SHAPER_STATUS freq_x/y (those were previously never updated).
import logging


def shaper_freq_accepted(freq, min_freq=5.0, max_freq=133.33):
    """Accept a fitted peak only when it sits inside the sweep band.

    Klipper may report a frequency above max_freq (the fit window is wider
    than the sweep). Those edge peaks are not written into [input_shaper].
    """
    try:
        value = float(freq)
        lo = float(min_freq)
        hi = float(max_freq)
    except (TypeError, ValueError):
        return False
    if not hi > lo:
        return False
    return lo <= value < hi


def combine_print_accel(shaper_accel, noise_accel, printer_accel):
    """Print acceleration cap.

    With no accepted shaper, use the noise-map accel (or 3000), never the
    travel accel from [printer]. A shaper suggestion is rounded to 100 and
    then limited by that same ceiling.
    """
    try:
        noise = float(noise_accel)
    except (TypeError, ValueError):
        noise = 0.
    if noise <= 0.:
        noise = 3000.
    try:
        printer = float(printer_accel)
    except (TypeError, ValueError):
        printer = 0.
    if printer > 0.:
        noise = min(noise, printer)
    if shaper_accel is None:
        return noise
    try:
        raw = float(shaper_accel)
    except (TypeError, ValueError):
        return noise
    if raw <= 0.:
        return noise
    rounded = round(raw / 100.) * 100.
    if rounded < 100.:
        rounded = 100.
    return min(rounded, noise)


class NcpskyPrintLimits:
    def __init__(self, config):
        self.printer = config.get_printer()
        self.cap = config.getfloat('max_accel', 0., minval=0.)
        self.travel_accel = config.getsection('printer').getfloat(
            'max_accel', above=0.)
        self.shaper_min_freq = 5.
        self.shaper_max_freq = 133.33
        try:
            tester = config.getsection('resonance_tester')
            self.shaper_min_freq = tester.getfloat('min_freq', 5.)
            self.shaper_max_freq = tester.getfloat('max_freq', 133.33)
        except Exception:
            logging.info("ncpsky print_limits: resonance_tester defaults")
        self._pending = None
        self._m204 = None
        self._set_velocity = None
        self._shaper_cmd = None
        self.gcode = self.printer.lookup_object('gcode')
        self.gcode.register_command(
            'NCPSKY_PRINT_LIMITS_BEGIN', self.cmd_BEGIN,
            desc=self.cmd_BEGIN_help)
        self.gcode.register_command(
            'NCPSKY_PRINT_LIMITS_RESTORE', self.cmd_RESTORE,
            desc=self.cmd_RESTORE_help)
        self.printer.register_event_handler('klippy:connect', self._connect)

    def _connect(self):
        gcode = self.gcode
        self._m204 = gcode.register_command('M204', None)
        if self._m204 is not None:
            gcode.register_command('M204', self.cmd_M204)
        self._set_velocity = gcode.register_command('SET_VELOCITY_LIMIT', None)
        if self._set_velocity is not None:
            gcode.register_command(
                'SET_VELOCITY_LIMIT', self.cmd_SET_VELOCITY_LIMIT)
        stats = self.printer.lookup_object('print_stats', None)
        if stats is not None:
            orig_start = stats.note_start
            orig_finish = stats._note_finish

            def note_start():
                orig_start()
                self.apply_cap()

            def note_finish(state, error_message=''):
                orig_finish(state, error_message)
                if stats.state in ('complete', 'error', 'cancelled'):
                    self.restore_travel()

            stats.note_start = note_start
            stats._note_finish = note_finish
        # Ready fires after all extras register SHAPER_CALIBRATE.
        self.printer.register_event_handler('klippy:ready', self._hook_shaper)

    def _hook_shaper(self):
        if self._shaper_cmd is not None:
            return
        orig = self.gcode.register_command('SHAPER_CALIBRATE', None)
        if orig is None:
            logging.info("ncpsky print_limits: no SHAPER_CALIBRATE to wrap")
            return
        self._shaper_cmd = orig
        try:
            from extras import shaper_calibrate as sc_mod
        except ImportError:
            logging.exception("ncpsky print_limits: shaper_calibrate import")
            self.gcode.register_command('SHAPER_CALIBRATE', orig)
            return

        limits = self
        orig_find = sc_mod.ShaperCalibrate.find_best_shaper
        orig_save = sc_mod.ShaperCalibrate.save_params

        def find_best(self_sc, calibration_data, *args, **kwargs):
            best, all_shapers = orig_find(
                self_sc, calibration_data, *args, **kwargs)
            if best is None:
                return best, all_shapers
            freq = getattr(best, 'freq', None)
            if not shaper_freq_accepted(
                    freq, limits.shaper_min_freq, limits.shaper_max_freq):
                limits._reject_shaper(freq)
                return best, all_shapers
            if getattr(best, 'max_accel', None):
                limits.note_shaper_accel(best.max_accel)
            return best, all_shapers

        def save_params(self_sc, configfile, axis, shaper_name, shaper_freq):
            if not shaper_freq_accepted(
                    shaper_freq, limits.shaper_min_freq, limits.shaper_max_freq):
                limits._reject_shaper(shaper_freq)
                return
            orig_save(self_sc, configfile, axis, shaper_name, shaper_freq)
            ax = (axis or '').lower()
            if ax in ('x', 'y'):
                limits._note_status_freq(ax, shaper_freq)

        def wrapped(gcmd, orig=orig):
            sc_mod.ShaperCalibrate.find_best_shaper = find_best
            sc_mod.ShaperCalibrate.save_params = save_params
            try:
                return orig(gcmd)
            finally:
                sc_mod.ShaperCalibrate.find_best_shaper = orig_find
                sc_mod.ShaperCalibrate.save_params = orig_save

        self.gcode.register_command('SHAPER_CALIBRATE', wrapped)
        logging.info("ncpsky print_limits: SHAPER_CALIBRATE bridged")

    def _reject_shaper(self, freq):
        try:
            text = "rejected %.2f Hz" % float(freq)
        except (TypeError, ValueError):
            text = "rejected"
        try:
            self.gcode.run_script_from_command(
                "SET_GCODE_VARIABLE MACRO=NCPSKY_SHAPER_STATUS "
                "VARIABLE=err VALUE='\"%s\"'" % text)
        except self.printer.command_error:
            logging.info("ncpsky print_limits: reject status skipped")
        self.gcode.respond_info(
            "NCPSKY shaper %s (outside %.2f..%.2f Hz)"
            % (text, self.shaper_min_freq, self.shaper_max_freq))

    def _noise_accel(self):
        macro = self.printer.lookup_object('gcode_macro NCPSKY_NOISE_MAP', None)
        if macro is None:
            return 0.
        variables = getattr(macro, 'variables', None) or {}
        try:
            return float(variables.get('max_accel') or 0.)
        except (TypeError, ValueError, AttributeError):
            return 0.

    def _effective_cap(self):
        if self.cap > 0.:
            return self.cap
        return combine_print_accel(None, self._noise_accel(), self.travel_accel)

    def _note_status_freq(self, axis, freq):
        var = 'freq_x' if axis == 'x' else 'freq_y'
        try:
            self.gcode.run_script_from_command(
                "SET_GCODE_VARIABLE MACRO=NCPSKY_SHAPER_STATUS "
                "VARIABLE=%s VALUE=%.3f" % (var, float(freq)))
        except self.printer.command_error:
            logging.info("ncpsky print_limits: status %s skipped", var)

    def _printing(self):
        stats = self.printer.lookup_object('print_stats', None)
        if stats is None:
            return False
        return stats.state in ('printing', 'paused')

    def clamp_accel(self, accel):
        if accel is None or not self._printing():
            return accel
        ceiling = self._effective_cap()
        if accel > ceiling:
            return ceiling
        return accel

    def _clamp_param(self, gcmd, name):
        params = gcmd.get_command_parameters()
        raw = params.get(name)
        if raw is None:
            return
        try:
            value = float(raw)
        except ValueError:
            return
        capped = self.clamp_accel(value)
        if capped != value:
            params[name] = '%.6f' % (capped,)

    def cmd_M204(self, gcmd):
        self._clamp_param(gcmd, 'S')
        self._clamp_param(gcmd, 'P')
        self._clamp_param(gcmd, 'T')
        self._m204(gcmd)

    def cmd_SET_VELOCITY_LIMIT(self, gcmd):
        self._clamp_param(gcmd, 'ACCEL')
        self._set_velocity(gcmd)

    def apply_cap(self):
        ceiling = self._effective_cap()
        if ceiling <= 0.:
            return
        toolhead = self.printer.lookup_object('toolhead')
        eventtime = self.printer.get_reactor().monotonic()
        current = toolhead.get_status(eventtime)['max_accel']
        if current > ceiling:
            toolhead.set_max_velocities(None, ceiling, None, None)
            logging.info("ncpsky print accel cap %.0f", ceiling)

    def restore_travel(self):
        toolhead = self.printer.lookup_object('toolhead')
        toolhead.set_max_velocities(None, self.travel_accel, None, None)

    cmd_BEGIN_help = "Start a shaper pass so the print accel cap is recomputed"
    cmd_RESTORE_help = (
        "Restore [printer] velocity/accel before resonance excitation "
        "(undo APPLY_NOISE_MAP soft limits)")

    def cmd_BEGIN(self, gcmd):
        self._pending = None
        gcmd.respond_info("NCPSKY print accel cap will be recomputed")

    def cmd_RESTORE(self, gcmd):
        # Noise-map APPLY leaves toolhead at ~300/3000; stock resonance
        # excitation needs the configured printer envelope.
        pcfg = self.printer.lookup_object('configfile').get_status(None)
        sett = (pcfg.get('settings') or {}).get('printer') or {}
        vel = float(sett.get('max_velocity') or 0.) or None
        accel = float(sett.get('max_accel') or 0.) or None
        a2d = sett.get('max_accel_to_decel')
        scv = sett.get('square_corner_velocity')
        parts = []
        if vel:
            parts.append('VELOCITY=%.3f' % vel)
        if accel:
            parts.append('ACCEL=%.3f' % accel)
            self.travel_accel = accel
        if a2d is not None:
            parts.append('ACCEL_TO_DECEL=%.3f' % float(a2d))
        if scv is not None:
            parts.append('SQUARE_CORNER_VELOCITY=%.3f' % float(scv))
        if not parts:
            gcmd.respond_info("NCPSKY print limits: no printer envelope")
            return
        self.gcode.run_script_from_command(
            'SET_VELOCITY_LIMIT ' + ' '.join(parts))
        gcmd.respond_info(
            "NCPSKY print limits restored for shaper (%s)" % (' '.join(parts),))

    def note_shaper_accel(self, accel):
        rounded = combine_print_accel(
            accel, self._noise_accel(), self.travel_accel)
        if self._pending is None:
            self._pending = rounded
        else:
            self._pending = min(self._pending, rounded)
        self.cap = self._pending
        configfile = self.printer.lookup_object('configfile')
        configfile.set('ncpsky_print_limits', 'max_accel', '%.0f' % (self.cap,))
        self.gcode.respond_info(
            "NCPSKY print accel cap %.0f mm/s^2" % (self.cap,))


def load_config(config):
    return NcpskyPrintLimits(config)
