# Async PID job for the panel. delayed_gcode cannot catch command errors, so
# failures left NCPSKY_PID_STATUS.busy=1 until the panel timed out (~40 min).
# This command writes err/busy/phase on failure so CalibratePage can stop.
import logging


class NcpskyPid:
    def __init__(self, config):
        self.printer = config.get_printer()
        self.gcode = self.printer.lookup_object('gcode')
        self.gcode.register_command(
            'NCPSKY_PID_JOB_RUN', self.cmd_RUN,
            desc='Run extruder then bed PID_CALIBRATE; update NCPSKY_PID_STATUS')

    def _set_status(self, phase=None, busy=None, err=None):
        parts = []
        if phase is not None:
            safe = str(phase).replace('"', '').replace("'", "")
            parts.append("VARIABLE=phase VALUE='\"%s\"'" % (safe,))
        if busy is not None:
            parts.append("VARIABLE=busy VALUE=%d" % (1 if busy else 0,))
        if err is not None:
            safe = str(err).replace('"', '').replace("'", "")[:160]
            parts.append("VARIABLE=err VALUE='\"%s\"'" % (safe,))
        for part in parts:
            self.gcode.run_script_from_command(
                "SET_GCODE_VARIABLE MACRO=NCPSKY_PID_STATUS %s" % (part,))

    def cmd_RUN(self, gcmd):
        try:
            self._set_status(phase='hotend', err='')
            self.gcode.run_script_from_command(
                'PID_CALIBRATE HEATER=extruder TARGET=210')
            self._set_status(phase='bed')
            self.gcode.run_script_from_command(
                'PID_CALIBRATE HEATER=heater_bed TARGET=60')
            self.gcode.run_script_from_command('M104 S0')
            self.gcode.run_script_from_command('M140 S0')
            self._set_status(phase='done', busy=0, err='')
            gcmd.respond_info(
                'NCPSKY: pid job done (await panel SAVE_CONFIG)')
        except self.printer.command_error as exc:
            msg = str(exc)
            logging.info('ncpsky_pid failed: %s', msg)
            try:
                self._set_status(phase='error', busy=0, err=msg)
            except Exception:
                logging.exception('ncpsky_pid failed to write status')
            raise


def load_config(config):
    return NcpskyPid(config)
