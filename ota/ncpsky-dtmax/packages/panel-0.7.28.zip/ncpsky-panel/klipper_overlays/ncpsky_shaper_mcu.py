# Route stock AccelQueryHelper clients (SHAPER_CALIBRATE / MEASURE_AXES_NOISE)
# through MCU ncpsky_reso_* sampling so host ADXL bulk never fights XDIRECT.
#
# MCU pushes ncpsky_reso_data (unsolicited). Host uses register_serial_response
# (this Klipper build has no MCU.register_response).
import collections
import logging
import os
import threading

FREEFALL_ACCEL = 9.80665 * 1000.
SCALE_XY = 0.003774 * FREEFALL_ACCEL
SCALE_Z = 0.003906 * FREEFALL_ACCEL

RESO_DATA_FMT = (
    "ncpsky_reso_data count=%c ovf=%u"
    " t0=%u x0=%i y0=%i z0=%i"
    " t1=%u x1=%i y1=%i z1=%i"
    " t2=%u x2=%i y2=%i z2=%i"
    " t3=%u x3=%i y3=%i z3=%i"
)

Accel_Measurement = collections.namedtuple(
    'Accel_Measurement', ('time', 'accel_x', 'accel_y', 'accel_z'))


class McuResoClient:
    def __init__(self, helper, axes_map, interval_us):
        self.helper = helper
        self.printer = helper.printer
        self.mcu = helper.mcu
        self.axes_map = axes_map
        self.interval_us = interval_us
        self.is_finished = False
        self.samples = []
        self.raw_clock = []  # (clock, x, y, z) — convert on main thread
        self.lock = threading.Lock()
        self.overflows = 0
        toolhead = self.printer.lookup_object('toolhead')
        self.request_start_time = toolhead.get_last_move_time()
        self.request_end_time = self.request_start_time
        try:
            chip = helper.chip
            if getattr(chip, 'query_adxl345_cmd', None) is not None:
                chip.query_adxl345_cmd.send_wait_ack([chip.oid, 0])
        except Exception:
            logging.exception("ncpsky_shaper_mcu: halt host adxl")
        helper._clients.append(self)
        helper.reso_begin.send([int(interval_us)])

    def handle_data(self, params):
        # Called from serial background thread.
        if self.is_finished:
            return
        n = int(params.get('count', 0))
        ovf = int(params.get('ovf', 0))
        batch = []
        for i in range(n):
            clock = int(params['t%d' % i])
            if clock == 0 and int(params['x%d' % i]) == 0:
                continue
            batch.append((
                clock,
                int(params['x%d' % i]),
                int(params['y%d' % i]),
                int(params['z%d' % i])))
        with self.lock:
            self.overflows += ovf
            self.raw_clock.extend(batch)

    def _decode(self, clock, rx, ry, rz):
        (x_pos, x_scale), (y_pos, y_scale), (z_pos, z_scale) = self.axes_map
        raw = (rx, ry, rz)
        x = round(raw[x_pos] * x_scale, 6)
        y = round(raw[y_pos] * y_scale, 6)
        z = round(raw[z_pos] * z_scale, 6)
        ptime = self.mcu.clock_to_print_time(clock)
        return Accel_Measurement(round(ptime, 6), x, y, z)

    def finish_measurements(self):
        toolhead = self.printer.lookup_object('toolhead')
        self.request_end_time = toolhead.get_last_move_time()
        toolhead.wait_moves()
        try:
            self.helper.reso_end.send([])
        except self.printer.command_error:
            logging.exception("ncpsky_shaper_mcu: reso_end")
        reactor = self.printer.get_reactor()
        eventtime = reactor.monotonic()
        deadline = eventtime + 0.25
        while eventtime < deadline:
            eventtime = reactor.pause(eventtime + 0.02)
        self.is_finished = True
        try:
            self.helper._clients.remove(self)
        except ValueError:
            pass
        with self.lock:
            ovf = self.overflows
        if ovf:
            logging.warning(
                "ncpsky_shaper_mcu: ring overflowed %d samples", ovf)

    def has_valid_samples(self):
        # Stock checks batch time overlap; with MCU clocks a tight
        # print_time window can drop everything on dwell-only tests.
        with self.lock:
            n = len(self.raw_clock)
        return n >= 50

    def get_samples(self):
        if self.samples:
            return self.samples
        with self.lock:
            raw = list(self.raw_clock)
            ovf = self.overflows
        out = []
        for clock, rx, ry, rz in raw:
            samp = self._decode(clock, rx, ry, rz)
            if samp.time < self.request_start_time - 0.05:
                continue
            if samp.time > self.request_end_time + 0.25:
                continue
            out.append(samp)
        if not out and raw:
            # Fall back: keep every decoded sample (MEASURE_AXES_NOISE).
            out = [self._decode(c, x, y, z) for c, x, y, z in raw]
            logging.info(
                "ncpsky_shaper_mcu: time-window empty, using all %d samples",
                len(out))
        logging.info(
            "ncpsky_shaper_mcu: samples raw=%d kept=%d ovf=%d "
            "window=%.3f..%.3f",
            len(raw), len(out), ovf,
            self.request_start_time, self.request_end_time)
        self.samples = out
        return self.samples

    def write_to_file(self, filename):
        def write_impl():
            try:
                os.nice(20)
            except Exception:
                pass
            with open(filename, 'w') as f:
                f.write("#time,accel_x,accel_y,accel_z\n")
                for t, ax, ay, az in (self.samples or self.get_samples()):
                    f.write("%.6f,%.6f,%.6f,%.6f\n" % (t, ax, ay, az))
        import multiprocessing
        proc = multiprocessing.Process(target=write_impl)
        proc.daemon = True
        proc.start()


class NcpskyShaperMcu:
    def __init__(self, config):
        self.printer = config.get_printer()
        # ~400 Hz: above 2×133 Hz Nyquist, light enough for XDIRECT+excitation.
        self.interval_us = config.getint(
            'interval_us', 500, minval=500, maxval=5000)
        self.mcu = None
        self.reso_begin = None
        self.reso_end = None
        self.chip = None
        self.axes_map = None
        self._clients = []
        self._wrapped = False
        self._resp = None
        self.printer.register_event_handler('klippy:connect', self._connect)
        self.printer.register_event_handler('klippy:ready', self._ready)

    def _connect(self):
        logging.info("ncpsky_shaper_mcu: connect hook v2 (serial_response)")
        self.mcu = self.printer.lookup_object('mcu')
        self.reso_begin = self.mcu.try_lookup_command(
            'ncpsky_reso_begin interval_us=%u')
        self.reso_end = self.mcu.try_lookup_command('ncpsky_reso_end')
        if self.reso_begin is None or self.reso_end is None:
            logging.info("ncpsky_shaper_mcu: MCU lacks reso commands")
            return
        if self._resp is None:
            # This FLSun tree exposes register_serial_response, not
            # register_response (upstream name).
            reg = getattr(self.mcu, 'register_serial_response', None)
            if reg is None:
                reg = getattr(self.mcu, 'register_response', None)
            if reg is None:
                logging.error("ncpsky_shaper_mcu: no response registration API")
                self.reso_begin = None
                return
            self._resp = reg(self._handle_reso_data, RESO_DATA_FMT)

    def _handle_reso_data(self, params):
        for client in list(self._clients):
            try:
                client.handle_data(params)
            except Exception:
                logging.exception("ncpsky_shaper_mcu: handle_data")

    def _axes_map_from_chip(self, chip):
        am = getattr(chip, 'axes_map', None)
        if am is not None:
            return am
        return ((0, SCALE_XY), (1, SCALE_XY), (2, SCALE_Z))

    def _ready(self):
        if self.reso_begin is None or self._wrapped:
            return
        chip = self.printer.lookup_object('adxl345', None)
        if chip is None or not hasattr(chip, 'start_internal_client'):
            logging.info("ncpsky_shaper_mcu: no adxl345")
            return
        self.chip = chip
        self.axes_map = self._axes_map_from_chip(chip)
        helper = self
        orig = chip.start_internal_client

        def start_internal_client(orig=orig, helper=helper):
            if helper.reso_begin is None:
                return orig()
            return McuResoClient(helper, helper.axes_map, helper.interval_us)

        chip.start_internal_client = start_internal_client
        self._wrapped = True
        logging.info(
            "ncpsky_shaper_mcu: ADXL internal client → MCU reso push @ %dus",
            self.interval_us)


def load_config(config):
    return NcpskyShaperMcu(config)
