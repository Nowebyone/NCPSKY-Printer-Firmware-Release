# StealthChop microstep table (MSLUT). No XDIRECT.
#
# The chip only stores a quarter wave and mirrors it, so only odd
# harmonics can be programmed. Acoustic 4th/6th tones at 80 mm/s are
# cut by shaping the current with a 3rd (and optional 5th) term.
import logging
import math

TOWERS = ("stepper_a", "stepper_b", "stepper_c")

DEFAULT_MSLUT = (
    0xAAAAB554,
    0x4A9554AA,
    0x24492929,
    0x10104222,
    0xFBFFFFFF,
    0xB5BB777D,
    0x49295556,
    0x00404222,
)
DEFAULT_W = (2, 1, 1, 1)
DEFAULT_X = (128, 255, 255)
DEFAULT_START_SIN = 0
DEFAULT_START_SIN90 = 247
AMP_CAP = 24
PEAK = 247


def _w_pair(wcode):
    # bit0 / bit1 increments for one Wx code
    return {
        0: (-1, 0),
        1: (0, 1),
        2: (1, 2),
        3: (2, 3),
    }[wcode & 3]


def decode_quarter(msluts, w, x, start_sin):
    bits = []
    for word in msluts:
        for shift in range(32):
            bits.append((word >> shift) & 1)
    values = [int(start_sin)]
    cur = int(start_sin)
    for i in range(256):
        if i < x[0]:
            wc = w[0]
        elif i < x[1]:
            wc = w[1]
        elif i < x[2]:
            wc = w[2]
        else:
            wc = w[3]
        lo, hi = _w_pair(wc)
        cur += hi if bits[i] else lo
        values.append(cur)
    # 257 samples: entry 0 plus 256 increments. Keep first 256.
    return values[:256]


def wave_quarter(a3, p3, a5, p5, peak=PEAK):
    """First quadrant samples for sin + 3rd + 5th.

    Free phase would break the mirrored quarter table, so P3/P5 only
    choose the sign (0 = positive, 128 = negative). Amplitude carries
    the strength.
    """
    a3 = max(-AMP_CAP, min(AMP_CAP, int(a3)))
    a5 = max(-AMP_CAP, min(AMP_CAP, int(a5)))
    if (int(p3) & 255) >= 128:
        a3 = -a3
    if (int(p5) & 255) >= 128:
        a5 = -a5
    out = []
    for i in range(256):
        th = (math.pi * 0.5) * (i / 256.0)
        y = (
            math.sin(th)
            + (a3 / float(peak)) * math.sin(3.0 * th)
            + (a5 / float(peak)) * math.sin(5.0 * th)
        )
        v = int(round(peak * y))
        if v < 0:
            v = 0
        if v > 255:
            v = 255
        out.append(v)
    out[0] = 0
    return out


def _smooth_encodable(values):
    """Force successive deltas into [-1, 3] so a table can store them."""
    out = [int(values[0])]
    for i in range(1, len(values)):
        target = int(values[i])
        prev = out[-1]
        delta = target - prev
        if delta < -1:
            delta = -1
        if delta > 3:
            delta = 3
        out.append(prev + delta)
    # Keep the peak near the chip default so PWM headroom stays.
    if out[-1] < 200:
        bump = 200 - out[-1]
        out = [min(255, v + bump) for v in out]
        out[0] = 0
    if out[-1] > 248:
        scale = 248.0 / float(out[-1])
        out = [int(round(v * scale)) for v in out]
        out[0] = 0
        out = _smooth_encodable(out)
    return out


def encode_quarter(values):
    values = _smooth_encodable(values)
    deltas = [0]
    for i in range(1, 256):
        deltas.append(values[i] - values[i - 1])
    # Grow up to four Wx segments; each segment only spans a 2-wide delta set.
    segs = [{"start": 0, "lo": deltas[1], "hi": deltas[1]}]
    for i in range(2, 256):
        d = deltas[i]
        lo = min(segs[-1]["lo"], d)
        hi = max(segs[-1]["hi"], d)
        if hi - lo <= 1:
            segs[-1]["lo"] = lo
            segs[-1]["hi"] = hi
            continue
        if len(segs) >= 4:
            # Merge by clamping this delta into the last segment.
            lo, hi = segs[-1]["lo"], segs[-1]["hi"]
            if d < lo:
                d = lo
            if d > hi:
                d = hi
            deltas[i] = d
            values[i] = values[i - 1] + d
            continue
        segs.append({"start": i, "lo": d, "hi": d})
    while len(segs) < 4:
        segs.append({"start": 255, "lo": segs[-1]["lo"], "hi": segs[-1]["hi"]})
    w = []
    for seg in segs[:4]:
        # Prefer the lower code that covers [lo, hi].
        lo, hi = seg["lo"], seg["hi"]
        chosen = None
        for code in range(4):
            a, b = _w_pair(code)
            if min(a, b) <= lo and max(a, b) >= hi and abs(b - a) == 1:
                chosen = code
                break
        if chosen is None:
            # Fall back to default-ish +1/+2
            chosen = 2
        w.append(chosen)
    x = [segs[1]["start"], segs[2]["start"], segs[3]["start"]]
    for i in range(3):
        if x[i] < 1:
            x[i] = 1
        if x[i] > 255:
            x[i] = 255
    if not (0 < x[0] <= x[1] <= x[2]):
        x = list(DEFAULT_X)
        w = list(DEFAULT_W)
    bits = []
    for i in range(256):
        if i < x[0]:
            wc = w[0]
        elif i < x[1]:
            wc = w[1]
        elif i < x[2]:
            wc = w[2]
        else:
            wc = w[3]
        lo, hi = _w_pair(wc)
        d = deltas[i] if i else 0
        # Entry 0 bit is unused for the first absolute sample; still stored.
        if i == 0:
            bits.append(0)
            continue
        if abs(d - lo) <= abs(d - hi):
            bits.append(0)
            # Rebuild forward value with chosen delta
            deltas[i] = lo
        else:
            bits.append(1)
            deltas[i] = hi
        values[i] = values[i - 1] + deltas[i]
    msluts = []
    for m in range(8):
        word = 0
        for i in range(32):
            word |= (bits[m * 32 + i] & 1) << i
        msluts.append(word)
    return {
        "mslut": msluts,
        "w": w,
        "x": x,
        "start_sin": int(values[0]) & 255,
        "start_sin90": int(values[255]) & 255,
        "values": values,
    }


def default_table():
    return {
        "mslut": list(DEFAULT_MSLUT),
        "w": list(DEFAULT_W),
        "x": list(DEFAULT_X),
        "start_sin": DEFAULT_START_SIN,
        "start_sin90": DEFAULT_START_SIN90,
    }


def build_table(a3=0, p3=0, a5=0, p5=0):
    if not a3 and not a5:
        return default_table()
    return encode_quarter(wave_quarter(a3, p3, a5, p5))


class NcpskyMslut:
    def __init__(self, config):
        self.printer = config.get_printer()
        self.gcode = self.printer.lookup_object("gcode")
        self.a3 = 0
        self.p3 = 0
        self.a5 = 0
        self.p5 = 0
        self.gcode.register_command(
            "NCPSKY_MSLUT_SET", self.cmd_SET,
            desc="Program StealthChop microstep table with 3rd/5th terms")
        self.gcode.register_command(
            "NCPSKY_MSLUT_DEFAULT", self.cmd_DEFAULT,
            desc="Restore the chip default sine microstep table")
        self.gcode.register_command(
            "NCPSKY_MSLUT_STATUS", self.cmd_STATUS,
            desc="Report the active MSLUT harmonic coefficients")

    def get_status(self, eventtime=None):
        del eventtime
        return {
            "a3": self.a3, "p3": self.p3,
            "a5": self.a5, "p5": self.p5,
        }

    def _tmc(self, name):
        return self.printer.lookup_object("tmc5160 " + name)

    def _write_table(self, name, table):
        tmc = self._tmc(name)
        fields = tmc.fields
        # Datasheet: rewrite near MSCNT=0. Standstill after a short dwell
        # is enough; this path never homes.
        for i, word in enumerate(table["mslut"]):
            val = fields.set_field("mslut%d" % i, int(word) & 0xffffffff)
            tmc.mcu_tmc.set_register("MSLUT%d" % i, val, None)
        try:
            val = fields.set_field("x3", int(table["x"][2]) & 255)
            val = fields.set_field("x2", int(table["x"][1]) & 255, val)
            val = fields.set_field("x1", int(table["x"][0]) & 255, val)
            val = fields.set_field("w3", int(table["w"][3]) & 3, val)
            val = fields.set_field("w2", int(table["w"][2]) & 3, val)
            val = fields.set_field("w1", int(table["w"][1]) & 3, val)
            val = fields.set_field("w0", int(table["w"][0]) & 3, val)
        except Exception:
            val = (
                ((int(table["x"][2]) & 255) << 24)
                | ((int(table["x"][1]) & 255) << 16)
                | ((int(table["x"][0]) & 255) << 8)
                | ((int(table["w"][3]) & 3) << 6)
                | ((int(table["w"][2]) & 3) << 4)
                | ((int(table["w"][1]) & 3) << 2)
                | ((int(table["w"][0]) & 3) << 0)
            )
        tmc.mcu_tmc.set_register("MSLUTSEL", val, None)
        try:
            val = fields.set_field("start_sin", int(table["start_sin"]) & 255)
            val = fields.set_field(
                "start_sin90", int(table["start_sin90"]) & 255, val)
        except Exception:
            val = ((int(table["start_sin90"]) & 255) << 16) | (
                int(table["start_sin"]) & 255)
        tmc.mcu_tmc.set_register("MSLUTSTART", val, None)

    def apply_coeffs(self, a3=0, p3=0, a5=0, p5=0):
        table = build_table(a3, p3, a5, p5)
        for name in TOWERS:
            self._write_table(name, table)
        self.a3 = int(a3)
        self.p3 = int(p3) & 255
        self.a5 = int(a5)
        self.p5 = int(p5) & 255
        return table

    def apply_default(self):
        return self.apply_coeffs(0, 0, 0, 0)

    def cmd_SET(self, gcmd):
        a3 = gcmd.get_int("A3", self.a3, minval=-AMP_CAP, maxval=AMP_CAP)
        p3 = gcmd.get_int("P3", self.p3, minval=0, maxval=255)
        a5 = gcmd.get_int("A5", self.a5, minval=-AMP_CAP, maxval=AMP_CAP)
        p5 = gcmd.get_int("P5", self.p5, minval=0, maxval=255)
        self.apply_coeffs(a3, p3, a5, p5)
        gcmd.respond_info(
            "NCPSKY mslut: a3=%d p3=%d a5=%d p5=%d" % (a3, p3, a5, p5))

    def cmd_DEFAULT(self, gcmd):
        self.apply_default()
        gcmd.respond_info("NCPSKY mslut: 默认正弦表")

    def cmd_STATUS(self, gcmd):
        gcmd.respond_info(
            "NCPSKY mslut: a3=%d p3=%d a5=%d p5=%d"
            % (self.a3, self.p3, self.a5, self.p5))


def load_config(config):
    return NcpskyMslut(config)
