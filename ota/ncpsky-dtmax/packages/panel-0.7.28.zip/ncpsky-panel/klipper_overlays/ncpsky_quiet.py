# StealthChop-first quiet policy. No coil direct-mode.
#
# Full StealthChop (tpwmthrs=0) unless a closed-loop homing stroke shows
# the towers lost steps at 800 mm/s and 12000 mm/s^2. Then only the high
# speed region switches to SpreadCycle, with a short chopper period so
# that hiss sits above the hearing range. Print speed limits are not cut.
import json
import logging
import os

from . import homing as homing_mod

TOWERS = ("stepper_a", "stepper_b", "stepper_c")
ACCEPT_VELOCITY = 800.0
ACCEPT_ACCEL = 12000.0
# ~1.5 mm at 213 steps/mm. Homing stroke should repeat; a skip moves it.
STROKE_SLOP = 320
PROBE_SPEEDS = (800.0, 600.0, 400.0, 200.0)
DEFAULT_HOME_RUN = 1.65
DEFAULT_HOME_HOLD = 1.65
DEFAULT_HOME2_RUN = 1.65
DEFAULT_HOME2_HOLD = 1.65
DEFAULT_PRINT_RUN = 1.65
DEFAULT_PRINT_HOLD = 0.45


class NcpskyQuiet:
    def __init__(self, config):
        self.printer = config.get_printer()
        self.gcode = self.printer.lookup_object("gcode")
        self.path = config.get(
            "profile", "/home/pi/printer_data/config/ncpsky_quiet.json")
        self.stealth_until = 0.0  # 0 = StealthChop at every speed
        self.spread_ultrasonic = False
        self.home_run = DEFAULT_HOME_RUN
        self.home_hold = DEFAULT_HOME_HOLD
        self.home2_run = DEFAULT_HOME2_RUN
        self.home2_hold = DEFAULT_HOME2_HOLD
        self.print_run = DEFAULT_PRINT_RUN
        self.print_hold = DEFAULT_PRINT_HOLD
        self._load()
        self.gcode.register_command(
            "NCPSKY_QUIET_HOME", self.cmd_HOME,
            desc="StealthChop + first-pass homing current")
        self.gcode.register_command(
            "NCPSKY_HOME", self.cmd_HOME_SEQ,
            desc="Delta home with separate first/second-pass currents")
        self.gcode.register_command(
            "NCPSKY_QUIET_APPLY", self.cmd_APPLY,
            desc="Reapply StealthChop and print/idle currents")
        self.gcode.register_command(
            "NCPSKY_QUIET_CALIBRATE", self.cmd_CALIBRATE,
            desc="Find the fastest StealthChop that holds 800 mm/s at 12000 accel")
        self.gcode.register_command(
            "NCPSKY_QUIET_CURRENT", self.cmd_CURRENT,
            desc="Set tower currents for home/home2/print without saving")
        self.gcode.register_command(
            "NCPSKY_QUIET_CURRENT_SAVE", self.cmd_CURRENT_SAVE,
            desc="Bake home/home2/print currents into the quiet profile")
        # Do not tune from klippy:ready. Autotune already writes StealthChop
        # there, and a second SPI pass during connect shuts the MCU down.
        self._install_home2_hook()

    def _install_home2_hook(self):
        # Stock G28.999 cannot change current between passes. Wrap the
        # retract that sits between pass 1 and pass 2 so home2_* applies
        # only to the accuracy-critical second hit.
        if getattr(homing_mod.Homing, "_ncpsky_home2_hook", False):
            return
        orig = homing_mod.Homing._retract_move
        quiet = self

        def _retract_then_home2(hstate, homing_info, forcepos, movepos):
            homepos = orig(hstate, homing_info, forcepos, movepos)
            quiet._set_tower_current(quiet.home2_run, quiet.home2_hold)
            quiet.printer.lookup_object("toolhead").dwell(0.05)
            return homepos

        homing_mod.Homing._retract_move = _retract_then_home2
        homing_mod.Homing._ncpsky_home2_hook = True

    def get_status(self, eventtime=None):
        del eventtime
        return {
            "stealth_until": self.stealth_until,
            "spread_ultrasonic": self.spread_ultrasonic,
            "home_run": self.home_run,
            "home_hold": self.home_hold,
            "home2_run": self.home2_run,
            "home2_hold": self.home2_hold,
            "print_run": self.print_run,
            "print_hold": self.print_hold,
        }

    def _load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
        except (OSError, ValueError):
            return
        self.stealth_until = float(data.get("stealth_until") or 0.0)
        self.spread_ultrasonic = bool(data.get("spread_ultrasonic"))
        cur = data.get("current") or {}
        self.home_run = float(cur.get("home_run") or DEFAULT_HOME_RUN)
        self.home_hold = float(cur.get("home_hold") or self.home_run)
        # Second pass defaults to full torque until mic-ranked; accuracy first.
        self.home2_run = float(cur.get("home2_run") or DEFAULT_HOME2_RUN)
        self.home2_hold = float(cur.get("home2_hold") or self.home2_run)
        self.print_run = float(cur.get("print_run") or DEFAULT_PRINT_RUN)
        self.print_hold = float(cur.get("print_hold") or DEFAULT_PRINT_HOLD)

    def _save(self):
        folder = os.path.dirname(self.path)
        if folder:
            os.makedirs(folder, exist_ok=True)
        payload = {
            "stealth_until": self.stealth_until,
            "spread_ultrasonic": self.spread_ultrasonic,
            "accept_velocity": ACCEPT_VELOCITY,
            "accept_accel": ACCEPT_ACCEL,
            "current": {
                "home_run": self.home_run,
                "home_hold": self.home_hold,
                "home2_run": self.home2_run,
                "home2_hold": self.home2_hold,
                "print_run": self.print_run,
                "print_hold": self.print_hold,
            },
        }
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2)
            handle.write("\n")
        os.replace(tmp, self.path)

    def _tuner(self, name):
        return self.printer.lookup_object("autotune_tmc " + name)

    def _silent_base(self):
        self.gcode.run_script_from_command(
            "AUTOTUNE_TMC STEPPER=stepper_a TUNING_GOAL=silent\n"
            "AUTOTUNE_TMC STEPPER=stepper_b TUNING_GOAL=silent\n"
            "AUTOTUNE_TMC STEPPER=stepper_c TUNING_GOAL=silent")

    def _set_tower_current(self, run_i, hold_i):
        run_i = float(run_i)
        hold_i = float(hold_i)
        if hold_i > run_i:
            hold_i = run_i
        for name in TOWERS:
            self.gcode.run_script_from_command(
                "SET_TMC_CURRENT STEPPER=%s CURRENT=%.3f HOLDCURRENT=%.3f"
                % (name, run_i, hold_i))

    def _apply(self):
        self._silent_base()
        self._set_tower_current(self.print_run, self.print_hold)
        if self.stealth_until <= 1.0:
            return
        for name in TOWERS:
            tuner = self._tuner(name)
            tuner._set_driver_velocity_field("tpwmthrs", self.stealth_until)
            tuner._set_driver_field("en_pwm_mode", True)
            if self.spread_ultrasonic:
                # SpreadCycle only above tpwmthrs. Short period keeps the
                # chopper above roughly 20 kHz on a 12 MHz TMC clock.
                tuner._set_driver_field("toff", 3)
                tuner._set_driver_field("tbl", 1)
                tuner._set_driver_field("hstrt", 1)
                tuner._set_driver_field("hend", 2)

    def _home_chopper(self):
        # Homing stays in StealthChop. Mic ranking moved the first pass to
        # 120 mm/s so the 4th/6th electrical peaks leave the loud band that
        # 80 mm/s hit. pwm_reg fine-sweep at 120 was flat within 0.3 dB, so
        # keep pwm_reg=1 / pwm_freq=2. Printing still goes back through
        # _apply().
        for name in TOWERS:
            tuner = self._tuner(name)
            tuner._set_driver_field("en_pwm_mode", True)
            tuner._set_driver_field("tpwmthrs", 0)
            tuner._set_driver_field("pwm_reg", 1)
            tuner._set_driver_field("pwm_freq", 2)

    def cmd_HOME(self, gcmd):
        self._home_chopper()
        self._set_tower_current(self.home_run, self.home_hold)
        gcmd.respond_info(
            "NCPSKY quiet: 一段归零电流 %.2f/%.2f A（二段 %.2f/%.2f）"
            % (self.home_run, self.home_hold,
               self.home2_run, self.home2_hold))

    def cmd_HOME_SEQ(self, gcmd):
        """Stock G28.999 with pass-1 then pass-2 currents. Accuracy on pass 2."""
        self._home_chopper()
        self._set_tower_current(self.home_run, self.home_hold)
        # Retract hook swaps to home2_* before second_homing_speed.
        self.gcode.run_script_from_command("G28.999")
        gcmd.respond_info(
            "NCPSKY home: 一段 %.2f A / 二段 %.2f A"
            % (self.home_run, self.home2_run))

    def cmd_APPLY(self, gcmd):
        self._apply()
        if self.stealth_until <= 1.0:
            gcmd.respond_info(
                "NCPSKY quiet: 全程 StealthChop 电流 %.2f/%.2f A"
                % (self.print_run, self.print_hold))
        else:
            gcmd.respond_info(
                "NCPSKY quiet: StealthChop 至 %.0f mm/s，电流 %.2f/%.2f A"
                % (self.stealth_until, self.print_run, self.print_hold))

    def cmd_CURRENT(self, gcmd):
        mode = (gcmd.get("MODE", "print") or "print").strip().lower()
        run_i = gcmd.get_float("RUN", None, above=0.2, maxval=2.0)
        hold_i = gcmd.get_float("HOLD", None, above=0.05, maxval=2.0)
        if mode in ("home", "homing"):
            if run_i is None:
                run_i = self.home_run
            if hold_i is None:
                hold_i = run_i
            self._home_chopper()
            self._set_tower_current(run_i, hold_i)
            gcmd.respond_info(
                "NCPSKY quiet: 试听一段归零电流 %.3f/%.3f" % (run_i, hold_i))
            return
        if mode in ("home2", "second", "homing2"):
            if run_i is None:
                run_i = self.home2_run
            if hold_i is None:
                hold_i = run_i
            self._home_chopper()
            self._set_tower_current(run_i, hold_i)
            gcmd.respond_info(
                "NCPSKY quiet: 试听二段归零电流 %.3f/%.3f" % (run_i, hold_i))
            return
        if run_i is None:
            run_i = self.print_run
        if hold_i is None:
            hold_i = self.print_hold
        self._set_tower_current(run_i, hold_i)
        gcmd.respond_info(
            "NCPSKY quiet: 试听打印电流 %.3f/%.3f" % (run_i, hold_i))

    def cmd_CURRENT_SAVE(self, gcmd):
        mode = (gcmd.get("MODE", "home") or "home").strip().lower()
        run_i = gcmd.get_float("RUN", None, above=0.2, maxval=2.0)
        hold_i = gcmd.get_float("HOLD", None, above=0.05, maxval=2.0)
        if mode in ("home", "homing"):
            if run_i is None:
                raise gcmd.error("一段归零电流要带 RUN=")
            self.home_run = float(run_i)
            self.home_hold = float(hold_i if hold_i is not None else run_i)
        elif mode in ("home2", "second", "homing2"):
            if run_i is None:
                raise gcmd.error("二段归零电流要带 RUN=")
            self.home2_run = float(run_i)
            self.home2_hold = float(hold_i if hold_i is not None else run_i)
        elif mode == "print":
            if run_i is None and hold_i is None:
                raise gcmd.error("打印电流要带 RUN= 或 HOLD=")
            if run_i is not None:
                self.print_run = float(run_i)
            if hold_i is not None:
                self.print_hold = float(hold_i)
        else:
            raise gcmd.error("MODE 只能是 home、home2 或 print")
        if self.home_hold > self.home_run:
            self.home_hold = self.home_run
        if self.home2_hold > self.home2_run:
            self.home2_hold = self.home2_run
        if self.print_hold > self.print_run:
            self.print_hold = self.print_run
        self._save()
        gcmd.respond_info(
            "NCPSKY quiet: 电流 home=%.2f/%.2f home2=%.2f/%.2f print=%.2f/%.2f"
            % (self.home_run, self.home_hold,
               self.home2_run, self.home2_hold,
               self.print_run, self.print_hold))

    def _towers(self):
        kin = self.printer.lookup_object("toolhead").get_kinematics()
        found = {}
        for rail in kin.rails:
            for stepper in rail.get_steppers():
                if stepper.get_name() in TOWERS:
                    found[stepper.get_name()] = stepper
        if len(found) != 3:
            raise self.printer.command_error("找不到三座塔的步进")
        return found

    def _mcu_pos(self):
        return {
            name: int(stepper.get_mcu_position())
            for name, stepper in self._towers().items()
        }

    def _home_stroke(self):
        """Steps from Z=40 center up to the endstops. A skipped rotor changes it."""
        self.gcode.run_script_from_command("G1 X0 Y0 Z40 F3000")
        self.printer.lookup_object("toolhead").wait_moves()
        before = self._mcu_pos()
        self.gcode.run_script_from_command("G28")
        self.printer.lookup_object("toolhead").wait_moves()
        after = self._mcu_pos()
        return {name: abs(after[name] - before[name]) for name in TOWERS}

    def _stress(self, velocity):
        feed = max(300, int(round(velocity * 60.0)))
        self.gcode.run_script_from_command(
            "SET_VELOCITY_LIMIT VELOCITY=%.1f ACCEL=%.1f MINIMUM_CRUISE_RATIO=0.5"
            % (max(velocity, 50.0), ACCEPT_ACCEL))
        # 70 mm is enough to finish the accel ramp at 800 mm/s and 12000.
        script = (
            "G90\n"
            "G1 X0 Y0 Z40 F3000\n"
            "G1 X70 Y0 Z40 F%d\n"
            "G1 X0 Y0 Z40 F%d\n"
            "G1 X-35 Y60 Z40 F%d\n"
            "G1 X0 Y0 Z40 F%d\n"
            "G1 X-35 Y-60 Z40 F%d\n"
            "G1 X0 Y0 Z40 F%d\n"
            "M400"
        ) % (feed, feed, feed, feed, feed, feed)
        self.gcode.run_script_from_command(script)
        self.printer.lookup_object("toolhead").wait_moves()

    def _stroke_far(self, base, got):
        worst = 0
        for name in TOWERS:
            worst = max(worst, abs(int(got[name]) - int(base[name])))
        return worst

    def cmd_CALIBRATE(self, gcmd):
        toolhead = self.printer.lookup_object("toolhead")
        status = toolhead.get_status(self.printer.get_reactor().monotonic())
        saved_v = status["max_velocity"]
        saved_a = status["max_accel"]
        saved_mcr = status.get("minimum_cruise_ratio", 0.5)
        try:
            self.stealth_until = 0.0
            self.spread_ultrasonic = False
            self._apply()
            self.gcode.run_script_from_command("G28")
            base = self._home_stroke()
            passed = None
            for speed in PROBE_SPEEDS:
                gcmd.respond_info("NCPSKY quiet: 试 %.0f mm/s" % speed)
                self.stealth_until = 0.0
                self.spread_ultrasonic = False
                self._apply()
                try:
                    self._stress(speed)
                except self.printer.command_error as err:
                    gcmd.respond_info(
                        "NCPSKY quiet: %.0f mm/s 运动失败 (%s)" % (speed, err))
                    continue
                stroke = self._home_stroke()
                slack = self._stroke_far(base, stroke)
                gcmd.respond_info(
                    "NCPSKY quiet: %.0f mm/s 归零行程差 %d 步" % (speed, slack))
                if slack <= STROKE_SLOP:
                    passed = speed
                    break
            if passed is None or passed + 1.0 >= ACCEPT_VELOCITY:
                self.stealth_until = 0.0
                self.spread_ultrasonic = False
                note = "全程 StealthChop，800 mm/s 验收通过"
                if passed is None:
                    # Still do not cut the speed limit. Mark the high band
                    # ultrasonic so a later apply can be inspected.
                    self.stealth_until = 200.0
                    self.spread_ultrasonic = True
                    note = "各档归零行程都不稳，高速段改超声 SpreadCycle，不降低速度上限"
            else:
                self.stealth_until = float(passed)
                self.spread_ultrasonic = True
                note = (
                    "StealthChop 至 %.0f mm/s，800 mm/s 走超声 SpreadCycle"
                    % passed)
            self._save()
            self._apply()
            gcmd.respond_info("NCPSKY quiet: 校准完成，" + note)
        finally:
            self.gcode.run_script_from_command(
                "SET_VELOCITY_LIMIT VELOCITY=%.4f ACCEL=%.4f MINIMUM_CRUISE_RATIO=%.4f"
                % (saved_v, saved_a, saved_mcr))


def load_config(config):
    return NcpskyQuiet(config)
