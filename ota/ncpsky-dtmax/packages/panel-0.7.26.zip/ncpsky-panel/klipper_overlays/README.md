# Klipper overlays (T1 Max)

## bed_mesh PROBE_HEIGHT

FLSun `PROBE_HEIGHT` called `probe.run_probe()`, removed in Klipper 0.14.
Patch uses `probe.run_single_probe()` and auto-loads `default` mesh if empty.

Apply on device:

```bash
python3 scripts/fix_probe_height_and_print.py
# IMPORTANT: systemctl restart klipper (FIRMWARE_RESTART is not enough)
```

File on printer: `/home/pi/klipper/klippy/extras/bed_mesh.py`
Backup: `bed_mesh.py.bak_probe_height`

## ncpsky_adaptive_mesh.py

Reads the printing gcode and sizes the round mesh. Stack install copies
`stack/klipper_extras/ncpsky_adaptive_mesh.py` to
`/home/pi/klipper/klippy/extras/ncpsky_adaptive_mesh.py`.
`adaptive_bed_mesh.cfg` loads it and wraps `probe_height`.
