#!/usr/bin/env python3
"""Build Klipper MCU firmware on Windows for ncpsky-dtmax profiles.

Detects / selects a chip profile (default: gd32f303vet6), seeds defconfig,
forces real Flash/RAM into autoconf.h when the profile requires it, then
cross-compiles. Does not touch the printer.

Requires: arm-none-eabi-gcc, mingw32-make, Git Bash, Python 3.

  python build_mcu_bin.py --version mcu-20261125 --profile gd32f303vet6
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
OTA_ROOT = os.path.abspath(os.path.join(HERE, ".."))
PANEL_ROOT = os.path.abspath(os.path.join(OTA_ROOT, ".."))
DIST = os.path.join(OTA_ROOT, "dist")
DEFAULT_SRC = os.path.join(DIST, "_mcu_build", "klipper")
VENDOR = os.path.join(OTA_ROOT, "vendor")

if HERE not in sys.path:
    sys.path.insert(0, HERE)
from mcu_profiles import get_profile, patch_autoconf  # noqa: E402

GIT_BASH_CANDIDATES = [
    r"C:\Program Files\Git\bin\bash.exe",
    r"C:\Program Files (x86)\Git\bin\bash.exe",
]
GCC_DIR_CANDIDATES = [
    r"C:\Program Files\STM32CubeCLT_1.21.0\GNU-tools-for-STM32\bin",
    r"C:\ST\STM32CubeCLT_1.18.0\GNU-tools-for-STM32\bin",
    r"F:\Software\DPJ\STM32\gcc-arm-none-eabi-10.3-2021.10\bin",
    r"C:\Program Files (x86)\Arm GNU Toolchain arm-none-eabi",
]
MAKE_CANDIDATES = [
    r"F:\Software\DPJ\STM32\MinGW\bin\mingw32-make.exe",
    r"C:\MinGW\bin\mingw32-make.exe",
    r"C:\msys64\usr\bin\make.exe",
]
READELF_DIR_CANDIDATES = [
    r"F:\Software\DPJ\STM32\MinGW\bin",
    r"C:\MinGW\bin",
]


def die(msg, code=1):
    sys.stderr.write("ERROR: %s\n" % msg)
    raise SystemExit(code)


def which_on_path(name):
    return shutil.which(name)


def find_file(candidates):
    for p in candidates:
        if p and os.path.isfile(p):
            return p
    return None


def _space_free_dir(gcc_dir):
    """collect2 fails when the toolchain path contains a space."""
    if " " not in gcc_dir:
        return gcc_dir
    parent = os.path.dirname(gcc_dir)
    link = os.path.join(os.environ.get("LOCALAPPDATA") or tempfile.gettempdir(), "ncpsky-arm-gcc")
    linked_bin = os.path.join(link, "bin")
    if not os.path.isfile(os.path.join(linked_bin, "arm-none-eabi-gcc.exe")):
        if os.path.lexists(link):
            subprocess.check_call(["cmd", "/c", "rmdir", link])
        subprocess.check_call(["cmd", "/c", "mklink", "/J", link, parent])
        print("gcc junction", link, "->", parent)
    return linked_bin


def find_gcc_prefix():
    for d in GCC_DIR_CANDIDATES:
        if not d:
            continue
        exe = os.path.join(d, "arm-none-eabi-gcc.exe")
        if os.path.isfile(exe):
            return "arm-none-eabi-", _space_free_dir(d)
        if os.path.isdir(d):
            for root, _dirs, files in os.walk(d):
                if "arm-none-eabi-gcc.exe" in files:
                    return "arm-none-eabi-", _space_free_dir(root)
    gcc = which_on_path("arm-none-eabi-gcc") or which_on_path("arm-none-eabi-gcc.exe")
    if gcc:
        return "arm-none-eabi-", _space_free_dir(os.path.dirname(os.path.abspath(gcc)))
    die("arm-none-eabi-gcc not found. Install Arm GNU Toolchain or STM32CubeCLT.")


def find_make():
    m = which_on_path("mingw32-make") or which_on_path("make")
    if m:
        return os.path.abspath(m)
    m = find_file(MAKE_CANDIDATES)
    if m:
        return m
    local = os.environ.get("LOCALAPPDATA", "")
    winget = os.path.join(local, "Microsoft", "WinGet", "Packages")
    if os.path.isdir(winget):
        for name in os.listdir(winget):
            if "LLVM-MinGW" not in name and "MinGW" not in name:
                continue
            root = os.path.join(winget, name)
            for dirpath, _dirs, files in os.walk(root):
                if "mingw32-make.exe" in files:
                    return os.path.join(dirpath, "mingw32-make.exe")
    die("mingw32-make / make not found (expected MinGW).")


def find_bash():
    for p in GIT_BASH_CANDIDATES:
        if os.path.isfile(p):
            return p
    b = which_on_path("bash")
    if b and "WindowsApps" not in b and "System32" not in b.replace("/", "\\"):
        return b
    die("Git Bash not found (C:\\Program Files\\Git\\bin\\bash.exe).")


def find_python():
    return sys.executable.replace("\\", "/")


def find_readelf_dir():
    for d in READELF_DIR_CANDIDATES:
        if os.path.isfile(os.path.join(d, "readelf.exe")) or os.path.isfile(
            os.path.join(d, "readelf")
        ):
            return d
    return None


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def ensure_vendor_into_src(src):
    kcfg_dst = os.path.join(src, "lib", "kconfiglib")
    kcfg_src = os.path.join(VENDOR, "kconfiglib")
    if not os.path.isfile(os.path.join(kcfg_dst, "kconfiglib.py")):
        if not os.path.isfile(os.path.join(kcfg_src, "kconfiglib.py")):
            die("missing vendor/kconfiglib — expected at %s" % kcfg_src)
        if os.path.isdir(kcfg_dst):
            shutil.rmtree(kcfg_dst)
        shutil.copytree(kcfg_src, kcfg_dst)
        print("seeded lib/kconfiglib from vendor")

    klippy_dst = os.path.join(src, "klippy")
    if not os.path.isfile(os.path.join(klippy_dst, "msgproto.py")):
        os.makedirs(klippy_dst, exist_ok=True)
        for name in ("msgproto.py", "util.py", "__init__.py"):
            s = os.path.join(VENDOR, "klippy", name)
            if not os.path.isfile(s):
                die("missing vendor/klippy/%s" % name)
            shutil.copy2(s, os.path.join(klippy_dst, name))
        print("seeded klippy/msgproto from vendor")


def patch_buildcommands_crlf(src):
    path = os.path.join(src, "scripts", "buildcommands.py")
    if not os.path.isfile(path):
        die("missing scripts/buildcommands.py in %s" % src)
    text = open(path, "r", encoding="utf-8", errors="replace").read()
    old = 'check_output("%s --version" % (tool,)).split(\'\\n\')[0]'
    new = 'check_output("%s --version" % (tool,)).splitlines()[0].strip()'
    if new in text or "splitlines()[0]" in text:
        return
    if old not in text:
        die("cannot patch buildcommands.py tool_versions() — unexpected source")
    open(path, "w", encoding="utf-8", newline="\n").write(text.replace(old, new, 1))
    print("patched scripts/buildcommands.py for Windows CRLF versions")


def patch_makefile_board_link(src):
    path = os.path.join(src, "Makefile")
    text = open(path, "r", encoding="utf-8", errors="replace").read()
    orig = text
    text = text.replace("$(Q)rm -f $(OUT)board\n", "$(Q)rm -rf $(OUT)board\n")
    text = text.replace(
        "$(Q)rm -f $(OUT)board-generic/board\n",
        "$(Q)rm -rf $(OUT)board-generic/board\n",
    )
    if text != orig:
        open(path, "w", encoding="utf-8", newline="\n").write(text)
        print("patched Makefile board-link rm -rf for Windows")


def inject_build_tag(src, tag, chip_label):
    path = os.path.join(src, "src", "basecmd.c")
    text = open(path, "r", encoding="utf-8", errors="replace").read()
    text = re.sub(
        r"(?m)^/\* NCPSKY_BUILD_TAG \*/\n(?:const char ncpsky_build_tag\[][^\n]*\n)?"
        r"(?:DECL_CONSTANT_STR\(\"NCPSKY_MCU_TAG\",[^\n]*\n)?"
        r"(?:DECL_CONSTANT_STR\(\"NCPSKY_MCU_CHIP\",[^\n]*\n)?",
        "",
        text,
    )
    text = re.sub(
        r'(?m)^DECL_CONSTANT_STR\("NCPSKY_MCU_TAG",\s*"[^"]*"\);\n?',
        "",
        text,
    )
    text = re.sub(
        r'(?m)^DECL_CONSTANT_STR\("NCPSKY_MCU_CHIP",\s*"[^"]*"\);\n?',
        "",
        text,
    )
    needle = '#include "command.h" // DECL_COMMAND'
    alt = '#include "command.h"'
    block = (
        '/* NCPSKY_BUILD_TAG */\n'
        'DECL_CONSTANT_STR("NCPSKY_MCU_TAG", "%s");\n'
        'DECL_CONSTANT_STR("NCPSKY_MCU_CHIP", "%s");\n'
    ) % (tag, chip_label)
    if needle in text:
        text = text.replace(needle, needle + "\n" + block, 1)
    elif alt in text:
        text = text.replace(alt, alt + " // DECL_COMMAND\n" + block, 1)
    else:
        die('basecmd.c missing #include "command.h"')
    open(path, "w", encoding="utf-8", newline="\n").write(text)
    print("tagged", tag, chip_label)


PHASE_C = os.path.abspath(
    os.path.join(HERE, "..", "..", "..", "products", "ncpsky-dtmax", "mcu", "phase", "ncpsky_xdirect.c")
)


def _insert_once(path, marker, old, new):
    text = open(path, "r", encoding="utf-8", errors="replace").read()
    if marker in text:
        return
    if old not in text:
        die("cannot patch %s — missing expected text" % path)
    open(path, "w", encoding="utf-8", newline="\n").write(text.replace(old, new, 1))
    print("patched", os.path.basename(path))


def apply_phase_sources(src):
    """Copy the XDIRECT driver in and hook stepper position plus SPI locking."""
    if not os.path.isfile(PHASE_C):
        die("missing %s" % PHASE_C)
    dest = os.path.join(src, "src", "ncpsky_xdirect.c")
    shutil.copy2(PHASE_C, dest)
    stepper = os.path.join(src, "src", "stepper.c")
    _insert_once(
        stepper,
        "ncpsky_stepper_position",
        "void\nstepper_shutdown(void)\n",
        "int32_t\n"
        "ncpsky_stepper_position(uint8_t oid)\n"
        "{\n"
        "    struct stepper *s = stepper_oid_lookup(oid);\n"
        "    uint32_t position = stepper_get_position(s);\n"
        "    return (int32_t)(position - POSITION_BIAS);\n"
        "}\n"
        "\n"
        "void\n"
        "stepper_shutdown(void)\n",
    )
    makefile = os.path.join(src, "src", "Makefile")
    _insert_once(
        makefile,
        "ncpsky_xdirect.c",
        "src-y += sched.c command.c basecmd.c debugcmds.c\n",
        "src-y += sched.c command.c basecmd.c debugcmds.c ncpsky_xdirect.c\n",
    )
    header = os.path.join(src, "src", "spi_software.h")
    _insert_once(
        header,
        "spi_software_xdirect_bus",
        "void spi_software_prepare(struct spi_software *ss);\n",
        "void spi_software_prepare(struct spi_software *ss);\n"
        "uint8_t spi_software_xdirect_bus(struct spi_software *ss);\n",
    )
    soft = os.path.join(src, "src", "spi_software.c")
    _insert_once(
        soft,
        "ncpsky_xdirect_owns_sclk",
        "void\nspi_software_prepare(struct spi_software *ss)\n",
        "uint8_t __attribute__((weak)) __attribute__((__noinline__))\n"
        "ncpsky_xdirect_owns_sclk(void *regs, uint32_t bit)\n"
        "{\n"
        "    return 0;\n"
        "}\n"
        "\n"
        "uint8_t\n"
        "spi_software_xdirect_bus(struct spi_software *ss)\n"
        "{\n"
        "    if (!ss)\n"
        "        return 0;\n"
        "    return ncpsky_xdirect_owns_sclk(ss->sclk.regs, ss->sclk.bit);\n"
        "}\n"
        "\n"
        "void\n"
        "spi_software_prepare(struct spi_software *ss)\n",
    )
    spicmds = os.path.join(src, "src", "spicmds.c")
    text = open(spicmds, "r", encoding="utf-8", errors="replace").read()
    if "NCPSKY_XDIRECT_LOCK" not in text:
        if '#include "board/irq.h"' not in text:
            needle = '#include "board/gpio.h" // gpio_out_write\n'
            if needle not in text:
                die("cannot patch spicmds.c includes")
            text = text.replace(
                needle,
                needle + '#include "board/irq.h" // irq_save\n',
                1,
            )
        old = (
            "    if (!(flags & (SF_SOFTWARE|SF_HARDWARE)))\n"
            "        // Not yet initialized\n"
            "        return;\n"
        )
        new = (
            "    if (!(flags & (SF_SOFTWARE|SF_HARDWARE)))\n"
            "        // Not yet initialized\n"
            "        return;\n"
            "    /* NCPSKY_XDIRECT_LOCK */\n"
            "    irqstatus_t xdirect_flag = 0;\n"
            "    uint8_t xdirect_locked = 0;\n"
            "    if (CONFIG_WANT_SOFTWARE_SPI && (flags & SF_SOFTWARE)\n"
            "        && spi_software_xdirect_bus(spi->spi_software)) {\n"
            "        xdirect_flag = irq_save();\n"
            "        xdirect_locked = 1;\n"
            "    }\n"
        )
        if old not in text:
            die("cannot patch spidev_transfer")
        text = text.replace(old, new, 1)
        old_tail = (
            "    if (flags & SF_HAVE_PIN)\n"
            "        gpio_out_write(spi->pin, !(flags & SF_CS_ACTIVE_HIGH));\n"
            "}\n"
        )
        new_tail = (
            "    if (flags & SF_HAVE_PIN)\n"
            "        gpio_out_write(spi->pin, !(flags & SF_CS_ACTIVE_HIGH));\n"
            "    if (xdirect_locked)\n"
            "        irq_restore(xdirect_flag);\n"
            "}\n"
        )
        if old_tail not in text:
            die("cannot patch spidev_transfer tail")
        text = text.replace(old_tail, new_tail, 1)
        open(spicmds, "w", encoding="utf-8", newline="\n").write(text)
        print("patched spicmds.c")


def to_bash_path(win_path):
    p = os.path.abspath(win_path).replace("\\", "/")
    if len(p) >= 2 and p[1] == ":":
        return "/%s%s" % (p[0].lower(), p[2:])
    return p


def _run_bash(bash, script):
    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", newline="\n", suffix=".sh", delete=False
    ) as tf:
        tf.write(script)
        sh_path = tf.name
    try:
        p = subprocess.run(
            [bash, "-lc", "bash '%s'" % to_bash_path(sh_path)], check=False
        )
        return p.returncode
    finally:
        try:
            os.unlink(sh_path)
        except OSError:
            pass


def run_make(src, bash, make_exe, gcc_dir, readelf_dir, jobs, cross_prefix, force):
    py = find_python()
    src_b = to_bash_path(src)
    make_b = to_bash_path(make_exe)
    gcc_b = to_bash_path(gcc_dir)
    extra_path = [gcc_b]
    if readelf_dir:
        extra_path.append(to_bash_path(readelf_dir))
    path_prefix = ":".join(extra_path)

    preamble = r"""
set -euo pipefail
TOOLBIN=$(mktemp -d)
cp -f "{make}" "$TOOLBIN/make" 2>/dev/null || ln -sf "{make}" "$TOOLBIN/make"
chmod +x "$TOOLBIN/make" 2>/dev/null || true
if [ -f "{gcc}/arm-none-eabi-cpp.exe" ]; then
  cp -f "{gcc}/arm-none-eabi-cpp.exe" "$TOOLBIN/cpp.exe" 2>/dev/null || ln -sf "{gcc}/arm-none-eabi-cpp.exe" "$TOOLBIN/cpp.exe"
fi
export PATH="$TOOLBIN:{path_prefix}:$PATH"
cd "{src}"
echo "make=$(command -v make)"
echo "gcc=$(command -v arm-none-eabi-gcc)"
echo "cpp=$(command -v cpp || true)"
arm-none-eabi-gcc --version | head -1
""".format(
        make=make_b, path_prefix=path_prefix, src=src_b, gcc=gcc_b
    )

    script1 = preamble + (
        'make olddefconfig PYTHON="%s" CROSS_PREFIX="%s" CPP=arm-none-eabi-cpp\n' % (py, cross_prefix)
    )
    if _run_bash(bash, script1) != 0:
        die("olddefconfig failed")

    if force:
        script_auto = preamble + (
            "rm -rf out\n"
            "mkdir -p out\n"
            'make out/autoconf.h PYTHON="%s" CROSS_PREFIX="%s" CPP=arm-none-eabi-cpp\n' % (py, cross_prefix)
        )
        if _run_bash(bash, script_auto) != 0:
            die("autoconf generation failed")
        autoconf = os.path.join(src, "out", "autoconf.h")
        patch_autoconf(autoconf, force)
        os.utime(autoconf, None)
        print("patched autoconf.h", force)

    script2 = preamble + r"""
set +e
make -j{jobs} PYTHON="{py}" CROSS_PREFIX="{cross}"
rc=$?
set -e
if [ "$rc" -ne 0 ] || [ ! -f out/klipper.bin ]; then
  echo "retry link with MAKEFLAGS cleared"
  MAKEFLAGS= make -j1 PYTHON="{py}" CROSS_PREFIX="{cross}"
fi
test -f out/klipper.bin
ls -la out/klipper.bin
grep -E 'CONFIG_(FLASH_SIZE|RAM_SIZE|MCU|FLASH_APPLICATION)' out/autoconf.h || true
""".format(
        jobs=int(jobs), py=py, cross=cross_prefix
    )
    # preamble already has set -euo; splice carefully
    script2 = (
        preamble
        + "set +e\n"
        + 'make -j%s PYTHON="%s" CROSS_PREFIX="%s" CPP=arm-none-eabi-cpp\n' % (int(jobs), py, cross_prefix)
        + "rc=$?\n"
        + "set -e\n"
        + 'if [ "$rc" -ne 0 ] || [ ! -f out/klipper.bin ]; then\n'
        + '  echo "retry link with MAKEFLAGS cleared"\n'
        + '  MAKEFLAGS= make -j1 PYTHON="%s" CROSS_PREFIX="%s" CPP=arm-none-eabi-cpp\n' % (py, cross_prefix)
        + "fi\n"
        + "test -f out/klipper.bin\n"
        + "ls -la out/klipper.bin\n"
        + "grep -E 'CONFIG_(FLASH_SIZE|RAM_SIZE|MCU|FLASH_APPLICATION)' out/autoconf.h || true\n"
    )
    if _run_bash(bash, script2) != 0:
        die("MCU build failed")


def vector_info(path):
    with open(path, "rb") as f:
        data = f.read(8)
    sp = int.from_bytes(data[0:4], "little")
    reset = int.from_bytes(data[4:8], "little")
    return sp, reset


def write_outputs(bin_src, version, tag, notes, profile):
    os.makedirs(DIST, exist_ok=True)
    base = version[:-4] if version.endswith(".bin") else version
    dest = os.path.join(DIST, "%s.bin" % base)
    shutil.copy2(bin_src, dest)
    digest = sha256_file(dest)
    size = os.path.getsize(dest)
    sp, reset = vector_info(dest)
    open(dest + ".sha256", "w", encoding="utf-8").write(
        "%s  %s\n" % (digest, os.path.basename(dest))
    )
    meta = {
        "kind": "mcu",
        "version": base,
        "file": os.path.basename(dest),
        "sha256": digest,
        "size": size,
        "profile": profile.get("id"),
        "chip": profile.get("id"),
        "chip_label": profile.get("label"),
        "flash_address": profile.get("flash_address"),
        "flash_size": profile.get("flash_size"),
        "ram_size": profile.get("ram_size"),
        "vector_sp": "0x%08X" % sp,
        "vector_reset": "0x%08X" % reset,
        "build_tag": tag,
        "built_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "host": "windows",
        "notes": notes,
    }
    meta_path = dest + ".json"
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)
        f.write("\n")
    print("OUT", dest)
    print("SHA", digest)
    print("SIZE", size)
    print("PROFILE", profile.get("id"))
    print("SP 0x%08X  RESET 0x%08X" % (sp, reset))
    print("META", meta_path)
    return dest, digest, meta


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--version", required=True, help="e.g. mcu-20261125")
    ap.add_argument("--tag", default=None)
    ap.add_argument("--src", default=DEFAULT_SRC)
    ap.add_argument(
        "--profile",
        default=None,
        help="MCU profile id (default: product default gd32f303vet6)",
    )
    ap.add_argument("--defconfig", default=None, help="Override profile defconfig path")
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--notes", default=None)
    ap.add_argument("--skip-tag", action="store_true")
    args = ap.parse_args()

    profile = get_profile(args.profile)
    defconfig = args.defconfig or profile.get("defconfig")
    if not defconfig or not os.path.isfile(defconfig):
        die("defconfig missing for profile %s" % profile.get("id"))

    src = os.path.abspath(args.src)
    if not os.path.isfile(os.path.join(src, "Makefile")):
        die(
            "MCU source not found at %s\n"
            "Seed once: python printers/flsun-t1-max/scratch/pull_klipper_mcu_src.py"
            % src
        )

    cross, gcc_dir = find_gcc_prefix()
    make_exe = find_make()
    bash = find_bash()
    readelf_dir = find_readelf_dir()
    print("profile", profile.get("id"), profile.get("label"))
    print("defconfig", defconfig)
    print("gcc_dir", gcc_dir)
    print("make", make_exe)

    ensure_vendor_into_src(src)
    patch_buildcommands_crlf(src)
    patch_makefile_board_link(src)
    apply_phase_sources(src)

    out_dir = os.path.join(src, "out")
    if os.path.isdir(out_dir):
        shutil.rmtree(out_dir)
    cfg = os.path.join(src, ".config")
    shutil.copy2(defconfig, cfg)
    print("seeded .config from", defconfig)

    tag = args.tag
    if not tag:
        ver = args.version[4:] if args.version.startswith("mcu-") else args.version
        tag = "NCPSKY-MCU-%s-%s" % (profile.get("id", "chip").upper(), ver)
    chip_label = profile.get("label") or profile.get("id") or "unknown"
    if not args.skip_tag:
        inject_build_tag(src, tag, chip_label)

    force = dict(profile.get("autoconf_force") or {})
    run_make(src, bash, make_exe, gcc_dir, readelf_dir, args.jobs, cross, force)

    notes = args.notes or (
        "Windows build profile=%s flash=%s" % (profile.get("id"), profile.get("flash_address"))
    )
    bin_src = os.path.join(src, "out", "klipper.bin")
    write_outputs(bin_src, args.version, tag, notes, profile)


if __name__ == "__main__":
    main()
