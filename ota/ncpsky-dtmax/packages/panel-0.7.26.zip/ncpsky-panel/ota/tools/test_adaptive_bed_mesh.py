#!/usr/bin/env python3
"""Adaptive mesh planner and gcode footprint scanner."""
from __future__ import annotations

import os
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
OVERLAY = os.path.abspath(os.path.join(HERE, "..", "..", "klipper_overlays"))
sys.path.insert(0, OVERLAY)

from ncpsky_adaptive_mesh import (  # noqa: E402
    blend_z,
    fused_probe_count,
    plan_adaptive_mesh,
    plan_line_lift,
    scan_gcode,
)


def plan(xmin, xmax, ymin, ymax):
    got = plan_adaptive_mesh(
        xmin, xmax, ymin, ymax,
        margin=10, max_r=135, min_r=20, min_n=3, max_n=7, spacing=45,
    )
    return (
        round(got["origin_x"], 2),
        round(got["origin_y"], 2),
        got["radius"],
        got["probe_count"],
        got["covered"],
    )


def expect_plan(box, origin, radius, count, covered):
    got = plan(*box)
    want = (origin[0], origin[1], radius, count, covered)
    if got != want:
        raise AssertionError("box %s\n got %s\n want %s" % (box, got, want))


def scan(text):
    fd, path = tempfile.mkstemp(suffix=".gcode")
    os.close(fd)
    try:
        with open(path, "w", encoding="utf-8", newline="\n") as handle:
            handle.write(text)
        return scan_gcode(path)
    finally:
        os.remove(path)


def main():
    expect_plan((-10, 10, -10, 10), (0.0, 0.0), 28.2, 3, True)
    expect_plan((-50, 50, -50, 50), (0.0, 0.0), 84.8, 5, True)
    expect_plan((0, 0, 0, 0), (0.0, 0.0), 20.0, 3, True)
    expect_plan((100, 130, -10, 10), (115.0, 0.0), 20.0, 3, True)
    expect_plan((120, 150, -5, 5), (115.0, 0.0), 20.0, 3, False)
    expect_plan((-170, 170, -170, 170), (0.0, 0.0), 135.0, 7, False)
    expect_plan((-40, -20, -5, 5), (-30.0, 0.0), 25.0, 3, True)

    # Purge arc is before the layer marker and must not inflate the mesh.
    orca = """
G21
G90
M82
G3 X0 Y-160 I160 Z0.3 E30 F2000
;LAYER_CHANGE
;Z:0.2
G92 E0
G1 X10 Y10 F9000
G1 X30 Y10 E1.2
G1 X30 Y30 E2.4
G1 X10 Y30 E3.6
G1 X10 Y10 E4.8
;LAYER_CHANGE
;Z:0.4
G1 X200 Y200 E8
"""
    got = scan(orca)
    if got != (10.0, 10.0, 30.0, 30.0, "first_layer"):
        raise AssertionError("orca footprint %s" % (got,))

    # Combined hop off the purge with almost no extrusion: keep only the landing point.
    hop = """
G90
M82
G1 X0 Y-160 E5
;LAYER_CHANGE
G1 X12 Y8 E5.2
G1 X22 Y8 E6
G1 X22 Y18 E7
;LAYER_CHANGE
"""
    got = scan(hop)
    if got != (12.0, 8.0, 22.0, 18.0, "first_layer"):
        raise AssertionError("hop footprint %s" % (got,))

    cura = """
G90
M83
;LAYER:0
G1 X-5 Y-5
G1 X5 Y-5 E0.4
G1 X5 Y5 E0.4
G1 X-5 Y5 E0.4
G1 X-5 Y-5 E0.4
;LAYER:1
G1 X80 Y80 E0.4
"""
    got = scan(cura)
    if got != (-5.0, -5.0, 5.0, 5.0, "first_layer"):
        raise AssertionError("cura footprint %s" % (got,))

    exclude_only = """
EXCLUDE_OBJECT_DEFINE NAME=a POLYGON=[[-15,-5],[15,-5],[15,5],[-15,5]]
EXCLUDE_OBJECT_DEFINE NAME=b POLYGON=[[20,0],[40,0],[40,10]]
G1 X0 Y0 E1
"""
    got = scan(exclude_only)
    if got != (-15.0, -5.0, 40.0, 10.0, "exclude_object"):
        raise AssertionError("exclude footprint %s" % (got,))

    if scan("G28\nG1 X1 Y1 E1\n") is not None:
        raise AssertionError("moves before a layer marker are not the part")

    # Same spacing keeps the original grid. A finer local mesh raises the count.
    if fused_probe_count(270, 7, 270, 7) != 7:
        raise AssertionError("same density should stay 7")
    if fused_probe_count(270, 7, 40, 5) < 27:
        raise AssertionError("finer local mesh should keep its spacing")

    outside, changed = blend_z(0.1, 0.4, 30, 20, 6)
    if changed or abs(outside - 0.1) > 1e-9:
        raise AssertionError("outside the probe circle must keep the old mesh")
    inside, changed = blend_z(0.1, 0.4, 0, 20, 6)
    if not changed or abs(inside - 0.4) > 1e-9:
        raise AssertionError("inside the probe circle must take the new point")
    mid, changed = blend_z(0.0, 1.0, 17, 20, 6)
    if not changed or not (0.0 < mid < 1.0):
        raise AssertionError("rim should blend old and new, got %s" % mid)

    cur = [0.0, -160.0, 0.3, 10.0]
    line = [80.0, -160.0, 0.3, 12.0]
    saw, inserts = plan_line_lift(cur, line, False, False)
    if not saw or inserts:
        raise AssertionError("the purge line itself must not lift")
    start = [20.0, 15.0, 0.2, 12.0]
    saw, inserts = plan_line_lift(line, start, saw, False)
    if not inserts or len(inserts) != 2:
        raise AssertionError("travel after the line should lift, got %s" % (inserts,))
    lift, travel = inserts
    if abs(lift[0][2] - 10.0) > 1e-9 or abs(travel[0][2] - 10.0) > 1e-9:
        raise AssertionError("lift height must be 10mm")
    if abs(travel[0][0] - 20.0) > 1e-9 or abs(travel[0][1] - 15.0) > 1e-9:
        raise AssertionError("travel must stop above the model start XY")
    if abs(travel[0][3] - 12.0) > 1e-9:
        raise AssertionError("the hop must not extrude")

    print("adaptive bed mesh checks ok")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except AssertionError as exc:
        print("FAIL", exc)
        sys.exit(1)
