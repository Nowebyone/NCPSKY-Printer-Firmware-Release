pragma Singleton
import QtQuick 2.15

QtObject {
    id: root

    property string machineName: "NCPSKY ▲ DTMax"
    // Panel / firmware identity (shown in Settings → About)
    property string panelVersion: "0.5.6"
    property string panelBuild: "2026.11.24"
    property string firmwareTarget: "FLSun T1 Max"
    property string klipperVersion: "—"
    property string klipperCoreVersion: "0.14.0"
    property string klipperCustomVersion: "—"
    property string moonrakerVersion: "—"
    property string hostName: "—"
    property string mcuInfo: "—"
    property string page: "home"
    property bool splashDone: false
    property bool connected: false
    property string klippyState: "disconnected"
    property string stateMessage: ""
    // Fullscreen calibration lock: hide nav, block page switches
    property bool calibrating: false
    // Confirm dialog / other modal: also block nav & page switches
    property bool pageLocked: false

    property real extruderTemp: 0
    property real extruderTarget: 0
    property real bedTemp: 0
    property real bedTarget: 0
    property real printProgress: 0
    property string printFilename: ""
    property bool printing: false
    property bool paused: false
    property bool printPaused: false
    // Panel-side print prep (motor check + start gcode) shown on Home print UI
    property bool printPreparing: false
    property string printPrepDetail: ""
    property int _printStartToken: 0
    property real printDuration: 0
    property real printEta: 0
    property string printEtaText: "--:--"
    property int printLayer: 0
    property int printLayerTotal: 0
    property real toolX: 0
    property real toolY: 0
    property real toolZ: 0
    property real bedRadius: 145
    property real printObjectHeight: 0
    property var printTrail: []
    property real _trailLastX: 99999
    property real _trailLastY: 99999
    property string _printMetaFor: ""
    property string filamentType: "PLA"
    property int filamentTemp: 210
    property int speedMode: 100
    property real speedFactor: 100
    property bool ledOn: false
    property var gcodeFiles: []
    property var hmsItems: []
    property color hmsBadgeColor: Theme.ok
    property string wifiSsid: ""
    property string wifiHint: "查询中…"
    property string wifiIp: ""
    property var wifiSignal: null
    property string wifiState: ""
    property var wifiList: []
    property bool wifiBusy: false
    property string wifiMessage: ""
    property bool proxyConfigured: false
    property bool proxyVlessConfigured: false
    property string proxyVlessHost: ""
    property string proxyMode: ""
    property string proxyType: ""
    property string proxyLabel: ""
    property string proxyManualServer: ""
    property string proxyManualPort: "443"
    property string proxyManualUuid: ""
    property string proxyManualSni: ""
    property string proxyManualPbk: ""
    property string proxyManualSid: ""
    property string proxyLocalPort: "7890"
    property bool proxySingboxActive: false
    property bool proxyLocalListening: false
    property int brightness: 100
    property string language: "zh"
    property string clockText: Qt.formatTime(new Date(), "hh:mm")

    // OTA (NCPSKY updater via helper :7126)
    property string otaChannel: "stable"
    property string otaSource: "http"
    property bool otaProxyEnabled: false
    property string otaProxyUrl: ""
    property string otaGithubMirror: ""
    property string otaGithubOwner: ""
    property string otaGithubRepoName: ""
    property string otaGithubRef: "main"
    property string otaGithubPrefix: ""
    property string otaGithubRepo: ""
    property string otaBaseUrl: ""
    property string otaSourceHint: ""
    property string otaStackVersion: "—"
    property string otaSystemVersion: "—"
    property string otaMcuVersion: "—"
    property var otaAvailable: []
    property var otaSelected: ({})
    property bool otaBusy: false
    property real otaProgress: 0
    property string otaMessage: ""
    property string otaError: ""
    property string otaLastCheck: ""
    property var otaConfirmMcu: null
    property string otaPhase: "idle"
    property real otaDiskFreeMb: 0
    property bool otaUpdateAvailable: false
    property string otaNotes: ""
    property string otaVersionLabel: ""
    property bool otaDialogOpen: false
    property bool otaBootChecked: false
    property string otaCheckStatus: ""   // "" | checking | latest | error

    property int _reqId: 1
    property string baseUrl: "http://127.0.0.1:7125"
    property string helperUrl: "http://127.0.0.1:7126"

    // Compact UI dictionary (zh default → en)
    property var _i18n: ({
        "settings.title": ["设置", "Settings"],
        "settings.sub": ["网络 · 代理 · 更新", "Network · proxy · update"],
        "settings.tab.wifi": ["Wi‑Fi", "Wi‑Fi"],
        "settings.tab.proxy": ["代理", "Proxy"],
        "settings.tab.update": ["更新", "Update"],
        "settings.tab.display": ["显示", "Display"],
        "settings.tab.more": ["更多", "More"],
        "settings.calibrate": ["校准", "Calibrate"],
        "settings.calibrate.sub": ["床网调平 · 震动 · 电机降噪", "Bed mesh · shaper · motor noise"],
        "settings.network": ["网络", "Network"],
        "settings.refresh": ["刷新", "Refresh"],
        "settings.offline": ["未连接", "Offline"],
        "settings.wifi": ["Wi‑Fi", "Wi‑Fi"],
        "settings.wifi.scan": ["扫描", "Scan"],
        "settings.wifi.disconnect": ["断开", "Disconnect"],
        "settings.wifi.connect": ["连接", "Connect"],
        "settings.wifi.password": ["Wi‑Fi 密码", "Wi‑Fi password"],
        "settings.wifi.open": ["开放网络", "Open network"],
        "settings.wifi.empty": ["点「扫描」查找附近热点", "Tap Scan for networks"],
        "settings.wifi.scanning": ["正在扫描…", "Scanning…"],
        "settings.wifi.connecting": ["正在连接…", "Connecting…"],
        "settings.wifi.disconnected": ["未连接 Wi‑Fi", "Wi‑Fi disconnected"],
        "settings.proxy": ["网络代理", "Proxy"],
        "settings.proxy.desc": ["无法访问更新时，可配置代理。", "Configure a proxy when updates need internet."],
        "settings.proxy.hint.simple": ["点「粘贴配置」输入分享链接或订阅地址即可。高级选项可展开。", "Paste a share link or subscription. Open Advanced for more."],
        "settings.proxy.enable": ["更新走代理", "Use for updates"],
        "settings.proxy.setup": ["粘贴配置", "Paste config"],
        "settings.proxy.share": ["分享链接", "Share link"],
        "settings.proxy.sub": ["机场订阅", "Subscription"],
        "settings.proxy.http": ["HTTP/SOCKS", "HTTP/SOCKS"],
        "settings.proxy.manual": ["手动", "Manual"],
        "settings.proxy.advanced": ["高级选项", "Advanced"],
        "settings.proxy.reconfig": ["更换配置", "Change config"],
        "settings.proxy.ready": ["代理运行中", "Proxy running"],
        "settings.proxy.configured": ["已配置", "Configured"],
        "settings.proxy.none": ["未配置", "Not set"],
        "settings.proxy.using": ["更新已启用", "Enabled for updates"],
        "settings.proxy.node": ["节点", "Node"],
        "settings.proxy.port": ["本地端口", "Local port"],
        "settings.proxy.apply": ["应用", "Apply"],
        "settings.proxy.server": ["服务器", "Server"],
        "settings.proxy.uuid": ["UUID/密码", "UUID/password"],
        "settings.proxy.sni": ["SNI", "SNI"],
        "settings.proxy.pbk": ["公钥 pbk", "Public key"],
        "settings.proxy.sid": ["短 ID", "Short ID"],
        "settings.display": ["显示与语言", "Display & language"],
        "wifi.secure": ["加密", "Secured"],
        "kb.ok": ["确定", "OK"],
        "kb.cancel": ["取消", "Cancel"],
        "kb.placeholder": ["点击按键输入…", "Type…"],
        "settings.brightness": ["屏幕亮度", "Brightness"],
        "settings.dim": ["较暗", "Dim"],
        "settings.mid": ["适中", "Medium"],
        "settings.bright": ["较亮", "Bright"],
        "settings.language": ["语言", "Language"],
        "settings.maintain": ["维护", "Maintenance"],
        "settings.expand": ["展开", "Expand"],
        "settings.collapse": ["收起", "Collapse"],
        "settings.maintain.hint": ["打印中请勿操作。校准请使用左侧「校准」页。", "Do not use while printing. Use Calibrate for leveling."],
        "settings.reboot": ["重启设备", "Restart"],
        "settings.estop": ["紧急停止", "E-Stop"],
        "settings.about": ["关于本机", "About"],
        "settings.ver.panel": ["面板版本", "Panel"],
        "settings.ver.firmware": ["固件版本", "Firmware"],
        "settings.ver.klipper_core": ["KlipperCore", "KlipperCore"],
        "settings.ver.klipper_custom": ["定制版本", "Custom build"],
        "settings.ver.moonraker": ["Moonraker", "Moonraker"],
        "settings.ver.target": ["适用机型", "Model"],
        "settings.ver.host": ["主机", "Host"],
        "settings.ver.mcu": ["控制板", "MCU / CPU"],
        "settings.ota": ["固件更新", "Firmware update"],
        "settings.ota.hint": ["打印中不可更新", "Blocked while printing"],
        "settings.ota.channel": ["更新通道", "Channel"],
        "settings.ota.proxy": ["代理", "Proxy"],
        "settings.ota.proxy.on": ["开", "On"],
        "settings.ota.proxy.off": ["关", "Off"],
        "settings.ota.stable": ["稳定版", "Stable"],
        "settings.ota.beta": ["测试版", "Beta"],
        "settings.ota.dev": ["开发版", "Dev"],
        "settings.ota.check": ["检查更新", "Check for updates"],
        "settings.ota.upgrade": ["立即更新", "Update now"],
        "settings.ota.later": ["稍后", "Later"],
        "settings.ota.rollback": ["回滚", "Rollback"],
        "settings.ota.confirm_mcu": ["确认刷写 MCU", "Confirm MCU flash"],
        "settings.ota.none": ["已是最新", "Up to date"],
        "settings.ota.busy": ["正在更新…", "Updating…"],
        "settings.ota.rebooting": ["更新完成，正在重启…", "Done — rebooting…"],
        "settings.ota.found": ["发现新版本", "Update available"],
        "settings.ota.dialog.title": ["有可用更新", "Update available"],
        "settings.ota.dialog.body": ["更新后设备将自动重启。Wi‑Fi、代理与打印记录会保留。", "Device will reboot. Wi‑Fi, proxy and print history are kept."],
        "settings.ota.stack": ["主机栈", "Stack"],
        "settings.ota.system": ["系统包", "System"],
        "settings.ota.mcu_pkg": ["MCU 固件", "MCU firmware"],
        "settings.ota.last": ["上次检查", "Last check"],
        "settings.ota.current": ["当前版本", "Current version"],
        "settings.ota.select": ["选择要更新的包", "Select packages"],
        "device.title": ["设备", "Device"],
        "device.temp": ["温度", "Temp"],
        "device.move": ["移动", "Move"],
        "device.extrude": ["出料", "Extrude"],
        "device.nozzle": ["喷嘴", "Nozzle"],
        "device.bed": ["热床", "Bed"],
        "device.off": ["关闭", "Off"],
        "device.preset.pla": ["PLA 210°", "PLA 210°"],
        "device.preset.petg": ["PETG 240°", "PETG 240°"],
        "device.preset.abs": ["ABS 250°", "ABS 250°"],
        "device.bed.pla": ["PLA 60°", "PLA 60°"],
        "device.bed.petg": ["PETG 80°", "PETG 80°"],
        "device.bed.abs": ["ABS 100°", "ABS 100°"],
        "device.xyz.home": ["回中", "Home"],
        "device.up": ["升", "Up"],
        "device.down": ["降", "Down"],
        "device.front": ["前", "Fwd"],
        "device.back": ["后", "Back"],
        "device.left": ["左", "L"],
        "device.right": ["右", "R"],
        "device.step": ["升降 / 步距", "Z / step"],
        "device.homeall": ["喷头归位", "Home all"],
        "device.extrude.hint": ["先加热喷嘴，再出料或回抽。用于换料或疏通。", "Heat nozzle first, then extrude or retract."],
        "device.extrude10": ["出料 10mm", "Extrude 10"],
        "device.retract10": ["回抽 10mm", "Retract 10"],
        "device.extrude50": ["出料 50mm", "Extrude 50"],
        "device.notheated": ["未加热", "Cold"],
        "home.ready": ["可以开始打印", "Ready to print"],
        "home.offline": ["设备离线", "Offline"],
        "home.pick": ["选文件 · 开始打印", "Pick file · Print"],
        "calibrate.title": ["校准", "Calibrate"],
        "heat.heating": ["加热中", "Heating"],
        "heat.cooling": ["冷却中", "Cooling"],
        "heat.hold": ["恒温", "Hold"],
        "toast.brightness": ["亮度", "Brightness"],
        "toast.lang.zh": ["已切换中文", "Switched to 中文"],
        "toast.lang.en": ["已切换 English", "Language: English"],
        "toast.brightness.fail": ["亮度调节失败", "Brightness failed"],
        "wifi.fail": ["无法读取网络", "Network unavailable"],
        "wifi.local": ["本机局域网", "Local network"],
        "wifi.open": ["开放", "Open"]
    })

    signal toast(string msg)
    signal hmsPushed(var item)

    function tr(key) {
        var row = _i18n[key]
        if (!row) return key
        return language === "en" ? row[1] : row[0]
    }

    function printSessionActive() {
        return printing || printPaused || printPreparing
    }

    function go(p) {
        if (calibrating || pageLocked)
            return
        // Compat aliases from older IA
        if (p === "controls") p = "device"
        if (p === "hms") p = "alerts"
        if (p === "calibration" || p === "calib") p = "calibrate"
        // During print/prep: only Home print UI + Messages
        if (printSessionActive() && p !== "home" && p !== "alerts")
            return
        page = p
    }

    function heaterBandText() {
        var et = Math.round(extruderTemp)
        var bt = Math.round(bedTemp)
        var ett = Math.round(extruderTarget)
        var btt = Math.round(bedTarget)
        var eHeat = ett > 0 && extruderTemp < ett - 1.5
        var bHeat = btt > 0 && bedTemp < btt - 1.5
        var eCool = (ett <= 0 && extruderTemp > 45) || (ett > 0 && extruderTemp > ett + 2.5)
        var bCool = (btt <= 0 && bedTemp > 40) || (btt > 0 && bedTemp > btt + 2.5)
        var eHold = ett > 0 && !eHeat && !eCool
        var bHold = btt > 0 && !bHeat && !bCool
        var ePart = tr("device.nozzle") + et + (ett > 0 ? ("→" + ett) : "") + "°"
        var bPart = tr("device.bed") + bt + (btt > 0 ? ("→" + btt) : "") + "°"
        if (eHeat || bHeat)
            return tr("heat.heating") + "  " + ePart + "  " + bPart
        if (eCool || bCool)
            return tr("heat.cooling") + "  " + ePart + "  " + bPart
        if (eHold || bHold)
            return tr("heat.hold") + "  " + ePart + "  " + bPart
        // Idle but still warm: show current only
        if (extruderTemp > 40 || bedTemp > 35)
            return tr("device.nozzle") + et + "°  " + tr("device.bed") + bt + "°"
        return ""
    }
    function nextId() { _reqId += 1; return _reqId }

    function _fmtEta(sec) {
        if (!sec || sec < 0) return "--:--"
        var m = Math.floor(sec / 60)
        var s = Math.floor(sec % 60)
        var h = Math.floor(m / 60)
        m = m % 60
        if (h > 0) return h + "h" + (m < 10 ? "0" : "") + m + "m"
        return (m < 10 ? "0" : "") + m + ":" + (s < 10 ? "0" : "") + s
    }

    function httpGet(path, cb) {
        var xhr = new XMLHttpRequest()
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== XMLHttpRequest.DONE) return
            if (xhr.status >= 200 && xhr.status < 300) {
                var data = null
                try { data = JSON.parse(xhr.responseText) } catch (e) { data = xhr.responseText }
                if (cb) cb(data, null)
            } else {
                if (cb) cb(null, "HTTP " + xhr.status)
            }
        }
        xhr.open("GET", baseUrl + path)
        xhr.send()
    }

    function _httpErrorMessage(status, body) {
        var msg = ""
        try {
            var j = JSON.parse(body)
            if (j && j.error) {
                if (typeof j.error === "string") msg = j.error
                else msg = j.error.message || JSON.stringify(j.error)
            }
        } catch (e) {
            msg = body || ""
        }
        msg = ("" + msg).replace(/\n/g, " ")
        if (msg.indexOf("samples_tolerance") >= 0 || msg.indexOf("Probe samples exceed") >= 0)
            return "探针读数不稳定（容差超限），请清洁探针/热床后再试"
        if (msg.indexOf("Must home") >= 0)
            return "需要先归位"
        if (msg.indexOf("Unknown command") >= 0)
            return "打印机不支持该指令：" + msg
        if (!msg)
            return "HTTP " + status
        return msg
    }

    function httpPost(path, bodyObj, cb) {
        var xhr = new XMLHttpRequest()
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== XMLHttpRequest.DONE) return
            if (xhr.status >= 200 && xhr.status < 300) {
                var data = null
                try { data = JSON.parse(xhr.responseText) } catch (e) { data = xhr.responseText }
                if (cb) cb(data, null)
            } else {
                if (cb) cb(null, _httpErrorMessage(xhr.status, xhr.responseText))
            }
        }
        xhr.open("POST", baseUrl + path)
        // Long calibrations (mesh / shaper) can exceed default network idle limits
        try { xhr.timeout = 600000 } catch (e2) {}
        xhr.ontimeout = function() {
            if (cb) cb(null, "等待超时（步骤过久未返回）")
        }
        if (bodyObj !== undefined && bodyObj !== null) {
            xhr.setRequestHeader("Content-Type", "application/json")
            xhr.send(JSON.stringify(bodyObj))
        } else {
            xhr.send()
        }
    }

    function rpc(method, params, cb) {
        var payload = { jsonrpc: "2.0", method: method, id: nextId() }
        if (params !== undefined) payload.params = params
        httpPost("/server/jsonrpc", payload, function(data, err) {
            if (err) {
                // fallback: some Moonraker builds accept POST /
                httpPost("/", payload, function(data2, err2) {
                    if (err2) {
                        if (cb) cb(null)
                        return
                    }
                    if (data2 && data2.error)
                        pushHms("warn", "RPC error", data2.error.message || "")
                    if (cb) cb(data2 ? data2.result : null)
                })
                return
            }
            if (data && data.error)
                pushHms("warn", "RPC error", data.error.message || "")
            if (cb) cb(data ? data.result : null)
        })
    }

    function gcode(script) {
        // REST is most portable
        httpPost("/printer/gcode/script?script=" + encodeURIComponent(script), null)
    }

    // Moonraker blocks until the script finishes — used by continuous calibration
    function gcodeWait(script, cb) {
        httpPost("/printer/gcode/script?script=" + encodeURIComponent(script), null, function(data, err) {
            if (cb) cb(!err, err || "")
        })
    }

    function _fileBase(path) {
        var s = "" + path
        var i = s.lastIndexOf("/")
        return i >= 0 ? s.substring(i + 1) : s
    }

    function _thumbUrlForMeta(path, meta) {
        var thumbs = (meta && meta.thumbnails) ? meta.thumbnails : []
        if (!thumbs.length) return ""
        // Prefer ~48px for list rows
        var best = null
        var bestScore = 1e9
        for (var i = 0; i < thumbs.length; i++) {
            var t = thumbs[i]
            var wh = Math.max(Number(t.width) || 0, Number(t.height) || 0)
            var score = Math.abs(wh - 48)
            if (score < bestScore) {
                bestScore = score
                best = t
            }
        }
        if (!best || !best.relative_path) return ""
        var rel = "" + best.relative_path
        // relative_path is usually ".thumbs/xxx.png" under the gcode dir
        var dir = ""
        var slash = path.lastIndexOf("/")
        if (slash >= 0)
            dir = path.substring(0, slash + 1)
        var full = dir + rel
        // Keep slashes in path; encode the rest
        var parts = full.split("/")
        for (var p = 0; p < parts.length; p++)
            parts[p] = encodeURIComponent(parts[p])
        return baseUrl + "/server/files/gcodes/" + parts.join("/")
    }

    function _fetchFileThumb(index, path) {
        httpGet("/server/files/metadata?filename=" + encodeURIComponent(path), function(data, err) {
            if (err || !data) return
            var meta = data.result || data
            var url = _thumbUrlForMeta(path, meta)
            if (!url) return
            var copy = gcodeFiles.slice()
            if (index < 0 || index >= copy.length) return
            if (!copy[index] || copy[index].path !== path) return
            copy[index] = {
                path: path,
                name: copy[index].name || _fileBase(path),
                thumb: url
            }
            gcodeFiles = copy
        })
    }

    function refreshFiles() {
        httpGet("/server/files/list?root=gcodes", function(data, err) {
            var out = []
            var list = data
            if (data && data.result) list = data.result
            if (list && list.length !== undefined) {
                for (var i = 0; i < list.length; i++) {
                    var f = list[i]
                    var path = (typeof f === "string") ? f : (f.path || f.filename || "")
                    if (path.toLowerCase().indexOf(".gcode") >= 0)
                        out.push({ path: path, name: _fileBase(path), thumb: "" })
                }
            }
            gcodeFiles = out
            for (var j = 0; j < out.length; j++)
                _fetchFileThumb(j, out[j].path)
        })
    }

    function startPrint(path) {
        if (!path || printSessionActive())
            return
        if (!connected) {
            toast("打印机未连接")
            return
        }
        var token = _printStartToken + 1
        _printStartToken = token
        printPreparing = true
        printFilename = _fileBase(path)
        printProgress = 0
        printLayer = 0
        printEtaText = "--:--"
        printPrepDetail = "正在检查电机状态…"
        page = "home"

        // Motor check first (user-facing: 检查电机状态), UI already on print home
        gcodeWait("CALIBRATE_MOTOR_NOISE", function(ok, errMsg) {
            if (token !== _printStartToken)
                return
            if (!ok) {
                printPreparing = false
                printPrepDetail = ""
                pushHms("warn", "打印准备失败", errMsg || "电机检查失败")
                return
            }
            printPrepDetail = "正在载入打印文件…"
            httpPost("/printer/print/start?filename=" + encodeURIComponent(path), null, function(data, err2) {
                if (token !== _printStartToken)
                    return
                if (err2) {
                    printPreparing = false
                    printPrepDetail = ""
                    pushHms("warn", "打印启动失败", err2)
                    return
                }
                printPrepDetail = "任务已启动 · 等待加热与归位…"
            })
        })
    }

    function pausePrint() {
        if (printPreparing && !printing)
            return
        httpPost("/printer/print/pause", null)
    }
    function resumePrint() { httpPost("/printer/print/resume", null) }
    function cancelPrint() {
        // Abort panel prep before Moonraker job exists
        if (printPreparing && !printing) {
            _printStartToken = _printStartToken + 1
            printPreparing = false
            printPrepDetail = ""
            return
        }
        httpPost("/printer/print/cancel", null)
        printPreparing = false
        printPrepDetail = ""
    }

    function _refreshPrintPrepDetail(status) {
        if (!printPreparing)
            return
        // Keep motor-check / load-file copy until job is actually printing
        if (!printing && !printPaused) {
            if (!printPrepDetail || printPrepDetail.indexOf("检查电机") >= 0
                    || printPrepDetail.indexOf("载入打印") >= 0)
                return
        }
        // First extruded progress / layer → leave prep UI
        if (printing && (printProgress >= 0.008 || printLayer > 0)) {
            printPreparing = false
            printPrepDetail = ""
            return
        }
        var et = Math.round(extruderTemp)
        var bt = Math.round(bedTemp)
        var ett = Math.round(extruderTarget)
        var btt = Math.round(bedTarget)
        var th = (status && status.toolhead) ? status.toolhead : {}
        var homed = ("" + (th.homed_axes || "")).toLowerCase()
        if (ett > 0 && extruderTemp < extruderTarget - 2.0) {
            printPrepDetail = "喷嘴加热中 · 当前 " + et + "° → 目标 " + ett + "°"
            return
        }
        if (btt > 0 && bedTemp < bedTarget - 2.0) {
            printPrepDetail = "热床加热中 · 当前 " + bt + "° → 目标 " + btt + "°"
            return
        }
        if (homed.indexOf("xyz") < 0) {
            printPrepDetail = "喷头归位中 · 请勿触碰机身"
            return
        }
        if (printing || printPaused) {
            printPrepDetail = "打印机准备中 · 喷嘴" + et + "° 热床" + bt + "° · 请稍候"
            return
        }
    }

    function setExtruderTemp(t) { gcode("SET_HEATER_TEMPERATURE HEATER=extruder TARGET=" + t) }
    function setBedTemp(t) { gcode("SET_HEATER_TEMPERATURE HEATER=heater_bed TARGET=" + t) }
    function setSpeed(pct) { speedMode = pct; speedFactor = pct; gcode("M220 S" + pct) }
    function homeAll() { gcode("G28") }
    function moveAxis(axis, dist, speed) {
        gcode("G91")
        gcode("G1 " + axis + dist + " F" + (speed || 3000))
        gcode("G90")
    }
    function extrude(mm) {
        gcode("M83")
        gcode("G1 E" + mm + " F300")
        gcode("M82")
    }
    function firmwareRestart() { httpPost("/printer/firmware_restart", null) }
    function emergencyStop() { httpPost("/printer/emergency_stop", null) }
    function restartKlipper() { rpc("machine.services.restart", { service: "klipper" }) }
    function restartMoonraker() { httpPost("/server/restart", null) }

    function helperGet(path, cb) {
        var xhr = new XMLHttpRequest()
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== XMLHttpRequest.DONE) return
            if (xhr.status >= 200 && xhr.status < 300) {
                var data = null
                try { data = JSON.parse(xhr.responseText) } catch (e) { data = xhr.responseText }
                if (cb) cb(data, null)
            } else {
                if (cb) cb(null, "HTTP " + xhr.status)
            }
        }
        xhr.open("GET", helperUrl + path)
        try { xhr.timeout = 60000 } catch (e2) {}
        xhr.ontimeout = function() {
            if (cb) cb(null, "timeout")
        }
        xhr.send()
    }

    function helperPost(path, bodyObj, cb) {
        var xhr = new XMLHttpRequest()
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== XMLHttpRequest.DONE) return
            if (xhr.status >= 200 && xhr.status < 300) {
                var data = null
                try { data = JSON.parse(xhr.responseText) } catch (e) { data = xhr.responseText }
                if (cb) cb(data, null)
            } else {
                if (cb) cb(null, "HTTP " + xhr.status)
            }
        }
        xhr.open("POST", helperUrl + path)
        try { xhr.timeout = 90000 } catch (e2) {}
        xhr.ontimeout = function() {
            if (cb) cb(null, "timeout")
        }
        xhr.setRequestHeader("Content-Type", "application/json")
        xhr.send(bodyObj ? JSON.stringify(bodyObj) : "{}")
    }

    function setBrightness(pct) {
        var target = Math.max(5, Math.min(100, Math.round(pct)))
        brightness = target
        helperPost("/brightness", { brightness: target }, function(data, err) {
            if (err || !data || data.ok === false) {
                toast(tr("toast.brightness.fail"))
                return
            }
            if (data.brightness !== undefined)
                brightness = Number(data.brightness)
            toast(tr("toast.brightness") + " " + brightness + "%")
        })
    }

    function setLanguage(lang) {
        if (lang !== "zh" && lang !== "en") return
        language = lang
        helperPost("/settings", { language: lang }, function(data, err) {
            // Persist best-effort; UI already switched
            if (err) console.log("lang save failed", err)
        })
        toast(lang === "en" ? tr("toast.lang.en") : tr("toast.lang.zh"))
    }

    function loadPrefs() {
        helperGet("/settings", function(data, err) {
            if (err || !data) return
            if (data.brightness !== undefined)
                brightness = Math.max(5, Math.min(100, Number(data.brightness) || brightness))
            if (data.language === "zh" || data.language === "en")
                language = data.language
        })
    }

    function _applyNetwork(data) {
        if (!data || data.ok === false) return
        var w = data.wifi || data.status || {}
        wifiSsid = w.ssid || ""
        wifiIp = w.ip || ((w.ips && w.ips.length) ? w.ips[0] : "")
        wifiSignal = (w.signal === undefined || w.signal === null) ? null : w.signal
        wifiState = w.state || ""
        var tip = []
        if (wifiSsid) tip.push(wifiSsid)
        if (wifiIp) tip.push(wifiIp)
        if (wifiSignal !== null && wifiSignal !== undefined) tip.push(wifiSignal + "dBm")
        if (wifiState && wifiState !== "COMPLETED") tip.push(wifiState)
        wifiHint = tip.length ? tip.join(" · ") : tr("wifi.local")

        if (data.proxy)
            _applyProxyStatus(data.proxy)
        if (data.hint)
            wifiHint = data.hint
    }

    function _applyProxyStatus(px) {
        if (!px) return
        proxyConfigured = !!(px.configured || px.vless_configured)
        proxyVlessConfigured = proxyConfigured
        proxyVlessHost = px.node || px.vless_host || ""
        proxyMode = px.mode || ""
        proxyType = px.type || ""
        proxyLabel = px.label || ""
        proxySingboxActive = !!px.singbox_active
        proxyLocalListening = !!px.local_listening
        if (px.local_port)
            proxyLocalPort = "" + px.local_port
        var man = px.manual || {}
        if (man.server) proxyManualServer = "" + man.server
        if (man.server_port) proxyManualPort = "" + man.server_port
        if (man.uuid) proxyManualUuid = "" + man.uuid
        if (man.sni) proxyManualSni = "" + man.sni
        if (man.fp) { /* ignore */ }
        if (man.pbk) proxyManualPbk = "" + man.pbk
        if (man.sid) proxyManualSid = "" + man.sid
    }

    function refreshWifi() {
        helperGet("/network/status", function(data, err) {
            if (!err && data && data.ok !== false) {
                _applyNetwork(data)
                return
            }
            // fallback: Moonraker system_info IPs
            httpGet("/machine/system_info", function(data2, err2) {
                if (err2 || !data2) {
                    wifiHint = tr("wifi.fail")
                    return
                }
                var info = data2.result || data2
                var sys = info.system_info || info
                var ni = sys.network || {}
                var tip = []
                for (var k in ni) {
                    if (!ni.hasOwnProperty(k)) continue
                    var iface = ni[k]
                    if (iface && iface.ip_addresses && iface.ip_addresses.length)
                        tip.push(k + " " + iface.ip_addresses[0])
                }
                wifiHint = tip.length ? tip.join(" · ") : tr("wifi.local")
                wifiIp = tip.length ? ("" + tip[0]).split(" ").pop() : ""
            })
        })
    }

    function wifiScan() {
        if (wifiBusy) return
        wifiBusy = true
        wifiMessage = tr("settings.wifi.scan") + "…"
        helperGet("/network/wifi/scan?wait=4", function(data, err) {
            wifiBusy = false
            if (err || !data || data.ok === false) {
                wifiMessage = (data && data.error) || err || tr("wifi.fail")
                toast(wifiMessage)
                return
            }
            wifiList = data.networks || []
            if (data.status)
                _applyNetwork({ ok: true, wifi: data.status })
            refreshWifi()
            wifiMessage = wifiList.length
                    ? (wifiList.length + " AP")
                    : tr("settings.wifi.empty")
            toast(wifiMessage)
        })
    }

    function wifiConnect(ssid, password, isOpen) {
        if (!ssid || wifiBusy) return
        wifiBusy = true
        wifiMessage = tr("settings.wifi.connecting")
        toast(wifiMessage)
        helperPost("/network/wifi/connect", {
            ssid: ssid,
            password: password || "",
            open: !!isOpen
        }, function(data, err) {
            wifiBusy = false
            if (err || !data || data.ok === false) {
                wifiMessage = (data && data.error) || err || "connect failed"
                toast(wifiMessage)
                return
            }
            if (data.status)
                _applyNetwork({ ok: true, wifi: data.status })
            refreshWifi()
            toast(tr("settings.wifi.connect") + ": " + ssid)
            // refresh list without blocking UI again hard
            helperGet("/network/wifi/scan?wait=1", function(scanData) {
                if (scanData && scanData.networks)
                    wifiList = scanData.networks
            })
        })
    }

    function wifiDisconnect() {
        helperPost("/network/wifi/disconnect", {}, function(data, err) {
            if (err || !data || data.ok === false) {
                toast((data && data.error) || err || "disconnect failed")
                return
            }
            if (data.status)
                _applyNetwork({ ok: true, wifi: data.status })
            refreshWifi()
            toast(tr("settings.wifi.disconnect"))
        })
    }

    function setProxyConfig(value, mode, manual) {
        var body = {
            value: value || "",
            mode: mode || "auto",
            restart: true,
            local_port: parseInt(proxyLocalPort) || 7890
        }
        if (manual)
            body.manual = manual
        helperPost("/network/proxy", body, function(data, err) {
            if (err || !data || data.ok === false) {
                toast((data && data.error) || err || "proxy failed")
                return
            }
            _applyProxyStatus(data)
            var otaUrl = data.ota_proxy_url || data.local_url || ("http://127.0.0.1:" + proxyLocalPort)
            otaSetProxyUrl(otaUrl, true)
            toast(tr("settings.proxy.ready"))
            refreshWifi()
        })
    }

    function setProxyVless(link) {
        setProxyConfig(link, "auto", null)
    }

    function clearHms() {
        hmsItems = []
        hmsBadgeColor = Theme.ok
    }

    function _refreshHmsBadge() {
        var worst = 0
        for (var i = 0; i < hmsItems.length; i++) {
            var s = hmsItems[i].severity || "info"
            var rank = 1
            if (s === "warning") rank = 2
            if (s === "error" || s === "critical") rank = 3
            if (rank > worst) worst = rank
        }
        if (worst >= 3) hmsBadgeColor = Theme.danger
        else if (worst === 2) hmsBadgeColor = Theme.warn
        else if (worst === 1) hmsBadgeColor = Theme.ok
        else hmsBadgeColor = Theme.ok
    }

    function loadMachineName() {
        // keep branded default; optional override via Moonraker device name later
    }

    function pushHms(level, title, detail) {
        var sev = level || "info"
        if (sev === "warn") sev = "warning"
        var item = {
            severity: sev,
            source: title || "system",
            message: detail || title || "",
            time: Qt.formatTime(new Date(), "hh:mm:ss"),
            level: sev,
            title: title,
            detail: detail,
            ts: Date.now()
        }
        var items = hmsItems.slice()
        items.unshift(item)
        if (items.length > 30) items = items.slice(0, 30)
        hmsItems = items
        _refreshHmsBadge()
        hmsPushed(item)
    }

    function _applyStatus(status) {
        if (!status) return
        if (status.extruder) {
            if (status.extruder.temperature !== undefined) extruderTemp = status.extruder.temperature
            if (status.extruder.target !== undefined) extruderTarget = status.extruder.target
        }
        if (status.heater_bed) {
            if (status.heater_bed.temperature !== undefined) bedTemp = status.heater_bed.temperature
            if (status.heater_bed.target !== undefined) bedTarget = status.heater_bed.target
        }
        if (status.print_stats) {
            var ps = status.print_stats
            if (ps.filename !== undefined && ps.filename !== null)
                printFilename = "" + ps.filename
            if (ps.state !== undefined && ps.state !== null) {
                printing = (ps.state === "printing" || ps.state === "paused")
                paused = (ps.state === "paused")
                printPaused = paused
                if (ps.state === "error") {
                    printPreparing = false
                    printPrepDetail = ""
                    pushHms("error", "Print error", ps.message || "")
                }
                if (ps.state === "complete" || ps.state === "cancelled" || ps.state === "standby") {
                    printPreparing = false
                    printPrepDetail = ""
                }
            }
            if (ps.total_duration !== undefined && ps.total_duration !== null)
                printDuration = Number(ps.total_duration) || 0
            if (ps.print_duration !== undefined && ps.print_duration !== null
                    && printProgress > 0 && printProgress < 1) {
                var remain = Number(ps.print_duration) / printProgress - Number(ps.print_duration)
                printEta = remain
                printEtaText = _fmtEta(remain)
            }
            if (ps.info) {
                if (ps.info.current_layer !== undefined && ps.info.current_layer !== null)
                    printLayer = Number(ps.info.current_layer) || 0
                if (ps.info.total_layer !== undefined && ps.info.total_layer !== null)
                    printLayerTotal = Number(ps.info.total_layer) || 0
            }
        }
        if (status.display_status && status.display_status.progress !== undefined
                && status.display_status.progress !== null)
            printProgress = Number(status.display_status.progress) || 0
        if (status.virtual_sdcard && status.virtual_sdcard.progress !== undefined
                && status.virtual_sdcard.progress !== null)
            printProgress = Number(status.virtual_sdcard.progress) || 0
        if (status.gcode_move && status.gcode_move.speed_factor !== undefined
                && status.gcode_move.speed_factor !== null)
            speedFactor = Math.round(Number(status.gcode_move.speed_factor) * 100) || 100

        // Live toolhead for print-follow viz (cheap; only used when printing)
        var pos = null
        if (status.motion_report && status.motion_report.live_position)
            pos = status.motion_report.live_position
        else if (status.toolhead && status.toolhead.position)
            pos = status.toolhead.position
        if (pos && pos.length >= 3) {
            toolX = Number(pos[0]) || 0
            toolY = Number(pos[1]) || 0
            toolZ = Number(pos[2]) || 0
            if (printing || printPaused)
                _pushPrintTrail(toolX, toolY)
        }
        if (!(printing || printPaused) && printTrail.length)
            printTrail = []

        _refreshPrintPrepDetail(status)
    }

    function _pushPrintTrail(x, y) {
        var dx = x - _trailLastX
        var dy = y - _trailLastY
        if (dx * dx + dy * dy < 4)
            return
        _trailLastX = x
        _trailLastY = y
        var t = printTrail.slice()
        t.push({ x: x, y: y })
        if (t.length > 48)
            t = t.slice(t.length - 48)
        printTrail = t
    }

    function refreshVersionInfo() {
        httpGet("/printer/info", function(data, err) {
            if (err || !data) return
            var info = data.result || data
            var ver = info.software_version || ""
            // Prefer NCPSKY-tracked custom build; "?" means vendor tree without git
            if (ver && ver !== "?")
                klipperVersion = "" + ver
            else if (klipperCustomVersion && klipperCustomVersion !== "—")
                klipperVersion = klipperCustomVersion
            else
                klipperVersion = "FLSun build"
            if (info.hostname)
                hostName = "" + info.hostname
            if (info.cpu_info)
                mcuInfo = "" + info.cpu_info
        })
        httpGet("/server/info", function(data, err) {
            if (err || !data) return
            var info = data.result || data
            var mv = info.moonraker_version || ""
            if (mv && mv !== "?")
                moonrakerVersion = "" + mv
            else if (info.api_version_string)
                moonrakerVersion = "API " + info.api_version_string
            else if (info.api_version)
                moonrakerVersion = "API " + info.api_version.join(".")
            else
                moonrakerVersion = "FLSun build"
        })
        refreshOtaStatus()
    }

    function _applyOtaStatus(data) {
        if (!data || data.ok === false) return
        if (data.channel) otaChannel = "" + data.channel
        if (data.source) otaSource = "" + data.source
        var px = data.proxy || {}
        otaProxyEnabled = !!px.enabled
        otaProxyUrl = px.url || ""
        otaGithubMirror = px.github_mirror || ""
        otaBaseUrl = data.base_url || ""
        var gh = data.github || {}
        otaGithubOwner = gh.owner || ""
        otaGithubRepoName = gh.repo || ""
        otaGithubRef = gh.ref || "main"
        otaGithubPrefix = gh.path_prefix || ""
        otaGithubRepo = gh.repo_slug || ((gh.owner || "") + "/" + (gh.repo || ""))
        // User-facing hint: no repo URLs — only channel / proxy state
        otaSourceHint = ""
        var v = data.versions || {}
        if (v.panel) panelVersion = "" + v.panel
        if (v.stack) otaStackVersion = "" + v.stack
        if (v.system) otaSystemVersion = "" + v.system
        if (v.mcu) otaMcuVersion = "" + v.mcu
        if (v.klipper_core) klipperCoreVersion = "" + v.klipper_core
        if (v.klipper_custom) {
            klipperCustomVersion = "" + v.klipper_custom
            if (!klipperVersion || klipperVersion === "—" || klipperVersion === "FLSun build")
                klipperVersion = klipperCustomVersion
        }
        if (data.firmware_target) firmwareTarget = "" + data.firmware_target
        otaAvailable = data.available || []
        otaUpdateAvailable = !!data.update_available || ((data.available || []).length > 0)
        otaNotes = data.notes || otaNotes || ""
        if (data.version_label)
            otaVersionLabel = "" + data.version_label
        otaBusy = !!data.busy
        otaProgress = Number(data.progress) || 0
        otaMessage = data.message || ""
        otaError = data.error || ""
        otaLastCheck = data.last_check || ""
        otaConfirmMcu = data.confirm_mcu || null
        otaPhase = data.phase || "idle"
        otaDiskFreeMb = Number(data.disk_free_mb) || 0
        pageLocked = otaBusy || !!otaConfirmMcu
    }

    function refreshOtaStatus() {
        helperGet("/ota/status", function(data, err) {
            if (err || !data) return
            _applyOtaStatus(data)
        })
    }

    function otaSetChannel(ch) {
        if (ch !== "stable" && ch !== "beta" && ch !== "dev") return
        helperPost("/ota/channel", { channel: ch }, function(data, err) {
            if (err || !data || data.ok === false) {
                toast((data && data.error) || err || "channel failed")
                return
            }
            otaChannel = data.channel || ch
            var label = ch === "stable" ? tr("settings.ota.stable")
                        : (ch === "beta" ? tr("settings.ota.beta") : tr("settings.ota.dev"))
            toast(tr("settings.ota.channel") + " · " + label)
            otaCheckStatus = ""
            otaUpdateAvailable = false
        })
    }

    function otaSetSource(src) {
        if (src !== "http" && src !== "github") return
        helperPost("/ota/source", { source: src }, function(data, err) {
            if (err || !data || data.ok === false) {
                toast((data && data.error) || err || "source failed")
                return
            }
            otaSource = data.source || src
            refreshOtaStatus()
            toast(tr("settings.ota.source") + ": "
                  + (otaSource === "github"
                     ? tr("settings.ota.source.github")
                     : tr("settings.ota.source.http")))
        })
    }

    function otaSetProxyEnabled(on) {
        helperPost("/ota/proxy", { enabled: !!on }, function(data, err) {
            if (err || !data || data.ok === false) {
                toast((data && data.error) || err || "proxy failed")
                return
            }
            var px = data.proxy || {}
            otaProxyEnabled = !!px.enabled
            otaProxyUrl = px.url || otaProxyUrl
            otaGithubMirror = px.github_mirror || otaGithubMirror
            refreshOtaStatus()
            toast(tr("settings.ota.proxy") + ": "
                  + (otaProxyEnabled
                     ? tr("settings.ota.proxy.on")
                     : tr("settings.ota.proxy.off")))
        })
    }

    function otaSetProxyUrl(url, enable) {
        var body = { url: url || "" }
        if (enable === true || enable === false)
            body.enabled = !!enable
        helperPost("/ota/proxy", body, function(data, err) {
            if (err || !data || data.ok === false) {
                toast((data && data.error) || err || "proxy url failed")
                return
            }
            var px = data.proxy || {}
            otaProxyEnabled = !!px.enabled
            otaProxyUrl = px.url || ""
            otaGithubMirror = px.github_mirror || ""
            refreshOtaStatus()
            toast(tr("settings.proxy.url") + " OK")
        })
    }

    function otaSetGithubMirror(mirror) {
        helperPost("/ota/proxy", { github_mirror: mirror || "" }, function(data, err) {
            if (err || !data || data.ok === false) {
                toast((data && data.error) || err || "mirror failed")
                return
            }
            var px = data.proxy || {}
            otaGithubMirror = px.github_mirror || ""
            refreshOtaStatus()
            toast(tr("settings.proxy.mirror") + " OK")
        })
    }

    function otaSaveServer(fields) {
        fields = fields || {}
        var body = {}
        if (fields.base_url !== undefined)
            body.base_url = fields.base_url
        if (fields.source)
            body.source = fields.source
        if (fields.owner || fields.repo || fields.ref || fields.path_prefix) {
            body.github = {}
            if (fields.owner !== undefined) body.github.owner = fields.owner
            if (fields.repo !== undefined) body.github.repo = fields.repo
            if (fields.ref !== undefined) body.github.ref = fields.ref
            if (fields.path_prefix !== undefined) body.github.path_prefix = fields.path_prefix
        }
        helperPost("/ota/config", body, function(data, err) {
            if (err || !data || data.ok === false) {
                toast((data && data.error) || err || "server save failed")
                return
            }
            refreshOtaStatus()
            toast(tr("settings.server.save") + " OK")
        })
    }

    function otaToggleSelect(id) {
        // Package picking removed for consumer UX — kept no-op for compatibility
        if (!id) return
    }

    function otaOpenDialog(notes, versionLabel) {
        otaNotes = notes || otaNotes || ""
        if (versionLabel)
            otaVersionLabel = versionLabel
        otaDialogOpen = true
    }

    function otaCloseDialog() {
        otaDialogOpen = false
    }

    function otaCheck(opts) {
        opts = opts || {}
        var silent = !!opts.silent
        var fromBoot = !!opts.boot
        if (printing || paused || printPreparing) {
            if (!silent)
                toast(tr("settings.ota.hint"))
            return
        }
        if (otaBusy)
            return
        otaCheckStatus = "checking"
        if (!silent)
            toast(tr("settings.ota.check") + "…")
        helperPost("/ota/check", {}, function(data, err) {
            otaLastCheck = Qt.formatDateTime(new Date(), "yyyy-MM-dd hh:mm")
            if (err || !data || data.ok === false) {
                otaCheckStatus = "error"
                otaUpdateAvailable = false
                if (!silent)
                    toast((data && data.error) || err || "检查失败")
                refreshOtaStatus()
                return
            }
            otaAvailable = data.available || []
            otaUpdateAvailable = !!data.update_available || otaAvailable.length > 0
            otaNotes = data.notes || ""
            otaVersionLabel = data.version_label || otaVersionLabel || panelVersion
            if (otaUpdateAvailable) {
                otaCheckStatus = ""
                otaOpenDialog(otaNotes, otaVersionLabel)
            } else {
                otaCheckStatus = "latest"
                if (!silent || !fromBoot)
                    toast(tr("settings.ota.none") + "  v" + (data.local_version || panelVersion))
            }
            refreshOtaStatus()
        })
    }

    function otaUpgradeAll() {
        if (otaBusy) return
        if (printing || paused || printPreparing) {
            toast(tr("settings.ota.hint"))
            return
        }
        otaDialogOpen = false
        pageLocked = true
        otaBusy = true
        otaPhase = "download"
        otaMessage = tr("settings.ota.busy")
        helperPost("/ota/upgrade", { all: true }, function(data, err) {
            if (err || !data || data.ok === false) {
                otaBusy = false
                pageLocked = false
                toast((data && data.error) || err || "更新失败")
                return
            }
            // Progress polled via otaPollTimer; device will reboot when done
        })
    }

    function otaUpgradeSelected() {
        otaUpgradeAll()
    }

    function otaBootAutoCheck() {
        if (otaBootChecked || otaBusy || printing || paused)
            return
        otaBootChecked = true
        otaBootCheckTimer.start()
    }

    property Timer otaBootCheckTimer: Timer {
        interval: 3500
        repeat: false
        onTriggered: root.otaCheck({ silent: true, boot: true })
    }

    function otaConfirmMcuFlash() {
        helperPost("/ota/confirm_mcu", {}, function(data, err) {
            if (err || !data || data.ok === false) {
                toast((data && data.error) || err || "mcu confirm failed")
                return
            }
            toast(tr("settings.ota.busy"))
            pageLocked = true
            otaBusy = true
        })
    }

    function otaRollback(kind) {
        if (otaBusy || printing || paused) {
            toast(tr("settings.ota.hint"))
            return
        }
        helperPost("/ota/rollback", { kind: kind || "panel" }, function(data, err) {
            if (err || !data || data.ok === false) {
                toast((data && data.error) || err || "rollback failed")
                return
            }
            toast(tr("settings.ota.rollback") + " OK")
            refreshOtaStatus()
        })
    }

    function loadPrintMeta(filename) {
        if (!filename) {
            printObjectHeight = 0
            return
        }
        httpGet("/server/files/metadata?filename=" + encodeURIComponent(filename), function(data, err) {
            if (err || !data) return
            var r = data.result || data
            if (r.object_height !== undefined && r.object_height !== null)
                printObjectHeight = Number(r.object_height) || 0
            if (r.layer_count && !printLayerTotal)
                printLayerTotal = Number(r.layer_count) || printLayerTotal
        })
    }

    function pollStatus() {
        var q = "/printer/objects/query"
                + "?extruder"
                + "&heater_bed"
                + "&print_stats"
                + "&display_status"
                + "&virtual_sdcard"
                + "&gcode_move"
                + "&motion_report"
                + "&toolhead"
        httpGet(q, function(data, err) {
            if (err || !data) {
                connected = false
                return
            }
            connected = true
            var status = null
            if (data.result && data.result.status) status = data.result.status
            else if (data.status) status = data.status
            else if (data.result) status = data.result
            _applyStatus(status)
            if (printing || printPaused) {
                if (printFilename && _printMetaFor !== printFilename) {
                    _printMetaFor = printFilename
                    printObjectHeight = 0
                    printTrail = []
                    _trailLastX = 99999
                    _trailLastY = 99999
                    loadPrintMeta(printFilename)
                }
            } else if (_printMetaFor) {
                _printMetaFor = ""
                printObjectHeight = 0
                printTrail = []
            }
        })
        httpGet("/printer/info", function(data, err) {
            if (err || !data) return
            var info = data.result || data
            klippyState = info.state || klippyState
            stateMessage = info.state_message || ""
            if (info.state === "error" || info.state === "shutdown")
                pushHms("error", "Printer " + info.state, info.state_message || "")
        })
    }

    property Timer clockTimer: Timer {
        interval: 1000; running: true; repeat: true
        onTriggered: root.clockText = Qt.formatTime(new Date(), "hh:mm")
    }

    property Timer pollTimer: Timer {
        interval: 500; running: true; repeat: true
        onTriggered: root.pollStatus()
    }

    property Timer otaPollTimer: Timer {
        interval: 1200
        running: root.otaBusy || !!root.otaConfirmMcu
        repeat: true
        onTriggered: root.refreshOtaStatus()
    }

    property Timer bootTimer: Timer {
        interval: 400; running: true; repeat: false
        onTriggered: {
            root.loadPrefs()
            root.refreshFiles()
            root.refreshWifi()
            root.refreshVersionInfo()
            root.loadMachineName()
            root.pollStatus()
        }
    }
}
