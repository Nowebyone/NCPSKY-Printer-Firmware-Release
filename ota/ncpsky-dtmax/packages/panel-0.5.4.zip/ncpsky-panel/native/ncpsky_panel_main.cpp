#include <QGuiApplication>
#include <QCoreApplication>
#include <QQmlApplicationEngine>
#include <QQmlError>
#include <QCursor>
#include <QPixmap>
#include <QWindow>
#include <QTimer>
#include <QUrl>
#include <QString>
#include <QByteArray>
#include <QObject>
#include <cstdio>

static QCursor makeBlankCursor()
{
    QPixmap pm(32, 32);
    pm.fill(Qt::transparent);
    return QCursor(pm, 0, 0);
}

static void applyBlank(const QCursor &blank)
{
    QGuiApplication::setOverrideCursor(blank);
    const auto windows = QGuiApplication::allWindows();
    for (QWindow *w : windows) {
        if (w)
            w->setCursor(blank);
    }
}

int main(int argc, char *argv[])
{
    qputenv("QT_QPA_FB_HIDECURSOR", QByteArray("1"));
    qputenv("QT_QPA_EGLFS_HIDECURSOR", QByteArray("1"));
    // Do NOT set FB_DISABLE_INPUT here — it broke painting on this board.
    qunsetenv("QT_QPA_FB_DISABLE_INPUT");
    qunsetenv("DISPLAY");

    QGuiApplication app(argc, argv);
    const QCursor blank = makeBlankCursor();
    applyBlank(blank);

    QString qmlRoot = QString::fromLocal8Bit(qgetenv("NCPSKY_QML_ROOT"));
    if (qmlRoot.isEmpty())
        qmlRoot = QStringLiteral("/home/pi/ncpsky-panel/qml");

    fprintf(stderr, "ncpsky-panel: qmlRoot=%s\n", qPrintable(qmlRoot));

    QQmlApplicationEngine engine;
    engine.addImportPath(qmlRoot);
    engine.addImportPath(QStringLiteral("/home/pi/qt/arm_qt_environment/qml"));

    QObject::connect(&engine, &QQmlApplicationEngine::warnings,
                     &app, [](const QList<QQmlError> &warnings) {
                         for (const QQmlError &err : warnings)
                             fprintf(stderr, "QML: %s\n", qPrintable(err.toString()));
                     });

    QObject::connect(
        &engine, &QQmlApplicationEngine::objectCreated,
        &app, [blank](QObject *obj, const QUrl &url) {
            fprintf(stderr, "ncpsky-panel: objectCreated %s obj=%p\n",
                    qPrintable(url.toString()), (void *)obj);
            if (!obj) {
                QCoreApplication::exit(1);
                return;
            }
            if (QWindow *w = qobject_cast<QWindow *>(obj)) {
                w->setCursor(blank);
                w->show();
            }
            applyBlank(blank);
        });

    QTimer *keeper = new QTimer(&app);
    QObject::connect(keeper, &QTimer::timeout, &app, [blank]() { applyBlank(blank); });
    keeper->start(500);

    engine.load(QUrl::fromLocalFile(qmlRoot + QStringLiteral("/main.qml")));
    fprintf(stderr, "ncpsky-panel: rootObjects=%d windows=%d\n",
            engine.rootObjects().size(), QGuiApplication::allWindows().size());
    if (engine.rootObjects().isEmpty())
        return 1;

    for (QWindow *w : QGuiApplication::allWindows()) {
        fprintf(stderr, "ncpsky-panel: win %dx%d visible=%d\n",
                w->width(), w->height(), int(w->isVisible()));
        w->setCursor(blank);
        w->show();
        w->requestActivate();
    }

    applyBlank(blank);
    return app.exec();
}
