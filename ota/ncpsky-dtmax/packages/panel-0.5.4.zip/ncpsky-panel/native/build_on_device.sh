#!/bin/bash
set -e
QT_ROOT=/home/pi/qt/arm_qt_environment
SRC=/home/pi/ncpsky-panel/native/ncpsky_panel_main.cpp
OUT=/home/pi/ncpsky-panel/bin
mkdir -p "$OUT"

# Ensure g++ exists
if ! command -v g++ >/dev/null 2>&1; then
  echo 1 | sudo -S apt-get update -qq
  echo 1 | sudo -S DEBIAN_FRONTEND=noninteractive apt-get install -y -qq g++
fi

g++ -std=c++14 -O2 \
  -I"${QT_ROOT}/include" \
  -I"${QT_ROOT}/include/QtCore" \
  -I"${QT_ROOT}/include/QtGui" \
  -I"${QT_ROOT}/include/QtQml" \
  -I"${QT_ROOT}/include/QtNetwork" \
  -L"${QT_ROOT}/lib" \
  -Wl,-rpath,"${QT_ROOT}/lib" \
  "$SRC" -o "$OUT/ncpsky-panel" \
  -lQt5Qml -lQt5Network -lQt5Gui -lQt5Core \
  -lpthread -ldl

chmod +x "$OUT/ncpsky-panel"
echo "built $OUT/ncpsky-panel"
file "$OUT/ncpsky-panel"
