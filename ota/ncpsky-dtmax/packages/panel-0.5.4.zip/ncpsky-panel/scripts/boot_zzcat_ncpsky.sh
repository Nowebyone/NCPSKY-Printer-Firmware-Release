#!/bin/bash
# Early boot: black → static brand still, then STOP (no fb race loop).
# Splash later: still → black → full radar intro.
mount -o remount,rw "/" 2>/dev/null || true
if [ -d /sys/class/gpio ]; then
  echo 108 > /sys/class/gpio/export 2>/dev/null || true
  echo out > /sys/class/gpio/gpio108/direction 2>/dev/null || true
  echo 1 > /sys/class/gpio/gpio108/value 2>/dev/null || true
fi
echo 100 > /sys/class/backlight/backlight/brightness 2>/dev/null || true
echo 0 > /sys/class/graphics/fb0/rotate 2>/dev/null || true

if [ -f /tmp/ncpsky_bootloop.pid ]; then
  kill "$(cat /tmp/ncpsky_bootloop.pid)" 2>/dev/null || true
  rm -f /tmp/ncpsky_bootloop.pid
fi

for ((i=1; i<=87; i+=2)); do
  if [ -r "/etc/zzcat/$i.raw" ] && [ -e /dev/fb0 ]; then
    cat "/etc/zzcat/$i.raw" > /dev/fb0
  fi
  sleep 0.022
done

if [ -r /etc/zzcat/87.raw ] && [ -e /dev/fb0 ]; then
  cat /etc/zzcat/87.raw > /dev/fb0
fi

if [ -f /home/pi/printer_data/gcodes/USB-DISKA/u_update ]; then
  /etc/uupdate
fi
exit 0
