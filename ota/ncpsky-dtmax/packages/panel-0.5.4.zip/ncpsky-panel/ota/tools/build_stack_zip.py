#!/usr/bin/env python3
"""Build stack OTA zip: macros/templates + optional klipper/moonraker trees.

Default: pack local macros from printer_data/config (ncpsky_*.cfg) and
optional --klipper / --moonraker source trees (code only, no .git/venv).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import zipfile
from datetime import datetime, timezone


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def add_tree(zf, src_root, arc_prefix, skip_names=None):
    skip_names = skip_names or {".git", "klippy-env", ".venv", "__pycache__", "out"}
    if not src_root or not os.path.isdir(src_root):
        return 0
    n = 0
    for dirpath, dirnames, filenames in os.walk(src_root):
        dirnames[:] = [d for d in dirnames if d not in skip_names]
        for fn in filenames:
            if fn.endswith((".pyc", ".o", ".a")):
                continue
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, src_root).replace("\\", "/")
            zf.write(full, "%s/%s" % (arc_prefix, rel))
            n += 1
    return n


def main():
    ap = argparse.ArgumentParser(description="Build NCPSKY stack OTA zip")
    ap.add_argument("--version", required=True, help="e.: 2026.11.23.1")
    ap.add_argument("--out", help="output zip")
    ap.add_argument("--macros-dir", help="dir of .cfg macros to ship")
    ap.add_argument("--klipper", help="optional klipper source root")
    ap.add_argument("--moonraker", help="optional moonraker source root")
    ap.add_argument(
        "--panel-root",
        default=None,
        help="ncpsky-panel root (for dist/)",
    )
    args = ap.parse_args()

    here = os.path.dirname(os.path.abspath(__file__))
    panel_root = args.panel_root or os.path.abspath(os.path.join(here, "..", ".."))
    out_dir = os.path.join(panel_root, "ota", "dist")
    os.makedirs(out_dir, exist_ok=True)
    out = args.out or os.path.join(out_dir, "stack-%s.zip" % args.version)

    macros = args.macros_dir
    if not macros:
        # Prefer repo-local templates if present
        cand = os.path.join(panel_root, "ota", "stack_templates", "macros")
        if os.path.isdir(cand):
            macros = cand
        else:
            macros = "/home/pi/printer_data/config"

    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        # marker
        info = (
            "product=NCPSKY DTMax\n"
            "firmware_target=FLSun T1 Max\n"
            "stack=%s\n"
            "klipper_core=0.14.0\n"
            % args.version
        ).encode()
        zf.writestr("stack/VERSION", info)
        zf.writestr(
            "stack/META.json",
            json.dumps({
                "product": "NCPSKY ▲ DTMax",
                "firmware_target": "FLSun T1 Max",
                "stack": args.version,
                "klipper_core": "0.14.0",
            }, indent=2) + "\n",
        )

        if macros and os.path.isdir(macros):
            for fn in os.listdir(macros):
                if not (fn.endswith(".cfg") or fn.endswith(".conf")):
                    continue
                if fn == "printer.cfg":
                    continue
                # Prefer ncpsky_* and known shared macros; still allow all non-printer.cfg
                full = os.path.join(macros, fn)
                zf.write(full, "stack/macros/%s" % fn)

        add_tree(zf, args.klipper, "stack/klipper")
        add_tree(zf, args.moonraker, "stack/moonraker")

        # optional include snippet for printer.cfg (does not overwrite SAVE_CONFIG)
        include_snip = (
            "# NCPSKY stack includes — managed by OTA; do not put SAVE_CONFIG here\n"
            "[include ncpsky_calib.cfg]\n"
            "# ncpsky_calib.cfg pulls in ncpsky_noise_map.cfg (ADXL speed bans / APPLY_NOISE_MAP)\n"
        )
        zf.writestr("stack/config_templates/ncpsky_includes.cfg", include_snip)

    digest = sha256_file(out)
    with open(out + ".sha256", "w", encoding="utf-8") as f:
        f.write("%s  %s\n" % (digest, os.path.basename(out)))
    meta = {
        "id": "stack-%s" % args.version,
        "kind": "stack",
        "version": args.version,
        "file": os.path.basename(out),
        "sha256": digest,
        "size": os.path.getsize(out),
        "built_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    print(json.dumps(meta, indent=2, ensure_ascii=False))
    print("Wrote", out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
