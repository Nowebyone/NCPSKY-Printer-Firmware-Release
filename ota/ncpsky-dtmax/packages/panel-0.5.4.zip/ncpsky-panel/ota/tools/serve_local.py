#!/usr/bin/env python3
"""Serve ota/dist (or a publish root) for lab tests.

Default URL path matches product taxonomy:
  http://127.0.0.1:8765/ota/ncpsky-dtmax/
"""
from __future__ import annotations

import argparse
import os
import shutil
import tempfile
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

DEFAULT_PREFIX = "ota/ncpsky-dtmax"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--root",
        help="directory that IS the product OTA root (channels/ + packages/) "
        "or a dist/ parent containing <product_id>/",
    )
    ap.add_argument(
        "--prefix",
        default=DEFAULT_PREFIX,
        help="URL path prefix under the HTTP root (default: %s)" % DEFAULT_PREFIX,
    )
    ap.add_argument("--port", type=int, default=8765)
    args = ap.parse_args()

    here = os.path.dirname(os.path.abspath(__file__))
    default_dist = os.path.abspath(os.path.join(here, "..", "dist"))
    root = os.path.abspath(args.root or default_dist)
    prefix = args.prefix.strip("/").replace("\\", "/")
    product_id = prefix.split("/")[-1]

    content = root
    # dist/<product_id>/ layout from extract
    nested = os.path.join(root, product_id)
    if os.path.isdir(os.path.join(root, "packages")):
        content = root
    elif os.path.isdir(nested) and os.path.isdir(os.path.join(nested, "packages")):
        content = nested
    elif os.path.isdir(os.path.join(root, "ota", product_id, "packages")):
        content = os.path.join(root, "ota", product_id)

    serve_root = mount_under_prefix(content, prefix)
    os.chdir(serve_root)
    handler = partial(SimpleHTTPRequestHandler, directory=serve_root)
    httpd = ThreadingHTTPServer(("0.0.0.0", args.port), handler)
    print(
        "Serving %s as http://0.0.0.0:%s/%s/ "
        "(base_url http://HOST:%s/%s)"
        % (content, args.port, prefix, args.port, prefix)
    )
    httpd.serve_forever()


def mount_under_prefix(ota_content_dir, prefix):
    """Temp tree so HTTP paths match github.path_prefix (e.g. ota/ncpsky-dtmax)."""
    parent = tempfile.mkdtemp(prefix="ncpsky_ota_http_")
    parts = prefix.split("/")
    cur = parent
    for p in parts[:-1]:
        cur = os.path.join(cur, p)
        os.makedirs(cur, exist_ok=True)
    link = os.path.join(cur, parts[-1])
    try:
        os.symlink(ota_content_dir, link, target_is_directory=True)
    except OSError:
        shutil.copytree(ota_content_dir, link)
    os.makedirs(os.path.join(link, "packages"), exist_ok=True)
    return parent


if __name__ == "__main__":
    main()
