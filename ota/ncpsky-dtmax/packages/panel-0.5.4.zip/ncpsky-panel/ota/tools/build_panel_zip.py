#!/usr/bin/env python3
"""Build panel OTA zip from ncpsky-panel tree.

Excludes settings.json, ota/backup, ota/staging, ota/config.json, ota/history.json.
Keeps ota/config.default.json, versions.json, schema, examples, tools, VERSION.
"""
from __future__ import annotations

import argparse
import hashlib
import os
import sys
import time
import zipfile
from datetime import datetime, timezone

SKIP_NAMES = {
    "settings.json",
    "__pycache__",
    ".git",
    ".qmlc",
    ".jsc",
}
SKIP_DIR_PARTS = {
    "ota/backup",
    "ota/staging",
    "ota/dist",
    "ota/history.json",
    "ota/config.json",
    "ota/proxy.json",
    "ota/proxy.vless",
    "ota/pending_cleanup.json",
    "native/debs",
    "native/build",
}
SKIP_BASENAMES = {
    "settings.json",
    "proxy.json",
    "proxy.vless",
    "secrets.json",
    ".env",
}


def panel_root(arg=None):
    if arg:
        return os.path.abspath(arg)
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.abspath(os.path.join(here, "..", ".."))


def read_version(root):
    path = os.path.join(root, "VERSION")
    with open(path, "r", encoding="utf-8") as f:
        return f.readline().strip()


def should_skip(rel):
    rel = rel.replace("\\", "/")
    base = os.path.basename(rel)
    if base in SKIP_NAMES or base in SKIP_BASENAMES or base.endswith(".qmlc"):
        return True
    for part in SKIP_DIR_PARTS:
        if rel == part or rel.startswith(part + "/") or rel.endswith("/" + part):
            return True
    if rel.startswith("ota/backup/") or rel.startswith("ota/staging/"):
        return True
    return False


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser(description="Build NCPSKY panel OTA zip")
    ap.add_argument("--root", help="ncpsky-panel root")
    ap.add_argument("--out", help="output zip path")
    ap.add_argument("--version", help="override VERSION")
    args = ap.parse_args()

    root = panel_root(args.root)
    ver = args.version or read_version(root)
    out_dir = os.path.join(root, "ota", "dist")
    os.makedirs(out_dir, exist_ok=True)
    out = args.out or os.path.join(out_dir, "panel-%s.zip" % ver)

    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for dirpath, dirnames, filenames in os.walk(root):
            # prune
            pruned = []
            for d in dirnames:
                rel_d = os.path.relpath(os.path.join(dirpath, d), root).replace("\\", "/")
                if d in (".git", "__pycache__") or rel_d in (
                    "ota/backup", "ota/staging", "ota/dist", "ota/tools/keys",
                    "native/debs", "native/build",
                ):
                    continue
                pruned.append(d)
            dirnames[:] = pruned
            for fn in filenames:
                full = os.path.join(dirpath, fn)
                rel = os.path.relpath(full, root).replace("\\", "/")
                if should_skip(rel):
                    continue
                # store under ncpsky-panel/ — preserve Unix execute bits for
                # shell launchers / native bin (Windows zip defaults to 0644)
                arc = "ncpsky-panel/" + rel
                info = zipfile.ZipInfo(arc)
                info.compress_type = zipfile.ZIP_DEFLATED
                info.date_time = time.localtime(os.path.getmtime(full))[:6]
                mode = os.stat(full).st_mode & 0o7777
                if (
                    fn.endswith(".sh")
                    or rel.startswith("bin/")
                    or (fn.endswith(".py") and rel.startswith("scripts/"))
                ):
                    mode |= 0o111
                # zip external_attr: unix mode in high 16 bits
                info.external_attr = (mode & 0o7777) << 16
                with open(full, "rb") as fh:
                    zf.writestr(info, fh.read())

    digest = sha256_file(out)
    side = out + ".sha256"
    with open(side, "w", encoding="utf-8") as f:
        f.write("%s  %s\n" % (digest, os.path.basename(out)))
    meta = {
        "id": "panel-%s" % ver,
        "kind": "panel",
        "version": ver,
        "file": os.path.basename(out),
        "sha256": digest,
        "size": os.path.getsize(out),
        "built_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }
    print(json_dumps(meta))
    print("Wrote", out)
    print("SHA256", digest)
    return 0


def json_dumps(obj):
    import json
    return json.dumps(obj, indent=2, ensure_ascii=False)


if __name__ == "__main__":
    sys.exit(main())
