#!/usr/bin/env python3
"""Optional ed25519 signing for OTA packages.

First release relies on sha256 (+ sidecar .sha256). This tool prepares
ed25519 signatures for a future panel pubkey check (field `sig` in manifest).

Generate keys once (on publish machine only):
  python sign.py keygen --out-dir ./keys

Sign a file:
  python sign.py sign --key keys/ota_ed25519 --file dist/panel-0.5.1.zip

Verify:
  python sign.py verify --pub keys/ota_ed25519.pub --file dist/panel-0.5.1.zip
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import os
import sys


def _require_nacl():
    try:
        from nacl import signing  # type: ignore
        return signing
    except Exception as ex:
        raise SystemExit(
            "PyNaCl required for ed25519: pip install pynacl\n%s" % ex
        )


def cmd_keygen(out_dir):
    signing = _require_nacl()
    os.makedirs(out_dir, exist_ok=True)
    sk = signing.SigningKey.generate()
    pk = sk.verify_key
    sk_path = os.path.join(out_dir, "ota_ed25519")
    pk_path = sk_path + ".pub"
    with open(sk_path, "wb") as f:
        f.write(bytes(sk))
    with open(pk_path, "wb") as f:
        f.write(bytes(pk))
    print("Wrote", sk_path)
    print("Wrote", pk_path)
    print("pubkey_b64", base64.b64encode(bytes(pk)).decode())


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.digest()


def cmd_sign(key_path, file_path):
    signing = _require_nacl()
    with open(key_path, "rb") as f:
        sk = signing.SigningKey(f.read())
    digest = _sha256(file_path)
    sig = sk.sign(digest).signature
    out = file_path + ".sig"
    with open(out, "w", encoding="utf-8") as f:
        f.write(base64.b64encode(sig).decode() + "\n")
    print(base64.b64encode(sig).decode())
    print("Wrote", out)
    return base64.b64encode(sig).decode()


def cmd_verify(pub_path, file_path, sig_b64=None):
    signing = _require_nacl()
    with open(pub_path, "rb") as f:
        vk = signing.VerifyKey(f.read())
    if not sig_b64:
        with open(file_path + ".sig", "r", encoding="utf-8") as f:
            sig_b64 = f.read().strip()
    sig = base64.b64decode(sig_b64)
    digest = _sha256(file_path)
    vk.verify(digest, sig)
    print("OK")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    k = sub.add_parser("keygen")
    k.add_argument("--out-dir", default="./keys")

    s = sub.add_parser("sign")
    s.add_argument("--key", required=True)
    s.add_argument("--file", required=True)

    v = sub.add_parser("verify")
    v.add_argument("--pub", required=True)
    v.add_argument("--file", required=True)
    v.add_argument("--sig", default=None)

    args = ap.parse_args()
    if args.cmd == "keygen":
        cmd_keygen(args.out_dir)
    elif args.cmd == "sign":
        cmd_sign(args.key, args.file)
    elif args.cmd == "verify":
        cmd_verify(args.pub, args.file, args.sig)
    return 0


if __name__ == "__main__":
    sys.exit(main())
