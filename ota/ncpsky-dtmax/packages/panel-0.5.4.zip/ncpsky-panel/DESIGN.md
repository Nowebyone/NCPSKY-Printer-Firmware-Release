# NCPSKY Panel 设计系统

可复用到后续 DIY 机的触摸屏前台（一期：480×272 / Qt Quick）。

## 原则

- **C 端信息架构**（不是 Klipper 分类）：首页 / 设备 / 耗材 / 校准 / 设置 / 消息。
- **首页只做一件事**：空闲→「选择文件开始」；打印中→进度与暂停/取消。
- **校准页**：自动归位 → 勾选（床网调平 / 震动补偿 / 电机降噪 / 噪音速度测绘）→ 自动保存。床网调平展开：探针预热 → 倾斜校正 → 自动调平 → 冷却（冷态探测易触发 `samples_tolerance`）。执行页有分步可视化。电机降噪走 `CALIBRATE_MOTOR_NOISE`；噪音速度测绘走 ADXL 扫速 → `noise_map.json` → `APPLY_NOISE_MAP`（不做打印中动态改 TMC）。
- **设备页**：温度 / 移动 / 出料 分段；危险维护留在设置「维护」。
- **触控优先**：热区 ≥48px；`TouchArea` 禁光标、`preventStealing`、关闭 hover；原生 `ncpsky-panel` + `QT_QPA_FB_HIDECURSOR=1` + 透明覆盖光标去掉软件箭头。
- **算力预算**：短时动效即可；禁止全屏模糊、粒子、重阴影。

## 色板

| Token | Hex | 用途 |
|---|---|---|
| `bg` | `#070809` | 全屏底 |
| `bgPanel` | `#0C0D0F` | 左导航 |
| `bgTile` | `#15171A` | 表面（无描边） |
| `accent` | `#A78BFA` | 柔和紫（状态/主按钮，少用） |
| `ok` | `#A78BFA` | 正常 |
| `warn` | `#D4A017` | 警告 |
| `danger` | `#D94B4B` | 错误 |
| `textPrimary` | `#E8EAED` | 主文字 |
| `textSecondary` | `#7A8088` | 次文字 |
| `textMute` | `#555B63` | 标签 |

质感原则：少描边、靠明度分层；主页是状态区+指标带+列表行动，禁止六宫格等大磁贴。
`InsetPanel` 做内凹井（深底 + 顶缘高光）；分段用 `SegButton`；轴控用 `PadKey`；列表用发丝分割线而非卡片框。
打印中：全宽 3px 进度条，数字轻字重。

## 字体阶梯

- 标题 `16` / 正文 `13` / 小字 `11` / 大数字 `22`
- 无衬线；禁止装饰衬线与营销花体

## 组件

| 组件 | 职责 |
|---|---|
| `NavRail` | 左 48px 五栏切换 |
| `QuickTile` | 主页磁贴，按压缩放 0.96 |
| `PrimaryButton` | 主/次/危险按钮 |
| `TopBar` | 机型名 + 温度摘要 + 连接点 + 时钟 |
| `ProgressHero`（打印页内嵌） | 进度条 + ETA |
| `Splash` | 开机品牌 2–3s，可点跳过 |

## 动效预算

| 场景 | 时长 |
|---|---|
| 磁贴/按钮按压 | ~120ms scale |
| 页面淡入 | 150–220ms |
| 进度条宽度 | ~400ms |
| 开机品牌 | ≤2.5s，可跳过 |

## 品牌

- 产品名：**NCPSKY**
- 机型默认：`NCPSKY ▲T1 Max`
- 开机动画必须露出品牌三角标 ▲，机型名次之

## FLSun 功能对表（一期验收）

| FLSun TUI 能力 | NCPSKY 落点 |
|---|---|
| 首页状态 / 温度 | 主页磁贴 + TopBar |
| 文件列表 / 开打 | Files 页 → Moonraker `printer.print.start` |
| 打印中暂停/恢复/取消 | Print 页 |
| 轴移动 / 归零 | 设备 → 移动 |
| 温控 / 速度 / 挤出 | 设备 → 温度 / 出料 |
| 进退料 | 耗材向导 |
| Wi‑Fi / 亮度 / 语言 / 机型名 | 设置 |
| 校准入口 | 校准选项卡（可勾选连续流程） |
| 告警弹窗 | 消息列表 + 重启设备 |

## 技术约束

- 通信：Moonraker **HTTP** 轮询（`/printer/objects/query` 等）；设备 Qt 未带 WebSockets QML 插件，故不用 WS
- 显示：`linuxfb` + tslib（与原 TUI 一致）
- QML 模块：Debian armhf `qml-module-qtquick2` 等已装入 `/home/pi/qt/arm_qt_environment/qml`
- 看门狗：`/etc/monitor` 已改为识别 `qmlscene.*main.qml`（备份 `/etc/monitor.bak_ncpsky`）
- 单实例：`run_panel.sh` 使用 `flock`
- 回滚：`/home/pi/ncpsky-panel/scripts/rollback_tui.sh` + 恢复 `startboot_bak_ncpsky` / `monitor.bak_ncpsky`

## 验收清单（FLSun 对表）

- [x] 开机品牌 Splash（NCPSKY ▲ / T1 Max，可跳过）
- [x] 左轨五栏 + 主页磁贴（文件/温度/耗材/网络/HMS）
- [x] Moonraker 在线态与温度刷新
- [x] 文件列表计数（gcodes）
- [x] startboot 切换 + monitor 不刷屏多开
- [ ] 触控开打 / 暂停恢复取消（需实机点按）
- [ ] 轴移动 / 温控 / 进退料向导（需实机点按）
- [ ] Wi‑Fi 提示 / 亮度 / 校准入口 / HMS 注入错误（需实机点按）
