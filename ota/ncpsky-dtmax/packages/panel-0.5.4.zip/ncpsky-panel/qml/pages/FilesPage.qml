import QtQuick 2.15
import "../components"
import ".."

Item {
    id: page

    Column {
        anchors.fill: parent
        anchors.leftMargin: 12
        anchors.rightMargin: 12
        anchors.topMargin: 4
        spacing: 6

        Row {
            width: parent.width
            height: Theme.touchMin - 4
            PageHeader {
                title: "选择文件"
                subtitle: "点按即可开始打印"
                width: parent.width - 100
                anchors.verticalCenter: parent.verticalCenter
            }
            SegButton {
                anchors.verticalCenter: parent.verticalCenter
                text: "返回"
                height: 36
                onClicked: AppState.go("home")
            }
        }

        ListView {
            id: list
            width: parent.width
            height: parent.height - 48
            clip: true
            model: AppState.gcodeFiles
            spacing: 0
            boundsBehavior: Flickable.StopAtBounds

            delegate: Item {
                width: list.width
                height: Theme.touchMin
                readonly property string filePath: (typeof modelData === "string")
                                                  ? modelData
                                                  : (modelData.path || "")
                readonly property string fileName: (typeof modelData === "string")
                                                  ? modelData
                                                  : (modelData.name || modelData.path || "")
                readonly property string thumbUrl: (typeof modelData === "object" && modelData && modelData.thumb)
                                                  ? modelData.thumb : ""

                Rectangle {
                    anchors.fill: parent
                    color: touch.pressed ? Theme.bgTilePressed : "transparent"
                }
                Rectangle {
                    anchors.bottom: parent.bottom
                    width: parent.width
                    height: 1
                    color: Theme.lineSoft
                }

                // Thumbnail — same row layout, just a small preview on the left
                Rectangle {
                    id: thumbBox
                    anchors.left: parent.left
                    anchors.leftMargin: 2
                    anchors.verticalCenter: parent.verticalCenter
                    width: 40
                    height: 40
                    radius: 4
                    color: Theme.bgTile
                    clip: true
                    Image {
                        id: thumbImage
                        anchors.fill: parent
                        anchors.margins: 2
                        source: thumbUrl
                        fillMode: Image.PreserveAspectCrop
                        asynchronous: true
                        cache: true
                        visible: status === Image.Ready
                    }
                    Text {
                        anchors.centerIn: parent
                        visible: thumbImage.status !== Image.Ready
                        text: "#"
                        color: Theme.textMute
                        font.family: Theme.fontFamily
                        font.pixelSize: 14
                        font.weight: Theme.fontWeight
                    }
                }

                Text {
                    anchors.left: thumbBox.right
                    anchors.leftMargin: 10
                    anchors.verticalCenter: parent.verticalCenter
                    width: parent.width - 56 - 52
                    text: fileName
                    color: Theme.textPrimary
                    font.pixelSize: Theme.fontBody
                    elide: Text.ElideMiddle
                }
                Text {
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    text: "打印"
                    color: Theme.accent
                    font.pixelSize: Theme.fontSmall
                    font.family: Theme.fontFamily
                    font.weight: Theme.fontWeight
                }
                TouchArea {
                    id: touch
                    anchors.fill: parent
                    onClicked: AppState.startPrint(filePath)
                }
            }

            Text {
                anchors.centerIn: parent
                visible: list.count === 0
                text: AppState.connected ? "还没有可打印文件" : "设备未连接"
                color: Theme.textMute
                font.pixelSize: Theme.fontBody
            }
        }
    }

    Component.onCompleted: AppState.refreshFiles()
}
