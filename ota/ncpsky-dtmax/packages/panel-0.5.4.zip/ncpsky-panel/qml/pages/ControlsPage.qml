import QtQuick 2.15
import "../components"
import ".."

// C-端「设备」页 — 温度可手动调节 / 移动十字键重排
Item {
    id: page
    property real moveStep: 10
    property string section: "temp"  // temp | move | extrude
    property string editHeater: ""   // extruder | bed

    function openTempEditor(heater) {
        page.editHeater = heater
        var cur = heater === "bed" ? AppState.bedTarget : AppState.extruderTarget
        if (!(cur > 0))
            cur = heater === "bed" ? AppState.bedTemp : AppState.extruderTemp
        kb.show({
            title: heater === "bed" ? (AppState.tr("device.bed") + " °C")
                                    : (AppState.tr("device.nozzle") + " °C"),
            text: Math.round(cur) > 0 ? ("" + Math.round(cur)) : "",
            numeric: true
        })
    }

    Column {
        anchors.fill: parent
        anchors.leftMargin: 8
        anchors.rightMargin: 8
        anchors.topMargin: 4
        anchors.bottomMargin: 4
        spacing: 4

        Row {
            width: parent.width
            height: 32
            spacing: 8

            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: AppState.tr("device.title")
                color: Theme.textPrimary
                font.pixelSize: Theme.fontTitle
                font.family: Theme.fontFamily
                font.weight: Theme.fontWeight
            }

            Item { width: 2; height: 1 }

            SegButton {
                text: AppState.tr("device.temp")
                width: 58
                height: 30
                active: page.section === "temp"
                onClicked: page.section = "temp"
            }
            SegButton {
                text: AppState.tr("device.move")
                width: 58
                height: 30
                active: page.section === "move"
                onClicked: page.section = "move"
            }
            SegButton {
                text: AppState.tr("device.extrude")
                width: 58
                height: 30
                active: page.section === "extrude"
                onClicked: page.section = "extrude"
            }
        }

        Item {
            width: parent.width
            height: parent.height - 36

            // —— 温度 ——
            InsetPanel {
                anchors.fill: parent
                visible: page.section === "temp"
                Row {
                    anchors.fill: parent
                    TempChannel {
                        width: parent.width / 2
                        height: parent.height
                        title: AppState.tr("device.nozzle")
                        current: AppState.extruderTemp
                        target: AppState.extruderTarget
                        accent: Theme.accent
                        maxTemp: 300
                        presets: [
                            { label: AppState.tr("device.off"), value: 0 },
                            { label: "PLA", value: 210 },
                            { label: "PETG", value: 240 },
                            { label: "ABS", value: 250 }
                        ]
                        onSetTemp: AppState.setExtruderTemp(value)
                        onRequestEdit: page.openTempEditor("extruder")
                    }
                    TempChannel {
                        width: parent.width / 2
                        height: parent.height
                        title: AppState.tr("device.bed")
                        current: AppState.bedTemp
                        target: AppState.bedTarget
                        accent: Theme.warn
                        showDivider: true
                        maxTemp: 120
                        stepCoarse: 5
                        presets: [
                            { label: AppState.tr("device.off"), value: 0 },
                            { label: "60°", value: 60 },
                            { label: "80°", value: 80 },
                            { label: "100°", value: 100 }
                        ]
                        onSetTemp: AppState.setBedTemp(value)
                        onRequestEdit: page.openTempEditor("bed")
                    }
                }
            }

            // —— 移动：左侧十字 + 右侧 Z/步距 ——
            Row {
                anchors.fill: parent
                spacing: 6
                visible: page.section === "move"

                InsetPanel {
                    width: Math.floor(parent.width * 0.58)
                    height: parent.height

                    Column {
                        anchors.centerIn: parent
                        spacing: 6

                        // Cross pad — equal cells, clear labels
                        Grid {
                            columns: 3
                            rows: 3
                            columnSpacing: 6
                            rowSpacing: 6
                            anchors.horizontalCenter: parent.horizontalCenter

                            Item { width: 54; height: 48 }
                            PadKey {
                                text: AppState.tr("device.front")
                                width: 54
                                height: 48
                                onClicked: AppState.moveAxis("Y", page.moveStep)
                            }
                            Item { width: 54; height: 48 }

                            PadKey {
                                text: AppState.tr("device.left")
                                width: 54
                                height: 48
                                onClicked: AppState.moveAxis("X", -page.moveStep)
                            }
                            PadKey {
                                text: AppState.tr("device.xyz.home")
                                width: 54
                                height: 48
                                primary: true
                                onClicked: AppState.homeAll()
                            }
                            PadKey {
                                text: AppState.tr("device.right")
                                width: 54
                                height: 48
                                onClicked: AppState.moveAxis("X", page.moveStep)
                            }

                            Item { width: 54; height: 48 }
                            PadKey {
                                text: AppState.tr("device.back")
                                width: 54
                                height: 48
                                onClicked: AppState.moveAxis("Y", -page.moveStep)
                            }
                            Item { width: 54; height: 48 }
                        }
                    }
                }

                InsetPanel {
                    width: parent.width - Math.floor(parent.width * 0.58) - 6
                    height: parent.height

                    Column {
                        anchors.fill: parent
                        anchors.margins: 8
                        spacing: 5

                        Text {
                            text: "Z 轴"
                            color: Theme.textMute
                            font.pixelSize: Theme.fontSmall
                        }
                        Row {
                            spacing: 5
                            width: parent.width
                            PadKey {
                                text: AppState.tr("device.up")
                                width: Math.floor((parent.width - 5) / 2)
                                height: 42
                                onClicked: AppState.moveAxis("Z", page.moveStep)
                            }
                            PadKey {
                                text: AppState.tr("device.down")
                                width: Math.floor((parent.width - 5) / 2)
                                height: 42
                                onClicked: AppState.moveAxis("Z", -page.moveStep)
                            }
                        }

                        Text {
                            text: AppState.tr("device.step")
                            color: Theme.textMute
                            font.pixelSize: Theme.fontSmall
                            topPadding: 2
                        }
                        Row {
                            spacing: 4
                            width: parent.width
                            SegButton {
                                text: "1"
                                width: Math.floor((parent.width - 8) / 3)
                                height: 34
                                active: page.moveStep === 1
                                onClicked: page.moveStep = 1
                            }
                            SegButton {
                                text: "10"
                                width: Math.floor((parent.width - 8) / 3)
                                height: 34
                                active: page.moveStep === 10
                                onClicked: page.moveStep = 10
                            }
                            SegButton {
                                text: "50"
                                width: Math.floor((parent.width - 8) / 3)
                                height: 34
                                active: page.moveStep === 50
                                onClicked: page.moveStep = 50
                            }
                        }
                        Text {
                            text: "单位 mm"
                            color: Theme.textMute
                            font.pixelSize: 10
                        }

                        Item { width: 1; height: 2 }

                        PrimaryButton {
                            text: AppState.tr("device.homeall")
                            primary: false
                            width: parent.width
                            height: 36
                            onClicked: AppState.homeAll()
                        }
                    }
                }
            }

            // —— 出料 ——
            Column {
                anchors.fill: parent
                anchors.margins: 4
                spacing: 8
                visible: page.section === "extrude"

                Text {
                    width: parent.width
                    text: AppState.tr("device.extrude.hint")
                    color: Theme.textSecondary
                    font.pixelSize: Theme.fontBody
                    wrapMode: Text.Wrap
                }
                Row {
                    spacing: 8
                    width: parent.width
                    PrimaryButton {
                        text: AppState.tr("device.extrude10")
                        width: Math.floor((parent.width - 16) / 3)
                        height: 44
                        onClicked: AppState.extrude(10)
                    }
                    PrimaryButton {
                        text: AppState.tr("device.retract10")
                        primary: false
                        width: Math.floor((parent.width - 16) / 3)
                        height: 44
                        onClicked: AppState.extrude(-10)
                    }
                    PrimaryButton {
                        text: AppState.tr("device.extrude50")
                        primary: false
                        width: Math.floor((parent.width - 16) / 3)
                        height: 44
                        onClicked: AppState.extrude(50)
                    }
                }
                Text {
                    text: AppState.tr("device.nozzle") + " " + Math.round(AppState.extruderTemp) + "°"
                           + (AppState.extruderTarget > 0
                              ? (" → " + Math.round(AppState.extruderTarget) + "°")
                              : (" · " + AppState.tr("device.notheated")))
                    color: AppState.extruderTarget > 0 ? Theme.accent : Theme.textMute
                    font.pixelSize: Theme.fontSmall
                }
            }
        }
    }

    OnScreenKeyboard {
        id: kb
        anchors.fill: parent
        onAccepted: {
            var n = parseFloat(value)
            if (!(n >= 0))
                return
            if (page.editHeater === "bed")
                AppState.setBedTemp(Math.min(120, Math.round(n)))
            else
                AppState.setExtruderTemp(Math.min(300, Math.round(n)))
            page.editHeater = ""
        }
        onCancelled: page.editHeater = ""
    }
}
