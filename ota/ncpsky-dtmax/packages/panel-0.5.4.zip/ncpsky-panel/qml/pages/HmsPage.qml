import QtQuick 2.15
import "../components"
import ".."

Item {
    id: page

    Column {
        anchors.fill: parent
        anchors.leftMargin: 12
        anchors.rightMargin: 12
        anchors.topMargin: 4
        spacing: 6

        Row {
            width: parent.width
            height: Theme.touchMin - 4
            PageHeader {
                title: "消息"
                subtitle: AppState.hmsItems.length ? (AppState.hmsItems.length + " 条") : "一切正常"
                width: parent.width - 150
                anchors.verticalCenter: parent.verticalCenter
            }
            SegButton {
                anchors.verticalCenter: parent.verticalCenter
                visible: AppState.printSessionActive()
                text: "返回"
                height: 36
                onClicked: AppState.go("home")
            }
            SegButton {
                anchors.verticalCenter: parent.verticalCenter
                visible: !AppState.printSessionActive()
                text: "清空"
                height: 36
                onClicked: AppState.clearHms()
            }
            Item { width: 6; height: 1; visible: !AppState.printSessionActive() }
            PrimaryButton {
                anchors.verticalCenter: parent.verticalCenter
                visible: !AppState.printSessionActive()
                text: "重启设备"
                danger: true
                height: 36
                onClicked: AppState.firmwareRestart()
            }
        }

        ListView {
            id: list
            width: parent.width
            height: parent.height - 48
            clip: true
            model: AppState.hmsItems
            spacing: 0
            boundsBehavior: Flickable.StopAtBounds

            delegate: Item {
                width: list.width
                height: Math.max(Theme.touchMin, msg.implicitHeight + 24)
                Rectangle {
                    anchors.left: parent.left
                    anchors.top: parent.top
                    anchors.topMargin: 14
                    width: 2
                    height: 14
                    radius: 1
                    color: {
                        var s = modelData.severity || "info"
                        if (s === "error" || s === "critical") return Theme.danger
                        if (s === "warning") return Theme.warn
                        return Theme.line
                    }
                }
                Column {
                    anchors.left: parent.left
                    anchors.leftMargin: 10
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 2
                    Text {
                        text: (modelData.source || "系统") + "  ·  " + (modelData.time || "")
                        color: Theme.textMute
                        font.pixelSize: Theme.fontSmall
                    }
                    Text {
                        id: msg
                        width: parent.width
                        text: modelData.message || ""
                        color: Theme.textPrimary
                        font.pixelSize: Theme.fontBody
                        wrapMode: Text.Wrap
                    }
                }
                Rectangle {
                    anchors.bottom: parent.bottom
                    width: parent.width
                    height: 1
                    color: Theme.lineSoft
                }
            }

            Text {
                anchors.centerIn: parent
                visible: list.count === 0
                text: "暂无消息"
                color: Theme.textMute
                font.pixelSize: Theme.fontTitle
                font.family: Theme.fontFamily
                font.weight: Theme.fontWeight
            }
        }
    }
}
