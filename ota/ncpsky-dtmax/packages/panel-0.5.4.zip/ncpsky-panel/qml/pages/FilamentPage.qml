import QtQuick 2.15
import "../components"
import ".."

Item {
    id: page
    property int step: 0
    property string action: "load"  // load | unload

    function bumpTemp(delta) {
        var next = Math.max(160, Math.min(280, AppState.filamentTemp + delta))
        AppState.filamentTemp = next
    }

    function openTempEditor() {
        kb.show({
            title: "建议温度 °C",
            text: "" + AppState.filamentTemp,
            numeric: true
        })
    }

    Column {
        anchors.fill: parent
        anchors.leftMargin: 8
        anchors.rightMargin: 8
        anchors.topMargin: 2
        anchors.bottomMargin: 4
        spacing: 4

        PageHeader {
            title: "耗材"
            subtitle: page.step === 0 ? "更换或装入耗材"
                     : page.step === 1 ? "正在预热喷嘴…"
                     : (page.action === "load" ? "请将耗材插入，直到咬入" : "请抽出耗材")
            width: parent.width
        }

        Flickable {
            width: parent.width
            height: Math.max(60, parent.height - 40)
            contentWidth: width
            contentHeight: Math.max(height, bodyCol.height + 8)
            clip: true
            boundsBehavior: Flickable.StopAtBounds
            interactive: !kb.open && contentHeight > height + 2
            pressDelay: 60

            Column {
                id: bodyCol
                width: parent.width
                spacing: 6

                InsetPanel {
                    width: parent.width
                    height: 44
                    Row {
                        anchors.fill: parent
                        Item {
                            width: parent.width / 3
                            height: parent.height
                            Column {
                                anchors.centerIn: parent
                                spacing: 1
                                Text { anchors.horizontalCenter: parent.horizontalCenter; text: "当前"; color: Theme.textMute; font.pixelSize: Theme.fontSmall }
                                Text { anchors.horizontalCenter: parent.horizontalCenter; text: AppState.filamentType; color: Theme.textPrimary; font.family: Theme.fontFamily; font.pixelSize: 15; font.weight: Theme.fontWeight }
                            }
                        }
                        Rectangle { anchors.verticalCenter: parent.verticalCenter; width: 1; height: 22; color: Theme.lineSoft }
                        Item {
                            width: parent.width / 3
                            height: parent.height
                            Column {
                                anchors.centerIn: parent
                                spacing: 1
                                Text { anchors.horizontalCenter: parent.horizontalCenter; text: "目标"; color: Theme.textMute; font.pixelSize: Theme.fontSmall }
                                Text { anchors.horizontalCenter: parent.horizontalCenter; text: AppState.filamentTemp + "°"; color: Theme.accent; font.family: Theme.fontFamily; font.pixelSize: 15; font.weight: Theme.fontWeight }
                            }
                            TouchArea {
                                anchors.fill: parent
                                onClicked: page.openTempEditor()
                            }
                        }
                        Rectangle { anchors.verticalCenter: parent.verticalCenter; width: 1; height: 22; color: Theme.lineSoft }
                        Item {
                            width: parent.width / 3 - 2
                            height: parent.height
                            Column {
                                anchors.centerIn: parent
                                spacing: 1
                                Text { anchors.horizontalCenter: parent.horizontalCenter; text: "喷嘴"; color: Theme.textMute; font.pixelSize: Theme.fontSmall }
                                Text { anchors.horizontalCenter: parent.horizontalCenter; text: Math.round(AppState.extruderTemp) + "°"; color: Theme.textPrimary; font.family: Theme.fontFamily; font.pixelSize: 15; font.weight: Theme.fontWeight }
                            }
                        }
                    }
                }

                Column {
                    width: parent.width
                    spacing: 5
                    visible: page.step === 0

                    Text {
                        text: "材料类型"
                        color: Theme.textMute
                        font.pixelSize: Theme.fontSmall
                    }
                    Row {
                        spacing: 6
                        SegButton { text: "PLA"; height: 32; width: 52; active: AppState.filamentType === "PLA"; onClicked: { AppState.filamentType = "PLA"; AppState.filamentTemp = 210 } }
                        SegButton { text: "PETG"; height: 32; width: 56; active: AppState.filamentType === "PETG"; onClicked: { AppState.filamentType = "PETG"; AppState.filamentTemp = 240 } }
                        SegButton { text: "ABS"; height: 32; width: 52; active: AppState.filamentType === "ABS"; onClicked: { AppState.filamentType = "ABS"; AppState.filamentTemp = 250 } }
                        SegButton { text: "TPU"; height: 32; width: 52; active: AppState.filamentType === "TPU"; onClicked: { AppState.filamentType = "TPU"; AppState.filamentTemp = 220 } }
                    }

                    Text {
                        text: "温度调节（点中间数字可手输）"
                        color: Theme.textMute
                        font.pixelSize: Theme.fontSmall
                    }
                    Row {
                        spacing: 5
                        width: parent.width
                        PadKey {
                            text: "−10"
                            width: 50
                            height: 38
                            onClicked: page.bumpTemp(-10)
                        }
                        PadKey {
                            text: "−1"
                            width: 42
                            height: 38
                            onClicked: page.bumpTemp(-1)
                        }
                        PadKey {
                            text: AppState.filamentTemp + "°"
                            width: 76
                            height: 38
                            primary: true
                            onClicked: page.openTempEditor()
                        }
                        PadKey {
                            text: "+1"
                            width: 42
                            height: 38
                            onClicked: page.bumpTemp(1)
                        }
                        PadKey {
                            text: "+10"
                            width: 50
                            height: 38
                            onClicked: page.bumpTemp(10)
                        }
                    }

                    Row {
                        spacing: 8
                        PrimaryButton {
                            text: "装入耗材"
                            width: 118
                            height: 38
                            onClicked: {
                                page.action = "load"
                                page.step = 1
                                AppState.setExtruderTemp(AppState.filamentTemp)
                                AppState.gcode("M302 P1")
                            }
                        }
                        PrimaryButton {
                            text: "退出耗材"
                            primary: false
                            width: 118
                            height: 38
                            onClicked: {
                                page.action = "unload"
                                page.step = 1
                                AppState.setExtruderTemp(AppState.filamentTemp)
                                AppState.gcode("M302 P1")
                            }
                        }
                    }
                }

                Row {
                    spacing: 8
                    visible: page.step > 0
                    PrimaryButton {
                        text: page.step === 1 ? "已预热，继续" : "完成"
                        width: 132
                        height: 38
                        onClicked: {
                            if (page.step === 1) {
                                AppState.extrude(page.action === "load" ? 50 : -50)
                                page.step = 2
                            } else {
                                page.step = 0
                                AppState.setExtruderTemp(0)
                            }
                        }
                    }
                    PrimaryButton {
                        text: "取消"
                        danger: true
                        height: 38
                        onClicked: {
                            page.step = 0
                            AppState.setExtruderTemp(0)
                        }
                    }
                }
            }
        }
    }

    OnScreenKeyboard {
        id: kb
        anchors.fill: parent
        onAccepted: {
            var n = parseInt(value)
            if (n >= 160 && n <= 280)
                AppState.filamentTemp = n
        }
    }
}
