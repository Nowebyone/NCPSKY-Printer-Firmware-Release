import QtQuick 2.15
import "../components"
import ".."

Item {
    id: page

    // —— 打印中 / 准备中：左侧状态 + 右侧跟打 ——
    Item {
        anchors.fill: parent
        anchors.leftMargin: 12
        anchors.rightMargin: 10
        anchors.topMargin: 8
        anchors.bottomMargin: 8
        visible: AppState.printSessionActive()

        readonly property int sideW: Math.max(150, Math.floor(width * 0.42))

        Row {
            anchors.fill: parent
            spacing: 8

            Column {
                width: parent.width - parent.parent.sideW - 8
                height: parent.height
                spacing: 6

                Text {
                    width: parent.width
                    text: AppState.printPreparing
                          ? "准备中"
                          : (AppState.printPaused ? "已暂停" : "正在打印")
                    color: Theme.textPrimary
                    font.pixelSize: 22
                    font.family: Theme.fontFamily
                    font.weight: Theme.fontWeight
                }
                Text {
                    width: parent.width
                    text: AppState.printFilename.length ? AppState.printFilename : "任务进行中"
                    color: Theme.textSecondary
                    font.pixelSize: Theme.fontSmall
                    elide: Text.ElideMiddle
                }

                // Prep: detailed status; print: progress
                Text {
                    width: parent.width
                    visible: AppState.printPreparing
                    text: AppState.printPrepDetail.length
                          ? AppState.printPrepDetail
                          : "正在准备打印…"
                    color: Theme.accent
                    font.pixelSize: Theme.fontBody
                    wrapMode: Text.WordWrap
                    maximumLineCount: 3
                    elide: Text.ElideRight
                }

                Item {
                    width: parent.width
                    height: 34
                    visible: !AppState.printPreparing
                    Text {
                        anchors.left: parent.left
                        anchors.verticalCenter: parent.verticalCenter
                        text: Math.round(AppState.printProgress * 100) + "%"
                        color: Theme.textPrimary
                        font.pixelSize: 26
                        font.family: Theme.fontFamily
                        font.weight: Theme.fontWeight
                    }
                    Text {
                        anchors.right: parent.right
                        anchors.verticalCenter: parent.verticalCenter
                        text: "约剩 " + AppState.printEtaText
                        color: Theme.textMute
                        font.pixelSize: Theme.fontSmall
                    }
                }
                Item {
                    width: parent.width
                    height: 3
                    visible: !AppState.printPreparing
                    Rectangle { anchors.fill: parent; color: Theme.lineSoft; radius: 1 }
                    Rectangle {
                        height: parent.height
                        radius: 1
                        width: parent.width * Math.max(0, Math.min(1, AppState.printProgress))
                        color: Theme.accent
                        Behavior on width { NumberAnimation { duration: Theme.animSlow } }
                    }
                }

                Text {
                    width: parent.width
                    visible: !AppState.printPreparing && AppState.printLayer > 0
                    text: "第 " + AppState.printLayer + " 层"
                           + (AppState.printLayerTotal ? (" / " + AppState.printLayerTotal) : "")
                    color: Theme.textMute
                    font.pixelSize: Theme.fontSmall
                }

                Item { width: 1; height: 4 }

                Column {
                    spacing: 6
                    PrimaryButton {
                        text: AppState.printPaused ? "继续" : "暂停"
                        width: parent.parent.width
                        height: 40
                        visible: !AppState.printPreparing
                        onClicked: AppState.printPaused ? AppState.resumePrint() : AppState.pausePrint()
                    }
                    PrimaryButton {
                        text: "取消"
                        danger: true
                        width: parent.parent.width
                        height: 36
                        onClicked: AppState.cancelPrint()
                    }
                }
            }

            PrintBedViz {
                width: parent.parent.sideW
                height: parent.height
                toolX: AppState.toolX
                toolY: AppState.toolY
                toolZ: AppState.toolZ
                bedRadius: AppState.bedRadius
                printProgress: AppState.printPreparing ? 0 : AppState.printProgress
                layerNow: AppState.printLayer
                layerTotal: AppState.printLayerTotal
                paused: AppState.printPaused || AppState.printPreparing
                trail: AppState.printTrail
                objectHeight: AppState.printObjectHeight
            }
        }
    }

    // —— 空闲：一件事——开始打印 ——
    Column {
        anchors.fill: parent
        anchors.leftMargin: 18
        anchors.rightMargin: 18
        anchors.topMargin: 8
        spacing: 14
        visible: !AppState.printSessionActive()

        Column {
            spacing: 6
            Text {
                text: AppState.machineName
                color: Theme.accent
                font.pixelSize: 11
                font.letterSpacing: 1.2
                font.family: Theme.fontFamily
                font.weight: Theme.fontWeight
            }
            Text {
                text: AppState.connected ? AppState.tr("home.ready") : AppState.tr("home.offline")
                color: Theme.textPrimary
                font.pixelSize: Theme.fontHuge
                font.weight: Theme.fontWeight
            }
            Text {
                text: "DELTA SERIES"
                color: Theme.textSecondary
                font.pixelSize: Theme.fontSmall
                font.letterSpacing: 1.6
            }
        }

        Item {
            width: parent.width
            height: 58
            Rectangle {
                anchors.fill: parent
                radius: Theme.radiusLg
                color: cta.pressed ? "#8B74E8" : Theme.accent
                Behavior on color { ColorAnimation { duration: 80 } }
            }
            Column {
                anchors.left: parent.left
                anchors.leftMargin: 16
                anchors.verticalCenter: parent.verticalCenter
                spacing: 2
                Text {
                    text: AppState.tr("home.pick")
                    color: "#120E1A"
                    font.pixelSize: Theme.fontTitle
                    font.family: Theme.fontFamily
                    font.weight: Theme.fontWeight
                }
                Text {
                    text: AppState.gcodeFiles.length + " 个可打印文件"
                    color: "#2A2340"
                    font.pixelSize: Theme.fontSmall
                }
            }
            Text {
                anchors.right: parent.right
                anchors.rightMargin: 16
                anchors.verticalCenter: parent.verticalCenter
                text: ">"
                color: "#120E1A"
                font.family: Theme.fontFamily
                font.pixelSize: 22
                font.weight: Theme.fontWeight
            }
            TouchArea {
                id: cta
                anchors.fill: parent
                onClicked: AppState.go("files")
            }
        }

        Item {
            width: parent.width
            height: 44
            Row {
                anchors.fill: parent
                spacing: 0
                Item {
                    width: parent.width / 2
                    height: parent.height
                    Column {
                        anchors.verticalCenter: parent.verticalCenter
                        spacing: 2
                        Text {
                            text: "喷嘴"
                            color: Theme.textMute
                            font.pixelSize: Theme.fontSmall
                        }
                        Text {
                            text: Math.round(AppState.extruderTemp) + "°C"
                            color: AppState.extruderTarget > 0 ? Theme.accent : Theme.textPrimary
                            font.pixelSize: 18
                            font.family: Theme.fontFamily
                            font.weight: Theme.fontWeight
                        }
                    }
                    TouchArea {
                        anchors.fill: parent
                        onClicked: AppState.go("device")
                    }
                }
                Rectangle {
                    anchors.verticalCenter: parent.verticalCenter
                    width: 1
                    height: 22
                    color: Theme.lineSoft
                }
                Item {
                    width: parent.width / 2 - 1
                    height: parent.height
                    Column {
                        anchors.verticalCenter: parent.verticalCenter
                        anchors.left: parent.left
                        anchors.leftMargin: 16
                        spacing: 2
                        Text {
                            text: "热床"
                            color: Theme.textMute
                            font.pixelSize: Theme.fontSmall
                        }
                        Text {
                            text: Math.round(AppState.bedTemp) + "°C"
                            color: AppState.bedTarget > 0 ? Theme.warn : Theme.textPrimary
                            font.pixelSize: 18
                            font.family: Theme.fontFamily
                            font.weight: Theme.fontWeight
                        }
                    }
                    TouchArea {
                        anchors.fill: parent
                        onClicked: AppState.go("device")
                    }
                }
            }
        }

        Row {
            spacing: 18
            Text {
                text: "耗材  " + AppState.filamentType
                color: Theme.textSecondary
                font.pixelSize: Theme.fontBody
                TouchArea {
                    anchors.fill: parent
                    anchors.margins: -10
                    onClicked: AppState.go("filament")
                }
            }
            Text {
                text: AppState.hmsItems.length
                      ? ("消息  " + AppState.hmsItems.length)
                      : "消息  正常"
                color: AppState.hmsItems.length ? AppState.hmsBadgeColor : Theme.textSecondary
                font.pixelSize: Theme.fontBody
                TouchArea {
                    anchors.fill: parent
                    anchors.margins: -10
                    onClicked: AppState.go("alerts")
                }
            }
        }
    }
}
