import QtQuick 2.15
import ".."

// Heater channel: readout + manual steppers + presets (fits ~200px tall pane)
Item {
    id: root
    property string title: ""
    property real current: 0
    property real target: 0
    property color accent: Theme.accent
    property var presets: []
    property bool showDivider: false
    property real stepFine: 1
    property real stepCoarse: 5
    property real maxTemp: 300

    signal setTemp(real value)
    signal requestEdit()

    readonly property bool heating: target > 0 && current < target - 1.5
    readonly property bool cooling: target > 0 && current > target + 2.5
    readonly property bool holding: target > 0 && !heating && !cooling
    readonly property real progress: {
        if (target <= 0) return 0
        var t = Math.max(1, target)
        return Math.max(0, Math.min(1, current / t))
    }
    readonly property string stateText: {
        if (target <= 0) return AppState.tr("device.off")
        if (heating) return "加热中"
        if (cooling) return "冷却中"
        return "恒温"
    }

    function bump(delta) {
        var base = root.target > 0 ? root.target : Math.round(root.current)
        var next = Math.max(0, Math.min(root.maxTemp, Math.round(base + delta)))
        root.setTemp(next)
    }

    Rectangle {
        visible: root.showDivider
        anchors.left: parent.left
        anchors.top: parent.top
        anchors.bottom: parent.bottom
        anchors.topMargin: 8
        anchors.bottomMargin: 8
        width: 1
        color: Theme.lineSoft
    }

    Column {
        anchors.fill: parent
        anchors.leftMargin: root.showDivider ? 10 : 8
        anchors.rightMargin: 6
        anchors.topMargin: 6
        anchors.bottomMargin: 6
        spacing: 4

        Row {
            width: parent.width
            spacing: 6
            Text {
                text: root.title
                color: Theme.textMute
                font.pixelSize: Theme.fontSmall
            }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: root.stateText
                color: root.target > 0 ? root.accent : Theme.textMute
                font.pixelSize: Theme.fontSmall
            }
        }

        Row {
            width: parent.width
            spacing: 4
            Text {
                text: Math.round(root.current) + "°"
                color: root.target > 0 ? root.accent : Theme.textPrimary
                font.pixelSize: 26
                font.family: Theme.fontFamily
                font.weight: Theme.fontWeight
            }
            Text {
                anchors.bottom: parent.bottom
                anchors.bottomMargin: 3
                text: root.target > 0 ? ("→ " + Math.round(root.target) + "°") : " "
                color: Theme.textSecondary
                font.pixelSize: Theme.fontSmall
            }
            Item { width: Math.max(2, parent.width - 148); height: 1 }
            PadKey {
                anchors.verticalCenter: parent.verticalCenter
                text: "设"
                width: 40
                height: 34
                primary: true
                onClicked: root.requestEdit()
            }
        }

        Item {
            width: parent.width
            height: 3
            Rectangle { anchors.fill: parent; radius: 2; color: "#1A1F24" }
            Rectangle {
                width: parent.width * root.progress
                height: parent.height
                radius: 2
                color: root.accent
                opacity: root.target > 0 ? 0.85 : 0.15
                Behavior on width { NumberAnimation { duration: 220 } }
            }
        }

        // Manual steppers + numeric edit
        Row {
            width: parent.width
            spacing: 3
            PadKey {
                text: "−5"
                width: Math.floor((parent.width - 9) / 4)
                height: 36
                onClicked: root.bump(-root.stepCoarse)
            }
            PadKey {
                text: "−1"
                width: Math.floor((parent.width - 9) / 4)
                height: 36
                onClicked: root.bump(-root.stepFine)
            }
            PadKey {
                text: "+1"
                width: Math.floor((parent.width - 9) / 4)
                height: 36
                onClicked: root.bump(root.stepFine)
            }
            PadKey {
                text: "+5"
                width: Math.floor((parent.width - 9) / 4)
                height: 36
                onClicked: root.bump(root.stepCoarse)
            }
        }

        Grid {
            width: parent.width
            columns: 2
            rowSpacing: 3
            columnSpacing: 3
            Repeater {
                model: root.presets
                delegate: Item {
                    width: (parent.width - 3) / 2
                    height: 28
                    property bool on: Math.round(root.target) === Math.round(modelData.value)
                    Rectangle {
                        anchors.fill: parent
                        radius: Theme.radius
                        color: {
                            if (chipTouch.pressed) return Theme.bgTilePressed
                            if (on) return Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.18)
                            return Theme.bgTile
                        }
                        border.width: on ? 0 : 1
                        border.color: Theme.lineSoft
                    }
                    Text {
                        anchors.centerIn: parent
                        width: parent.width - 4
                        horizontalAlignment: Text.AlignHCenter
                        elide: Text.ElideRight
                        text: modelData.label
                        color: on ? root.accent : Theme.textSecondary
                        font.pixelSize: Theme.fontSmall
                    }
                    TouchArea {
                        id: chipTouch
                        anchors.fill: parent
                        onClicked: root.setTemp(modelData.value)
                    }
                }
            }
        }
    }
}
