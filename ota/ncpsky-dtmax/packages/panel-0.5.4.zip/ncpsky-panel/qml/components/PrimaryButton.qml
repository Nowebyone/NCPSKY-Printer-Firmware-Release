import QtQuick 2.15
import ".."

Item {
    id: btn
    property string text: ""
    property bool primary: true
    property bool danger: false
    property bool enabled: true
    signal clicked()

    width: Math.max(Theme.touchMin + 12, label.implicitWidth + 28)
    height: Theme.touchMin - 6
    opacity: enabled ? 1 : 0.35

    Rectangle {
        anchors.fill: parent
        radius: Theme.radius
        color: {
            if (!btn.enabled) return Theme.bgTile
            if (touch.pressed) {
                if (danger) return "#B83E3E"
                if (primary) return "#8B74E8"
                return Theme.bgTilePressed
            }
            if (danger) return Theme.danger
            if (primary) return Theme.accent
            return Theme.bgTile
        }
        border.color: primary || danger ? "transparent" : Theme.line
        border.width: primary || danger ? 0 : 1
    }
    Text {
        id: label
        anchors.centerIn: parent
        text: btn.text
        color: (primary || danger) ? "#120E1A" : Theme.textPrimary
        font.pixelSize: Theme.fontBody
        font.family: Theme.fontFamily
        font.weight: Theme.fontWeight
    }
    TouchArea {
        id: touch
        anchors.fill: parent
        enabled: btn.enabled
        onClicked: btn.clicked()
    }
}
