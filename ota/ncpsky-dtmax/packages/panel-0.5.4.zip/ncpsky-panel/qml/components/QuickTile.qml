import QtQuick 2.15
import ".."

Item {
    id: tile
    property string title: ""
    property string value: ""
    property string subtitle: ""
    property color accent: Theme.textSecondary
    property bool emphasize: false
    signal clicked()

    width: 128
    height: 64

    opacity: ma.pressed ? 0.85 : 1.0
    Behavior on opacity { NumberAnimation { duration: Theme.animFast } }

    Rectangle {
        anchors.fill: parent
        radius: Theme.radiusLg
        color: ma.pressed ? Theme.bgTilePressed : Theme.bgTile
        // no border — tonal surface only
    }

    Column {
        anchors.fill: parent
        anchors.leftMargin: 10
        anchors.rightMargin: 8
        anchors.topMargin: 8
        spacing: 3
        Text {
            text: tile.title
            color: Theme.textMute
            font.pixelSize: Theme.fontSmall
            font.letterSpacing: 0.4
        }
        Text {
            text: tile.value
            color: Theme.textPrimary
            font.pixelSize: tile.emphasize ? Theme.fontDisplay : Theme.fontTitle
            font.family: Theme.fontFamily
            font.weight: Theme.fontWeight
            elide: Text.ElideRight
            width: parent.width
        }
        Text {
            text: tile.subtitle
            color: tile.accent
            font.pixelSize: Theme.fontSmall
            visible: tile.subtitle.length > 0
        }
    }

    MouseArea {
        id: ma
        anchors.fill: parent
        onClicked: tile.clicked()
    }
}
