import QtQuick 2.15
import ".."

Item {
    id: hero
    property real progress: 0
    property string etaText: "--:--"
    property string title: ""
    height: 72
    width: parent ? parent.width : 200

    Column {
        anchors.fill: parent
        spacing: 8

        Row {
            width: parent.width
            Text {
                text: Math.round(hero.progress * 100) + "%"
                color: Theme.textPrimary
                font.pixelSize: Theme.fontHuge
                font.family: Theme.fontFamily
                font.weight: Theme.fontWeight
            }
            Item { width: parent.width - 200; height: 1 }
            Column {
                anchors.verticalCenter: parent.verticalCenter
                spacing: 2
                Text {
                    anchors.right: parent.right
                    text: "剩余"
                    color: Theme.textMute
                    font.pixelSize: Theme.fontSmall
                }
                Text {
                    anchors.right: parent.right
                    text: hero.etaText
                    color: Theme.textSecondary
                    font.pixelSize: Theme.fontBody
                }
            }
        }

        // Full-bleed thin progress
        Item {
            width: parent.width
            height: 3
            Rectangle {
                anchors.fill: parent
                color: Theme.lineSoft
            }
            Rectangle {
                height: parent.height
                width: parent.width * Math.max(0, Math.min(1, hero.progress))
                color: Theme.accent
                Behavior on width { NumberAnimation { duration: Theme.animSlow } }
            }
        }
    }
}
