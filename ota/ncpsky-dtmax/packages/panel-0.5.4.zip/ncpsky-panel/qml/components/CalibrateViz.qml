import QtQuick 2.15
import ".."

// Lightweight Canvas viz for calibration steps (no Qt3D)
Item {
    id: root
    property string mode: "home"   // home|tilt|mesh|shaper|tmc|save|view
    // auto: by mode; delta: force machine viz; spectrum: force shaper PSD panel
    property string content: "auto"
    property bool portraitPanel: false
    property bool vibrate: false
    property real toolX: 0
    property real toolY: 0
    property real toolZ: 0
    property real bedRadius: 145
    property real shaperFreqX: 34
    property real shaperFreqY: 33
    property real sweepHz: 30
    property real shaperFreqMin: 30
    property real shaperFreqMax: 50
    property var shaperPsdX: []
    property var shaperPsdY: []
    property var shaperWave: []
    property string shaperPhase: ""
    property real progress: 0
    property var probeTrail: []
    // View-tab: applied calibration snapshot
    property string viewKind: "shaper"  // shaper|mesh|tmc
    property var meshPoints: []
    property real meshZMin: 0
    property real meshZMax: 0
    property string meshProfile: ""
    property var meshParams: ({})
    property var tiltInfo: ({})
    property var tmcMotors: []
    property var noiseCurve: []
    property string shaperTypeX: ""
    property string shaperTypeY: ""
    // Visual kinematics — defaults match FLSun T1 Max; page may override from config
    property real armLength: 345
    property real deltaRadius: 172
    property real towerAngleA: 210
    property real towerAngleB: 330
    property real towerAngleC: 90
    // Accel chase uses real toolhead limits from printer (mm/s, mm/s²)
    property real maxVel: 1200
    property real maxAccel: 40000
    property real dispX: 0
    property real dispY: 0
    property real dispZ: 20
    property real velX: 0
    property real velY: 0
    property real velZ: 0
    property bool _dispInit: false
    // Projection: bed foreshortening + vertical scale (taller = less "flat")
    property real viewYScale: 0.55
    property real viewZScale: 1.05

    property real _t: 0
    property real _pulse: 0

    onViewKindChanged: canvas.requestPaint()
    onMeshPointsChanged: canvas.requestPaint()
    onTmcMotorsChanged: canvas.requestPaint()
    onNoiseCurveChanged: canvas.requestPaint()

    function chaseAxis(disp, vel, target, dt, maxA, maxV) {
        var d = target - disp
        var dist = Math.abs(d)
        if (dist < 0.05)
            return { p: target, v: 0 }
        var dir = d > 0 ? 1 : -1
        var stopDist = (vel * vel) / (2 * Math.max(1, maxA))
        var a = (vel * dir > 0 && dist <= stopDist) ? (-dir * maxA) : (dir * maxA)
        var v = vel + a * dt
        if (vel * dir > 0 && v * dir < 0 && dist <= stopDist)
            v = 0
        if (Math.abs(v) > maxV)
            v = dir * maxV
        var step = v * dt
        if (Math.abs(step) >= dist)
            return { p: target, v: 0 }
        return { p: disp + step, v: v }
    }

    function syncDisp(dt) {
        if (!root._dispInit) {
            root.dispX = root.toolX
            root.dispY = root.toolY
            root.dispZ = root.toolZ
            root.velX = 0
            root.velY = 0
            root.velZ = 0
            root._dispInit = true
            return
        }
        var maxA = Math.max(500, root.maxAccel)
        var maxV = Math.max(50, root.maxVel)
        var rx = root.chaseAxis(root.dispX, root.velX, root.toolX, dt, maxA, maxV)
        var ry = root.chaseAxis(root.dispY, root.velY, root.toolY, dt, maxA, maxV)
        var rz = root.chaseAxis(root.dispZ, root.velZ, root.toolZ, dt, maxA, maxV)
        root.dispX = rx.p; root.velX = rx.v
        root.dispY = ry.p; root.velY = ry.v
        root.dispZ = rz.p; root.velZ = rz.v
    }

    function wantsDelta() {
        if (root.content === "delta") return true
        if (root.content === "spectrum") return false
        return root.mode === "home" || root.mode === "tilt" || root.mode === "mesh"
                || (root.mode === "shaper" && root.vibrate)
    }

    onModeChanged: {
        if (wantsDelta())
            root._dispInit = false
    }

    onVisibleChanged: {
        if (visible)
            root._dispInit = false
    }

    Timer {
        interval: 40
        running: root.visible
        repeat: true
        onTriggered: {
            root._t += 0.04
            root._pulse = 0.5 + 0.5 * Math.sin(root._t * 6)
            if (root.wantsDelta())
                root.syncDisp(0.04)
            canvas.requestPaint()
        }
    }

    function drawEllipse(ctx, cx, cy, rx, ry) {
        ctx.save()
        ctx.translate(cx, cy)
        ctx.scale(1, ry / Math.max(1, rx))
        ctx.beginPath()
        ctx.arc(0, 0, rx, 0, Math.PI * 2)
        ctx.restore()
    }

    Canvas {
        id: canvas
        anchors.fill: parent
        antialiasing: true

        onPaint: {
            var ctx = getContext("2d")
            var w = width, h = height
            ctx.clearRect(0, 0, w, h)
            ctx.fillStyle = "#0C1014"
            ctx.fillRect(0, 0, w, h)

            if (root.mode === "view") {
                if (root.viewKind === "mesh")
                    paintMeshView(ctx, w, h)
                else if (root.viewKind === "tmc")
                    paintTmcView(ctx, w, h)
                else
                    paintShaper(ctx, w, h)
                return
            }

            var showSpectrum = (root.content === "spectrum")
                    || (root.content === "auto" && root.mode === "shaper" && !root.vibrate)
            var showDelta = root.wantsDelta()
                    || (root.content === "auto" && (root.mode === "home" || root.mode === "tilt" || root.mode === "mesh"))

            if (showSpectrum)
                paintShaper(ctx, w, h)
            else if (root.mode === "tmc" && root.content !== "delta")
                paintTmc(ctx, w, h)
            else if (root.mode === "save" && root.content !== "delta")
                paintSave(ctx, w, h)
            else
                paintDeltaProbe(ctx, w, h)
        }

        // Printer XY → screen: +X right, +Y away (C back/top), +Z up
        // portraitPanel: tall side rail — squeeze XY a bit, keep vertical readable
        function iso(x, y, z) {
            var fitXY = Math.max(root.bedRadius, root.deltaRadius) * (root.portraitPanel ? 2.05 : 2.3)
            var fitZ = Math.max(260, root.armLength * 0.95)
            var yF = root.portraitPanel ? 0.42 : root.viewYScale
            var zF = root.portraitPanel ? 0.88 : root.viewZScale
            var s
            var cx = width * 0.50
            var cy
            if (root.portraitPanel) {
                // Fill vertical: scale by height first, allow slightly compact width
                s = Math.min(width / (fitXY * 0.92), height / (fitZ * zF * 0.78 + 36))
                cy = height * 0.86
            } else {
                var sxy = width / fitXY
                var sz = height / (fitXY * yF * 0.35 + fitZ * zF * 0.72)
                s = Math.min(sxy, sz)
                cy = height * 0.78
            }
            var X = x * s
            var Y = -y * s * yF - z * s * zF
            return { x: cx + X, y: cy + Y }
        }

        function carriageZ(tx, ty, ex, ey, ez) {
            // Delta IK: carZ = ez + sqrt(L² - horiz²)  (~300mm at center on T1 Max)
            var dx = ex - tx
            var dy = ey - ty
            var horiz2 = dx * dx + dy * dy
            var L = root.armLength
            var rem = L * L - horiz2
            if (rem < 1) rem = 1
            return ez + Math.sqrt(rem)
        }

        function paintDeltaProbe(ctx, w, h) {
            var R = root.bedRadius
            var DR = root.deltaRadius
            var towers = [
                { a: root.towerAngleA, c: "#3D8BFF", n: "A" },
                { a: root.towerAngleB, c: "#A78BFA", n: "B" },
                { a: root.towerAngleC, c: "#D4A017", n: "C" }
            ]
            var ex = root.dispX
            var ey = root.dispY
            var ez = root.dispZ
            // Resonance shake: follow sweep axis / frequency
            if (root.vibrate || (root.mode === "shaper" && root.content === "delta")) {
                var amp = 2.2 + 3.2 * root._pulse
                var hz = Math.max(8, Math.min(80, root.sweepHz))
                var shake = Math.sin(root._t * hz * Math.PI * 2) * amp
                if (root.shaperPhase === "y")
                    ey += shake
                else
                    ex += shake
            }
            if (ez < -5) ez = -5
            if (ez > 80) ez = 80

            // Precompute tower XY + carriage Z from IK (no fake short clamp)
            var i, ang, tx, ty, cz
            var towerPos = []
            var railTop = 0
            for (i = 0; i < 3; i++) {
                ang = towers[i].a * Math.PI / 180
                tx = Math.cos(ang) * DR
                ty = Math.sin(ang) * DR
                cz = carriageZ(tx, ty, ex, ey, ez)
                if (cz > railTop) railTop = cz
                towerPos.push({ tx: tx, ty: ty, cz: cz, c: towers[i].c, n: towers[i].n, a: towers[i].a })
            }
            railTop = Math.max(railTop + 25, root.armLength * 0.92)

            // Tower rails up to real carriage band
            for (i = 0; i < 3; i++) {
                var tp = towerPos[i]
                var base = iso(tp.tx, tp.ty, 0)
                var top = iso(tp.tx, tp.ty, railTop)
                ctx.strokeStyle = tp.c
                ctx.globalAlpha = 0.35
                ctx.lineWidth = 3
                ctx.beginPath()
                ctx.moveTo(base.x, base.y)
                ctx.lineTo(top.x, top.y)
                ctx.stroke()
                ctx.globalAlpha = 0.75
                ctx.lineWidth = 1.2
                ctx.beginPath()
                ctx.moveTo(base.x, base.y)
                ctx.lineTo(top.x, top.y)
                ctx.stroke()
            }

            // Bed — ellipse aspect matches viewYScale (less pancake)
            var yF = root.viewYScale
            var c0 = iso(0, 0, 0)
            var rim = iso(R, 0, 0)
            var rx = Math.abs(rim.x - c0.x)
            var ry = Math.max(10, rx * yF)
            ctx.globalAlpha = 0.9
            ctx.fillStyle = "#12161A"
            root.drawEllipse(ctx, c0.x, c0.y, rx, ry)
            ctx.fill()
            ctx.strokeStyle = "#2A3138"
            ctx.lineWidth = 1.5
            root.drawEllipse(ctx, c0.x, c0.y, rx, ry)
            ctx.stroke()
            ctx.globalAlpha = 0.35
            ctx.strokeStyle = "#3A4450"
            ctx.lineWidth = 1
            for (var g = 1; g <= 3; g++) {
                var rr = R * g / 3
                var p = iso(rr, 0, 0)
                var grx = Math.abs(p.x - c0.x)
                root.drawEllipse(ctx, c0.x, c0.y, grx, Math.max(6, grx * yF))
                ctx.stroke()
            }

            // Probe trail (settled points stay; nozzle moves with accel)
            ctx.globalAlpha = 0.95
            for (var t = 0; t < root.probeTrail.length; t++) {
                var pt = root.probeTrail[t]
                var pp = iso(pt.x, pt.y, 0)
                ctx.fillStyle = root.mode === "tilt" ? "#D4A017" : "#A78BFA"
                ctx.beginPath()
                ctx.arc(pp.x, pp.y, 2.2, 0, Math.PI * 2)
                ctx.fill()
            }

            // Effector joint radius on platform (for dual rods)
            var jointR = 12
            var n = iso(ex, ey, ez)

            // Dual parallel rods A/B/C → effector
            for (i = 0; i < 3; i++) {
                tp = towerPos[i]
                ang = tp.a * Math.PI / 180
                // offset perpendicular to tower radial for parallel pair
                var ox = -Math.sin(ang) * 6
                var oy = Math.cos(ang) * 6
                var carL = iso(tp.tx + ox * 0.15, tp.ty + oy * 0.15, tp.cz)
                var carR = iso(tp.tx - ox * 0.15, tp.ty - oy * 0.15, tp.cz)
                var jL = iso(ex + ox, ey + oy, ez + 2)
                var jR = iso(ex - ox, ey - oy, ez + 2)
                ctx.globalAlpha = 0.85
                ctx.strokeStyle = tp.c
                ctx.lineWidth = 1.6
                ctx.beginPath()
                ctx.moveTo(carL.x, carL.y)
                ctx.lineTo(jL.x, jL.y)
                ctx.stroke()
                ctx.beginPath()
                ctx.moveTo(carR.x, carR.y)
                ctx.lineTo(jR.x, jR.y)
                ctx.stroke()
                // faint arm fill between pair
                ctx.globalAlpha = 0.12
                ctx.fillStyle = tp.c
                ctx.beginPath()
                ctx.moveTo(carL.x, carL.y)
                ctx.lineTo(carR.x, carR.y)
                ctx.lineTo(jR.x, jR.y)
                ctx.lineTo(jL.x, jL.y)
                ctx.closePath()
                ctx.fill()
            }

            // Carriages on rails
            for (i = 0; i < 3; i++) {
                tp = towerPos[i]
                var car = iso(tp.tx, tp.ty, tp.cz)
                ctx.globalAlpha = 1
                ctx.fillStyle = tp.c
                ctx.strokeStyle = "#0C1014"
                ctx.lineWidth = 1
                ctx.beginPath()
                ctx.rect(car.x - 5, car.y - 4, 10, 8)
                ctx.fill()
                ctx.stroke()
                ctx.fillStyle = "#E8EAED"
                ctx.font = "10px sans-serif"
                ctx.fillText(tp.n, car.x + 7, car.y + 3)
                // small height tick
                ctx.fillStyle = tp.c
                ctx.font = "9px sans-serif"
                ctx.fillText(tp.cz.toFixed(0), car.x + 7, car.y + 14)
            }

            // Effector platform + nozzle
            ctx.globalAlpha = 1
            var eA = iso(ex + jointR * Math.cos(210 * Math.PI / 180),
                         ey + jointR * Math.sin(210 * Math.PI / 180), ez + 2)
            var eB = iso(ex + jointR * Math.cos(330 * Math.PI / 180),
                         ey + jointR * Math.sin(330 * Math.PI / 180), ez + 2)
            var eC = iso(ex + jointR * Math.cos(90 * Math.PI / 180),
                         ey + jointR * Math.sin(90 * Math.PI / 180), ez + 2)
            ctx.fillStyle = "#2A3138"
            ctx.strokeStyle = "#E8EAED"
            ctx.lineWidth = 1.2
            ctx.beginPath()
            ctx.moveTo(eA.x, eA.y)
            ctx.lineTo(eB.x, eB.y)
            ctx.lineTo(eC.x, eC.y)
            ctx.closePath()
            ctx.fill()
            ctx.stroke()

            var glow = 4 + 3 * root._pulse
            ctx.fillStyle = "rgba(167,139,250," + (0.15 + 0.2 * root._pulse) + ")"
            ctx.beginPath()
            ctx.arc(n.x, n.y, glow + 4, 0, Math.PI * 2)
            ctx.fill()
            ctx.fillStyle = "#E8EAED"
            ctx.beginPath()
            ctx.arc(n.x, n.y, 3.2, 0, Math.PI * 2)
            ctx.fill()
            // nozzle tip toward bed
            ctx.fillStyle = "#A78BFA"
            ctx.beginPath()
            ctx.moveTo(n.x, n.y + 2)
            ctx.lineTo(n.x - 3.5, n.y + 11)
            ctx.lineTo(n.x + 3.5, n.y + 11)
            ctx.closePath()
            ctx.fill()

            ctx.fillStyle = "#7A8088"
            ctx.font = "11px sans-serif"
            var label = "喷头归位"
            if (root.mode === "tilt") label = "倾斜校正"
            else if (root.mode === "mesh") label = "自动调平"
            else if (root.mode === "home") label = "喷头归位"
            else if (root.mode === "shaper") label = "共振 · " + ((root.shaperPhase === "y") ? "Y" : "X")
            ctx.fillText(label, 6, 12)
            ctx.fillStyle = "#5A6169"
            ctx.fillText("X " + ex.toFixed(0) + "  Y " + ey.toFixed(0) + "  Z " + ez.toFixed(1), 8, h - 8)
            ctx.globalAlpha = 1
        }

        function paintShaper(ctx, w, h) {
            var padL = 28, padR = 10, padT = 22, padB = 18
            var gw = w - padL - padR
            var waveH = Math.max(28, Math.floor(h * 0.28))
            var gh = h - padT - padB - waveH - 6
            var axis = (root.shaperPhase === "y") ? "Y" : "X"
            var fLo = root.shaperFreqMin
            var fHi = root.shaperFreqMax
            ctx.fillStyle = "#7A8088"
            ctx.font = "11px sans-serif"
            if (root.mode === "view") {
                var tx = root.shaperTypeX || "—"
                var ty = root.shaperTypeY || "—"
                ctx.fillText("已应用共振  X " + (root.shaperFreqX > 1 ? root.shaperFreqX.toFixed(1) : "--")
                             + " " + tx + "  ·  Y "
                             + (root.shaperFreqY > 1 ? root.shaperFreqY.toFixed(1) : "--")
                             + " " + ty, 8, 14)
            } else {
                ctx.fillText("共振实测 · " + axis + " " + fLo.toFixed(0) + "→" + fHi.toFixed(0) + "Hz", 8, 14)
            }

            // Live displacement waveform (from motion_report)
            var wy0 = padT
            ctx.strokeStyle = "#2A3138"
            ctx.strokeRect(padL, wy0, gw, waveH)
            var wave = root.shaperWave || []
            if (wave.length >= 2) {
                var minV = wave[0], maxV = wave[0]
                var wi
                for (wi = 1; wi < wave.length; wi++) {
                    if (wave[wi] < minV) minV = wave[wi]
                    if (wave[wi] > maxV) maxV = wave[wi]
                }
                var span = Math.max(0.05, maxV - minV)
                ctx.strokeStyle = axis === "Y" ? "#A78BFA" : "#3D8BFF"
                ctx.lineWidth = 1.5
                ctx.beginPath()
                for (wi = 0; wi < wave.length; wi++) {
                    var xx = padL + wi / Math.max(1, wave.length - 1) * gw
                    var yy = wy0 + waveH - (wave[wi] - minV) / span * (waveH - 4) - 2
                    if (wi === 0) ctx.moveTo(xx, yy); else ctx.lineTo(xx, yy)
                }
                ctx.stroke()
            } else {
                ctx.fillStyle = "#555B63"
                ctx.font = "10px sans-serif"
                ctx.fillText("等待喷头振动…", padL + 8, wy0 + waveH * 0.55)
            }

            var plotT = wy0 + waveH + 8
            ctx.strokeStyle = "#2A3138"
            ctx.beginPath()
            ctx.moveTo(padL, plotT)
            ctx.lineTo(padL, plotT + gh)
            ctx.lineTo(padL + gw, plotT + gh)
            ctx.stroke()

            var f0 = fLo, f1 = Math.max(fLo + 1, fHi)
            function xOf(f) { return padL + (f - f0) / (f1 - f0) * gw }
            function yOf(v) { return plotT + gh - Math.max(0, Math.min(1, v)) * gh }

            ctx.strokeStyle = "#1A1F24"
            var step = (f1 - f0) > 30 ? 10 : 5
            for (var gf = Math.ceil(f0 / step) * step; gf <= f1; gf += step) {
                var gx = xOf(gf)
                ctx.beginPath(); ctx.moveTo(gx, plotT); ctx.lineTo(gx, plotT + gh); ctx.stroke()
                ctx.fillStyle = "#555B63"
                ctx.font = "9px sans-serif"
                ctx.fillText(String(gf), gx - 6, plotT + gh + 12)
            }

            function strokePsd(color, pts) {
                if (!pts || pts.length < 2) return false
                ctx.strokeStyle = color
                ctx.lineWidth = 1.8
                ctx.beginPath()
                var first = true
                for (var i = 0; i < pts.length; i++) {
                    var f = pts[i].f, v = pts[i].v
                    if (f < f0 || f > f1) continue
                    var xx = xOf(f), yy = yOf(v)
                    if (first) { ctx.moveTo(xx, yy); first = false } else ctx.lineTo(xx, yy)
                }
                ctx.stroke()
                return !first
            }
            var hasX = strokePsd("#3D8BFF", root.shaperPsdX)
            var hasY = strokePsd("#A78BFA", root.shaperPsdY)
            if (!hasX && !hasY) {
                ctx.fillStyle = "#555B63"
                ctx.font = "10px sans-serif"
                ctx.fillText("频谱将在本轴测完后显示（ADXL 实测）", padL + 6, plotT + gh * 0.5)
            }

            var sx = xOf(Math.max(f0, Math.min(f1, root.sweepHz)))
            ctx.strokeStyle = "rgba(212,160,23,0.85)"
            ctx.lineWidth = 1
            ctx.beginPath()
            ctx.moveTo(sx, plotT)
            ctx.lineTo(sx, plotT + gh)
            ctx.stroke()

            ctx.fillStyle = "#3D8BFF"
            ctx.font = "11px sans-serif"
            ctx.fillText("X " + (root.shaperFreqX > 1 ? root.shaperFreqX.toFixed(1) : "--") + "Hz", padL + 4, plotT + 12)
            ctx.fillStyle = "#A78BFA"
            ctx.fillText("Y " + (root.shaperFreqY > 1 ? root.shaperFreqY.toFixed(1) : "--") + "Hz", padL + 70, plotT + 12)
            if (root.mode !== "view") {
                ctx.fillStyle = "#D4A017"
                ctx.font = "10px sans-serif"
                ctx.fillText("~" + root.sweepHz.toFixed(1) + " Hz", sx + 4, plotT + 12)
            }
        }

        function heatColor(t) {
            // t 0..1 cool→hot (blue→green→amber→red)
            t = Math.max(0, Math.min(1, t))
            if (t < 0.33) {
                var u = t / 0.33
                return "rgb(" + Math.round(30 + 30 * u) + "," + Math.round(90 + 80 * u) + "," + Math.round(200 - 40 * u) + ")"
            }
            if (t < 0.66) {
                var v = (t - 0.33) / 0.33
                return "rgb(" + Math.round(60 + 140 * v) + "," + Math.round(170 - 40 * v) + "," + Math.round(80 - 60 * v) + ")"
            }
            var w = (t - 0.66) / 0.34
            return "rgb(" + Math.round(200 + 40 * w) + "," + Math.round(130 - 90 * w) + "," + Math.round(40 - 20 * w) + ")"
        }

        function paintMeshView(ctx, w, h) {
            var pts = root.meshPoints || []
            var rows = pts.length
            var cols = rows ? (pts[0] ? pts[0].length : 0) : 0
            var zLo = root.meshZMin
            var zHi = root.meshZMax
            var zAvg = (zLo + zHi) * 0.5
            var span = Math.max(0.001, zHi - zLo)

            ctx.fillStyle = "#7A8088"
            ctx.font = "11px sans-serif"
            var title = "床网"
            if (root.meshProfile)
                title += " · " + root.meshProfile
            if (rows && cols)
                title += "  " + cols + "×" + rows + "  Δ" + span.toFixed(3) + "mm"
            ctx.fillText(title, 8, 14)

            var tilt = root.tiltInfo || {}
            ctx.fillStyle = "#555B63"
            ctx.font = "10px sans-serif"
            var ea = tilt.endstop_a || 0, eb = tilt.endstop_b || 0, ec = tilt.endstop_c || 0
            ctx.fillText("倾斜  A" + ea.toFixed(2) + " B" + eb.toFixed(2)
                         + " C" + ec.toFixed(2) + " · 左俯视 / 右斜视", 8, 28)

            var padT = 34
            if (!rows || !cols) {
                ctx.fillStyle = "#5A6169"
                ctx.font = "12px sans-serif"
                ctx.fillText("暂无床网数据，请先执行床网调平", 18, padT + 28)
                return
            }

            var mp = root.meshParams || {}
            var minX = (mp.min_x !== undefined) ? Number(mp.min_x) : -root.bedRadius
            var maxX = (mp.max_x !== undefined) ? Number(mp.max_x) : root.bedRadius
            var minY = (mp.min_y !== undefined) ? Number(mp.min_y) : -root.bedRadius
            var maxY = (mp.max_y !== undefined) ? Number(mp.max_y) : root.bedRadius
            if (maxX <= minX) { minX = -135; maxX = 135 }
            if (maxY <= minY) { minY = -135; maxY = 135 }
            var meshR = Math.max(Math.abs(minX), Math.abs(maxX), Math.abs(minY), Math.abs(maxY), 1)

            function sampleXY(r, c) {
                var x = minX + (cols === 1 ? 0 : (c / (cols - 1)) * (maxX - minX))
                var y = maxY - (rows === 1 ? 0 : (r / (rows - 1)) * (maxY - minY))
                return { x: x, y: y, z: Number(pts[r][c]) || 0 }
            }

            // —— Left: top-down circular (fill leftover height) ——
            var foot = 12
            var plotH = Math.max(40, h - padT - foot)
            var leftW = Math.floor(w * 0.38)
            var cx0 = leftW * 0.50
            var cy0 = padT + plotH * 0.50
            var rBed = Math.min(leftW * 0.46, plotH * 0.46)
            ctx.beginPath()
            ctx.arc(cx0, cy0, rBed, 0, Math.PI * 2)
            ctx.fillStyle = "#12161A"
            ctx.fill()
            ctx.strokeStyle = "#2A3138"
            ctx.lineWidth = 1.2
            ctx.stroke()
            ctx.save()
            ctx.beginPath()
            ctx.arc(cx0, cy0, rBed - 0.5, 0, Math.PI * 2)
            ctx.clip()
            var cellR = Math.max(2.8, rBed / Math.max(cols, rows) * 0.72)
            for (var r = 0; r < rows; r++) {
                for (var c = 0; c < cols; c++) {
                    var p = sampleXY(r, c)
                    if ((p.x * p.x + p.y * p.y) > meshR * meshR * 1.04)
                        continue
                    var sx = cx0 + (p.x / meshR) * rBed
                    var sy = cy0 - (p.y / meshR) * rBed
                    ctx.beginPath()
                    ctx.arc(sx, sy, cellR, 0, Math.PI * 2)
                    ctx.fillStyle = heatColor((p.z - zLo) / span)
                    ctx.fill()
                }
            }
            ctx.restore()
            ctx.fillStyle = "#555B63"
            ctx.font = "9px sans-serif"
            ctx.fillText("俯视", cx0 - 10, h - 4)

            // —— Right: oblique surface (Z exaggerated) ——
            var rightW = w - leftW
            var ox = leftW + rightW * 0.50
            var oy = padT + plotH * 0.58
            // isometric-ish axes — use most of right pane
            var sXY = Math.min(rightW * 0.36, plotH * 0.40) / meshR
            var zBoost = Math.min(56, Math.max(24, plotH * 0.34)) / span  // px per mm
            function iso(x, y, z) {
                // rotate ~35° around Z then tilt
                var ang = 0.55
                var xr = x * Math.cos(ang) - y * Math.sin(ang)
                var yr = x * Math.sin(ang) + y * Math.cos(ang)
                return {
                    x: ox + xr * sXY * 1.05,
                    y: oy - yr * sXY * 0.55 - (z - zAvg) * zBoost
                }
            }

            // Reference flat plane at zAvg (ideal level)
            ctx.beginPath()
            var ring = 16
            for (var i = 0; i <= ring; i++) {
                var a = (i / ring) * Math.PI * 2
                var px = Math.cos(a) * meshR * 0.98
                var py = Math.sin(a) * meshR * 0.98
                var ip = iso(px, py, zAvg)
                if (i === 0) ctx.moveTo(ip.x, ip.y)
                else ctx.lineTo(ip.x, ip.y)
            }
            ctx.closePath()
            ctx.strokeStyle = "rgba(138,145,153,0.45)"
            ctx.lineWidth = 1
            ctx.stroke()
            // Inner dashed feel via second faint ring
            ctx.beginPath()
            for (var j = 0; j <= ring; j++) {
                var a2 = (j / ring) * Math.PI * 2
                var qx = Math.cos(a2) * meshR * 0.70
                var qy = Math.sin(a2) * meshR * 0.70
                var iq = iso(qx, qy, zAvg)
                if (j === 0) ctx.moveTo(iq.x, iq.y)
                else ctx.lineTo(iq.x, iq.y)
            }
            ctx.closePath()
            ctx.strokeStyle = "rgba(138,145,153,0.22)"
            ctx.stroke()

            // Build back-to-front quads (sort by depth ≈ rotated y)
            var quads = []
            for (var r2 = 0; r2 < rows - 1; r2++) {
                for (var c2 = 0; c2 < cols - 1; c2++) {
                    var a00 = sampleXY(r2, c2)
                    var a10 = sampleXY(r2, c2 + 1)
                    var a01 = sampleXY(r2 + 1, c2)
                    var a11 = sampleXY(r2 + 1, c2 + 1)
                    var mx = (a00.x + a10.x + a01.x + a11.x) * 0.25
                    var my = (a00.y + a10.y + a01.y + a11.y) * 0.25
                    if ((mx * mx + my * my) > meshR * meshR * 1.08)
                        continue
                    var depth = mx * Math.sin(0.55) + my * Math.cos(0.55)
                    var zMid = (a00.z + a10.z + a01.z + a11.z) * 0.25
                    quads.push({
                        depth: depth,
                        z: zMid,
                        p: [a00, a10, a11, a01]
                    })
                }
            }
            quads.sort(function(u, v) { return u.depth - v.depth })

            for (var q = 0; q < quads.length; q++) {
                var qd = quads[q]
                ctx.beginPath()
                for (var k = 0; k < 4; k++) {
                    var pt = qd.p[k]
                    var sp = iso(pt.x, pt.y, pt.z)
                    if (k === 0) ctx.moveTo(sp.x, sp.y)
                    else ctx.lineTo(sp.x, sp.y)
                }
                ctx.closePath()
                ctx.fillStyle = heatColor((qd.z - zLo) / span)
                ctx.globalAlpha = 0.82
                ctx.fill()
                ctx.globalAlpha = 1
                ctx.strokeStyle = "rgba(8,10,12,0.35)"
                ctx.lineWidth = 0.7
                ctx.stroke()
            }

            // Scale legend
            ctx.fillStyle = "#555B63"
            ctx.font = "9px sans-serif"
            ctx.fillText("斜视(起伏已放大)  灰圈=平均平面", leftW + 8, h - 4)
            ctx.fillStyle = "#3D8BFF"
            ctx.fillText(zLo.toFixed(2), leftW + 8, padT + 12)
            ctx.fillStyle = "#D94B4B"
            ctx.fillText(zHi.toFixed(2), w - 36, padT + 12)
        }

        function paintTmcView(ctx, w, h) {
            ctx.fillStyle = "#7A8088"
            ctx.font = "11px sans-serif"
            ctx.fillText("噪音速度曲线", 8, 14)

            var pts = root.noiseCurve || []
            if (!pts.length) {
                ctx.fillStyle = "#5A6169"
                ctx.font = "12px sans-serif"
                ctx.fillText("暂无测速数据 · 请先执行电机降噪", 16, 40)
                return
            }

            var padL = 36, padR = 12, padT = 28, padB = 28
            var plotW = Math.max(40, w - padL - padR)
            var plotH = Math.max(40, h - padT - padB)
            var vMin = Number(pts[0].v) || 0
            var vMax = Number(pts[0].v) || 1
            var rMax = 0
            for (var i = 0; i < pts.length; i++) {
                var vv = Number(pts[i].v) || 0
                var rr = Number(pts[i].rms) || 0
                if (vv < vMin) vMin = vv
                if (vv > vMax) vMax = vv
                if (rr > rMax) rMax = rr
            }
            if (vMax <= vMin) vMax = vMin + 1
            if (rMax <= 0) rMax = 1

            ctx.strokeStyle = "#1A1F24"
            ctx.lineWidth = 1
            ctx.beginPath()
            ctx.moveTo(padL, padT)
            ctx.lineTo(padL, padT + plotH)
            ctx.lineTo(padL + plotW, padT + plotH)
            ctx.stroke()

            ctx.fillStyle = "#555B63"
            ctx.font = "9px sans-serif"
            ctx.fillText(vMin.toFixed(0), padL, h - 8)
            ctx.fillText(vMax.toFixed(0) + " mm/s", padL + plotW - 42, h - 8)
            ctx.fillText("噪音", 6, padT + 8)
            ctx.fillText(rMax.toFixed(3), 4, padT + 20)

            ctx.strokeStyle = "#3D8BFF"
            ctx.lineWidth = 2
            ctx.beginPath()
            for (var j = 0; j < pts.length; j++) {
                var px = padL + ((Number(pts[j].v) - vMin) / (vMax - vMin)) * plotW
                var py = padT + plotH - ((Number(pts[j].rms) || 0) / rMax) * plotH
                if (j === 0) ctx.moveTo(px, py)
                else ctx.lineTo(px, py)
            }
            ctx.stroke()

            ctx.fillStyle = "#3D8BFF"
            for (var k = 0; k < pts.length; k++) {
                var dx = padL + ((Number(pts[k].v) - vMin) / (vMax - vMin)) * plotW
                var dy = padT + plotH - ((Number(pts[k].rms) || 0) / rMax) * plotH
                ctx.beginPath()
                ctx.arc(dx, dy, 2.2, 0, Math.PI * 2)
                ctx.fill()
            }
        }

        function paintTmc(ctx, w, h) {
            ctx.fillStyle = "#7A8088"
            ctx.font = "11px sans-serif"
            ctx.fillText("电机降噪", 8, 14)

            var names = ["A", "B", "C", "E"]
            var colors = ["#3D8BFF", "#A78BFA", "#D4A017", "#D94B4B"]
            var bw = (w - 40) / 4
            for (var i = 0; i < 4; i++) {
                var x0 = 12 + i * (bw + 4)
                var y0 = 28
                var bh = h - 48
                ctx.fillStyle = "#151A1F"
                ctx.fillRect(x0, y0, bw, bh)
                ctx.strokeStyle = colors[i]
                ctx.lineWidth = 1.5
                ctx.beginPath()
                for (var x = 0; x < bw; x++) {
                    var phase = root._t * 10 + i * 1.2 + x * 0.22
                    var amp = 0.35 + 0.2 * Math.sin(root._t * 2 + i)
                    if (i === 3) amp *= 0.55
                    var yy = y0 + bh * 0.5 + Math.sin(phase) * bh * 0.28 * amp
                    if (x === 0) ctx.moveTo(x0 + x, yy); else ctx.lineTo(x0 + x, yy)
                }
                ctx.stroke()
                ctx.fillStyle = colors[i]
                ctx.font = "12px sans-serif"
                ctx.fillText(names[i], x0 + bw * 0.5 - 4, h - 8)
            }
        }

        function paintSave(ctx, w, h) {
            ctx.fillStyle = "#7A8088"
            ctx.font = "11px sans-serif"
            ctx.fillText("保存结果", 8, 14)
            var cx = w * 0.5, cy = h * 0.48
            var r = 22 + 4 * root._pulse
            ctx.strokeStyle = "#1A1F24"
            ctx.lineWidth = 3
            ctx.beginPath()
            ctx.arc(cx, cy, r, 0, Math.PI * 2)
            ctx.stroke()
            ctx.strokeStyle = "#A78BFA"
            ctx.beginPath()
            ctx.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * Math.max(0.12, root.progress))
            ctx.stroke()
            ctx.strokeStyle = "#E8EAED"
            ctx.lineWidth = 2.5
            ctx.beginPath()
            ctx.moveTo(cx - 10, cy + 1)
            ctx.lineTo(cx - 2, cy + 9)
            ctx.lineTo(cx + 12, cy - 8)
            ctx.stroke()
            ctx.fillStyle = "#8A9199"
            ctx.font = "12px sans-serif"
            ctx.fillText("写入 printer.cfg", cx - 42, cy + 40)
        }
    }
}
