import QtQuick 2.15
import ".."

Item {
    id: bar
    height: 24
    width: parent.width

    Rectangle {
        anchors.bottom: parent.bottom
        width: parent.width
        height: 1
        color: Theme.lineSoft
    }

    Row {
        id: leftRow
        anchors.left: parent.left
        anchors.leftMargin: 12
        anchors.right: rightRow.left
        anchors.rightMargin: 8
        anchors.verticalCenter: parent.verticalCenter
        spacing: 8
        clip: true

        Text {
            anchors.verticalCenter: parent.verticalCenter
            text: AppState.machineName
            color: Theme.textPrimary
            font.pixelSize: 10
            font.letterSpacing: 0.8
            font.family: Theme.fontFamily
            font.weight: Theme.fontWeight
        }

        Text {
            id: heatText
            anchors.verticalCenter: parent.verticalCenter
            visible: text.length > 0
            width: Math.min(implicitWidth, Math.max(0, leftRow.width - 120))
            elide: Text.ElideRight
            text: AppState.heaterBandText()
            color: {
                if (text.indexOf("加热") === 0 || text.indexOf("Heating") === 0) return Theme.accent
                if (text.indexOf("冷却") === 0 || text.indexOf("Cooling") === 0) return Theme.warn
                if (text.indexOf("恒温") === 0 || text.indexOf("Hold") === 0) return Theme.ok
                return Theme.textSecondary
            }
            font.pixelSize: Theme.fontSmall
        }

        Timer {
            interval: 500
            running: true
            repeat: true
            onTriggered: heatText.text = AppState.heaterBandText()
        }
    }

    Row {
        id: rightRow
        anchors.right: parent.right
        anchors.rightMargin: 8
        anchors.verticalCenter: parent.verticalCenter
        spacing: 6

        // Message bubble — square, severity-colored when unread/items exist
        Item {
            width: 20
            height: 20
            anchors.verticalCenter: parent.verticalCenter

            Rectangle {
                anchors.fill: parent
                radius: 4
                color: msgTouch.pressed ? Theme.bgTilePressed : Theme.bgTile
                border.width: 1
                border.color: AppState.hmsItems.length ? AppState.hmsBadgeColor : Theme.line
            }
            // "i" mark — avoids missing-glyph tofu and fragile bubble paths
            Text {
                anchors.centerIn: parent
                text: "i"
                color: AppState.hmsItems.length ? AppState.hmsBadgeColor : Theme.textMute
                font.family: Theme.fontFamily
                font.pixelSize: 12
                font.weight: Theme.fontWeight
            }
            Rectangle {
                visible: AppState.hmsItems.length > 0
                anchors.right: parent.right
                anchors.top: parent.top
                anchors.rightMargin: -1
                anchors.topMargin: -1
                width: 6
                height: 6
                radius: 3
                color: AppState.hmsBadgeColor
            }
            TouchArea {
                id: msgTouch
                anchors.fill: parent
                anchors.margins: -4
                onClicked: AppState.go("alerts")
            }
        }

        Rectangle {
            width: 5
            height: 5
            radius: 2.5
            anchors.verticalCenter: parent.verticalCenter
            color: AppState.connected ? Theme.ok : Theme.danger
            opacity: 0.9
        }
        Text {
            anchors.verticalCenter: parent.verticalCenter
            text: AppState.clockText
            color: Theme.textSecondary
            font.pixelSize: Theme.fontSmall
            font.letterSpacing: 0.5
            font.family: Theme.fontFamily
            font.weight: Theme.fontWeight
        }
    }

    Timer {
        interval: 1000
        running: true
        repeat: true
        onTriggered: AppState.clockText = Qt.formatTime(new Date(), "hh:mm")
    }
}
