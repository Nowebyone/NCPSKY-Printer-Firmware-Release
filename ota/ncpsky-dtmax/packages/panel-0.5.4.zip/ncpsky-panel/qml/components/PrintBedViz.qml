import QtQuick 2.15
import ".."

// Lightweight print-follow viz: bed disk + growing part + live nozzle trail
Item {
    id: root
    property real toolX: 0
    property real toolY: 0
    property real toolZ: 0
    property real bedRadius: 145
    property real printProgress: 0     // 0..1
    property int layerNow: 0
    property int layerTotal: 0
    property bool paused: false
    property var trail: []             // [{x,y}] newest last
    property real objectHeight: 0      // mm from metadata; 0 = estimate

    property real _t: 0

    Timer {
        interval: 50
        running: root.visible
        repeat: true
        onTriggered: {
            root._t += 0.05
            canvas.requestPaint()
        }
    }

    onToolXChanged: canvas.requestPaint()
    onToolYChanged: canvas.requestPaint()
    onPrintProgressChanged: canvas.requestPaint()
    onTrailChanged: canvas.requestPaint()

    Canvas {
        id: canvas
        anchors.fill: parent
        antialiasing: true

        onPaint: {
            var ctx = getContext("2d")
            var w = width, h = height
            if (w < 4 || h < 4) return
            ctx.clearRect(0, 0, w, h)
            ctx.fillStyle = "#0C1014"
            ctx.fillRect(0, 0, w, h)

            var pad = 8
            var cx = w * 0.50
            var cy = h * 0.58
            var rBed = Math.min(w, h) * 0.36
            var yScale = 0.55
            var zRef = Math.max(40, root.objectHeight > 0 ? root.objectHeight : 80)

            function map(x, y, z) {
                var sx = cx + (x / Math.max(1, root.bedRadius)) * rBed
                var sy = cy - (y / Math.max(1, root.bedRadius)) * rBed * yScale
                        - (z / zRef) * rBed * 0.70
                return { x: sx, y: sy }
            }

            function ellipse(mx, my, rx, fill, stroke, lw) {
                ctx.save()
                ctx.translate(mx, my)
                ctx.scale(1, yScale)
                ctx.beginPath()
                ctx.arc(0, 0, rx, 0, Math.PI * 2)
                if (fill) {
                    ctx.fillStyle = fill
                    ctx.fill()
                }
                if (stroke) {
                    ctx.strokeStyle = stroke
                    ctx.lineWidth = lw || 1
                    ctx.stroke()
                }
                ctx.restore()
            }

            // Bed
            ellipse(cx, cy, rBed, "#151A1F", "#2A3138", 1.5)
            ellipse(cx, cy, rBed * 0.92, null, "#1E242A", 1)

            var p = Math.max(0, Math.min(1, root.printProgress))
            var grow = Math.max(0.05, p)
            var partR = rBed * (0.20 + 0.40 * Math.min(1, grow * 1.1))
            var partH = zRef * grow
            var layers = Math.max(2, Math.min(12, root.layerTotal > 0
                        ? Math.ceil(grow * Math.min(12, root.layerTotal))
                        : Math.ceil(grow * 10)))

            for (var i = 0; i < layers; i++) {
                var t = (i + 1) / layers
                var z = partH * t
                var rr = partR * (0.90 + 0.10 * Math.sin(t * Math.PI))
                var m = map(0, 0, z)
                var alpha = 0.10 + 0.50 * t
                var fill = "rgba(167,139,250," + alpha.toFixed(3) + ")"
                var stroke = (i === layers - 1) ? "rgba(167,139,250,0.7)" : null
                ellipse(m.x, m.y, rr, fill, stroke, 1.2)
            }

            // Trail on bed plane
            var trail = root.trail || []
            if (trail.length > 1) {
                for (var k = 1; k < trail.length; k++) {
                    var a0 = trail[k - 1]
                    var a1 = trail[k]
                    var p0 = map(Number(a0.x) || 0, Number(a0.y) || 0, 0.4)
                    var p1 = map(Number(a1.x) || 0, Number(a1.y) || 0, 0.4)
                    var a = 0.18 + 0.65 * (k / (trail.length - 1))
                    ctx.beginPath()
                    ctx.moveTo(p0.x, p0.y)
                    ctx.lineTo(p1.x, p1.y)
                    ctx.strokeStyle = "rgba(61,139,255," + a.toFixed(3) + ")"
                    ctx.lineWidth = 1.4
                    ctx.stroke()
                }
            }

            // Nozzle
            var nz = map(root.toolX, root.toolY, Math.max(0, root.toolZ))
            var pulse = 0.75 + 0.25 * Math.sin(root._t * 6)
            ctx.beginPath()
            ctx.arc(nz.x, nz.y, 4.2 * pulse, 0, Math.PI * 2)
            ctx.fillStyle = root.paused ? "#D4A017" : "#A78BFA"
            ctx.fill()
            ctx.beginPath()
            ctx.moveTo(nz.x, nz.y)
            ctx.lineTo(nz.x, nz.y + 9)
            ctx.strokeStyle = root.paused ? "#D4A017" : "#A78BFA"
            ctx.lineWidth = 1.5
            ctx.stroke()

            // Caption
            ctx.fillStyle = "#7A8088"
            ctx.font = "10px sans-serif"
            var cap = root.paused ? "已暂停" : "跟打中"
            if (root.layerNow > 0) {
                cap += "  L" + root.layerNow
                if (root.layerTotal > 0)
                    cap += "/" + root.layerTotal
            }
            ctx.fillText(cap, pad, 12)
            ctx.fillStyle = "#555B63"
            ctx.fillText(Math.round(p * 100) + "%", w - 34, 12)
        }
    }
}
