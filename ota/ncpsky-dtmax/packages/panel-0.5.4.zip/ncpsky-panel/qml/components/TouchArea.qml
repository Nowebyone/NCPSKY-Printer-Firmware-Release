import QtQuick 2.15

// Touch-first hit target: blank cursor, steal-proof, no hover ghosting
MouseArea {
    id: area
    property bool pressedVisual: pressed
    cursorShape: Qt.BlankCursor
    hoverEnabled: false
    preventStealing: true
    acceptedButtons: Qt.LeftButton
    // Slightly enlarge effective hit box without shifting visuals
    anchors.margins: 0
}
