import QtQuick 2.15
import ".."

Item {
    id: root
    anchors.fill: parent
    z: 300
    visible: queue.length > 0 || current.open

    property var queue: []
    property var current: ({ open: false, severity: "info", title: "", message: "", sticky: false })

    function enqueue(item) {
        if (!item) return
        var sev = item.severity || item.level || "info"
        if (sev === "warn") sev = "warning"
        var sticky = (sev === "error" || sev === "critical")
        var next = {
            open: true,
            severity: sev,
            title: item.title || item.source || "",
            message: item.message || item.detail || "",
            sticky: sticky
        }
        if (current.open && current.sticky) {
            var q = queue.slice()
            q.push(next)
            if (q.length > 8) q = q.slice(q.length - 8)
            queue = q
            return
        }
        show(next)
    }

    function show(item) {
        hideTimer.stop()
        current = item
        if (!item.sticky)
            hideTimer.interval = (item.severity === "warning") ? 4000 : 2500
        if (!item.sticky)
            hideTimer.start()
    }

    function dismiss() {
        hideTimer.stop()
        if (queue.length) {
            var q = queue.slice()
            var next = q.shift()
            queue = q
            show(next)
        } else {
            current = ({ open: false, severity: "info", title: "", message: "", sticky: false })
        }
    }

    function accent() {
        var s = current.severity
        if (s === "error" || s === "critical") return Theme.danger
        if (s === "warning") return Theme.warn
        return Theme.ok
    }

    Timer {
        id: hideTimer
        repeat: false
        onTriggered: root.dismiss()
    }

    // Soft toast — bottom-right, compact unless sticky/critical
    Rectangle {
        id: card
        visible: current.open
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.rightMargin: 8
        anchors.bottomMargin: 8
        width: current.sticky ? Math.min(parent.width - 20, 220) : Math.min(parent.width - 28, 168)
        height: col.implicitHeight + (current.sticky ? 14 : 10)
        radius: Theme.radius
        color: "#F0101316"
        border.width: 1
        border.color: accent()
        opacity: current.open ? 0.96 : 0
        Behavior on opacity { NumberAnimation { duration: 120 } }

        Rectangle {
            anchors.left: parent.left
            anchors.top: parent.top
            anchors.bottom: parent.bottom
            width: 2
            radius: 1
            color: accent()
        }

        Column {
            id: col
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            anchors.margins: current.sticky ? 8 : 6
            anchors.leftMargin: 8
            spacing: 2
            Text {
                width: parent.width
                visible: !!current.title
                text: current.title
                color: accent()
                font.pixelSize: current.sticky ? Theme.fontSmall : 10
                font.family: Theme.fontFamily
                font.weight: Theme.fontWeight
                elide: Text.ElideRight
            }
            Text {
                width: parent.width
                text: current.message
                color: Theme.textPrimary
                font.pixelSize: current.sticky ? Theme.fontBody : Theme.fontSmall
                wrapMode: Text.Wrap
                maximumLineCount: current.sticky ? 4 : 2
                elide: Text.ElideRight
            }
            Text {
                visible: current.sticky
                text: "点按关闭"
                color: Theme.textMute
                font.pixelSize: 10
            }
        }

        TouchArea {
            anchors.fill: parent
            onClicked: root.dismiss()
        }
    }
}
