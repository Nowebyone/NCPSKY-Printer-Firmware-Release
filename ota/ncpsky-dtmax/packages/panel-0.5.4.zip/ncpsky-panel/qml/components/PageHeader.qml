import QtQuick 2.15
import ".."

Item {
    id: hdr
    property string title: ""
    property string subtitle: ""
    height: subtitle.length ? 36 : 24
    width: parent ? parent.width : 200

    Column {
        anchors.left: parent.left
        anchors.verticalCenter: parent.verticalCenter
        spacing: 2
        Text {
            text: hdr.title
            color: Theme.textPrimary
            font.pixelSize: Theme.fontTitle
            font.family: Theme.fontFamily
            font.weight: Theme.fontWeight
            font.letterSpacing: 0.4
        }
        Text {
            visible: hdr.subtitle.length > 0
            text: hdr.subtitle
            color: Theme.textMute
            font.pixelSize: Theme.fontSmall
        }
    }
}
