#!/bin/bash
# Run ON device as root/pi. Deploys panel + swaps startboot with rollback.
set -e
PANEL_DST=/home/pi/ncpsky-panel
SRC="${1:-/tmp/ncpsky-panel}"
OUT=/home/pi/qt/out_linux
STARTBOOT="${OUT}/startboot.sh"
BACKUP_DIR="${OUT}/startboot_bak_ncpsky"

echo "[ncpsky] install from ${SRC} -> ${PANEL_DST}"
mkdir -p "${PANEL_DST}"
rm -rf "${PANEL_DST}/qml" "${PANEL_DST}/scripts"
cp -a "${SRC}/qml" "${PANEL_DST}/"
cp -a "${SRC}/scripts" "${PANEL_DST}/"
if [ -f "${SRC}/DESIGN.md" ]; then cp -a "${SRC}/DESIGN.md" "${PANEL_DST}/"; fi
chmod +x "${PANEL_DST}/scripts/"*.sh

NAME_FILE=/home/pi/ncpsky-panel/machine_name.txt
if [ -f /home/pi/printer_data/config/machine_name.txt ]; then
  cp /home/pi/printer_data/config/machine_name.txt "${NAME_FILE}" || true
elif [ -f /home/pi/qt/out_linux/machine_name.txt ]; then
  cp /home/pi/qt/out_linux/machine_name.txt "${NAME_FILE}" || true
else
  echo "NCPSKY ▲T1 Max" > "${NAME_FILE}"
fi

# Ensure Qt libs/plugins readable (FLSun ships lib dir as 700)
chmod a+rx /home/pi/qt /home/pi/qt/arm_qt_environment 2>/dev/null || true
chmod -R a+rX /home/pi/qt/arm_qt_environment/lib /home/pi/qt/arm_qt_environment/plugins \
  /home/pi/qt/arm_qt_environment/qml /home/pi/qt/arm_qt_environment/bin \
  /home/pi/qt/arm_tslib /home/pi/qt/fonts 2>/dev/null || true
chmod 755 /home/pi/qt/arm_qt_environment/lib 2>/dev/null || true

mkdir -p "${BACKUP_DIR}"
if [ -f "${STARTBOOT}" ] && [ ! -f "${BACKUP_DIR}/startboot.sh" ]; then
  cp -a "${STARTBOOT}" "${BACKUP_DIR}/startboot.sh"
  echo "[ncpsky] backed up startboot -> ${BACKUP_DIR}/startboot.sh"
fi

cat > "${STARTBOOT}" << 'EOF'
#!/bin/bash
# NCPSKY panel boot (rollback: restore from startboot_bak_ncpsky/startboot.sh)
# Always `bash run_panel.sh` — OTA zip must not brick splash if +x is lost.
export HOME=/home/pi
cd /home/pi/qt/out_linux || true
pkill -x TUI 2>/dev/null || true
exec bash /home/pi/ncpsky-panel/scripts/run_panel.sh
EOF
chmod +x "${STARTBOOT}"

cat > /home/pi/ncpsky-panel/scripts/rollback_tui.sh << 'EOF'
#!/bin/bash
set -e
OUT=/home/pi/qt/out_linux
BAK=${OUT}/startboot_bak_ncpsky/startboot.sh
MONBAK=/etc/monitor.bak_ncpsky
if [ ! -f "$BAK" ]; then
  echo "No backup at $BAK" >&2
  exit 1
fi
killall -9 qmlscene 2>/dev/null || true
cp -a "$BAK" "${OUT}/startboot.sh"
chmod +x "${OUT}/startboot.sh"
if [ -f "$MONBAK" ]; then
  cp -a "$MONBAK" /etc/monitor
  systemctl restart monitor.service 2>/dev/null || true
fi
echo "Restored startboot to TUI. Reboot or run startboot.sh"
EOF
chmod +x /home/pi/ncpsky-panel/scripts/rollback_tui.sh

echo "[ncpsky] installed. Start with: ${STARTBOOT}"
echo "[ncpsky] rollback: /home/pi/ncpsky-panel/scripts/rollback_tui.sh"
