#!/usr/bin/env python3
"""Build STM32F103 Klipper MCU firmware on Windows (no T1 / WSL required).

Requires on PATH or discovered locally:
  - arm-none-eabi-gcc (STM32CubeCLT or Arm GNU Toolchain)
  - mingw32-make (MinGW)
  - Git Bash (sh / ln / strings helpers)
  - Python 3

Source tree default: ota/dist/_mcu_build/klipper
  Seed once via extract / pull, or --src. Tool auto-fills vendored
  kconfiglib + klippy/msgproto and applies the Windows CRLF fix.

Example:
  python build_mcu_bin.py --version mcu-20261129 --tag NCPSKY-MCU-2026.11.24.8
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
OTA_ROOT = os.path.abspath(os.path.join(HERE, ".."))
PANEL_ROOT = os.path.abspath(os.path.join(OTA_ROOT, ".."))
DIST = os.path.join(OTA_ROOT, "dist")
DEFAULT_SRC = os.path.join(DIST, "_mcu_build", "klipper")
VENDOR = os.path.join(OTA_ROOT, "vendor")
PRODUCT_DEFCONFIG = os.path.abspath(
    os.path.join(PANEL_ROOT, "..", "products", "ncpsky-dtmax", "mcu", "defconfig")
)

GIT_BASH_CANDIDATES = [
    r"C:\Program Files\Git\bin\bash.exe",
    r"C:\Program Files (x86)\Git\bin\bash.exe",
]

GCC_DIR_CANDIDATES = [
    # STM32CubeCLT first: its LTO works with MinGW make -j on this workstation.
    r"C:\ST\STM32CubeCLT_1.18.0\GNU-tools-for-STM32\bin",
    r"F:\Software\DPJ\STM32\gcc-arm-none-eabi-10.3-2021.10\bin",
    r"C:\Program Files (x86)\Arm GNU Toolchain arm-none-eabi",
]

MAKE_CANDIDATES = [
    r"F:\Software\DPJ\STM32\MinGW\bin\mingw32-make.exe",
    r"C:\MinGW\bin\mingw32-make.exe",
    r"C:\msys64\usr\bin\make.exe",
]

READELF_DIR_CANDIDATES = [
    r"F:\Software\DPJ\STM32\MinGW\bin",
    r"C:\MinGW\bin",
]


def die(msg, code=1):
    sys.stderr.write("ERROR: %s\n" % msg)
    raise SystemExit(code)


def which_on_path(name):
    return shutil.which(name)


def find_file(candidates):
    for p in candidates:
        if p and os.path.isfile(p):
            return p
    return None


def find_gcc_prefix():
    """Return (CROSS_PREFIX, gcc_dir). Prefer known Arm GNU installs over PATH."""
    for d in GCC_DIR_CANDIDATES:
        if not d:
            continue
        exe = os.path.join(d, "arm-none-eabi-gcc.exe")
        if os.path.isfile(exe):
            return "arm-none-eabi-", d
        if os.path.isdir(d):
            for root, _dirs, files in os.walk(d):
                if "arm-none-eabi-gcc.exe" in files:
                    return "arm-none-eabi-", root
    gcc = which_on_path("arm-none-eabi-gcc") or which_on_path("arm-none-eabi-gcc.exe")
    if gcc:
        return "arm-none-eabi-", os.path.dirname(os.path.abspath(gcc))
    die(
        "arm-none-eabi-gcc not found. Install Arm GNU Toolchain or STM32CubeCLT."
    )


def find_make():
    m = which_on_path("mingw32-make") or which_on_path("make")
    if m:
        return os.path.abspath(m)
    m = find_file(MAKE_CANDIDATES)
    if m:
        return m
    die("mingw32-make / make not found (expected MinGW).")


def find_bash():
    b = which_on_path("bash")
    # Prefer real Git Bash over WSL stub
    for p in GIT_BASH_CANDIDATES:
        if os.path.isfile(p):
            return p
    if b and "WindowsApps" not in b and "System32" not in b.replace("/", "\\"):
        return b
    die("Git Bash not found (C:\\Program Files\\Git\\bin\\bash.exe).")


def find_python():
    # Prefer the interpreter running this script
    return sys.executable.replace("\\", "/")


def find_readelf_dir():
    for d in READELF_DIR_CANDIDATES:
        if os.path.isfile(os.path.join(d, "readelf.exe")) or os.path.isfile(
            os.path.join(d, "readelf")
        ):
            return d
    # arm-none-eabi-readelf is enough if we alias; check-gcc.sh calls `readelf`
    return None


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def ensure_vendor_into_src(src):
    """Copy vendored kconfiglib + msgproto into the MCU source tree."""
    kcfg_dst = os.path.join(src, "lib", "kconfiglib")
    kcfg_src = os.path.join(VENDOR, "kconfiglib")
    if not os.path.isfile(os.path.join(kcfg_dst, "kconfiglib.py")):
        if not os.path.isfile(os.path.join(kcfg_src, "kconfiglib.py")):
            die("missing vendor/kconfiglib — expected at %s" % kcfg_src)
        if os.path.isdir(kcfg_dst):
            shutil.rmtree(kcfg_dst)
        shutil.copytree(kcfg_src, kcfg_dst)
        print("seeded lib/kconfiglib from vendor")

    klippy_dst = os.path.join(src, "klippy")
    need = not os.path.isfile(os.path.join(klippy_dst, "msgproto.py"))
    if need:
        os.makedirs(klippy_dst, exist_ok=True)
        for name in ("msgproto.py", "util.py", "__init__.py"):
            s = os.path.join(VENDOR, "klippy", name)
            if not os.path.isfile(s):
                die("missing vendor/klippy/%s" % name)
            shutil.copy2(s, os.path.join(klippy_dst, name))
        print("seeded klippy/msgproto from vendor")


def patch_buildcommands_crlf(src):
    """Windows tool --version emits \\r; stock split('\\n') breaks generated C."""
    path = os.path.join(src, "scripts", "buildcommands.py")
    if not os.path.isfile(path):
        die("missing scripts/buildcommands.py in %s" % src)
    text = open(path, "r", encoding="utf-8", errors="replace").read()
    old = 'check_output("%s --version" % (tool,)).split(\'\\n\')[0]'
    new = (
        'check_output("%s --version" % (tool,)).splitlines()[0].strip()'
    )
    if new in text:
        return
    if old not in text:
        # already patched with comment variant, or upstream changed
        if "splitlines()[0]" in text:
            return
        die("cannot patch buildcommands.py tool_versions() — unexpected source")
    text = text.replace(old, new, 1)
    # Keep LF for make/sh friendliness
    open(path, "w", encoding="utf-8", newline="\n").write(text)
    print("patched scripts/buildcommands.py for Windows CRLF versions")


def ensure_config(src, defconfig):
    cfg = os.path.join(src, ".config")
    if os.path.isfile(cfg):
        return
    if defconfig and os.path.isfile(defconfig):
        shutil.copy2(defconfig, cfg)
        print("seeded .config from", defconfig)
        return
    die("no .config in source tree and no --defconfig given")


def inject_build_tag(src, tag):
    """Embed tag via DECL_CONSTANT_STR so LTO cannot strip it from identify data."""
    path = os.path.join(src, "src", "basecmd.c")
    text = open(path, "r", encoding="utf-8", errors="replace").read()
    # Drop previous NCPSKY tag artifacts (const char placed above includes, or DECL_)
    text = re.sub(
        r"(?m)^/\* NCPSKY_BUILD_TAG \*/\n(?:const char ncpsky_build_tag\[][^\n]*\n)?\n?",
        "",
        text,
    )
    text = re.sub(
        r'(?m)^/\* NCPSKY_BUILD_TAG \*/\nDECL_CONSTANT_STR\("NCPSKY_MCU_TAG",\s*"[^"]*"\);\n?',
        "",
        text,
    )
    text = re.sub(
        r'(?m)^DECL_CONSTANT_STR\("NCPSKY_MCU_TAG",\s*"[^"]*"\);\n?',
        "",
        text,
    )
    needle = '#include "command.h" // DECL_COMMAND'
    alt = '#include "command.h"'
    block = (
        '/* NCPSKY_BUILD_TAG */\n'
        'DECL_CONSTANT_STR("NCPSKY_MCU_TAG", "%s");\n'
    ) % tag
    if needle in text:
        text = text.replace(needle, needle + "\n" + block, 1)
    elif alt in text:
        text = text.replace(alt, alt + " // DECL_COMMAND\n" + block, 1)
    else:
        die("basecmd.c missing #include \"command.h\"")

    open(path, "w", encoding="utf-8", newline="\n").write(text)
    print("tagged", tag)


def to_bash_path(win_path):
    p = os.path.abspath(win_path).replace("\\", "/")
    if len(p) >= 2 and p[1] == ":":
        return "/%s%s" % (p[0].lower(), p[2:])
    return p


def run_make(src, bash, make_exe, gcc_dir, readelf_dir, jobs, cross_prefix):
    py = find_python()
    src_b = to_bash_path(src)
    make_b = to_bash_path(make_exe)
    gcc_b = to_bash_path(gcc_dir)
    extra_path = [gcc_b]
    if readelf_dir:
        extra_path.append(to_bash_path(readelf_dir))
    path_prefix = ":".join(extra_path)

    script = r"""
set -euo pipefail
TOOLBIN=$(mktemp -d)
ln -sf "{make}" "$TOOLBIN/make"
export PATH="{path_prefix}:$TOOLBIN:$PATH"
cd "{src}"
echo "make=$(command -v make)"
echo "gcc=$(command -v arm-none-eabi-gcc)"
echo "python={py}"
arm-none-eabi-gcc --version | head -1
make olddefconfig PYTHON="{py}" CROSS_PREFIX="{cross}"
make clean PYTHON="{py}" CROSS_PREFIX="{cross}"
# Parallel build; if LTO link fails on MinGW jobserver, retry link with MAKEFLAGS cleared.
set +e
make -j{jobs} PYTHON="{py}" CROSS_PREFIX="{cross}"
rc=$?
set -e
if [ "$rc" -ne 0 ] || [ ! -f out/klipper.bin ]; then
  echo "retry link with MAKEFLAGS cleared"
  MAKEFLAGS= make -j1 PYTHON="{py}" CROSS_PREFIX="{cross}"
fi
test -f out/klipper.bin
ls -la out/klipper.bin
""".format(
        make=make_b,
        path_prefix=path_prefix,
        src=src_b,
        py=py,
        cross=cross_prefix,
        jobs=int(jobs),
    )

    with tempfile.NamedTemporaryFile(
        mode="w", encoding="utf-8", newline="\n", suffix=".sh", delete=False
    ) as tf:
        tf.write(script)
        sh_path = tf.name
    try:
        cmd = [bash, "-lc", "bash '%s'" % to_bash_path(sh_path)]
        print("RUN", " ".join(cmd))
        p = subprocess.run(cmd, check=False)
        if p.returncode != 0:
            die("MCU build failed (exit %s)" % p.returncode, p.returncode)
    finally:
        try:
            os.unlink(sh_path)
        except OSError:
            pass


def write_outputs(bin_src, version, tag, notes, chip):
    os.makedirs(DIST, exist_ok=True)
    name = version if version.endswith(".bin") else "%s.bin" % version
    if not name.startswith("mcu-") and not version.startswith("mcu-"):
        # keep caller version as-is; publish.py handles id
        pass
    dest = os.path.join(DIST, name if name.endswith(".bin") else name + ".bin")
    if not dest.endswith(".bin"):
        dest += ".bin"
    # normalize: version arg may be mcu-20261129
    base = version
    if base.endswith(".bin"):
        base = base[:-4]
    dest = os.path.join(DIST, "%s.bin" % base)

    shutil.copy2(bin_src, dest)
    digest = sha256_file(dest)
    size = os.path.getsize(dest)
    open(dest + ".sha256", "w", encoding="utf-8").write(
        "%s  %s\n" % (digest, os.path.basename(dest))
    )
    meta = {
        "kind": "mcu",
        "version": base,
        "file": os.path.basename(dest),
        "sha256": digest,
        "size": size,
        "chip": chip,
        "build_tag": tag,
        "built_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "host": "windows",
        "notes": notes,
    }
    meta_path = dest + ".json"
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)
        f.write("\n")
    print("OUT", dest)
    print("SHA", digest)
    print("SIZE", size)
    print("META", meta_path)
    return dest, digest, meta


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "--version",
        required=True,
        help="MCU package version, e.g. mcu-20261129",
    )
    ap.add_argument(
        "--tag",
        default=None,
        help="NCPSKY_MCU_TAG string embedded in firmware identify data",
    )
    ap.add_argument(
        "--src",
        default=DEFAULT_SRC,
        help="Klipper MCU source tree (default: ota/dist/_mcu_build/klipper)",
    )
    ap.add_argument(
        "--defconfig",
        default=PRODUCT_DEFCONFIG if os.path.isfile(PRODUCT_DEFCONFIG) else None,
        help="Seed .config if missing",
    )
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--chip", default="stm32f103xe")
    ap.add_argument("--notes", default="Windows cross-build")
    ap.add_argument(
        "--skip-tag",
        action="store_true",
        help="Do not modify basecmd.c",
    )
    args = ap.parse_args()

    src = os.path.abspath(args.src)
    if not os.path.isfile(os.path.join(src, "Makefile")):
        die(
            "MCU source not found at %s\n"
            "Seed once: python printers/flsun-t1-max/scratch/pull_klipper_mcu_src.py\n"
            "or extract_t1max_firmware.py, then re-run."
            % src
        )

    cross, gcc_dir = find_gcc_prefix()
    make_exe = find_make()
    bash = find_bash()
    readelf_dir = find_readelf_dir()
    print("gcc_dir", gcc_dir)
    print("make", make_exe)
    print("bash", bash)

    ensure_vendor_into_src(src)
    patch_buildcommands_crlf(src)
    ensure_config(src, args.defconfig)

    tag = args.tag
    if not tag:
        # mcu-20261129 -> NCPSKY-MCU-20261129
        ver = args.version[4:] if args.version.startswith("mcu-") else args.version
        tag = "NCPSKY-MCU-%s" % ver
    if not args.skip_tag:
        inject_build_tag(src, tag)

    run_make(src, bash, make_exe, gcc_dir, readelf_dir, args.jobs, cross)
    bin_src = os.path.join(src, "out", "klipper.bin")
    write_outputs(bin_src, args.version, tag, args.notes, args.chip)


if __name__ == "__main__":
    main()
