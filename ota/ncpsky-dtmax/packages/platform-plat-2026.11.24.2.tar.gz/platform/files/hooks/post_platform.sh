#!/bin/bash
# NCPSKY platform post-hook — ensure startboot uses bash run_panel.sh
set -e
BOOT=/home/pi/qt/out_linux/startboot.sh
mkdir -p /home/pi/qt/out_linux
cat > "$BOOT" <<'EOF'
#!/bin/bash
export HOME=/home/pi
cd /home/pi/qt/out_linux || true
pkill -x TUI 2>/dev/null || true
exec bash /home/pi/ncpsky-panel/scripts/run_panel.sh
EOF
chmod 755 "$BOOT"
