# NCPSKY platform package
Buckets under files/ map via META.json install_map.
