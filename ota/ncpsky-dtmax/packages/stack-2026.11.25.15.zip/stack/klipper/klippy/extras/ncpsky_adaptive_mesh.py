# NCPSKY adaptive bed mesh for delta beds.
# Reads the running gcode file (first-layer extrusion, else EXCLUDE_OBJECT
# polygons) and probes only that circle. No slicer start-gcode placeholders.
import json
import logging
import math
import os
import re

WORD_RE = re.compile(r'([A-Za-z])([+-]?(?:\d+(?:\.\d*)?|\.\d+))')
LAYER_CHANGE_RE = re.compile(r'^;\s*LAYER_CHANGE\s*$', re.I)
LAYER_NUM_RE = re.compile(r'^;\s*LAYER\s*:\s*(\d+)\s*$', re.I)
POLYGON_RE = re.compile(r'POLYGON\s*=\s*(\[\[.*?\]\])', re.I)


def plan_adaptive_mesh(xmin, xmax, ymin, ymax, margin, max_r, min_r,
                       min_n, max_n, spacing):
    """Circle that covers the rectangle, clamped to the probeable radius."""
    if max_n % 2 == 0:
        max_n -= 1
    if min_n < 3:
        min_n = 3
    if min_n % 2 == 0:
        min_n += 1
    if max_n < min_n:
        max_n = min_n
    if spacing < 5.0:
        spacing = 45.0
    if min_r < 5.0:
        min_r = 20.0
    if margin < 0.0:
        margin = 0.0
    ox = (xmin + xmax) / 2.0
    oy = (ymin + ymax) / 2.0
    half_x = (xmax - xmin) / 2.0 + margin
    half_y = (ymax - ymin) / 2.0 + margin
    radius = math.sqrt(half_x * half_x + half_y * half_y)
    if radius < min_r:
        radius = min_r
    origin_dist = math.hypot(ox, oy)
    if origin_dist + radius > max_r:
        radius = max(max_r - origin_dist, min_r)
    origin_dist = math.hypot(ox, oy)
    if origin_dist + radius > max_r and origin_dist > 0.01:
        allow = max(max_r - radius, 0.0)
        scale = allow / origin_dist
        ox *= scale
        oy *= scale
    radius = min(radius, max_r)
    radius = int(radius * 10) / 10.0
    if radius < min_r <= max_r:
        radius = int(min_r * 10) / 10.0
        origin_dist = math.hypot(ox, oy)
        if origin_dist + radius > max_r and origin_dist > 0.01:
            allow = max(max_r - radius, 0.0)
            scale = allow / origin_dist
            ox *= scale
            oy *= scale
    count = _probe_count(radius * 2.0, spacing, min_n, max_n, radius)
    limit2 = radius * radius + 0.25
    covered = True
    for px, py in ((xmin, ymin), (xmin, ymax), (xmax, ymin), (xmax, ymax)):
        dx = px - ox
        dy = py - oy
        if dx * dx + dy * dy > limit2:
            covered = False
            break
    return {
        'origin_x': ox,
        'origin_y': oy,
        'radius': radius,
        'probe_count': count,
        'covered': covered,
    }


def full_mesh(max_r, max_n):
    if max_n % 2 == 0:
        max_n -= 1
    if max_n < 3:
        max_n = 3
    return {
        'origin_x': 0.0,
        'origin_y': 0.0,
        'radius': int(max_r * 10) / 10.0,
        'probe_count': max_n,
        'covered': True,
    }


def _probe_count(diameter, spacing, min_n, max_n, radius):
    intervals = diameter / spacing
    nint = int(intervals)
    if intervals > nint:
        nint += 1
    raw = nint + 1
    if raw < min_n:
        raw = min_n
    if raw > max_n:
        raw = max_n
    if raw % 2 == 0:
        if raw + 1 <= max_n:
            raw += 1
        elif raw - 1 >= min_n:
            raw -= 1
    max_fit = int(radius * 2.0) + 1
    if max_fit % 2 == 0:
        max_fit -= 1
    if max_fit < 3:
        max_fit = 3
    if raw > max_fit:
        raw = max_fit
    if raw % 2 == 0:
        raw -= 1
    if raw < 3:
        raw = 3
    return raw


def scan_gcode(path, max_header=8 * 1024 * 1024, max_layer=16 * 1024 * 1024):
    """Return (xmin, ymin, xmax, ymax, source) or None.

    First-layer extruding moves win. The purge in the start gcode is ignored
    because it sits before the first layer marker. EXCLUDE_OBJECT polygons are
    the fallback when the file has no layer comments.
    """
    bounds = _Bounds()
    exclude = _Bounds()
    state = _Motion()
    in_layer = False
    seen_layer = False
    read_bytes = 0
    with open(path, 'r', encoding='utf-8', errors='replace') as handle:
        for raw in handle:
            read_bytes += len(raw)
            line = raw.split(';', 1)[0].strip()
            comment = raw.strip()
            if _layer_edge(comment, in_layer, seen_layer):
                if not seen_layer:
                    seen_layer = True
                    in_layer = True
                else:
                    break
                if line:
                    state.feed(line, None)
                continue
            if not seen_layer and read_bytes <= max_header:
                _note_exclude(comment, exclude)
            if in_layer and read_bytes > max_layer:
                break
            if not seen_layer and read_bytes > max_header:
                break
            if line:
                state.feed(line, bounds if in_layer else None)
    if bounds.ready:
        return (bounds.xmin, bounds.ymin, bounds.xmax, bounds.ymax, 'first_layer')
    if exclude.ready:
        return (exclude.xmin, exclude.ymin, exclude.xmax, exclude.ymax, 'exclude_object')
    return None


def _layer_edge(comment, in_layer, seen_layer):
    if LAYER_CHANGE_RE.match(comment):
        return True
    match = LAYER_NUM_RE.match(comment)
    if not match:
        return False
    num = int(match.group(1))
    if not seen_layer:
        return num == 0
    return num >= 1


def _note_exclude(comment, bounds):
    if 'EXCLUDE_OBJECT_DEFINE' not in comment.upper():
        return
    match = POLYGON_RE.search(comment)
    if not match:
        return
    try:
        points = json.loads(match.group(1))
    except (TypeError, ValueError):
        return
    for pt in points:
        if isinstance(pt, (list, tuple)) and len(pt) >= 2:
            bounds.add(float(pt[0]), float(pt[1]))


class _Bounds:
    def __init__(self):
        self.ready = False
        self.xmin = self.ymin = self.xmax = self.ymax = 0.0

    def add(self, x, y):
        if not self.ready:
            self.xmin = self.xmax = x
            self.ymin = self.ymax = y
            self.ready = True
            return
        self.xmin = min(self.xmin, x)
        self.xmax = max(self.xmax, x)
        self.ymin = min(self.ymin, y)
        self.ymax = max(self.ymax, y)

    def add_arc(self, x0, y0, x1, y1, i, j, clockwise):
        self.add(x0, y0)
        self.add(x1, y1)
        cx = x0 + i
        cy = y0 + j
        radius = math.hypot(i, j)
        if radius < 1e-6:
            return
        a0 = math.atan2(y0 - cy, x0 - cx)
        a1 = math.atan2(y1 - cy, x1 - cx)
        if clockwise:
            sweep = (a0 - a1) % (2.0 * math.pi)
        else:
            sweep = (a1 - a0) % (2.0 * math.pi)
        if sweep < 1e-9:
            sweep = 2.0 * math.pi
        for ang in (0.0, math.pi / 2.0, math.pi, 3.0 * math.pi / 2.0):
            if clockwise:
                delta = (a0 - ang) % (2.0 * math.pi)
            else:
                delta = (ang - a0) % (2.0 * math.pi)
            if delta <= sweep + 1e-6:
                self.add(cx + radius * math.cos(ang), cy + radius * math.sin(ang))


class _Motion:
    def __init__(self):
        self.x = self.y = self.z = self.e = 0.0
        self.abs_xyz = True
        self.abs_e = True

    def feed(self, line, bounds):
        parts = line.split()
        if not parts:
            return
        cmd = parts[0].upper()
        if cmd in ('G90',):
            self.abs_xyz = True
            self.abs_e = True
            return
        if cmd in ('G91',):
            self.abs_xyz = False
            self.abs_e = False
            return
        if cmd in ('M82',):
            self.abs_e = True
            return
        if cmd in ('M83',):
            self.abs_e = False
            return
        words = {}
        for match in WORD_RE.finditer(line):
            words[match.group(1).upper()] = float(match.group(2))
        if cmd == 'G92':
            if 'X' in words:
                self.x = words['X']
            if 'Y' in words:
                self.y = words['Y']
            if 'Z' in words:
                self.z = words['Z']
            if 'E' in words:
                self.e = words['E']
            return
        if cmd not in ('G0', 'G00', 'G1', 'G01', 'G2', 'G02', 'G3', 'G03'):
            return
        nx, ny = self.x, self.y
        if 'X' in words:
            nx = words['X'] if self.abs_xyz else self.x + words['X']
        if 'Y' in words:
            ny = words['Y'] if self.abs_xyz else self.y + words['Y']
        if 'Z' in words:
            self.z = words['Z'] if self.abs_xyz else self.z + words['Z']
        extruded = 0.0
        if 'E' in words:
            if self.abs_e:
                extruded = words['E'] - self.e
                self.e = words['E']
            else:
                extruded = words['E']
                self.e += words['E']
        moved = abs(nx - self.x) > 1e-6 or abs(ny - self.y) > 1e-6
        travel = cmd in ('G0', 'G00')
        if bounds is not None and moved and extruded > 1e-6 and not travel:
            dist = math.hypot(nx - self.x, ny - self.y)
            # A long, nearly dry move is the hop off the purge line, not the part.
            sparse = dist > 20.0 and extruded / dist < 0.01
            if cmd in ('G2', 'G02', 'G3', 'G03') and not sparse:
                i = words.get('I', 0.0)
                j = words.get('J', 0.0)
                bounds.add_arc(self.x, self.y, nx, ny, i, j, cmd in ('G2', 'G02'))
            elif sparse:
                bounds.add(nx, ny)
            else:
                bounds.add(self.x, self.y)
                bounds.add(nx, ny)
        self.x, self.y = nx, ny


class NcpskyAdaptiveMesh:
    def __init__(self, config):
        self.printer = config.get_printer()
        self.margin = config.getfloat('margin', 10.0)
        self.min_radius = config.getfloat('min_radius', 20.0, above=0.)
        self.min_probe = config.getint('min_probe', 3, minval=3)
        self.spacing = config.getfloat('target_spacing', 45.0, above=1.)
        self.max_radius = config.getfloat('max_radius', 0.0)
        self.max_probe = config.getint('max_probe', 0)
        self.enabled = config.getboolean('enabled', True)
        self._meshed_path = None
        self.gcode = self.printer.lookup_object('gcode')
        self.gcode.register_command(
            'ADAPTIVE_BED_MESH', self.cmd_ADAPTIVE_BED_MESH,
            desc=self.cmd_ADAPTIVE_BED_MESH_help)
        self.gcode.register_command(
            'SET_ADAPTIVE_BED_MESH', self.cmd_SET_ADAPTIVE_BED_MESH,
            desc=self.cmd_SET_ADAPTIVE_BED_MESH_help)
        self.printer.register_event_handler(
            'virtual_sdcard:reset_file', self._on_reset_file)

    def _on_reset_file(self):
        self._meshed_path = None

    def _bed_limits(self):
        eventtime = self.printer.get_reactor().monotonic()
        settings = self.printer.lookup_object('configfile').get_status(eventtime)
        mesh = settings.get('settings', {}).get('bed_mesh', {})
        cfg_r = float(mesh.get('mesh_radius') or 135.0)
        cfg_n = int(mesh.get('round_probe_count') or 7)
        max_r = cfg_r
        if self.max_radius > 1.0:
            max_r = min(self.max_radius, cfg_r)
        max_n = cfg_n
        if self.max_probe >= 3:
            max_n = min(self.max_probe, cfg_n)
        return max_r, max_n

    def _gcode_path(self):
        vsd = self.printer.lookup_object('virtual_sdcard', None)
        if vsd is None:
            return None
        path = vsd.file_path()
        if path and os.path.isfile(path):
            return path
        eventtime = self.printer.get_reactor().monotonic()
        filename = self.printer.lookup_object('print_stats').get_status(eventtime).get('filename') or ''
        dirname = getattr(vsd, 'sdcard_dirname', '') or ''
        if filename and dirname:
            cand = os.path.join(dirname, filename)
            if os.path.isfile(cand):
                return cand
        return None

    cmd_ADAPTIVE_BED_MESH_help = "Mesh only the area this gcode actually prints"

    def cmd_ADAPTIVE_BED_MESH(self, gcmd):
        if not self.enabled and 'X_MIN' not in gcmd.get_command_parameters():
            gcmd.respond_info("ADAPTIVE_BED_MESH: disabled, skip")
            return
        path = self._gcode_path()
        params = gcmd.get_command_parameters()
        explicit = all(k in params for k in ('X_MIN', 'X_MAX', 'Y_MIN', 'Y_MAX'))
        if path and path == self._meshed_path and not explicit:
            gcmd.respond_info("ADAPTIVE_BED_MESH: already meshed this file")
            return
        max_r, max_n = self._bed_limits()
        if 'MAX_RADIUS' in params:
            max_r = min(gcmd.get_float('MAX_RADIUS'), max_r)
        if 'MAX_PROBE' in params:
            max_n = min(gcmd.get_int('MAX_PROBE', minval=3), max_n)
        margin = gcmd.get_float('MARGIN', self.margin)
        spacing = gcmd.get_float('SPACING', self.spacing)
        min_r = gcmd.get_float('MIN_RADIUS', self.min_radius)
        min_n = gcmd.get_int('MIN_PROBE', self.min_probe, minval=3)
        source = 'none'
        planned = None
        if explicit:
            xmin = min(gcmd.get_float('X_MIN'), gcmd.get_float('X_MAX'))
            xmax = max(gcmd.get_float('X_MIN'), gcmd.get_float('X_MAX'))
            ymin = min(gcmd.get_float('Y_MIN'), gcmd.get_float('Y_MAX'))
            ymax = max(gcmd.get_float('Y_MIN'), gcmd.get_float('Y_MAX'))
            source = 'params'
            planned = plan_adaptive_mesh(
                xmin, xmax, ymin, ymax, margin, max_r, min_r, min_n, max_n, spacing)
        else:
            scanned = None
            if path:
                try:
                    scanned = scan_gcode(path)
                except Exception:
                    logging.exception("ncpsky adaptive mesh scan failed")
                    gcmd.respond_info("ADAPTIVE_BED_MESH: gcode scan failed, full mesh")
            if scanned:
                xmin, ymin, xmax, ymax, source = scanned
                planned = plan_adaptive_mesh(
                    xmin, xmax, ymin, ymax, margin, max_r, min_r, min_n, max_n, spacing)
                gcmd.respond_info(
                    "ADAPTIVE_BED_MESH[%s]: bounds (%.1f,%.1f)-(%.1f,%.1f) margin=%.1f "
                    "-> ORIGIN=%.2f,%.2f R=%.1f N=%d covered=%d"
                    % (source, xmin, ymin, xmax, ymax, margin,
                       planned['origin_x'], planned['origin_y'],
                       planned['radius'], planned['probe_count'],
                       1 if planned['covered'] else 0))
            else:
                planned = full_mesh(max_r, max_n)
                gcmd.respond_info(
                    "ADAPTIVE_BED_MESH: no print bounds, full mesh R=%.1f N=%d"
                    % (planned['radius'], planned['probe_count']))
        if explicit:
            gcmd.respond_info(
                "ADAPTIVE_BED_MESH[params]: ORIGIN=%.2f,%.2f R=%.1f N=%d covered=%d"
                % (planned['origin_x'], planned['origin_y'], planned['radius'],
                   planned['probe_count'], 1 if planned['covered'] else 0))
        self._run_mesh(gcmd, planned)
        if path:
            self._meshed_path = path

    def _run_mesh(self, gcmd, planned):
        toolhead = self.printer.lookup_object('toolhead')
        eventtime = self.printer.get_reactor().monotonic()
        status = toolhead.get_status(eventtime)
        if 'xyz' not in status.get('homed_axes', ''):
            self.gcode.run_script_from_command('G28')
            eventtime = self.printer.get_reactor().monotonic()
            status = toolhead.get_status(eventtime)
        sav_vel = status['max_velocity']
        sav_accel = status['max_accel']
        sav_mcr = self._cruise_ratio(status)
        try:
            self.gcode.run_script_from_command('_NCPSKY_QUIET_TRAVEL_LIMIT')
            # Quiet travel caps velocity near 120. Mesh XY uses bed_mesh speed.
            self.gcode.run_script_from_command(
                'SET_VELOCITY_LIMIT VELOCITY=500 ACCEL=8000 MINIMUM_CRUISE_RATIO=0.5')
            self.gcode.run_script_from_command(
                "BED_MESH_CALIBRATE PROFILE=adaptive MESH_ORIGIN=%.2f,%.2f "
                "MESH_RADIUS=%.1f ROUND_PROBE_COUNT=%d"
                % (planned['origin_x'], planned['origin_y'],
                   planned['radius'], planned['probe_count']))
            self.gcode.run_script_from_command('G1 X0 Y0 Z20 F3000')
        finally:
            self.gcode.run_script_from_command(
                "SET_VELOCITY_LIMIT VELOCITY=%s ACCEL=%s MINIMUM_CRUISE_RATIO=%s"
                % (sav_vel, sav_accel, sav_mcr))

    def _cruise_ratio(self, status):
        if 'minimum_cruise_ratio' in status:
            return float(status['minimum_cruise_ratio'])
        accel = float(status.get('max_accel') or 1.)
        legacy = status.get('max_accel_to_decel')
        if legacy is None or accel <= 0:
            return 0.5
        return max(0., min(0.99, 1. - (float(legacy) / accel)))

    cmd_SET_ADAPTIVE_BED_MESH_help = "Enable adaptive mesh and tune margin / spacing"

    def cmd_SET_ADAPTIVE_BED_MESH(self, gcmd):
        params = gcmd.get_command_parameters()
        if 'ENABLE' in params:
            self.enabled = bool(gcmd.get_int('ENABLE'))
        if 'MARGIN' in params:
            self.margin = gcmd.get_float('MARGIN')
        if 'SPACING' in params:
            self.spacing = gcmd.get_float('SPACING', above=1.)
        if 'MIN_RADIUS' in params:
            self.min_radius = gcmd.get_float('MIN_RADIUS', above=0.)
        if 'MAX_RADIUS' in params:
            self.max_radius = gcmd.get_float('MAX_RADIUS')
        if 'MAX_PROBE' in params:
            self.max_probe = gcmd.get_int('MAX_PROBE', minval=0)
        gcmd.respond_info(
            "ADAPTIVE_BED_MESH settings: enabled=%s margin=%s spacing=%s "
            "min_radius=%s max_radius=%s max_probe=%s"
            % (self.enabled, self.margin, self.spacing,
               self.min_radius, self.max_radius, self.max_probe))

    def get_status(self, eventtime):
        return {
            'enabled': self.enabled,
            'margin': self.margin,
            'spacing': self.spacing,
            'min_radius': self.min_radius,
        }


def load_config(config):
    return NcpskyAdaptiveMesh(config)
