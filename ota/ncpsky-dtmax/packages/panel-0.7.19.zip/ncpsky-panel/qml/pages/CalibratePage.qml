import QtQuick 2.15
import "../components"
import ".."

Item {
    id: page

    // Order: bed → motor noise → shaper. TMC/noise map first so resonance
    // matches the final chopper; then one SAVE_CONFIG at the end.
    property var steps: [
        {
            id: "bed",
            title: "床网调平",
            detail: "改善首层贴合与高度不均 · 约 15–20 分钟",
            on: true,
            runSteps: [
                { id: "preheat", title: "准备中", script: "NCPSKY_PROBE_PREHEAT" },
                { id: "tilt", title: "床面校正", script: "NCPSKY_CALIBRATE_TILT" },
                { id: "mesh", title: "床面测量", script: "NCPSKY_CALIBRATE_MESH" },
                { id: "cooldown", title: "收尾", script: "NCPSKY_PROBE_COOLDOWN" }
            ]
        },
        {
            id: "motor_noise",
            title: "电机降噪",
            detail: "降低运行噪音，让打印更安静 · 约 20–30 分钟",
            on: true,
            runSteps: [
                { id: "tmc", title: "电机降噪", script: "CALIBRATE_MOTOR_NOISE" },
                { id: "noisemap", title: "电机降噪", script: "NCPSKY_NOISE_MAP_CALIBRATE" }
            ]
        },
        {
            id: "shaper",
            title: "震动补偿",
            detail: "减轻鬼影、振纹，提升高速打印观感 · 约 8–12 分钟",
            script: "NCPSKY_SHAPER_CALIBRATE",
            on: true
        }
    ]

    property bool running: false
    property bool abort: false
    property int runIndex: 0
    property int runTotal: 0
    property string runTitle: ""
    property string runPhase: "idle"
    property string runError: ""
    property var queue: []
    property string vizMode: "home"
    property real stepProgress: 0
    property real stepElapsed: 0
    property real toolX: 0
    property real toolY: 0
    property real toolZ: 20
    property real shaperFreqX: 34
    property real shaperFreqY: 33
    property real sweepHz: 30
    // Match printer [resonance_tester] band (FLSun stock 30→50)
    property real shaperFreqMin: 30
    property real shaperFreqMax: 50
    property real shaperHzPerSec: 1
    property var shaperPsdX: []
    property var shaperPsdY: []
    property var shaperWave: []
    property string shaperPhase: ""
    property bool shaperAwait: false
    property bool shaperSeenBusy: false
    property string shaperCsvGot: ""
    property real shaperAxisElapsed: 0
    property bool noiseMapAwait: false
    property bool noiseMapSeenBusy: false
    property string noiseMapPhase: ""
    property string noiseMapDetail: ""
    property real _waveLastX: 0
    property real _waveLastT: 0
    property var probeTrail: []
    property real bedRadius: 145
    property real deltaRadius: 172
    property real armLength: 345
    property real towerAngleA: 210
    property real towerAngleB: 330
    property real towerAngleC: 90
    property real printerAccel: 40000
    property real printerVel: 1200
    property bool geoReady: false
    property real lastTrailX: 9999
    property real lastTrailY: 9999
    property int runToken: 0
    property bool confirmOpen: false
    property string statusDetail: ""
    property string motionPhase: ""
    // 校准 | 查看
    property string mainTab: "run"   // run | view
    property string viewKind: "shaper"  // shaper | mesh | tmc
    property string viewStatus: ""
    property var meshPoints: []
    property real meshZMin: 0
    property real meshZMax: 0
    property string meshProfile: ""
    property var meshParams: ({})
    property var tiltInfo: ({})
    property var tmcMotors: []
    property var noiseCurve: []
    property string shaperTypeX: ""
    property string shaperTypeY: ""

    function selectedCount() {
        var n = 0
        for (var i = 0; i < steps.length; i++)
            if (steps[i].on) n++
        return n
    }

    function cloneStep(s, onOverride) {
        var o = {
            id: s.id,
            title: s.title,
            detail: s.detail,
            on: (onOverride === undefined) ? s.on : onOverride
        }
        if (s.script) o.script = s.script
        if (s.runSteps) o.runSteps = s.runSteps
        return o
    }

    function toggleStep(idx) {
        if (running) return
        var copy = []
        for (var i = 0; i < steps.length; i++)
            copy.push(cloneStep(steps[i], (i === idx) ? !steps[i].on : steps[i].on))
        steps = copy
    }

    function selectAll(on) {
        if (running) return
        var copy = []
        for (var i = 0; i < steps.length; i++)
            copy.push(cloneStep(steps[i], on))
        steps = copy
    }

    function modeForStep(step) {
        if (!step) return "home"
        if (step.id === "tilt") return "tilt"
        if (step.id === "mesh") return "mesh"
        if (step.id === "preheat" || step.id === "cooldown") return "home"
        if (step.id === "shaper") return "shaper"
        if (step.id === "tmc") return "tmc"
        if (step.id === "noisemap") return "tmc"
        if (step.id === "save") return "save"
        if (step.id === "home") return "home"
        return "home"
    }

    function buildQueue() {
        var q = []
        q.push({ id: "home", title: "喷头归位", script: "G28", auto: true })
        for (var i = 0; i < steps.length; i++) {
            var s = steps[i]
            if (!s.on) continue
            if (s.runSteps && s.runSteps.length) {
                for (var j = 0; j < s.runSteps.length; j++)
                    q.push(s.runSteps[j])
            } else if (s.script) {
                q.push(s)
            }
        }
        if (q.length > 1) {
            q.push({ id: "save", title: "保存结果", script: "SAVE_CONFIG", auto: true })
        }
        return q
    }

    function confirmSummary() {
        var names = []
        for (var i = 0; i < steps.length; i++)
            if (steps[i].on) names.push(steps[i].title)
        return "将自动归位并执行：" + names.join("、") + "，最后保存配置。期间不可退出或切换页面，请勿触碰机身。"
    }

    function askStart() {
        if (mainTab !== "run") return
        if (running || AppState.printing || AppState.printPaused) return
        if (!selectedCount()) return
        if (!AppState.connected) {
            runPhase = "error"
            runError = "打印机未连接"
            return
        }
        confirmOpen = true
        AppState.pageLocked = true
        AppState.page = "calibrate"
    }

    function setMainTab(tab) {
        if (running || confirmOpen) return
        mainTab = tab
        if (tab === "view")
            refreshViewData()
    }

    function setViewKind(kind) {
        viewKind = kind
        if (kind === "shaper") {
            fetchShaperCsv("x")
            fetchShaperCsv("y")
        }
    }

    function refreshViewData() {
        viewStatus = "读取中…"
        AppState.helperGet("/calib/view", function(data, err) {
            if (err || !data || data.ok === false) {
                viewStatus = "读取失败"
                return
            }
            var sh = data.shaper || {}
            if (sh.freq_x) shaperFreqX = Number(sh.freq_x)
            if (sh.freq_y) shaperFreqY = Number(sh.freq_y)
            shaperTypeX = sh.type_x || ""
            shaperTypeY = sh.type_y || ""

            var mesh = data.mesh || {}
            meshPoints = mesh.points || []
            meshZMin = Number(mesh.z_min) || 0
            meshZMax = Number(mesh.z_max) || 0
            meshProfile = mesh.profile || ""
            meshParams = mesh.params || {}

            tiltInfo = data.tilt || {}
            tmcMotors = data.tmc || []
            var nm = data.noise_map || {}
            noiseCurve = nm.curve || []

            var bits = []
            if (sh.freq_x || sh.freq_y)
                bits.push("震动补偿已完成")
            if (mesh.rows)
                bits.push("床网调平已完成")
            if ((nm.curve || []).length)
                bits.push("电机降噪已完成")
            viewStatus = bits.length ? bits.join(" · ") : "暂无已保存数据"

            if (viewKind === "shaper") {
                fetchShaperCsv("x")
                fetchShaperCsv("y")
            }
        })
    }

    function cancelConfirm() {
        confirmOpen = false
        if (!running)
            AppState.pageLocked = false
    }

    function startRun() {
        if (running || AppState.printing || AppState.printPaused) return
        if (!selectedCount()) return
        if (!AppState.connected) {
            confirmOpen = false
            AppState.pageLocked = false
            runPhase = "error"
            runError = "打印机未连接"
            return
        }
        confirmOpen = false
        queue = buildQueue()
        abort = false
        running = true
        runPhase = "run"
        runError = ""
        runTotal = queue.length
        runIndex = 0
        probeTrail = []
        stepElapsed = 0
        statusDetail = "正在启动校准流程…"
        runToken = runToken + 1
        AppState.pageLocked = true
        AppState.calibrating = true
        AppState.page = "calibrate"
        advance(runToken)
    }

    function finishOk() {
        running = false
        liveTimer.stop()
        readyWaitTimer.stop()
        readyWaitTimer.cb = null
        AppState.calibrating = false
        AppState.pageLocked = false
        confirmOpen = false
        runPhase = "done"
        runTitle = "校准完成"
        statusDetail = "全部步骤已完成，结果已写入配置。"
        AppState.pushHms("info", "校准", "自动校准流程已完成")
    }

    function finishError(msg) {
        running = false
        liveTimer.stop()
        readyWaitTimer.stop()
        readyWaitTimer.cb = null
        noiseMapAwait = false
        shaperAwait = false
        AppState.calibrating = false
        AppState.pageLocked = false
        confirmOpen = false
        runPhase = "error"
        runError = msg || "步骤失败"
        runTitle = "校准中断"
        statusDetail = runError
        AppState.pushHms("warn", "校准", runError)
    }

    function refreshStatusDetail() {
        var step = (queue && runIndex < queue.length) ? queue[runIndex] : null
        var id = step ? step.id : ""
        var et = Math.round(AppState.extruderTemp)
        var bt = Math.round(AppState.bedTemp)
        var ett = Math.round(AppState.extruderTarget)
        var btt = Math.round(AppState.bedTarget)
        var bedStep = (id === "home" || id === "preheat" || id === "tilt" || id === "mesh")
        if (bedStep && motionPhase === "home") {
            statusDetail = "正在回零…"
            return
        }
        if (bedStep && motionPhase === "motor") {
            statusDetail = "正在检测电机状态…"
            return
        }
        var nozzleWait = ett > 0 && AppState.extruderTemp < AppState.extruderTarget - 2.0
        var bedWait = btt > 0 && AppState.bedTemp < AppState.bedTarget - 2.0
        if (bedStep && (motionPhase === "heat" || (id === "preheat" && (nozzleWait || bedWait)))) {
            if (nozzleWait && bedWait)
                statusDetail = "等待温度达标 · 喷嘴 " + et + "°/" + ett + "° · 热床 " + bt + "°/" + btt + "°"
            else if (nozzleWait)
                statusDetail = "等待喷嘴温度达标 · 当前 " + et + "° → 目标 " + ett + "°"
            else if (bedWait)
                statusDetail = "等待热床温度达标 · 当前 " + bt + "° → 目标 " + btt + "°"
            else
                statusDetail = "温度已达标 · 正在稳定热床…"
            return
        }
        if (bedStep && motionPhase === "level") {
            if (id === "tilt")
                statusDetail = "床网调平 · 正在校正打印面 · 请勿触碰"
            else if (id === "mesh")
                statusDetail = "床网调平 · 正在测量床面 · 请勿触碰"
            else
                statusDetail = "正在热床调平…"
            return
        }
        if (id === "home") {
            statusDetail = "喷头归位中 · 请稍候"
            return
        }
        if (id === "preheat") {
            statusDetail = "床网调平 · 准备就位 · 喷嘴" + et + "° / 热床" + bt + "°"
            return
        }
        if (id === "tilt") {
            statusDetail = "床网调平 · 正在校正打印面 · 请勿触碰"
            return
        }
        if (id === "mesh") {
            statusDetail = "床网调平 · 正在测量床面 · 请勿触碰"
            return
        }
        if (id === "cooldown") {
            statusDetail = "床网调平 · 收尾降温中"
            return
        }
        if (id === "shaper") {
            var ax = (shaperPhase === "y") ? "第二阶段" : ((shaperPhase === "done") ? "即将完成" : "第一阶段")
            statusDetail = "震动补偿 · " + ax + " · 机身会轻微震动，请勿触碰"
            return
        }
        if (id === "noisemap") {
            statusDetail = "电机降噪 · 正在测绘安静速度 · 请勿触碰"
            return
        }
        if (id === "tmc") {
            statusDetail = "电机降噪 · 正在套用静音斩波 · 请稍候"
            return
        }
        if (id === "save") {
            statusDetail = "正在保存结果 · 完成后即可使用"
            return
        }
        statusDetail = runTitle || "校准进行中…"
    }

    function advance(token) {
        if (token === undefined) token = runToken
        if (token !== runToken) return
        // Calibration is non-interruptible; abort flag ignored once started
        if (runIndex >= queue.length) {
            finishOk()
            return
        }
        var step = queue[runIndex]
        runTitle = step.title
        vizMode = modeForStep(step)
        stepProgress = 0
        stepElapsed = 0
        if (vizMode === "tilt" || vizMode === "mesh")
            probeTrail = []
        refreshStatusDetail()
        liveTimer.start()

        // Shaper is async (delayed_gcode): HTTP returns at once; poll busy then continue
        if (step.id === "shaper") {
            shaperAwait = true
            shaperSeenBusy = false
            shaperCsvGot = ""
            shaperPhase = "starting"
            shaperAxisElapsed = 0
            sweepHz = shaperFreqMin
            shaperPsdX = []
            shaperPsdY = []
            shaperWave = []
            AppState.gcodeWait(step.script, function(ok, errMsg) {
                if (token !== runToken) return
                if (!ok) {
                    shaperAwait = false
                    finishError((step.title || "步骤") + "失败" + (errMsg ? (" · " + errMsg) : ""))
                    return
                }
                // completion detected in pollLive / liveTimer
            })
            return
        }

        // Noise map: arm macro then POST fileserver /noise_map/run; poll job + gcode status
        if (step.id === "noisemap") {
            noiseMapAwait = true
            noiseMapSeenBusy = false
            noiseMapPhase = "starting"
            noiseMapDetail = "准备扫速…"
            AppState.gcodeWait(step.script, function(ok, errMsg) {
                if (token !== runToken) return
                if (!ok) {
                    noiseMapAwait = false
                    finishError("电机降噪失败" + (errMsg ? (" · " + errMsg) : ""))
                    return
                }
                startNoiseMapSweep(token)
            })
            return
        }

        AppState.gcodeWait(step.script, function(ok, errMsg) {
            if (token !== runToken) return
            if (!ok && step.id === "save")
                ok = true
            if (!ok) {
                finishError((step.title || "步骤") + "失败" + (errMsg ? (" · " + errMsg) : ""))
                return
            }
            runIndex = runIndex + 1
            advance(token)
        })
    }

    function finishShaperStep(token) {
        if (token !== runToken) return
        shaperAwait = false
        // Wait until Klipper is ready before motor-noise steps (guards mid-flow SAVE_CONFIG / reconnect).
        waitPrinterReady(token, 90, function(ok) {
            if (token !== runToken) return
            if (!ok) {
                finishError("震动补偿后打印机未就绪")
                return
            }
            runIndex = runIndex + 1
            advance(token)
        })
    }

    function waitPrinterReady(token, timeoutSec, cb) {
        readyWaitTimer.stop()
        readyWaitTimer.token = token
        readyWaitTimer.left = Math.max(5, Number(timeoutSec) || 60)
        readyWaitTimer.cb = cb
        readyWaitTimer.tick()
        readyWaitTimer.start()
    }

    function startNoiseMapSweep(token) {
        if (token !== runToken) return
        noiseMapDetail = "启动扫速…"
        AppState.helperPost("/noise_map/run", {}, function(data, err) {
            if (token !== runToken) return
            if (err || !data || data.ok === false) {
                noiseMapAwait = false
                finishError("电机降噪启动失败" + (err ? (" · " + err) : (data && data.error ? (" · " + data.error) : "")))
                return
            }
            noiseMapSeenBusy = true
            noiseMapPhase = (data.phase || "sweep")
            noiseMapDetail = data.message || "扫速中"
            // completion via pollLive
        })
    }

    function finishNoiseMapStep(token) {
        if (token !== runToken) return
        noiseMapAwait = false
        runIndex = runIndex + 1
        advance(token)
    }

    function pollNoiseMapJob(token) {
        if (token !== runToken || !noiseMapAwait) return
        AppState.helperGet("/noise_map/job", function(data, err) {
            if (token !== runToken || !noiseMapAwait) return
            if (err || !data) return
            if (data.phase) noiseMapPhase = "" + data.phase
            if (data.message) noiseMapDetail = "" + data.message
            if (data.progress !== undefined)
                stepProgress = Math.min(0.99, Math.max(stepProgress, Number(data.progress) || 0))
            var busy = Number(data.busy)
            if (busy === 1) noiseMapSeenBusy = true
            // Only treat explicit terminal phases as success — never "idle" after arming.
            if (data.phase === "done") {
                stepProgress = 1
                finishNoiseMapStep(token)
                return
            }
            if (data.phase === "seed_applied" && busy === 0 && stepElapsed > 8) {
                stepProgress = 1
                finishNoiseMapStep(token)
                return
            }
            if (data.phase === "error" || (data.error && ("" + data.error).length && busy === 0 && noiseMapSeenBusy)) {
                noiseMapAwait = false
                finishError("电机降噪失败 · " + (data.error || data.message || "unknown"))
            }
        })
    }

    function parseShaperCsv(text, axis) {
        if (!text) return
        var lines = ("" + text).split("\n")
        if (lines.length < 2) return
        var head = lines[0]
        var m = head.match(/mzv\(([0-9.]+)\)/i)
        if (m) {
            var f = Number(m[1])
            if (f > 1) {
                if (axis === "x") shaperFreqX = f
                else shaperFreqY = f
            }
        }
        var pts = []
        for (var i = 1; i < lines.length; i++) {
            var cols = lines[i].split(",")
            if (cols.length < 5) continue
            var freq = Number(cols[0])
            var psd = Number(cols[4]) // psd_xyz
            if (!(freq >= 0) || !(psd >= 0)) continue
            if (freq < 5 || freq > 80) continue
            pts.push({ f: freq, v: psd })
        }
        if (pts.length < 3) return
        var peak = 0
        for (var j = 0; j < pts.length; j++)
            if (pts[j].v > peak) peak = pts[j].v
        if (peak <= 0) peak = 1
        var norm = []
        for (var k = 0; k < pts.length; k++)
            norm.push({ f: pts[k].f, v: Math.min(1, pts[k].v / peak) })
        if (axis === "x") shaperPsdX = norm
        else shaperPsdY = norm
    }

    function fetchShaperCsv(axis) {
        var xhr = new XMLHttpRequest()
        xhr.onreadystatechange = function() {
            if (xhr.readyState !== XMLHttpRequest.DONE) return
            if (xhr.status >= 200 && xhr.status < 300)
                parseShaperCsv(xhr.responseText, axis)
        }
        xhr.open("GET", "http://127.0.0.1:7126/shaper/" + axis)
        xhr.send()
    }

    function pushTrail(x, y) {
        var dx = x - lastTrailX
        var dy = y - lastTrailY
        if (dx * dx + dy * dy < 36)
            return
        lastTrailX = x
        lastTrailY = y
        var trail = probeTrail.slice()
        trail.push({ x: x, y: y })
        if (trail.length > 64)
            trail = trail.slice(trail.length - 64)
        probeTrail = trail
    }

    function refreshPrinterGeo() {
        if (geoReady) return
        AppState.httpGet("/printer/objects/query?configfile", function(data, err) {
            if (err || !data) return
            var st = (data.result && data.result.status) ? data.result.status : {}
            var sett = (st.configfile && st.configfile.settings) ? st.configfile.settings : {}
            var pr = sett.printer || {}
            if (pr.delta_radius) deltaRadius = Number(pr.delta_radius) || deltaRadius
            if (pr.print_radius) bedRadius = Number(pr.print_radius) || bedRadius
            var sa = sett.stepper_a || {}, sb = sett.stepper_b || {}, sc = sett.stepper_c || {}
            if (sa.arm_length) armLength = Number(sa.arm_length) || armLength
            if (sa.angle !== undefined) towerAngleA = Number(sa.angle) || towerAngleA
            if (sb.angle !== undefined) towerAngleB = Number(sb.angle) || towerAngleB
            if (sc.angle !== undefined) towerAngleC = Number(sc.angle) || towerAngleC
            var rt = sett.resonance_tester || {}
            if (rt.min_freq !== undefined) shaperFreqMin = Number(rt.min_freq) || shaperFreqMin
            if (rt.max_freq !== undefined) shaperFreqMax = Number(rt.max_freq) || shaperFreqMax
            if (rt.hz_per_sec !== undefined) shaperHzPerSec = Number(rt.hz_per_sec) || shaperHzPerSec
            geoReady = true
        })
    }

    function pollLive() {
        refreshPrinterGeo()
        var q = "/printer/objects/query?toolhead&bed_mesh&gcode_move&motion_report"
                + "&extruder&heater_bed"
                + "&gcode_macro%20NCPSKY_SHAPER_STATUS"
                + "&gcode_macro%20NCPSKY_MOTION_STATUS"
                + "&gcode_macro%20NCPSKY_NOISE_MAP_STATUS&idle_timeout"
        AppState.httpGet(q, function(data, err) {
            if (err || !data) return
            var st = (data.result && data.result.status) ? data.result.status : (data.status || {})
            if (st.toolhead) {
                if (st.toolhead.max_accel !== undefined && Number(st.toolhead.max_accel) > 0)
                    printerAccel = Number(st.toolhead.max_accel)
                if (st.toolhead.max_velocity !== undefined && Number(st.toolhead.max_velocity) > 0)
                    printerVel = Number(st.toolhead.max_velocity)
            }
            // Prefer live_position (real-time trapq) so motion matches printer accel profile
            var lp = (st.motion_report && st.motion_report.live_position)
                     ? st.motion_report.live_position : null
            var p = (st.toolhead && st.toolhead.position) ? st.toolhead.position : null
            if (lp || p) {
                var src = lp || p
                toolX = Number(src[0]) || 0
                toolY = Number(src[1]) || 0
                toolZ = Number(src[2]) || 0
                if (vizMode === "tilt" || vizMode === "mesh" || vizMode === "home")
                    pushTrail(toolX, toolY)
            }
            var ms = st["gcode_macro NCPSKY_MOTION_STATUS"] || {}
            if (ms.phase !== undefined && ms.phase !== null)
                motionPhase = "" + ms.phase
            if (st.bed_mesh && st.bed_mesh.mesh_max) {
                var mx = Number(st.bed_mesh.mesh_max[0]) || 0
                if (mx > 10) bedRadius = mx
            }

            // Real shaper motion + async completion
            if (vizMode === "shaper") {
                var wx = toolX
                var wy = toolY
                var sample = (shaperPhase === "y") ? wy : wx
                var wave = shaperWave.slice()
                wave.push(sample)
                if (wave.length > 96)
                    wave = wave.slice(wave.length - 96)
                shaperWave = wave
                var ss = st["gcode_macro NCPSKY_SHAPER_STATUS"] || {}
                var prevPhase = shaperPhase
                if (ss.phase !== undefined && ss.phase !== null && ("" + ss.phase).length)
                    shaperPhase = "" + ss.phase
                if (shaperPhase !== prevPhase && (shaperPhase === "x" || shaperPhase === "y"))
                    shaperAxisElapsed = 0
                if (ss.freq_x !== undefined && Number(ss.freq_x) > 1)
                    shaperFreqX = Number(ss.freq_x)
                if (ss.freq_y !== undefined && Number(ss.freq_y) > 1)
                    shaperFreqY = Number(ss.freq_y)

                if ((shaperPhase === "y" || shaperPhase === "done") && shaperCsvGot.indexOf("x") < 0) {
                    shaperCsvGot = shaperCsvGot + "x"
                    fetchShaperCsv("x")
                }
                if (shaperPhase === "done" && shaperCsvGot.indexOf("y") < 0) {
                    shaperCsvGot = shaperCsvGot + "y"
                    fetchShaperCsv("y")
                }

                if (shaperAwait) {
                    var busy = Number(ss.busy)
                    if (ss.busy !== undefined && busy === 1)
                        shaperSeenBusy = true
                    var done = (shaperPhase === "done")
                            || (shaperSeenBusy && ss.busy !== undefined && busy === 0 && stepElapsed > 3)
                    if (done) {
                        stepProgress = 1
                        shaperAwait = false
                        finishShaperStep(runToken)
                        return
                    }
                    if (stepElapsed > 600) {
                        shaperAwait = false
                        finishError("震动补偿超时")
                        return
                    }
                }
            }

            if (noiseMapAwait) {
                var ns = st["gcode_macro NCPSKY_NOISE_MAP_STATUS"] || {}
                if (ns.phase !== undefined && ns.phase !== null && ("" + ns.phase).length)
                    noiseMapPhase = "" + ns.phase
                var nbusy = Number(ns.busy)
                if (ns.busy !== undefined && nbusy === 1)
                    noiseMapSeenBusy = true
                if (stepElapsed > 1200) {
                    noiseMapAwait = false
                    finishError("电机降噪超时")
                    return
                }
                pollNoiseMapJob(runToken)
            }
        })
    }

    Timer {
        id: readyWaitTimer
        interval: 1000
        repeat: true
        running: false
        property int token: 0
        property int left: 0
        property var cb: null
        function tick() {
            if (token !== runToken) {
                stop()
                return
            }
            AppState.httpGet("/printer/info", function(data, err) {
                if (token !== runToken) {
                    stop()
                    return
                }
                var st = ""
                if (!err && data) {
                    var r = data.result || data
                    st = ("" + (r.state || "")).toLowerCase()
                }
                if (st === "ready") {
                    stop()
                    var done = cb
                    cb = null
                    if (done) done(true)
                    return
                }
                left -= 1
                statusDetail = "等待打印机就绪…" + (st ? (" (" + st + ")") : "")
                if (left <= 0) {
                    stop()
                    var fail = cb
                    cb = null
                    if (fail) fail(false)
                }
            })
        }
        onTriggered: tick()
    }

    Timer {
        id: liveTimer
        interval: 80
        repeat: true
        running: false
        onTriggered: {
            stepElapsed += interval / 1000.0
            // soft intra-step progress (unknown duration)
            stepProgress = Math.min(0.95, 1 - Math.exp(-stepElapsed / 25.0))
            if (vizMode === "save")
                stepProgress = Math.min(0.99, stepElapsed / 3.0)
            if (vizMode === "shaper") {
                // Continuous sweep min→max per axis (not a single tone)
                var span = Math.max(1, shaperFreqMax - shaperFreqMin)
                var sweepDur = span / Math.max(0.1, shaperHzPerSec)
                if (shaperPhase === "x" || shaperPhase === "y") {
                    shaperAxisElapsed += interval / 1000.0
                    var t = Math.min(1, shaperAxisElapsed / sweepDur)
                    sweepHz = shaperFreqMin + t * span
                }
                if (shaperPhase === "starting" || shaperPhase === "")
                    stepProgress = Math.min(0.08, stepElapsed / 8.0)
                else if (shaperPhase === "x")
                    stepProgress = 0.08 + 0.42 * Math.min(1, shaperAxisElapsed / Math.max(1, sweepDur + 8))
                else if (shaperPhase === "y")
                    stepProgress = 0.55 + 0.4 * Math.min(1, shaperAxisElapsed / Math.max(1, sweepDur + 8))
                else if (shaperPhase === "done")
                    stepProgress = 1
            }
            if (vizMode === "tmc")
                stepProgress = Math.min(0.95, stepElapsed / 8.0)
            refreshStatusDetail()
            pollLive()
        }
    }

    // —— 配置态 / 查看态 ——
    Column {
        anchors.fill: parent
        anchors.leftMargin: 10
        anchors.rightMargin: 10
        anchors.topMargin: 4
        anchors.bottomMargin: 6
        spacing: 6
        visible: runPhase === "idle" || runPhase === "done" || runPhase === "error"

        Row {
            width: parent.width
            height: 32
            spacing: 8
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: "校准"
                color: Theme.textPrimary
                font.pixelSize: Theme.fontTitle
                font.family: Theme.fontFamily
                font.weight: Theme.fontWeight
            }
            SegButton {
                text: "执行"
                width: 56
                height: 30
                active: page.mainTab === "run"
                enabled: !page.running
                onClicked: page.setMainTab("run")
            }
            SegButton {
                text: "查看"
                width: 56
                height: 30
                active: page.mainTab === "view"
                enabled: !page.running
                onClicked: page.setMainTab("view")
            }
            Item { width: 8; height: 1 }
            SegButton {
                anchors.verticalCenter: parent.verticalCenter
                visible: page.mainTab === "run"
                text: selectedCount() === steps.length ? "清空" : "全选"
                height: 30
                enabled: !running
                onClicked: selectAll(selectedCount() !== steps.length)
            }
            SegButton {
                anchors.verticalCenter: parent.verticalCenter
                visible: page.mainTab === "view"
                text: "刷新"
                height: 30
                onClicked: page.refreshViewData()
            }
        }

        // —— 执行：勾选列表 ——
        // view 页无底栏按钮，把剩余高度全给内容（床网卡片等）
        readonly property int _footerH: page.mainTab === "run" ? (Theme.touchMin - 4 + 6) : 0
        readonly property int _bodyH: Math.max(80, height - 32 - 6 - _footerH)

        ListView {
            id: list
            width: parent.width
            height: parent._bodyH
            clip: true
            visible: page.mainTab === "run"
            model: steps
            spacing: 0
            boundsBehavior: Flickable.StopAtBounds

            delegate: Item {
                width: list.width
                height: 40
                property bool on: modelData.on

                Rectangle {
                    anchors.fill: parent
                    color: rowTouch.pressed ? Theme.bgTilePressed : "transparent"
                }
                Rectangle {
                    id: box
                    anchors.left: parent.left
                    anchors.leftMargin: 2
                    anchors.verticalCenter: parent.verticalCenter
                    width: 22
                    height: 22
                    radius: 4
                    color: on ? Theme.accent : "transparent"
                    border.width: on ? 0 : 1
                    border.color: Theme.line
                    Text {
                        anchors.centerIn: parent
                        visible: on
                        text: "*"
                        color: "#120E1A"
                        font.pixelSize: 13
                        font.family: Theme.fontFamily
                        font.weight: Theme.fontWeight
                    }
                }
                Column {
                    anchors.left: box.right
                    anchors.leftMargin: 10
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 1
                    Text {
                        text: modelData.title
                        color: on ? Theme.textPrimary : Theme.textMute
                        font.pixelSize: Theme.fontBody
                        font.family: Theme.fontFamily
                        font.weight: Theme.fontWeight
                    }
                    Text {
                        text: modelData.detail
                        color: Theme.textMute
                        font.pixelSize: Theme.fontSmall
                    }
                }
                Rectangle {
                    anchors.bottom: parent.bottom
                    width: parent.width
                    height: 1
                    color: Theme.lineSoft
                }
                TouchArea {
                    id: rowTouch
                    anchors.fill: parent
                    enabled: !page.running
                    onClicked: page.toggleStep(index)
                }
            }
        }

        // —— 查看：已应用校准数据 ——
        Column {
            width: parent.width
            height: parent._bodyH
            spacing: 6
            visible: page.mainTab === "view"

            Row {
                id: viewTabs
                width: parent.width
                spacing: 6
                SegButton {
                    text: "震动"
                    width: 64
                    height: 30
                    active: page.viewKind === "shaper"
                    onClicked: page.setViewKind("shaper")
                }
                SegButton {
                    text: "床网"
                    width: 64
                    height: 30
                    active: page.viewKind === "mesh"
                    onClicked: page.setViewKind("mesh")
                }
                SegButton {
                    text: "降噪"
                    width: 64
                    height: 30
                    active: page.viewKind === "tmc"
                    onClicked: page.setViewKind("tmc")
                }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    width: Math.max(40, parent.width - 220)
                    text: page.viewStatus
                    color: Theme.textMute
                    font.pixelSize: Theme.fontSmall
                    elide: Text.ElideRight
                }
            }

            CalibrateViz {
                width: parent.width
                height: Math.max(60, parent.height - viewTabs.height - parent.spacing)
                mode: "view"
                viewKind: page.viewKind
                shaperFreqX: page.shaperFreqX
                shaperFreqY: page.shaperFreqY
                shaperFreqMin: page.shaperFreqMin
                shaperFreqMax: page.shaperFreqMax
                shaperPsdX: page.shaperPsdX
                shaperPsdY: page.shaperPsdY
                shaperTypeX: page.shaperTypeX
                shaperTypeY: page.shaperTypeY
                meshPoints: page.meshPoints
                meshZMin: page.meshZMin
                meshZMax: page.meshZMax
                meshProfile: page.meshProfile
                meshParams: page.meshParams
                tiltInfo: page.tiltInfo
                tmcMotors: page.tmcMotors
                noiseCurve: page.noiseCurve
            }
        }

        Row {
            spacing: 8
            visible: page.mainTab === "run"
            PrimaryButton {
                text: selectedCount() ? ("开始校准 · " + selectedCount() + " 项") : "请先勾选步骤"
                width: 168
                height: Theme.touchMin - 4
                enabled: selectedCount() > 0 && !AppState.printing && !AppState.printPaused && AppState.connected
                onClicked: page.askStart()
            }
            PrimaryButton {
                text: "维护"
                primary: false
                height: Theme.touchMin - 4
                enabled: !AppState.calibrating
                onClicked: AppState.go("settings")
            }
        }
    }

    // —— 执行态：全屏；右侧竖条 Delta 顶满，左侧信息/频谱 ——
    Item {
        anchors.fill: parent
        anchors.margins: 6
        visible: runPhase === "run"

        readonly property int sideW: Math.max(168, Math.floor(width * 0.40))

        Row {
            anchors.fill: parent
            spacing: 6

            // LEFT: steps + detail (+ spectrum when shaper)
            Column {
                width: parent.width - parent.parent.sideW - 6
                height: parent.height
                spacing: 4

                Row {
                    width: parent.width
                    height: 18
                    Text {
                        width: parent.width - 56
                        text: runTitle
                        color: Theme.textPrimary
                        font.pixelSize: Theme.fontTitle
                        font.family: Theme.fontFamily
                        font.weight: Theme.fontWeight
                        elide: Text.ElideRight
                    }
                    Text {
                        width: 52
                        horizontalAlignment: Text.AlignRight
                        text: Math.min(runIndex + 1, runTotal) + "/" + runTotal
                        color: Theme.accent
                        font.pixelSize: Theme.fontBody
                    }
                }

                Item {
                    width: parent.width
                    height: 3
                    Rectangle { anchors.fill: parent; color: Theme.lineSoft; radius: 1 }
                    Rectangle {
                        height: parent.height
                        radius: 1
                        width: {
                            if (runTotal <= 0) return 0
                            return parent.width * ((runIndex + stepProgress) / runTotal)
                        }
                        color: Theme.accent
                        Behavior on width { NumberAnimation { duration: 180 } }
                    }
                }

                Text {
                    width: parent.width
                    height: 36
                    text: page.statusDetail
                    color: Theme.textSecondary
                    font.pixelSize: Theme.fontSmall
                    wrapMode: Text.WordWrap
                    maximumLineCount: 3
                    elide: Text.ElideRight
                }

                CalibrateViz {
                    width: parent.width
                    height: parent.height - 78
                    visible: page.vizMode === "shaper" || page.vizMode === "tmc" || page.vizMode === "save"
                    mode: page.vizMode
                    content: page.vizMode === "shaper" ? "spectrum" : "auto"
                    toolX: page.toolX
                    toolY: page.toolY
                    toolZ: page.toolZ
                    shaperFreqX: page.shaperFreqX
                    shaperFreqY: page.shaperFreqY
                    sweepHz: page.sweepHz
                    shaperFreqMin: page.shaperFreqMin
                    shaperFreqMax: page.shaperFreqMax
                    shaperPsdX: page.shaperPsdX
                    shaperPsdY: page.shaperPsdY
                    shaperWave: page.shaperWave
                    shaperPhase: page.shaperPhase
                    progress: page.stepProgress
                }

                Item {
                    width: parent.width
                    height: (page.vizMode === "shaper" || page.vizMode === "tmc" || page.vizMode === "save")
                            ? 1 : (parent.height - 78)
                    visible: !(page.vizMode === "shaper" || page.vizMode === "tmc" || page.vizMode === "save")
                    Text {
                        anchors.centerIn: parent
                        width: parent.width - 12
                        horizontalAlignment: Text.AlignHCenter
                        wrapMode: Text.WordWrap
                        text: "右侧为机身实时姿态\n探测点将留在热床上"
                        color: Theme.textMute
                        font.pixelSize: Theme.fontSmall
                    }
                }

                Text {
                    width: parent.width
                    text: "校准进行中 · 不可退出"
                    color: Theme.textMute
                    font.pixelSize: Theme.fontSmall
                    horizontalAlignment: Text.AlignHCenter
                }
            }

            // RIGHT: Delta machine — full vertical strip
            CalibrateViz {
                width: parent.parent.sideW
                height: parent.height
                mode: (page.vizMode === "tmc" || page.vizMode === "save") ? "home" : page.vizMode
                content: "delta"
                portraitPanel: true
                vibrate: page.vizMode === "shaper"
                toolX: page.toolX
                toolY: page.toolY
                toolZ: page.toolZ
                bedRadius: page.bedRadius
                deltaRadius: page.deltaRadius
                armLength: page.armLength
                towerAngleA: page.towerAngleA
                towerAngleB: page.towerAngleB
                towerAngleC: page.towerAngleC
                maxAccel: page.printerAccel
                maxVel: page.printerVel
                shaperFreqX: page.shaperFreqX
                shaperFreqY: page.shaperFreqY
                sweepHz: page.sweepHz
                shaperFreqMin: page.shaperFreqMin
                shaperFreqMax: page.shaperFreqMax
                shaperPhase: page.shaperPhase
                progress: page.stepProgress
                probeTrail: page.probeTrail
            }
        }
    }

    // —— 开始前确认（遮罩 MouseArea 在卡片之下）——
    Item {
        anchors.fill: parent
        visible: confirmOpen
        z: 100

        // Dimmer + swallow (declared first = under the card)
        Rectangle {
            anchors.fill: parent
            color: "#CC080A0B"
            MouseArea {
                anchors.fill: parent
                cursorShape: Qt.BlankCursor
                hoverEnabled: false
                preventStealing: true
                onClicked: { /* block background */ }
            }
        }

        Rectangle {
            id: confirmCard
            anchors.centerIn: parent
            width: Math.min(parent.width - 24, 360)
            height: 148
            radius: Theme.radiusLg
            color: Theme.bgElevated
            border.width: 1
            border.color: Theme.line
            // Keep card above dimmer for hit-testing
            z: 1

            Column {
                anchors.fill: parent
                anchors.margins: 14
                spacing: 10

                Text {
                    text: "确认开始校准？"
                    color: Theme.textPrimary
                    font.pixelSize: Theme.fontTitle
                    font.family: Theme.fontFamily
                    font.weight: Theme.fontWeight
                }
                Text {
                    width: parent.width
                    text: page.confirmSummary()
                    color: Theme.textSecondary
                    font.pixelSize: Theme.fontSmall
                    wrapMode: Text.WordWrap
                }
                Item { width: 1; height: 4 }
                Row {
                    spacing: 10
                    anchors.horizontalCenter: parent.horizontalCenter
                    PrimaryButton {
                        text: "取消"
                        primary: false
                        width: 100
                        height: 40
                        onClicked: page.cancelConfirm()
                    }
                    PrimaryButton {
                        text: "开始校准"
                        width: 120
                        height: 40
                        onClicked: page.startRun()
                    }
                }
            }
        }
    }
}
